(()=>{var ax=Object.defineProperty;var lx=(i,e)=>{for(var t in e)ax(i,t,{get:e[t],enumerable:!0})};var Xn={};lx(Xn,{ACESFilmicToneMapping:()=>Jo,AddEquation:()=>Zs,AddOperation:()=>Bf,AdditiveAnimationBlendMode:()=>Ku,AdditiveBlending:()=>wt,AgXToneMapping:()=>$o,AlphaFormat:()=>Zu,AlwaysCompare:()=>Qf,AlwaysDepth:()=>za,AlwaysStencilFunc:()=>qf,AmbientLight:()=>Al,AnimationAction:()=>Ol,AnimationClip:()=>Ys,AnimationLoader:()=>jh,AnimationMixer:()=>uu,AnimationObjectGroup:()=>hu,AnimationUtils:()=>$h,ArcCurve:()=>al,ArrayCamera:()=>Ul,ArrowHelper:()=>Lu,AttachedBindMode:()=>Ih,Audio:()=>Fl,AudioAnalyser:()=>cu,AudioContext:()=>Go,AudioListener:()=>au,AudioLoader:()=>ru,AxesHelper:()=>Nu,BackSide:()=>Ln,BasicDepthPacking:()=>Xf,BasicShadowMap:()=>b0,BatchedMesh:()=>el,BezierInterpolant:()=>Tl,Bone:()=>wo,BooleanKeyframeTrack:()=>Ki,Box2:()=>Hl,Box3:()=>bn,Box3Helper:()=>Iu,BoxGeometry:()=>mi,BoxHelper:()=>Pu,BufferAttribute:()=>bt,BufferGeometry:()=>ke,BufferGeometryLoader:()=>Ll,ByteType:()=>Wu,Cache:()=>Ni,Camera:()=>Cr,CameraHelper:()=>Cu,CanvasTexture:()=>pi,CapsuleGeometry:()=>sl,CatmullRomCurve3:()=>je,CineonToneMapping:()=>Zo,CircleGeometry:()=>oi,ClampToEdgeWrapping:()=>$n,Clock:()=>xu,Color:()=>q,ColorKeyframeTrack:()=>Bo,ColorManagement:()=>Mt,Compatibility:()=>og,CompressedArrayTexture:()=>qh,CompressedCubeTexture:()=>Zh,CompressedTexture:()=>Mr,CompressedTextureLoader:()=>Qh,ConeGeometry:()=>vn,ConstantAlphaFactor:()=>Nf,ConstantColorFactor:()=>Df,Controls:()=>Vo,CubeCamera:()=>Nl,CubeDepthTexture:()=>il,CubeReflectionMapping:()=>ki,CubeRefractionMapping:()=>Ss,CubeTexture:()=>Vs,CubeTextureLoader:()=>eu,CubeUVReflectionMapping:()=>Lr,CubicBezierCurve:()=>Ao,CubicBezierCurve3:()=>ll,CubicInterpolant:()=>El,CullFaceBack:()=>Ou,CullFaceFront:()=>gf,CullFaceFrontBack:()=>M0,CullFaceNone:()=>mf,Curve:()=>ai,CurvePath:()=>hl,CustomBlending:()=>xf,CustomToneMapping:()=>Ko,CylinderGeometry:()=>xn,Cylindrical:()=>vu,Data3DTexture:()=>_r,DataArrayTexture:()=>gr,DataTexture:()=>Un,DataTextureLoader:()=>tu,DataUtils:()=>Fh,DecrementStencilOp:()=>O0,DecrementWrapStencilOp:()=>z0,DefaultLoadingManager:()=>sp,DepthFormat:()=>Ui,DepthStencilFormat:()=>Ts,DepthTexture:()=>gs,DetachedBindMode:()=>Of,DirectionalLight:()=>Ms,DirectionalLightHelper:()=>Au,DiscreteInterpolant:()=>Sl,DodecahedronGeometry:()=>rl,DoubleSide:()=>De,DstAlphaFactor:()=>Rf,DstColorFactor:()=>Cf,DynamicCopyUsage:()=>eg,DynamicDrawUsage:()=>$s,DynamicReadUsage:()=>$0,EdgesGeometry:()=>ol,EllipseCurve:()=>br,EqualCompare:()=>Kf,EqualDepth:()=>Ga,EqualStencilFunc:()=>W0,EquirectangularReflectionMapping:()=>Ks,EquirectangularRefractionMapping:()=>jo,Euler:()=>Gn,EventDispatcher:()=>ri,ExternalTexture:()=>Ro,ExtrudeGeometry:()=>en,FileLoader:()=>Si,Float16BufferAttribute:()=>Gh,Float32BufferAttribute:()=>_e,FloatType:()=>kn,Fog:()=>Ja,FogExp2:()=>Za,FramebufferTexture:()=>Yh,FrontSide:()=>zi,Frustum:()=>Ji,FrustumArray:()=>Qa,GLBufferAttribute:()=>gu,GLSL1:()=>ng,GLSL3:()=>$u,GreaterCompare:()=>$f,GreaterDepth:()=>Wa,GreaterEqualCompare:()=>wc,GreaterEqualDepth:()=>Va,GreaterEqualStencilFunc:()=>Z0,GreaterStencilFunc:()=>Y0,GridHelper:()=>wu,Group:()=>ce,HTMLTexture:()=>Jh,HalfFloatType:()=>yn,HemisphereLight:()=>Rr,HemisphereLightHelper:()=>Tu,IcosahedronGeometry:()=>Tn,ImageBitmapLoader:()=>su,ImageLoader:()=>qs,ImageUtils:()=>qa,IncrementStencilOp:()=>B0,IncrementWrapStencilOp:()=>H0,InstancedBufferAttribute:()=>Zi,InstancedBufferGeometry:()=>Dl,InstancedInterleavedBuffer:()=>mu,InstancedMesh:()=>En,Int16BufferAttribute:()=>zh,Int32BufferAttribute:()=>kh,Int8BufferAttribute:()=>Bh,IntType:()=>Gl,InterleavedBuffer:()=>Gs,InterleavedBufferAttribute:()=>fs,Interpolant:()=>ys,InterpolateBezier:()=>Dh,InterpolateDiscrete:()=>_o,InterpolateLinear:()=>Ya,InterpolateSmooth:()=>La,InterpolationSamplingMode:()=>rg,InterpolationSamplingType:()=>sg,InvertStencilOp:()=>k0,KeepStencilOp:()=>Na,KeyframeTrack:()=>jn,LOD:()=>Ka,LatheGeometry:()=>Oi,Layers:()=>xr,LessCompare:()=>Jf,LessDepth:()=>ka,LessEqualCompare:()=>Tc,LessEqualDepth:()=>pr,LessEqualStencilFunc:()=>X0,LessStencilFunc:()=>V0,Light:()=>Hi,LightProbe:()=>Pl,LightShadow:()=>Ar,Line:()=>Bi,Line3:()=>Mu,LineBasicMaterial:()=>tn,LineCurve:()=>Co,LineCurve3:()=>cl,LineDashedMaterial:()=>bl,LineLoop:()=>tl,LineSegments:()=>Sn,LinearFilter:()=>Xt,LinearInterpolant:()=>Fo,LinearMipMapLinearFilter:()=>R0,LinearMipMapNearestFilter:()=>w0,LinearMipmapLinearFilter:()=>Gi,LinearMipmapNearestFilter:()=>Qo,LinearSRGBColorSpace:()=>vo,LinearToneMapping:()=>Yo,LinearTransfer:()=>yo,Loader:()=>Fn,LoaderUtils:()=>ko,LoadingManager:()=>Ho,LoopOnce:()=>Hf,LoopPingPong:()=>kf,LoopRepeat:()=>zf,MOUSE:()=>bs,Material:()=>_n,MaterialBlending:()=>E0,MaterialLoader:()=>Il,MathUtils:()=>Br,Matrix2:()=>yu,Matrix3:()=>ht,Matrix4:()=>nt,MaxEquation:()=>bf,Mesh:()=>W,MeshBasicMaterial:()=>Qe,MeshDepthMaterial:()=>No,MeshDistanceMaterial:()=>Uo,MeshLambertMaterial:()=>yl,MeshMatcapMaterial:()=>Ml,MeshNormalMaterial:()=>vl,MeshPhongMaterial:()=>xl,MeshPhysicalMaterial:()=>hn,MeshStandardMaterial:()=>Xs,MeshToonMaterial:()=>Ht,MinEquation:()=>Mf,MirroredRepeatWrapping:()=>go,MixOperation:()=>Ff,MultiplyBlending:()=>zu,MultiplyOperation:()=>Xo,NearestFilter:()=>jt,NearestMipMapLinearFilter:()=>T0,NearestMipMapNearestFilter:()=>S0,NearestMipmapLinearFilter:()=>Nr,NearestMipmapNearestFilter:()=>Vu,NeutralToneMapping:()=>Js,NeverCompare:()=>Zf,NeverDepth:()=>Ha,NeverStencilFunc:()=>G0,NoBlending:()=>gi,NoColorSpace:()=>es,NoNormalPacking:()=>D0,NoToneMapping:()=>Ti,NormalAnimationBlendMode:()=>Sc,NormalBlending:()=>Vn,NormalGAPacking:()=>N0,NormalRGPacking:()=>L0,NotEqualCompare:()=>jf,NotEqualDepth:()=>Xa,NotEqualStencilFunc:()=>q0,NumberKeyframeTrack:()=>Tr,Object3D:()=>_t,ObjectLoader:()=>iu,ObjectSpaceNormalMap:()=>Yf,OctahedronGeometry:()=>xs,OneFactor:()=>Sf,OneMinusConstantAlphaFactor:()=>Uf,OneMinusConstantColorFactor:()=>Lf,OneMinusDstAlphaFactor:()=>Af,OneMinusDstColorFactor:()=>Pf,OneMinusSrcAlphaFactor:()=>Gu,OneMinusSrcColorFactor:()=>wf,OrthographicCamera:()=>ji,PCFShadowMap:()=>Wo,PCFSoftShadowMap:()=>_f,PMREMGenerator:()=>zr,Path:()=>li,PerspectiveCamera:()=>on,Plane:()=>ii,PlaneGeometry:()=>cn,PlaneHelper:()=>Du,PointLight:()=>Yt,PointLightHelper:()=>Su,Points:()=>ms,PointsMaterial:()=>ps,PolarGridHelper:()=>Ru,PolyhedronGeometry:()=>_s,PositionalAudio:()=>lu,PropertyBinding:()=>Nt,PropertyMixer:()=>Bl,QuadraticBezierCurve:()=>Po,QuadraticBezierCurve3:()=>Io,Quaternion:()=>$t,QuaternionKeyframeTrack:()=>wr,QuaternionLinearInterpolant:()=>wl,R11_EAC_Format:()=>tc,RED_GREEN_RGTC2_Format:()=>oa,RED_RGTC1_Format:()=>Mc,REVISION:()=>zl,RG11_EAC_Format:()=>ra,RGBADepthPacking:()=>C0,RGBAFormat:()=>In,RGBAIntegerFormat:()=>ql,RGBA_ASTC_10x10_Format:()=>mc,RGBA_ASTC_10x5_Format:()=>dc,RGBA_ASTC_10x6_Format:()=>fc,RGBA_ASTC_10x8_Format:()=>pc,RGBA_ASTC_12x10_Format:()=>gc,RGBA_ASTC_12x12_Format:()=>_c,RGBA_ASTC_4x4_Format:()=>sc,RGBA_ASTC_5x4_Format:()=>rc,RGBA_ASTC_5x5_Format:()=>oc,RGBA_ASTC_6x5_Format:()=>ac,RGBA_ASTC_6x6_Format:()=>lc,RGBA_ASTC_8x5_Format:()=>cc,RGBA_ASTC_8x6_Format:()=>hc,RGBA_ASTC_8x8_Format:()=>uc,RGBA_BPTC_Format:()=>xc,RGBA_ETC2_EAC_Format:()=>ec,RGBA_PVRTC_2BPPV1_Format:()=>$l,RGBA_PVRTC_4BPPV1_Format:()=>Kl,RGBA_S3TC_DXT1_Format:()=>na,RGBA_S3TC_DXT3_Format:()=>ia,RGBA_S3TC_DXT5_Format:()=>sa,RGBDepthPacking:()=>P0,RGBFormat:()=>Ju,RGBIntegerFormat:()=>A0,RGB_BPTC_SIGNED_Format:()=>vc,RGB_BPTC_UNSIGNED_Format:()=>yc,RGB_ETC1_Format:()=>jl,RGB_ETC2_Format:()=>Ql,RGB_PVRTC_2BPPV1_Format:()=>Jl,RGB_PVRTC_4BPPV1_Format:()=>Zl,RGB_S3TC_DXT1_Format:()=>ta,RGDepthPacking:()=>I0,RGFormat:()=>ws,RGIntegerFormat:()=>Yl,RawShaderMaterial:()=>Ws,Ray:()=>Fi,Raycaster:()=>_u,RectAreaLight:()=>Cl,RedFormat:()=>Xl,RedIntegerFormat:()=>ea,ReinhardToneMapping:()=>qo,RenderObjectRefreshType:()=>ag,RenderTarget:()=>Eo,RenderTarget3D:()=>du,RepeatWrapping:()=>Hs,ReplaceStencilOp:()=>F0,ReverseSubtractEquation:()=>yf,RingGeometry:()=>vs,SIGNED_R11_EAC_Format:()=>nc,SIGNED_RED_GREEN_RGTC2_Format:()=>Ec,SIGNED_RED_RGTC1_Format:()=>bc,SIGNED_RG11_EAC_Format:()=>ic,SRGBColorSpace:()=>Wt,SRGBTransfer:()=>Ct,Scene:()=>yr,ShaderChunk:()=>vt,ShaderLib:()=>Vi,ShaderMaterial:()=>xt,ShadowMaterial:()=>_l,Shape:()=>kt,ShapeGeometry:()=>Sr,ShapePath:()=>Uu,ShapeUtils:()=>Ei,ShortType:()=>Xu,Skeleton:()=>ja,SkeletonHelper:()=>Eu,SkinnedMesh:()=>$a,Source:()=>Lh,Sphere:()=>gn,SphereGeometry:()=>Rt,Spherical:()=>Ir,SphericalHarmonics3:()=>zo,SplineCurve:()=>Do,SpotLight:()=>Rl,SpotLightHelper:()=>bu,Sprite:()=>Dn,SpriteMaterial:()=>ln,SrcAlphaFactor:()=>ku,SrcAlphaSaturateFactor:()=>If,SrcColorFactor:()=>Tf,StaticCopyUsage:()=>Q0,StaticDrawUsage:()=>Rc,StaticReadUsage:()=>K0,StereoCamera:()=>ou,StreamCopyUsage:()=>tg,StreamDrawUsage:()=>J0,StreamReadUsage:()=>j0,StringKeyframeTrack:()=>$i,SubtractEquation:()=>vf,SubtractiveBlending:()=>Hu,TOUCH:()=>Es,TangentSpaceNormalMap:()=>Qi,TetrahedronGeometry:()=>pl,Texture:()=>an,TextureLoader:()=>nu,TextureSource:()=>bi,TextureUtils:()=>Fu,Timer:()=>Pr,TimestampQuery:()=>ig,TorusGeometry:()=>dt,TorusKnotGeometry:()=>ml,Triangle:()=>Li,TriangleFanDrawMode:()=>Wf,TriangleStripDrawMode:()=>Vf,TrianglesDrawMode:()=>Gf,TubeGeometry:()=>et,UVMapping:()=>kl,Uint16BufferAttribute:()=>So,Uint32BufferAttribute:()=>To,Uint8BufferAttribute:()=>Oh,Uint8ClampedBufferAttribute:()=>Hh,Uniform:()=>fu,UniformsGroup:()=>pu,UniformsLib:()=>Ae,UniformsUtils:()=>wi,UnsignedByteType:()=>Qn,UnsignedInt101111Type:()=>qu,UnsignedInt248Type:()=>Fr,UnsignedInt5999Type:()=>Yu,UnsignedIntType:()=>_i,UnsignedShort4444Type:()=>Vl,UnsignedShort5551Type:()=>Wl,UnsignedShortType:()=>Ur,VSMShadowMap:()=>Dr,Vector2:()=>J,Vector3:()=>A,Vector4:()=>Ut,VectorKeyframeTrack:()=>Oo,VideoFrameTexture:()=>Xh,VideoTexture:()=>nl,WebGL3DRenderTarget:()=>Uh,WebGLArrayRenderTarget:()=>Nh,WebGLCoordinateSystem:()=>si,WebGLCubeRenderTarget:()=>Ic,WebGLRenderTarget:()=>Qt,WebGLRenderer:()=>Dc,WebGLUtils:()=>$g,WebGPUCoordinateSystem:()=>zs,WebXRController:()=>vr,WireframeGeometry:()=>gl,WrapAroundEnding:()=>xo,ZeroCurvatureEnding:()=>Bs,ZeroFactor:()=>Ef,ZeroSlopeEnding:()=>Os,ZeroStencilOp:()=>U0,createCanvasElement:()=>ep,error:()=>qe,getConsoleFunction:()=>hg,log:()=>bo,setConsoleFunction:()=>cg,warn:()=>be,warnOnce:()=>qi});var zl="186",bs={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},Es={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},mf=0,Ou=1,gf=2,M0=3,b0=0,Wo=1,_f=2,Dr=3,zi=0,Ln=1,De=2,gi=0,Vn=1,wt=2,Hu=3,zu=4,xf=5,E0=6,Zs=100,vf=101,yf=102,Mf=103,bf=104,Ef=200,Sf=201,Tf=202,wf=203,ku=204,Gu=205,Rf=206,Af=207,Cf=208,Pf=209,If=210,Df=211,Lf=212,Nf=213,Uf=214,Ha=0,za=1,ka=2,pr=3,Ga=4,Va=5,Wa=6,Xa=7,Xo=0,Ff=1,Bf=2,Ti=0,Yo=1,qo=2,Zo=3,Jo=4,Ko=5,$o=6,Js=7,Ih="attached",Of="detached",kl=300,ki=301,Ss=302,Ks=303,jo=304,Lr=306,Hs=1e3,$n=1001,go=1002,jt=1003,Vu=1004,S0=1004,Nr=1005,T0=1005,Xt=1006,Qo=1007,w0=1007,Gi=1008,R0=1008,Qn=1009,Wu=1010,Xu=1011,Ur=1012,Gl=1013,_i=1014,kn=1015,yn=1016,Vl=1017,Wl=1018,Fr=1020,Yu=35902,qu=35899,Zu=1021,Ju=1022,In=1023,Ui=1026,Ts=1027,Xl=1028,ea=1029,ws=1030,Yl=1031,A0=1032,ql=1033,ta=33776,na=33777,ia=33778,sa=33779,Zl=35840,Jl=35841,Kl=35842,$l=35843,jl=36196,Ql=37492,ec=37496,tc=37488,nc=37489,ra=37490,ic=37491,sc=37808,rc=37809,oc=37810,ac=37811,lc=37812,cc=37813,hc=37814,uc=37815,dc=37816,fc=37817,pc=37818,mc=37819,gc=37820,_c=37821,xc=36492,vc=36494,yc=36495,Mc=36283,bc=36284,oa=36285,Ec=36286,Hf=2200,zf=2201,kf=2202,_o=2300,Ya=2301,La=2302,Dh=2303,Bs=2400,Os=2401,xo=2402,Sc=2500,Ku=2501,Gf=0,Vf=1,Wf=2,Xf=3200,C0=3201,P0=3202,I0=3203,Qi=0,Yf=1,es="",Wt="srgb",vo="srgb-linear",yo="linear",Ct="srgb",D0="",L0="rg",N0="ga",U0=0,Na=7680,F0=7681,B0=7682,O0=7683,H0=34055,z0=34056,k0=5386,G0=512,V0=513,W0=514,X0=515,Y0=516,q0=517,Z0=518,qf=519,Zf=512,Jf=513,Kf=514,Tc=515,$f=516,jf=517,wc=518,Qf=519,Rc=35044,$s=35048,J0=35040,K0=35045,$0=35049,j0=35041,Q0=35046,eg=35050,tg=35042,ng="100",$u="300 es",si=2e3,zs=2001,ig={COMPUTE:"compute",RENDER:"render"},sg={PERSPECTIVE:"perspective",LINEAR:"linear",FLAT:"flat"},rg={NORMAL:"normal",CENTROID:"centroid",SAMPLE:"sample",FIRST:"first",EITHER:"either"},og={TEXTURE_COMPARE:"depthTextureCompare"},ag={NONE:0,SHARED:1,FULL:2};function cx(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}var hx={Int8Array,Uint8Array,Uint8ClampedArray,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array};function po(i,e){return new hx[i](e)}function lg(i){return ArrayBuffer.isView(i)&&!(i instanceof DataView)}function Mo(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function ep(){let i=Mo("canvas");return i.style.display="block",i}var hm={},ks=null;function cg(i){ks=i}function hg(){return ks}function bo(...i){let e="THREE."+i.shift();ks?ks("log",e,...i):console.log(e,...i)}function ug(i){let e=i[0];if(typeof e=="string"&&e.startsWith("TSL:")){let t=i[1];t&&t.isStackTrace?i[0]+=" "+t.getLocation():i[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return i}function be(...i){i=ug(i);let e="THREE."+i.shift();if(ks)ks("warn",e,...i);else{let t=i[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...i)}}function qe(...i){i=ug(i);let e="THREE."+i.shift();if(ks)ks("error",e,...i);else{let t=i[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...i)}}function qi(...i){let e=i.join(" ");e in hm||(hm[e]=!0,be(...i))}function dg(i,e,t){return new Promise(function(n,s){function r(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:s();break;case i.TIMEOUT_EXPIRED:setTimeout(r,t);break;default:n()}}setTimeout(r,t)})}var fg={[Ha]:za,[ka]:Wa,[Ga]:Xa,[pr]:Va,[za]:Ha,[Wa]:ka,[Xa]:Ga,[Va]:pr},ri=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){let n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){let n=this._listeners;if(n===void 0)return;let s=n[e];if(s!==void 0){let r=s.indexOf(t);r!==-1&&s.splice(r,1)}}dispatchEvent(e){let t=this._listeners;if(t===void 0)return;let n=t[e.type];if(n!==void 0){e.target=this;let s=n.slice(0);for(let r=0,o=s.length;r<o;r++)s[r].call(this,e);e.target=null}}},On=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],um=1234567,fr=Math.PI/180,mr=180/Math.PI;function fi(){let i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(On[i&255]+On[i>>8&255]+On[i>>16&255]+On[i>>24&255]+"-"+On[e&255]+On[e>>8&255]+"-"+On[e>>16&15|64]+On[e>>24&255]+"-"+On[t&63|128]+On[t>>8&255]+"-"+On[t>>16&255]+On[t>>24&255]+On[n&255]+On[n>>8&255]+On[n>>16&255]+On[n>>24&255]).toLowerCase()}function at(i,e,t){return Math.max(e,Math.min(t,i))}function tp(i,e){return(i%e+e)%e}function ux(i,e,t,n,s){return n+(i-e)*(s-n)/(t-e)}function dx(i,e,t){return i!==e?(t-i)/(e-i):0}function Ua(i,e,t){return(1-t)*i+t*e}function fx(i,e,t,n){return Ua(i,e,1-Math.exp(-t*n))}function px(i,e=1){return e-Math.abs(tp(i,e*2)-e)}function mx(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*(3-2*i))}function gx(i,e,t){return i<=e?0:i>=t?1:(i=(i-e)/(t-e),i*i*i*(i*(i*6-15)+10))}function _x(i,e){return i+Math.floor(Math.random()*(e-i+1))}function xx(i,e){return i+Math.random()*(e-i)}function vx(i){return i*(.5-Math.random())}function yx(i){i!==void 0&&(um=i);let e=um+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function Mx(i){return i*fr}function bx(i){return i*mr}function Ex(i){return i>0&&Number.isInteger(i)&&2**Math.round(Math.log2(i))===i}function Sx(i){return Math.pow(2,Math.ceil(Math.log(i)/Math.LN2))}function Tx(i){return Math.pow(2,Math.floor(Math.log(i)/Math.LN2))}function wx(i,e,t,n,s){let r=Math.cos,o=Math.sin,a=r(t/2),l=o(t/2),c=r((e+n)/2),h=o((e+n)/2),u=r((e-n)/2),d=o((e-n)/2),f=r((n-e)/2),p=o((n-e)/2);switch(s){case"XYX":i.set(a*h,l*u,l*d,a*c);break;case"YZY":i.set(l*d,a*h,l*u,a*c);break;case"ZXZ":i.set(l*u,l*d,a*h,a*c);break;case"XZX":i.set(a*h,l*p,l*f,a*c);break;case"YXY":i.set(l*f,a*h,l*p,a*c);break;case"ZYZ":i.set(l*p,l*f,a*h,a*c);break;default:be("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+s)}}function Kn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:case Uint8ClampedArray:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function gt(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}var Br={DEG2RAD:fr,RAD2DEG:mr,generateUUID:fi,clamp:at,euclideanModulo:tp,mapLinear:ux,inverseLerp:dx,lerp:Ua,damp:fx,pingpong:px,smoothstep:mx,smootherstep:gx,randInt:_x,randFloat:xx,randFloatSpread:vx,seededRandom:yx,degToRad:Mx,radToDeg:bx,isPowerOfTwo:Ex,ceilPowerOfTwo:Sx,floorPowerOfTwo:Tx,setQuaternionFromProperEuler:wx,normalize:gt,denormalize:Kn},ap=class ap{constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6],this.y=s[1]*t+s[4]*n+s[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=at(this.x,e.x,t.x),this.y=at(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=at(this.x,e,t),this.y=at(this.y,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(at(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(at(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),s=Math.sin(t),r=this.x-e.x,o=this.y-e.y;return this.x=r*n-o*s+e.x,this.y=r*s+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};ap.prototype.isVector2=!0;var J=ap,$t=class{constructor(e=0,t=0,n=0,s=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=s}static slerpFlat(e,t,n,s,r,o,a){let l=n[s+0],c=n[s+1],h=n[s+2],u=n[s+3],d=r[o+0],f=r[o+1],p=r[o+2],_=r[o+3];if(u!==_||l!==d||c!==f||h!==p){let g=l*d+c*f+h*p+u*_;g<0&&(d=-d,f=-f,p=-p,_=-_,g=-g);let m=1-a;if(g<.9995){let v=Math.acos(g),E=Math.sin(v);m=Math.sin(m*v)/E,a=Math.sin(a*v)/E,l=l*m+d*a,c=c*m+f*a,h=h*m+p*a,u=u*m+_*a}else{l=l*m+d*a,c=c*m+f*a,h=h*m+p*a,u=u*m+_*a;let v=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=v,c*=v,h*=v,u*=v}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,s,r,o){let a=n[s],l=n[s+1],c=n[s+2],h=n[s+3],u=r[o],d=r[o+1],f=r[o+2],p=r[o+3];return e[t]=a*p+h*u+l*f-c*d,e[t+1]=l*p+h*d+c*u-a*f,e[t+2]=c*p+h*f+a*d-l*u,e[t+3]=h*p-a*u-l*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,s){return this._x=e,this._y=t,this._z=n,this._w=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,s=e._y,r=e._z,o=e._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(s/2),u=a(r/2),d=l(n/2),f=l(s/2),p=l(r/2);switch(o){case"XYZ":this._x=d*h*u+c*f*p,this._y=c*f*u-d*h*p,this._z=c*h*p+d*f*u,this._w=c*h*u-d*f*p;break;case"YXZ":this._x=d*h*u+c*f*p,this._y=c*f*u-d*h*p,this._z=c*h*p-d*f*u,this._w=c*h*u+d*f*p;break;case"ZXY":this._x=d*h*u-c*f*p,this._y=c*f*u+d*h*p,this._z=c*h*p+d*f*u,this._w=c*h*u-d*f*p;break;case"ZYX":this._x=d*h*u-c*f*p,this._y=c*f*u+d*h*p,this._z=c*h*p-d*f*u,this._w=c*h*u+d*f*p;break;case"YZX":this._x=d*h*u+c*f*p,this._y=c*f*u+d*h*p,this._z=c*h*p-d*f*u,this._w=c*h*u-d*f*p;break;case"XZY":this._x=d*h*u-c*f*p,this._y=c*f*u-d*h*p,this._z=c*h*p+d*f*u,this._w=c*h*u+d*f*p;break;default:be("Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,s=Math.sin(n);return this._x=e.x*s,this._y=e.y*s,this._z=e.z*s,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],s=t[4],r=t[8],o=t[1],a=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=n+a+u;if(d>0){let f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(r-c)*f,this._z=(o-s)*f}else if(n>a&&n>u){let f=2*Math.sqrt(1+n-a-u);this._w=(h-l)/f,this._x=.25*f,this._y=(s+o)/f,this._z=(r+c)/f}else if(a>u){let f=2*Math.sqrt(1+a-n-u);this._w=(r-c)/f,this._x=(s+o)/f,this._y=.25*f,this._z=(l+h)/f}else{let f=2*Math.sqrt(1+u-n-a);this._w=(o-s)/f,this._x=(r+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(at(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let s=Math.min(1,t/n);return this.slerp(e,s),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,s=e._y,r=e._z,o=e._w,a=t._x,l=t._y,c=t._z,h=t._w;return this._x=n*h+o*a+s*c-r*l,this._y=s*h+o*l+r*a-n*c,this._z=r*h+o*c+n*l-s*a,this._w=o*h-n*a-s*l-r*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,s=e._y,r=e._z,o=e._w,a=this.dot(e);a<0&&(n=-n,s=-s,r=-r,o=-o,a=-a);let l=1-t;if(a<.9995){let c=Math.acos(a),h=Math.sin(c);l=Math.sin(l*c)/h,t=Math.sin(t*c)/h,this._x=this._x*l+n*t,this._y=this._y*l+s*t,this._z=this._z*l+r*t,this._w=this._w*l+o*t,this._onChangeCallback()}else this._x=this._x*l+n*t,this._y=this._y*l+s*t,this._z=this._z*l+r*t,this._w=this._w*l+o*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),s=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(s*Math.sin(e),s*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},lp=class lp{constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(dm.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(dm.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6]*s,this.y=r[1]*t+r[4]*n+r[7]*s,this.z=r[2]*t+r[5]*n+r[8]*s,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,s=this.z,r=e.elements,o=1/(r[3]*t+r[7]*n+r[11]*s+r[15]);return this.x=(r[0]*t+r[4]*n+r[8]*s+r[12])*o,this.y=(r[1]*t+r[5]*n+r[9]*s+r[13])*o,this.z=(r[2]*t+r[6]*n+r[10]*s+r[14])*o,this}applyQuaternion(e){let t=this.x,n=this.y,s=this.z,r=e.x,o=e.y,a=e.z,l=e.w,c=2*(o*s-a*n),h=2*(a*t-r*s),u=2*(r*n-o*t);return this.x=t+l*c+o*u-a*h,this.y=n+l*h+a*c-r*u,this.z=s+l*u+r*h-o*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,s=this.z,r=e.elements;return this.x=r[0]*t+r[4]*n+r[8]*s,this.y=r[1]*t+r[5]*n+r[9]*s,this.z=r[2]*t+r[6]*n+r[10]*s,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=at(this.x,e.x,t.x),this.y=at(this.y,e.y,t.y),this.z=at(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=at(this.x,e,t),this.y=at(this.y,e,t),this.z=at(this.z,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(at(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,s=e.y,r=e.z,o=t.x,a=t.y,l=t.z;return this.x=s*l-r*a,this.y=r*o-n*l,this.z=n*a-s*o,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return yd.copy(this).projectOnVector(e),this.sub(yd)}reflect(e){return this.sub(yd.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(at(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,s=this.z-e.z;return t*t+n*n+s*s}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let s=Math.sin(t)*e;return this.x=s*Math.sin(n),this.y=Math.cos(t)*e,this.z=s*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),s=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=s,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};lp.prototype.isVector3=!0;var A=lp,yd=new A,dm=new $t,cp=class cp{constructor(e,t,n,s,r,o,a,l,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c)}set(e,t,n,s,r,o,a,l,c){let h=this.elements;return h[0]=e,h[1]=s,h[2]=a,h[3]=t,h[4]=r,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],p=n[8],_=s[0],g=s[3],m=s[6],v=s[1],E=s[4],y=s[7],w=s[2],M=s[5],T=s[8];return r[0]=o*_+a*v+l*w,r[3]=o*g+a*E+l*M,r[6]=o*m+a*y+l*T,r[1]=c*_+h*v+u*w,r[4]=c*g+h*E+u*M,r[7]=c*m+h*y+u*T,r[2]=d*_+f*v+p*w,r[5]=d*g+f*E+p*M,r[8]=d*m+f*y+p*T,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8];return t*o*h-t*a*c-n*r*h+n*a*l+s*r*c-s*o*l}invert(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=h*o-a*c,d=a*l-h*r,f=c*r-o*l,p=t*u+n*d+s*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let _=1/p;return e[0]=u*_,e[1]=(s*c-h*n)*_,e[2]=(a*n-s*o)*_,e[3]=d*_,e[4]=(h*t-s*l)*_,e[5]=(s*r-a*t)*_,e[6]=f*_,e[7]=(n*l-c*t)*_,e[8]=(o*t-n*r)*_,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,s,r,o,a){let l=Math.cos(r),c=Math.sin(r);return this.set(n*l,n*c,-n*(l*o+c*a)+o+e,-s*c,s*l,-s*(-c*o+l*a)+a+t,0,0,1),this}scale(e,t){return qi("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(Md.makeScale(e,t)),this}rotate(e){return qi("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(Md.makeRotation(-e)),this}translate(e,t){return qi("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(Md.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let s=0;s<9;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}};cp.prototype.isMatrix3=!0;var ht=cp,Md=new ht,fm=new ht().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),pm=new ht().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Rx(){let i={enabled:!0,workingColorSpace:vo,spaces:{},convert:function(s,r,o){return this.enabled===!1||r===o||!r||!o||(this.spaces[r].transfer===Ct&&(s.r=ds(s.r),s.g=ds(s.g),s.b=ds(s.b)),this.spaces[r].primaries!==this.spaces[o].primaries&&(s.applyMatrix3(this.spaces[r].toXYZ),s.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===Ct&&(s.r=mo(s.r),s.g=mo(s.g),s.b=mo(s.b))),s},workingToColorSpace:function(s,r){return this.convert(s,this.workingColorSpace,r)},colorSpaceToWorking:function(s,r){return this.convert(s,r,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===es?yo:this.spaces[s].transfer},getToneMappingMode:function(s){return this.spaces[s].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(s,r=this.workingColorSpace){return s.fromArray(this.spaces[r].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,r,o){return s.copy(this.spaces[r].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(s,r){return qi("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),i.workingToColorSpace(s,r)},toWorkingColorSpace:function(s,r){return qi("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),i.colorSpaceToWorking(s,r)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return i.define({[vo]:{primaries:e,whitePoint:n,transfer:yo,toXYZ:fm,fromXYZ:pm,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Wt},outputColorSpaceConfig:{drawingBufferColorSpace:Wt}},[Wt]:{primaries:e,whitePoint:n,transfer:Ct,toXYZ:fm,fromXYZ:pm,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Wt}}}),i}var Mt=Rx();function ds(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function mo(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}var qr,qa=class{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{qr===void 0&&(qr=Mo("canvas")),qr.width=e.width,qr.height=e.height;let s=qr.getContext("2d");e instanceof ImageData?s.putImageData(e,0,0):s.drawImage(e,0,0,e.width,e.height),n=qr}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=Mo("canvas");t.width=e.width,t.height=e.height;let n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);let s=n.getImageData(0,0,e.width,e.height),r=s.data;for(let o=0;o<r.length;o++)r[o]=ds(r[o]/255)*255;return n.putImageData(s,0,0),t}else if(e.data){let t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(ds(t[n]/255)*255):t[n]=ds(t[n]);return{data:t,width:e.width,height:e.height}}else return be("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},Ax=0,bi=class{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Ax++}),this.uuid=fi(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){let t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:""},s=this.data;if(s!==null){let r;if(Array.isArray(s)){r=[];for(let o=0,a=s.length;o<a;o++)s[o].isDataTexture?r.push(bd(s[o].image)):r.push(bd(s[o]))}else r=bd(s);n.url=r}return t||(e.images[this.uuid]=n),n}};function bd(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?qa.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(be("Texture: Unable to serialize Texture."),{})}var Lh=class extends bi{constructor(e=null){qi('Source: "Source" has been renamed to "TextureSource". Please update your code to use "THREE.TextureSource" instead.'),super(e),this.isSource=!0}},Cx=0,Ed=new A,an=class i extends ri{constructor(e=i.DEFAULT_IMAGE,t=i.DEFAULT_MAPPING,n=$n,s=$n,r=Xt,o=Gi,a=In,l=Qn,c=i.DEFAULT_ANISOTROPY,h=es){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Cx++}),this.uuid=fi(),this.name="",this.source=new bi(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=s,this.magFilter=r,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new J(0,0),this.repeat=new J(1,1),this.center=new J(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ht,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Ed).x}get height(){return this.source.getSize(Ed).y}get depth(){return this.source.getSize(Ed).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(let t in e){let n=e[t];if(n===void 0){be(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}let s=this[t];if(s===void 0){be(`Texture.setValues(): property '${t}' does not exist.`);continue}s&&n&&s.isVector2&&n.isVector2||s&&n&&s.isVector3&&n.isVector3||s&&n&&s.isMatrix3&&n.isMatrix3?s.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==kl)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Hs:e.x=e.x-Math.floor(e.x);break;case $n:e.x=e.x<0?0:1;break;case go:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Hs:e.y=e.y-Math.floor(e.y);break;case $n:e.y=e.y<0?0:1;break;case go:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};an.DEFAULT_IMAGE=null;an.DEFAULT_MAPPING=kl;an.DEFAULT_ANISOTROPY=1;var hp=class hp{constructor(e=0,t=0,n=0,s=1){this.x=e,this.y=t,this.z=n,this.w=s}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,s){return this.x=e,this.y=t,this.z=n,this.w=s,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,s=this.z,r=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*s+o[12]*r,this.y=o[1]*t+o[5]*n+o[9]*s+o[13]*r,this.z=o[2]*t+o[6]*n+o[10]*s+o[14]*r,this.w=o[3]*t+o[7]*n+o[11]*s+o[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,s,r,l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],p=l[9],_=l[2],g=l[6],m=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-_)<.01&&Math.abs(p-g)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+_)<.1&&Math.abs(p+g)<.1&&Math.abs(c+f+m-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let E=(c+1)/2,y=(f+1)/2,w=(m+1)/2,M=(h+d)/4,T=(u+_)/4,x=(p+g)/4;return E>y&&E>w?E<.01?(n=0,s=.707106781,r=.707106781):(n=Math.sqrt(E),s=M/n,r=T/n):y>w?y<.01?(n=.707106781,s=0,r=.707106781):(s=Math.sqrt(y),n=M/s,r=x/s):w<.01?(n=.707106781,s=.707106781,r=0):(r=Math.sqrt(w),n=T/r,s=x/r),this.set(n,s,r,t),this}let v=Math.sqrt((g-p)*(g-p)+(u-_)*(u-_)+(d-h)*(d-h));return Math.abs(v)<.001&&(v=1),this.x=(g-p)/v,this.y=(u-_)/v,this.z=(d-h)/v,this.w=Math.acos((c+f+m-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=at(this.x,e.x,t.x),this.y=at(this.y,e.y,t.y),this.z=at(this.z,e.z,t.z),this.w=at(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=at(this.x,e,t),this.y=at(this.y,e,t),this.z=at(this.z,e,t),this.w=at(this.w,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(at(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};hp.prototype.isVector4=!0;var Ut=hp,Eo=class extends ri{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Xt,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new Ut(0,0,e,t),this.scissorTest=!1,this.viewport=new Ut(0,0,e,t),this.textures=[];let s={width:e,height:t,depth:n.depth},r=new an(s),o=n.count;for(let a=0;a<o;a++)this.textures[a]=r.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){let t={minFilter:Xt,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let n=0;n<this.textures.length;n++)this.textures[n].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let s=0,r=this.textures.length;s<r;s++)this.textures[s].image.width=e,this.textures[s].image.height=t,this.textures[s].image.depth=n,this.textures[s].isData3DTexture!==!0&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;let s=Object.assign({},e.textures[t].image);this.textures[t].source=new bi(s)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){let t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}},Qt=class extends Eo{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}},gr=class extends an{constructor(e=null,t=1,n=1,s=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=jt,this.minFilter=jt,this.wrapR=$n,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}},Nh=class extends Qt{constructor(e=1,t=1,n=1,s={}){super(e,t,s),this.isWebGLArrayRenderTarget=!0,this.depth=n,this.texture=new gr(null,e,t,n),this._setTextureOptions(s),this.texture.isRenderTargetTexture=!0}},_r=class extends an{constructor(e=null,t=1,n=1,s=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:s},this.magFilter=jt,this.minFilter=jt,this.wrapR=$n,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}},Uh=class extends Qt{constructor(e=1,t=1,n=1,s={}){super(e,t,s),this.isWebGL3DRenderTarget=!0,this.depth=n,this.texture=new _r(null,e,t,n),this._setTextureOptions(s),this.texture.isRenderTargetTexture=!0}},Bu=class Bu{constructor(e,t,n,s,r,o,a,l,c,h,u,d,f,p,_,g){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,s,r,o,a,l,c,h,u,d,f,p,_,g)}set(e,t,n,s,r,o,a,l,c,h,u,d,f,p,_,g){let m=this.elements;return m[0]=e,m[4]=t,m[8]=n,m[12]=s,m[1]=r,m[5]=o,m[9]=a,m[13]=l,m[2]=c,m[6]=h,m[10]=u,m[14]=d,m[3]=f,m[7]=p,m[11]=_,m[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Bu().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();let t=this.elements,n=e.elements,s=1/Zr.setFromMatrixColumn(e,0).length(),r=1/Zr.setFromMatrixColumn(e,1).length(),o=1/Zr.setFromMatrixColumn(e,2).length();return t[0]=n[0]*s,t[1]=n[1]*s,t[2]=n[2]*s,t[3]=0,t[4]=n[4]*r,t[5]=n[5]*r,t[6]=n[6]*r,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,s=e.y,r=e.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(s),c=Math.sin(s),h=Math.cos(r),u=Math.sin(r);if(e.order==="XYZ"){let d=o*h,f=o*u,p=a*h,_=a*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=f+p*c,t[5]=d-_*c,t[9]=-a*l,t[2]=_-d*c,t[6]=p+f*c,t[10]=o*l}else if(e.order==="YXZ"){let d=l*h,f=l*u,p=c*h,_=c*u;t[0]=d+_*a,t[4]=p*a-f,t[8]=o*c,t[1]=o*u,t[5]=o*h,t[9]=-a,t[2]=f*a-p,t[6]=_+d*a,t[10]=o*l}else if(e.order==="ZXY"){let d=l*h,f=l*u,p=c*h,_=c*u;t[0]=d-_*a,t[4]=-o*u,t[8]=p+f*a,t[1]=f+p*a,t[5]=o*h,t[9]=_-d*a,t[2]=-o*c,t[6]=a,t[10]=o*l}else if(e.order==="ZYX"){let d=o*h,f=o*u,p=a*h,_=a*u;t[0]=l*h,t[4]=p*c-f,t[8]=d*c+_,t[1]=l*u,t[5]=_*c+d,t[9]=f*c-p,t[2]=-c,t[6]=a*l,t[10]=o*l}else if(e.order==="YZX"){let d=o*l,f=o*c,p=a*l,_=a*c;t[0]=l*h,t[4]=_-d*u,t[8]=p*u+f,t[1]=u,t[5]=o*h,t[9]=-a*h,t[2]=-c*h,t[6]=f*u+p,t[10]=d-_*u}else if(e.order==="XZY"){let d=o*l,f=o*c,p=a*l,_=a*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+_,t[5]=o*h,t[9]=f*u-p,t[2]=p*u-f,t[6]=a*h,t[10]=_*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Px,e,Ix)}lookAt(e,t,n){let s=this.elements;return ui.subVectors(e,t),ui.lengthSq()===0&&(ui.z=1),ui.normalize(),Is.crossVectors(n,ui),Is.lengthSq()===0&&(Math.abs(n.z)===1?ui.x+=1e-4:ui.z+=1e-4,ui.normalize(),Is.crossVectors(n,ui)),Is.normalize(),Gc.crossVectors(ui,Is),s[0]=Is.x,s[4]=Gc.x,s[8]=ui.x,s[1]=Is.y,s[5]=Gc.y,s[9]=ui.y,s[2]=Is.z,s[6]=Gc.z,s[10]=ui.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,s=t.elements,r=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],p=n[2],_=n[6],g=n[10],m=n[14],v=n[3],E=n[7],y=n[11],w=n[15],M=s[0],T=s[4],x=s[8],S=s[12],C=s[1],L=s[5],F=s[9],I=s[13],P=s[2],U=s[6],z=s[10],V=s[14],ie=s[3],$=s[7],se=s[11],te=s[15];return r[0]=o*M+a*C+l*P+c*ie,r[4]=o*T+a*L+l*U+c*$,r[8]=o*x+a*F+l*z+c*se,r[12]=o*S+a*I+l*V+c*te,r[1]=h*M+u*C+d*P+f*ie,r[5]=h*T+u*L+d*U+f*$,r[9]=h*x+u*F+d*z+f*se,r[13]=h*S+u*I+d*V+f*te,r[2]=p*M+_*C+g*P+m*ie,r[6]=p*T+_*L+g*U+m*$,r[10]=p*x+_*F+g*z+m*se,r[14]=p*S+_*I+g*V+m*te,r[3]=v*M+E*C+y*P+w*ie,r[7]=v*T+E*L+y*U+w*$,r[11]=v*x+E*F+y*z+w*se,r[15]=v*S+E*I+y*V+w*te,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],s=e[8],r=e[12],o=e[1],a=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],f=e[14],p=e[3],_=e[7],g=e[11],m=e[15],v=l*f-c*d,E=a*f-c*u,y=a*d-l*u,w=o*f-c*h,M=o*d-l*h,T=o*u-a*h;return t*(_*v-g*E+m*y)-n*(p*v-g*w+m*M)+s*(p*E-_*w+m*T)-r*(p*y-_*M+g*T)}determinantAffine(){let e=this.elements,t=e[0],n=e[4],s=e[8],r=e[1],o=e[5],a=e[9],l=e[2],c=e[6],h=e[10];return t*(o*h-a*c)-n*(r*h-a*l)+s*(r*c-o*l)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let s=this.elements;return e.isVector3?(s[12]=e.x,s[13]=e.y,s[14]=e.z):(s[12]=e,s[13]=t,s[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],s=e[2],r=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],f=e[11],p=e[12],_=e[13],g=e[14],m=e[15],v=t*a-n*o,E=t*l-s*o,y=t*c-r*o,w=n*l-s*a,M=n*c-r*a,T=s*c-r*l,x=h*_-u*p,S=h*g-d*p,C=h*m-f*p,L=u*g-d*_,F=u*m-f*_,I=d*m-f*g,P=v*I-E*F+y*L+w*C-M*S+T*x;if(P===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let U=1/P;return e[0]=(a*I-l*F+c*L)*U,e[1]=(s*F-n*I-r*L)*U,e[2]=(_*T-g*M+m*w)*U,e[3]=(d*M-u*T-f*w)*U,e[4]=(l*C-o*I-c*S)*U,e[5]=(t*I-s*C+r*S)*U,e[6]=(g*y-p*T-m*E)*U,e[7]=(h*T-d*y+f*E)*U,e[8]=(o*F-a*C+c*x)*U,e[9]=(n*C-t*F-r*x)*U,e[10]=(p*M-_*y+m*v)*U,e[11]=(u*y-h*M-f*v)*U,e[12]=(a*S-o*L-l*x)*U,e[13]=(t*L-n*S+s*x)*U,e[14]=(_*E-p*w-g*v)*U,e[15]=(h*w-u*E+d*v)*U,this}scale(e){let t=this.elements,n=e.x,s=e.y,r=e.z;return t[0]*=n,t[4]*=s,t[8]*=r,t[1]*=n,t[5]*=s,t[9]*=r,t[2]*=n,t[6]*=s,t[10]*=r,t[3]*=n,t[7]*=s,t[11]*=r,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],s=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,s))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),s=Math.sin(t),r=1-n,o=e.x,a=e.y,l=e.z,c=r*o,h=r*a;return this.set(c*o+n,c*a-s*l,c*l+s*a,0,c*a+s*l,h*a+n,h*l-s*o,0,c*l-s*a,h*l+s*o,r*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,s,r,o){return this.set(1,n,r,0,e,1,o,0,t,s,1,0,0,0,0,1),this}compose(e,t,n){let s=this.elements,r=t._x,o=t._y,a=t._z,l=t._w,c=r+r,h=o+o,u=a+a,d=r*c,f=r*h,p=r*u,_=o*h,g=o*u,m=a*u,v=l*c,E=l*h,y=l*u,w=n.x,M=n.y,T=n.z;return s[0]=(1-(_+m))*w,s[1]=(f+y)*w,s[2]=(p-E)*w,s[3]=0,s[4]=(f-y)*M,s[5]=(1-(d+m))*M,s[6]=(g+v)*M,s[7]=0,s[8]=(p+E)*T,s[9]=(g-v)*T,s[10]=(1-(d+_))*T,s[11]=0,s[12]=e.x,s[13]=e.y,s[14]=e.z,s[15]=1,this}decompose(e,t,n){let s=this.elements;e.x=s[12],e.y=s[13],e.z=s[14];let r=this.determinantAffine();if(r===0)return n.set(1,1,1),t.identity(),this;let o=Zr.set(s[0],s[1],s[2]).length(),a=Zr.set(s[4],s[5],s[6]).length(),l=Zr.set(s[8],s[9],s[10]).length();r<0&&(o=-o),Ci.copy(this);let c=1/o,h=1/a,u=1/l;return Ci.elements[0]*=c,Ci.elements[1]*=c,Ci.elements[2]*=c,Ci.elements[4]*=h,Ci.elements[5]*=h,Ci.elements[6]*=h,Ci.elements[8]*=u,Ci.elements[9]*=u,Ci.elements[10]*=u,t.setFromRotationMatrix(Ci),n.x=o,n.y=a,n.z=l,this}makePerspective(e,t,n,s,r,o,a=si,l=!1){let c=this.elements,h=2*r/(t-e),u=2*r/(n-s),d=(t+e)/(t-e),f=(n+s)/(n-s),p,_;if(l)p=r/(o-r),_=o*r/(o-r);else if(a===si)p=-(o+r)/(o-r),_=-2*o*r/(o-r);else if(a===zs)p=-o/(o-r),_=-o*r/(o-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=_,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,s,r,o,a=si,l=!1){let c=this.elements,h=2/(t-e),u=2/(n-s),d=-(t+e)/(t-e),f=-(n+s)/(n-s),p,_;if(l)p=1/(o-r),_=o/(o-r);else if(a===si)p=-2/(o-r),_=-(o+r)/(o-r);else if(a===zs)p=-1/(o-r),_=-r/(o-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return c[0]=h,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=p,c[14]=_,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let s=0;s<16;s++)if(t[s]!==n[s])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}};Bu.prototype.isMatrix4=!0;var nt=Bu,Zr=new A,Ci=new nt,Px=new A(0,0,0),Ix=new A(1,1,1),Is=new A,Gc=new A,ui=new A,mm=new nt,gm=new $t,Gn=class i{constructor(e=0,t=0,n=0,s=i.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=s}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,s=this._order){return this._x=e,this._y=t,this._z=n,this._order=s,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let s=e.elements,r=s[0],o=s[4],a=s[8],l=s[1],c=s[5],h=s[9],u=s[2],d=s[6],f=s[10];switch(t){case"XYZ":this._y=Math.asin(at(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,r)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-at(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,r),this._z=0);break;case"ZXY":this._x=Math.asin(at(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-at(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(at(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-at(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-h,f),this._y=0);break;default:be("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return mm.makeRotationFromQuaternion(e),this.setFromRotationMatrix(mm,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return gm.setFromEuler(this),this.setFromQuaternion(gm,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Gn.DEFAULT_ORDER="XYZ";var xr=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},Dx=0,_m=new A,Jr=new $t,rs=new nt,Vc=new A,va=new A,Lx=new A,Nx=new $t,xm=new A(1,0,0),vm=new A(0,1,0),ym=new A(0,0,1),Mm={type:"added"},Ux={type:"removed"},Kr={type:"childadded",child:null},Sd={type:"childremoved",child:null},_t=class i extends ri{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Dx++}),this.uuid=fi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=i.DEFAULT_UP.clone();let e=new A,t=new Gn,n=new $t,s=new A(1,1,1);function r(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(r),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new nt},normalMatrix:{value:new ht}}),this.matrix=new nt,this.matrixWorld=new nt,this.matrixAutoUpdate=i.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=i.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new xr,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Jr.setFromAxisAngle(e,t),this.quaternion.multiply(Jr),this}rotateOnWorldAxis(e,t){return Jr.setFromAxisAngle(e,t),this.quaternion.premultiply(Jr),this}rotateX(e){return this.rotateOnAxis(xm,e)}rotateY(e){return this.rotateOnAxis(vm,e)}rotateZ(e){return this.rotateOnAxis(ym,e)}translateOnAxis(e,t){return _m.copy(e).applyQuaternion(this.quaternion),this.position.add(_m.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(xm,e)}translateY(e){return this.translateOnAxis(vm,e)}translateZ(e){return this.translateOnAxis(ym,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(rs.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Vc.copy(e):Vc.set(e,t,n);let s=this.parent;this.updateWorldMatrix(!0,!1),va.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?rs.lookAt(va,Vc,this.up):rs.lookAt(Vc,va,this.up),this.quaternion.setFromRotationMatrix(rs),s&&(rs.extractRotation(s.matrixWorld),Jr.setFromRotationMatrix(rs),this.quaternion.premultiply(Jr.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(qe("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Mm),Kr.child=e,this.dispatchEvent(Kr),Kr.child=null):qe("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Ux),Sd.child=e,this.dispatchEvent(Sd),Sd.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),rs.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),rs.multiply(e.parent.matrixWorld)),e.applyMatrix4(rs),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Mm),Kr.child=e,this.dispatchEvent(Kr),Kr.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,s=this.children.length;n<s;n++){let o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let s=this.children;for(let r=0,o=s.length;r<o;r++)s[r].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(va,e,Lx),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(va,Nx,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(e){e(this);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let e=this.pivot;if(e!==null){let t=e.x,n=e.y,s=e.z,r=this.matrix.elements;r[12]+=t-r[0]*t-r[4]*n-r[8]*s,r[13]+=n-r[1]*t-r[5]*n-r[9]*s,r[14]+=s-r[2]*t-r[6]*n-r[10]*s}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,s=t.length;n<s;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){let s=this.parent;if(e===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){let r=this.children;for(let o=0,a=r.length;o<a;o++)r[o].updateWorldMatrix(!1,!0,n)}}toJSON(e){let t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});let s={};s.uuid=this.uuid,s.type=this.type,s.name=this.name,s.castShadow=this.castShadow,s.receiveShadow=this.receiveShadow,s.visible=this.visible,s.frustumCulled=this.frustumCulled,s.renderOrder=this.renderOrder,s.static=this.static,s.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),this.pivot!==null&&(s.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(s.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(s.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(a=>({...a})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(e),s.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(s.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(s.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(s.boundingBox=this.boundingBox.toJSON()));function r(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(s.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){s.geometry=r(e.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let u=l[c];r(e.shapes,u)}else r(e.shapes,l)}}if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(r(e.materials,this.material[l]));s.material=a}else s.material=r(e.materials,this.material);if(this.children.length>0){s.children=[];for(let a=0;a<this.children.length;a++)s.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){s.animations=[];for(let a=0;a<this.animations.length;a++){let l=this.animations[a];s.animations.push(r(e.animations,l))}}if(t){let a=o(e.geometries),l=o(e.materials),c=o(e.textures),h=o(e.images),u=o(e.shapes),d=o(e.skeletons),f=o(e.animations),p=o(e.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),p.length>0&&(n.nodes=p)}return n.object=s,n;function o(a){let l=[];for(let c in a){let h=a[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){let s=e.children[n];this.add(s.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}};_t.DEFAULT_UP=new A(0,1,0);_t.DEFAULT_MATRIX_AUTO_UPDATE=!0;_t.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var ce=class extends _t{constructor(){super(),this.isGroup=!0,this.type="Group"}},Fx={type:"move"},vr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new ce,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new ce,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new A,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new A),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new ce,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new A,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new A,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let s=null,r=null,o=null,a=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){o=!0;for(let _ of e.hand.values()){let g=t.getJointPose(_,n),m=this._getHandJoint(c,_);g!==null&&(m.matrix.fromArray(g.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,m.jointRadius=g.radius),m.visible=g!==null}let h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,p=.005;c.inputState.pinching&&d>f+p?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=f-p&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,n),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1,l.eventsEnabled&&l.dispatchEvent({type:"gripUpdated",data:e,target:this})));a!==null&&(s=t.getPose(e.targetRaySpace,n),s===null&&r!==null&&(s=r),s!==null&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Fx)))}return a!==null&&(a.visible=s!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new ce;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},pg={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ds={h:0,s:0,l:0},Wc={h:0,s:0,l:0};function Td(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}var q=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let s=e;s&&s.isColor?this.copy(s):typeof s=="number"?this.setHex(s):typeof s=="string"&&this.setStyle(s)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Wt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Mt.colorSpaceToWorking(this,t),this}setRGB(e,t,n,s=Mt.workingColorSpace){return this.r=e,this.g=t,this.b=n,Mt.colorSpaceToWorking(this,s),this}setHSL(e,t,n,s=Mt.workingColorSpace){if(e=tp(e,1),t=at(t,0,1),n=at(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,o=2*n-r;this.r=Td(o,r,e+1/3),this.g=Td(o,r,e),this.b=Td(o,r,e-1/3)}return Mt.colorSpaceToWorking(this,s),this}setStyle(e,t=Wt){function n(r){r!==void 0&&parseFloat(r)<1&&be("Color: Alpha component of "+e+" will be ignored.")}let s;if(s=/^(\w+)\(([^\)]*)\)/.exec(e)){let r,o=s[1],a=s[2];switch(o){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:be("Color: Unknown color model "+e)}}else if(s=/^\#([A-Fa-f\d]+)$/.exec(e)){let r=s[1],o=r.length;if(o===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(r,16),t);be("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Wt){let n=pg[e.toLowerCase()];return n!==void 0?this.setHex(n,t):be("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=ds(e.r),this.g=ds(e.g),this.b=ds(e.b),this}copyLinearToSRGB(e){return this.r=mo(e.r),this.g=mo(e.g),this.b=mo(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Wt){return Mt.workingToColorSpace(Hn.copy(this),e),Math.round(at(Hn.r*255,0,255))*65536+Math.round(at(Hn.g*255,0,255))*256+Math.round(at(Hn.b*255,0,255))}getHexString(e=Wt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Mt.workingColorSpace){Mt.workingToColorSpace(Hn.copy(this),t);let n=Hn.r,s=Hn.g,r=Hn.b,o=Math.max(n,s,r),a=Math.min(n,s,r),l,c,h=(a+o)/2;if(a===o)l=0,c=0;else{let u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(s-r)/u+(s<r?6:0);break;case s:l=(r-n)/u+2;break;case r:l=(n-s)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=Mt.workingColorSpace){return Mt.workingToColorSpace(Hn.copy(this),t),e.r=Hn.r,e.g=Hn.g,e.b=Hn.b,e}getStyle(e=Wt){Mt.workingToColorSpace(Hn.copy(this),e);let t=Hn.r,n=Hn.g,s=Hn.b;return e!==Wt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(s*255)})`}offsetHSL(e,t,n){return this.getHSL(Ds),this.setHSL(Ds.h+e,Ds.s+t,Ds.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Ds),e.getHSL(Wc);let n=Ua(Ds.h,Wc.h,t),s=Ua(Ds.s,Wc.s,t),r=Ua(Ds.l,Wc.l,t);return this.setHSL(n,s,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,s=this.b,r=e.elements;return this.r=r[0]*t+r[3]*n+r[6]*s,this.g=r[1]*t+r[4]*n+r[7]*s,this.b=r[2]*t+r[5]*n+r[8]*s,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Hn=new q;q.NAMES=pg;var Za=class i{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new q(e),this.density=t}clone(){return new i(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}},Ja=class i{constructor(e,t=1,n=1e3){this.isFog=!0,this.name="",this.color=new q(e),this.near=t,this.far=n}clone(){return new i(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},yr=class extends _t{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Gn,this.environmentIntensity=1,this.environmentRotation=new Gn,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}},Pi=new A,os=new A,wd=new A,as=new A,$r=new A,jr=new A,bm=new A,Rd=new A,Ad=new A,Cd=new A,Pd=new Ut,Id=new Ut,Dd=new Ut,Li=class i{constructor(e=new A,t=new A,n=new A){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,s){s.subVectors(n,t),Pi.subVectors(e,t),s.cross(Pi);let r=s.lengthSq();return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)}static getBarycoord(e,t,n,s,r){Pi.subVectors(s,t),os.subVectors(n,t),wd.subVectors(e,t);let o=Pi.dot(Pi),a=Pi.dot(os),l=Pi.dot(wd),c=os.dot(os),h=os.dot(wd),u=o*c-a*a;if(u===0)return r.set(0,0,0),null;let d=1/u,f=(c*l-a*h)*d,p=(o*h-a*l)*d;return r.set(1-f-p,p,f)}static containsPoint(e,t,n,s){return this.getBarycoord(e,t,n,s,as)===null?!1:as.x>=0&&as.y>=0&&as.x+as.y<=1}static getInterpolation(e,t,n,s,r,o,a,l){return this.getBarycoord(e,t,n,s,as)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,as.x),l.addScaledVector(o,as.y),l.addScaledVector(a,as.z),l)}static getInterpolatedAttribute(e,t,n,s,r,o){return Pd.setScalar(0),Id.setScalar(0),Dd.setScalar(0),Pd.fromBufferAttribute(e,t),Id.fromBufferAttribute(e,n),Dd.fromBufferAttribute(e,s),o.setScalar(0),o.addScaledVector(Pd,r.x),o.addScaledVector(Id,r.y),o.addScaledVector(Dd,r.z),o}static isFrontFacing(e,t,n,s){return Pi.subVectors(n,t),os.subVectors(e,t),Pi.cross(os).dot(s)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,s){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[s]),this}setFromAttributeAndIndices(e,t,n,s){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,s),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Pi.subVectors(this.c,this.b),os.subVectors(this.a,this.b),Pi.cross(os).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return i.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return i.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,s,r){return i.getInterpolation(e,this.a,this.b,this.c,t,n,s,r)}containsPoint(e){return i.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return i.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,s=this.b,r=this.c,o,a;$r.subVectors(s,n),jr.subVectors(r,n),Rd.subVectors(e,n);let l=$r.dot(Rd),c=jr.dot(Rd);if(l<=0&&c<=0)return t.copy(n);Ad.subVectors(e,s);let h=$r.dot(Ad),u=jr.dot(Ad);if(h>=0&&u<=h)return t.copy(s);let d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return o=l/(l-h),t.copy(n).addScaledVector($r,o);Cd.subVectors(e,r);let f=$r.dot(Cd),p=jr.dot(Cd);if(p>=0&&f<=p)return t.copy(r);let _=f*c-l*p;if(_<=0&&c>=0&&p<=0)return a=c/(c-p),t.copy(n).addScaledVector(jr,a);let g=h*p-f*u;if(g<=0&&u-h>=0&&f-p>=0)return bm.subVectors(r,s),a=(u-h)/(u-h+(f-p)),t.copy(s).addScaledVector(bm,a);let m=1/(g+_+d);return o=_*m,a=d*m,t.copy(n).addScaledVector($r,o).addScaledVector(jr,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},bn=class{constructor(e=new A(1/0,1/0,1/0),t=new A(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Ii.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Ii.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=Ii.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=r.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,Ii):Ii.fromBufferAttribute(r,o),Ii.applyMatrix4(e.matrixWorld),this.expandByPoint(Ii);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Xc.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Xc.copy(n.boundingBox)),Xc.applyMatrix4(e.matrixWorld),this.union(Xc)}let s=e.children;for(let r=0,o=s.length;r<o;r++)this.expandByObject(s[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Ii),Ii.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ya),Yc.subVectors(this.max,ya),Qr.subVectors(e.a,ya),eo.subVectors(e.b,ya),to.subVectors(e.c,ya),Ls.subVectors(eo,Qr),Ns.subVectors(to,eo),tr.subVectors(Qr,to);let t=[0,-Ls.z,Ls.y,0,-Ns.z,Ns.y,0,-tr.z,tr.y,Ls.z,0,-Ls.x,Ns.z,0,-Ns.x,tr.z,0,-tr.x,-Ls.y,Ls.x,0,-Ns.y,Ns.x,0,-tr.y,tr.x,0];return!Ld(t,Qr,eo,to,Yc)||(t=[1,0,0,0,1,0,0,0,1],!Ld(t,Qr,eo,to,Yc))?!1:(qc.crossVectors(Ls,Ns),t=[qc.x,qc.y,qc.z],Ld(t,Qr,eo,to,Yc))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Ii).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Ii).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(ls[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ls[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ls[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ls[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ls[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ls[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ls[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ls[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ls),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}},ls=[new A,new A,new A,new A,new A,new A,new A,new A],Ii=new A,Xc=new bn,Qr=new A,eo=new A,to=new A,Ls=new A,Ns=new A,tr=new A,ya=new A,Yc=new A,qc=new A,nr=new A;function Ld(i,e,t,n,s){for(let r=0,o=i.length-3;r<=o;r+=3){nr.fromArray(i,r);let a=s.x*Math.abs(nr.x)+s.y*Math.abs(nr.y)+s.z*Math.abs(nr.z),l=e.dot(nr),c=t.dot(nr),h=n.dot(nr);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}var us=Bx();function Bx(){let i=new ArrayBuffer(4),e=new Float32Array(i),t=new Uint32Array(i),n=new Uint32Array(512),s=new Uint32Array(512);for(let l=0;l<256;++l){let c=l-127;c<-27?(n[l]=0,n[l|256]=32768,s[l]=24,s[l|256]=24):c<-14?(n[l]=1024>>-c-14,n[l|256]=1024>>-c-14|32768,s[l]=-c-1,s[l|256]=-c-1):c<=15?(n[l]=c+15<<10,n[l|256]=c+15<<10|32768,s[l]=13,s[l|256]=13):c<128?(n[l]=31744,n[l|256]=64512,s[l]=24,s[l|256]=24):(n[l]=31744,n[l|256]=64512,s[l]=13,s[l|256]=13)}let r=new Uint32Array(2048),o=new Uint32Array(64),a=new Uint32Array(64);for(let l=1;l<1024;++l){let c=l<<13,h=0;for(;!(c&8388608);)c<<=1,h-=8388608;c&=-8388609,h+=947912704,r[l]=c|h}for(let l=1024;l<2048;++l)r[l]=939524096+(l-1024<<13);for(let l=1;l<31;++l)o[l]=l<<23;o[31]=1199570944,o[32]=2147483648;for(let l=33;l<63;++l)o[l]=2147483648+(l-32<<23);o[63]=3347054592;for(let l=1;l<64;++l)l!==32&&(a[l]=1024);return{floatView:e,uint32View:t,baseTable:n,shiftTable:s,mantissaTable:r,exponentTable:o,offsetTable:a}}function ni(i){Math.abs(i)>65504&&be("DataUtils.toHalfFloat(): Value out of range."),i=at(i,-65504,65504),us.floatView[0]=i;let e=us.uint32View[0],t=e>>23&511;return us.baseTable[t]+((e&8388607)>>us.shiftTable[t])}function Ia(i){let e=i>>10;return us.uint32View[0]=us.mantissaTable[us.offsetTable[e]+(i&1023)]+us.exponentTable[e],us.floatView[0]}var Fh=class{static toHalfFloat(e){return ni(e)}static fromHalfFloat(e){return Ia(e)}},mn=new A,Zc=new J,Ox=0,bt=class extends ri{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Ox++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=Rc,this.updateRanges=[],this.gpuType=kn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let s=0,r=this.itemSize;s<r;s++)this.array[e+s]=t.array[n+s];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Zc.fromBufferAttribute(this,t),Zc.applyMatrix3(e),this.setXY(t,Zc.x,Zc.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)mn.fromBufferAttribute(this,t),mn.applyMatrix3(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)mn.fromBufferAttribute(this,t),mn.applyMatrix4(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)mn.fromBufferAttribute(this,t),mn.applyNormalMatrix(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)mn.fromBufferAttribute(this,t),mn.transformDirection(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=Kn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=gt(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Kn(t,this.array)),t}setX(e,t){return this.normalized&&(t=gt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Kn(t,this.array)),t}setY(e,t){return this.normalized&&(t=gt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Kn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=gt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Kn(t,this.array)),t}setW(e,t){return this.normalized&&(t=gt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=gt(t,this.array),n=gt(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=gt(t,this.array),n=gt(n,this.array),s=gt(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=gt(t,this.array),n=gt(n,this.array),s=gt(s,this.array),r=gt(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=s,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}},Bh=class extends bt{constructor(e,t,n){super(new Int8Array(e),t,n)}},Oh=class extends bt{constructor(e,t,n){super(new Uint8Array(e),t,n)}},Hh=class extends bt{constructor(e,t,n){super(new Uint8ClampedArray(e),t,n)}},zh=class extends bt{constructor(e,t,n){super(new Int16Array(e),t,n)}},So=class extends bt{constructor(e,t,n){super(new Uint16Array(e),t,n)}},kh=class extends bt{constructor(e,t,n){super(new Int32Array(e),t,n)}},To=class extends bt{constructor(e,t,n){super(new Uint32Array(e),t,n)}},Gh=class extends bt{constructor(e,t,n){super(new Uint16Array(e),t,n),this.isFloat16BufferAttribute=!0}getX(e){let t=Ia(this.array[e*this.itemSize]);return this.normalized&&(t=Kn(t,this.array)),t}setX(e,t){return this.normalized&&(t=gt(t,this.array)),this.array[e*this.itemSize]=ni(t),this}getY(e){let t=Ia(this.array[e*this.itemSize+1]);return this.normalized&&(t=Kn(t,this.array)),t}setY(e,t){return this.normalized&&(t=gt(t,this.array)),this.array[e*this.itemSize+1]=ni(t),this}getZ(e){let t=Ia(this.array[e*this.itemSize+2]);return this.normalized&&(t=Kn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=gt(t,this.array)),this.array[e*this.itemSize+2]=ni(t),this}getW(e){let t=Ia(this.array[e*this.itemSize+3]);return this.normalized&&(t=Kn(t,this.array)),t}setW(e,t){return this.normalized&&(t=gt(t,this.array)),this.array[e*this.itemSize+3]=ni(t),this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=gt(t,this.array),n=gt(n,this.array)),this.array[e+0]=ni(t),this.array[e+1]=ni(n),this}setXYZ(e,t,n,s){return e*=this.itemSize,this.normalized&&(t=gt(t,this.array),n=gt(n,this.array),s=gt(s,this.array)),this.array[e+0]=ni(t),this.array[e+1]=ni(n),this.array[e+2]=ni(s),this}setXYZW(e,t,n,s,r){return e*=this.itemSize,this.normalized&&(t=gt(t,this.array),n=gt(n,this.array),s=gt(s,this.array),r=gt(r,this.array)),this.array[e+0]=ni(t),this.array[e+1]=ni(n),this.array[e+2]=ni(s),this.array[e+3]=ni(r),this}},_e=class extends bt{constructor(e,t,n){super(new Float32Array(e),t,n)}},Hx=new bn,Ma=new A,Nd=new A,gn=class{constructor(e=new A,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t!==void 0?n.copy(t):Hx.setFromPoints(e).getCenter(n);let s=0;for(let r=0,o=e.length;r<o;r++)s=Math.max(s,n.distanceToSquared(e[r]));return this.radius=Math.sqrt(s),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ma.subVectors(e,this.center);let t=Ma.lengthSq();if(t>this.radius*this.radius){let n=Math.sqrt(t),s=(n-this.radius)*.5;this.center.addScaledVector(Ma,s/n),this.radius+=s}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Nd.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ma.copy(e.center).add(Nd)),this.expandByPoint(Ma.copy(e.center).sub(Nd))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}},zx=0,Mi=new nt,Ud=new _t,no=new A,di=new bn,ba=new bn,Pn=new A,ke=class i extends ri{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:zx++}),this.uuid=fi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(cx(e)?To:So)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new ht().getNormalMatrix(e);n.applyNormalMatrix(r),n.needsUpdate=!0}let s=this.attributes.tangent;return s!==void 0&&(s.transformDirection(e),s.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return Mi.makeRotationFromQuaternion(e),this.applyMatrix4(Mi),this}rotateX(e){return Mi.makeRotationX(e),this.applyMatrix4(Mi),this}rotateY(e){return Mi.makeRotationY(e),this.applyMatrix4(Mi),this}rotateZ(e){return Mi.makeRotationZ(e),this.applyMatrix4(Mi),this}translate(e,t,n){return Mi.makeTranslation(e,t,n),this.applyMatrix4(Mi),this}scale(e,t,n){return Mi.makeScale(e,t,n),this.applyMatrix4(Mi),this}lookAt(e){return Ud.lookAt(e),Ud.updateMatrix(),this.applyMatrix4(Ud.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(no).negate(),this.translate(no.x,no.y,no.z),this}setFromPoints(e){let t=this.getAttribute("position");if(t===void 0){let n=[];for(let s=0,r=e.length;s<r;s++){let o=e[s];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new _e(n,3))}else{let n=Math.min(e.length,t.count);for(let s=0;s<n;s++){let r=e[s];t.setXYZ(s,r.x,r.y,r.z||0)}e.length>t.count&&be("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new bn);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){qe("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new A(-1/0,-1/0,-1/0),new A(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,s=t.length;n<s;n++){let r=t[n];di.setFromBufferAttribute(r),this.morphTargetsRelative?(Pn.addVectors(this.boundingBox.min,di.min),this.boundingBox.expandByPoint(Pn),Pn.addVectors(this.boundingBox.max,di.max),this.boundingBox.expandByPoint(Pn)):(this.boundingBox.expandByPoint(di.min),this.boundingBox.expandByPoint(di.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&qe('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new gn);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){qe("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new A,1/0);return}if(e){let n=this.boundingSphere.center;if(di.setFromBufferAttribute(e),t)for(let r=0,o=t.length;r<o;r++){let a=t[r];ba.setFromBufferAttribute(a),this.morphTargetsRelative?(Pn.addVectors(di.min,ba.min),di.expandByPoint(Pn),Pn.addVectors(di.max,ba.max),di.expandByPoint(Pn)):(di.expandByPoint(ba.min),di.expandByPoint(ba.max))}di.getCenter(n);let s=0;for(let r=0,o=e.count;r<o;r++)Pn.fromBufferAttribute(e,r),s=Math.max(s,n.distanceToSquared(Pn));if(t)for(let r=0,o=t.length;r<o;r++){let a=t[r],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)Pn.fromBufferAttribute(a,c),l&&(no.fromBufferAttribute(e,c),Pn.add(no)),s=Math.max(s,n.distanceToSquared(Pn))}this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&qe('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){qe("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=t.position,s=t.normal,r=t.uv,o=this.getAttribute("tangent");(o===void 0||o.count!==n.count)&&(o=new bt(new Float32Array(4*n.count),4),this.setAttribute("tangent",o));let a=[],l=[];for(let x=0;x<n.count;x++)a[x]=new A,l[x]=new A;let c=new A,h=new A,u=new A,d=new J,f=new J,p=new J,_=new A,g=new A;function m(x,S,C){c.fromBufferAttribute(n,x),h.fromBufferAttribute(n,S),u.fromBufferAttribute(n,C),d.fromBufferAttribute(r,x),f.fromBufferAttribute(r,S),p.fromBufferAttribute(r,C),h.sub(c),u.sub(c),f.sub(d),p.sub(d);let L=1/(f.x*p.y-p.x*f.y);isFinite(L)&&(_.copy(h).multiplyScalar(p.y).addScaledVector(u,-f.y).multiplyScalar(L),g.copy(u).multiplyScalar(f.x).addScaledVector(h,-p.x).multiplyScalar(L),a[x].add(_),a[S].add(_),a[C].add(_),l[x].add(g),l[S].add(g),l[C].add(g))}let v=this.groups;v.length===0&&(v=[{start:0,count:e.count}]);for(let x=0,S=v.length;x<S;++x){let C=v[x],L=C.start,F=C.count;for(let I=L,P=L+F;I<P;I+=3)m(e.getX(I+0),e.getX(I+1),e.getX(I+2))}let E=new A,y=new A,w=new A,M=new A;function T(x){w.fromBufferAttribute(s,x),M.copy(w);let S=a[x];E.copy(S),E.sub(w.multiplyScalar(w.dot(S))).normalize(),y.crossVectors(M,S);let L=y.dot(l[x])<0?-1:1;o.setXYZW(x,E.x,E.y,E.z,L)}for(let x=0,S=v.length;x<S;++x){let C=v[x],L=C.start,F=C.count;for(let I=L,P=L+F;I<P;I+=3)T(e.getX(I+0)),T(e.getX(I+1)),T(e.getX(I+2))}this._transformed=!0}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==t.count)n=new bt(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);let s=new A,r=new A,o=new A,a=new A,l=new A,c=new A,h=new A,u=new A;if(e)for(let d=0,f=e.count;d<f;d+=3){let p=e.getX(d+0),_=e.getX(d+1),g=e.getX(d+2);s.fromBufferAttribute(t,p),r.fromBufferAttribute(t,_),o.fromBufferAttribute(t,g),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),a.fromBufferAttribute(n,p),l.fromBufferAttribute(n,_),c.fromBufferAttribute(n,g),a.add(h),l.add(h),c.add(h),n.setXYZ(p,a.x,a.y,a.z),n.setXYZ(_,l.x,l.y,l.z),n.setXYZ(g,c.x,c.y,c.z)}else for(let d=0,f=t.count;d<f;d+=3)s.fromBufferAttribute(t,d+0),r.fromBufferAttribute(t,d+1),o.fromBufferAttribute(t,d+2),h.subVectors(o,r),u.subVectors(s,r),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Pn.fromBufferAttribute(e,t),Pn.normalize(),e.setXYZ(t,Pn.x,Pn.y,Pn.z)}toNonIndexed(){function e(a,l){let c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h),f=0,p=0;for(let _=0,g=l.length;_<g;_++){a.isInterleavedBufferAttribute?f=l[_]*a.data.stride+a.offset:f=l[_]*h;for(let m=0;m<h;m++)d[p++]=c[f++]}return new bt(d,h,u)}if(this.index===null)return be("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new i,n=this.index.array,s=this.attributes;for(let a in s){let l=s[a],c=e(l,n);t.setAttribute(a,c)}let r=this.morphAttributes;for(let a in r){let l=[],c=r[a];for(let h=0,u=c.length;h<u;h++){let d=c[h],f=e(d,n);l.push(f)}t.morphAttributes[a]=l}t.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,l=o.length;a<l;a++){let c=o[a];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){let e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let l in n){let c=n[l];e.data.attributes[l]=c.toJSON(e.data)}let s={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){let f=c[u];h.push(f.toJSON(e.data))}h.length>0&&(s[l]=h,r=!0)}r&&(e.data.morphAttributes=s,e.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(e.data.boundingSphere=a.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone());let s=e.attributes;for(let c in s){let h=s[c];this.setAttribute(c,h.clone(t))}let r=e.morphAttributes;for(let c in r){let h=[],u=r[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;let o=e.groups;for(let c=0,h=o.length;c<h;c++){let u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}let a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());let l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}},Gs=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Rc,this.updateRanges=[],this.version=0,this.uuid=fi()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let s=0,r=this.stride;s<r;s++)this.array[e+s]=t.array[n+s];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=fi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=fi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer)));let t={uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride};return t.usage=this.usage,t}},Jn=new A,fs=class i{constructor(e,t,n,s=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=s}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)Jn.fromBufferAttribute(this,t),Jn.applyMatrix4(e),this.setXYZ(t,Jn.x,Jn.y,Jn.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Jn.fromBufferAttribute(this,t),Jn.applyNormalMatrix(e),this.setXYZ(t,Jn.x,Jn.y,Jn.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Jn.fromBufferAttribute(this,t),Jn.transformDirection(e),this.setXYZ(t,Jn.x,Jn.y,Jn.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=Kn(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=gt(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=gt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=gt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=gt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=gt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Kn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Kn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Kn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Kn(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=gt(t,this.array),n=gt(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=gt(t,this.array),n=gt(n,this.array),s=gt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this}setXYZW(e,t,n,s,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=gt(t,this.array),n=gt(n,this.array),s=gt(s,this.array),r=gt(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=s,this.data.array[e+3]=r,this}clone(e){if(e===void 0){bo("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return new bt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new i(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){bo("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let n=0;n<this.count;n++){let s=n*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[s+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Fd=new A,kx=new A,Gx=new ht,ii=class{constructor(e=new A(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,s){return this.normal.set(e,t,n),this.constant=s,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let s=Fd.subVectors(n,t).cross(kx.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(s,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){let s=e.delta(Fd),r=this.normal.dot(s);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let o=-(e.start.dot(this.normal)+this.constant)/r;return n===!0&&(o<0||o>1)?null:t.copy(e.start).addScaledVector(s,o)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||Gx.getNormalMatrix(e),s=this.coplanarPoint(Fd).applyMatrix4(e),r=this.normal.applyMatrix3(n).normalize();return this.constant=-s.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}},Vx=0,_n=class extends ri{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Vx++}),this.uuid=fi(),this.name="",this.type="Material",this.blending=Vn,this.side=zi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ku,this.blendDst=Gu,this.blendEquation=Zs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new q(0,0,0),this.blendAlpha=0,this.depthFunc=pr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=qf,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Na,this.stencilZFail=Na,this.stencilZPass=Na,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){be(`Material: parameter '${t}' has value of undefined.`);continue}let s=this[t];if(s===void 0){be(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}s&&s.isColor?s.set(n):s&&s.isVector2&&n&&n.isVector2||s&&s.isEuler&&n&&n.isEuler||s&&s.isVector3&&n&&n.isVector3?s.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let n={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(r=>r.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function s(r){let o=[];for(let a in r){let l=r[a];delete l.metadata,o.push(l)}return o}if(t){let r=s(e.textures),o=s(e.images);r.length>0&&(n.textures=r),o.length>0&&(n.images=o)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new q().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(n=>new ii().fromJSON(n))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let n=e.normalScale;Array.isArray(n)===!1&&(n=[n,n]),this.normalScale=new J().fromArray(n)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new J().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let s=t.length;n=new Array(s);for(let r=0;r!==s;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}},ln=class extends _n{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new q(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},io,Ea=new A,so=new A,ro=new A,oo=new J,Sa=new J,mg=new nt,Jc=new A,Ta=new A,Kc=new A,Em=new J,Bd=new J,Sm=new J,Dn=class extends _t{constructor(e=new ln){if(super(),this.isSprite=!0,this.type="Sprite",io===void 0){io=new ke;let t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Gs(t,5);io.setIndex([0,1,2,0,2,3]),io.setAttribute("position",new fs(n,3,0,!1)),io.setAttribute("uv",new fs(n,2,3,!1))}this.geometry=io,this.material=e,this.center=new J(.5,.5),this.count=1}intersectsFrustum(e){return e.intersectsSprite(this)}raycast(e,t){e.camera===null&&qe('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),so.setFromMatrixScale(this.matrixWorld),mg.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),ro.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&so.multiplyScalar(-ro.z);let n=this.material.rotation,s,r;n!==0&&(r=Math.cos(n),s=Math.sin(n));let o=this.center;$c(Jc.set(-.5,-.5,0),ro,o,so,s,r),$c(Ta.set(.5,-.5,0),ro,o,so,s,r),$c(Kc.set(.5,.5,0),ro,o,so,s,r),Em.set(0,0),Bd.set(1,0),Sm.set(1,1);let a=e.ray.intersectTriangle(Jc,Ta,Kc,!1,Ea);if(a===null&&($c(Ta.set(-.5,.5,0),ro,o,so,s,r),Bd.set(0,1),a=e.ray.intersectTriangle(Jc,Kc,Ta,!1,Ea),a===null))return;let l=e.ray.origin.distanceTo(Ea);l<e.near||l>e.far||t.push({distance:l,point:Ea.clone(),uv:Li.getInterpolation(Ea,Jc,Ta,Kc,Em,Bd,Sm,new J),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function $c(i,e,t,n,s,r){oo.subVectors(i,t).addScalar(.5).multiply(n),s!==void 0?(Sa.x=r*oo.x-s*oo.y,Sa.y=s*oo.x+r*oo.y):Sa.copy(oo),i.copy(e),i.x+=Sa.x,i.y+=Sa.y,i.applyMatrix4(mg)}var jc=new A,Tm=new A,Ka=class extends _t{constructor(){super(),this.isLOD=!0,this._currentLevel=0,this.type="LOD",Object.defineProperties(this,{levels:{enumerable:!0,value:[]}}),this.autoUpdate=!0}copy(e){super.copy(e,!1);let t=e.levels;for(let n=0,s=t.length;n<s;n++){let r=t[n];this.addLevel(r.object.clone(),r.distance,r.hysteresis)}return this.autoUpdate=e.autoUpdate,this}addLevel(e,t=0,n=0){t=Math.abs(t);let s=this.levels,r;for(r=0;r<s.length&&!(t<s[r].distance);r++);return s.splice(r,0,{distance:t,hysteresis:n,object:e}),this.add(e),this}removeLevel(e){let t=this.levels;for(let n=0;n<t.length;n++)if(t[n].distance===e){let s=t.splice(n,1);return this.remove(s[0].object),!0}return!1}getCurrentLevel(){return this._currentLevel}getObjectForDistance(e){let t=this.levels;if(t.length>0){let n,s;for(n=1,s=t.length;n<s;n++){let r=t[n].distance;if(t[n].object.visible&&(r-=r*t[n].hysteresis),e<r)break}return t[n-1].object}return null}raycast(e,t){if(this.levels.length>0){jc.setFromMatrixPosition(this.matrixWorld);let s=e.ray.origin.distanceTo(jc);this.getObjectForDistance(s).raycast(e,t)}}update(e){let t=this.levels;if(t.length>1){jc.setFromMatrixPosition(e.matrixWorld),Tm.setFromMatrixPosition(this.matrixWorld);let n=jc.distanceTo(Tm)/e.zoom;t[0].object.visible=!0;let s,r;for(s=1,r=t.length;s<r;s++){let o=t[s].distance;if(t[s].object.visible&&(o-=o*t[s].hysteresis),n>=o)t[s-1].object.visible=!1,t[s].object.visible=!0;else break}for(this._currentLevel=s-1;s<r;s++)t[s].object.visible=!1}}toJSON(e){let t=super.toJSON(e);t.object.autoUpdate=this.autoUpdate,t.object.levels=[];let n=this.levels;for(let s=0,r=n.length;s<r;s++){let o=n[s];t.object.levels.push({object:o.object.uuid,distance:o.distance,hysteresis:o.hysteresis})}return t}},cs=new A,Od=new A,Qc=new A,eh=new A,Fi=class{constructor(e=new A,t=new A(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,cs)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=cs.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(cs.copy(this.origin).addScaledVector(this.direction,t),cs.distanceToSquared(e))}distanceSqToSegment(e,t,n,s){Od.copy(e).add(t).multiplyScalar(.5),Qc.copy(t).sub(e).normalize(),eh.copy(this.origin).sub(Od);let r=e.distanceTo(t)*.5,o=-this.direction.dot(Qc),a=eh.dot(this.direction),l=-eh.dot(Qc),c=eh.lengthSq(),h=Math.abs(1-o*o),u,d,f,p;if(h>0)if(u=o*l-a,d=o*a-l,p=r*h,u>=0)if(d>=-p)if(d<=p){let _=1/h;u*=_,d*=_,f=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d=-r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d<=-p?(u=Math.max(0,-(-o*r+a)),d=u>0?-r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c):d<=p?(u=0,d=Math.min(Math.max(-r,-l),r),f=d*(d+2*l)+c):(u=Math.max(0,-(o*r+a)),d=u>0?r:Math.min(Math.max(-r,-l),r),f=-u*u+d*(d+2*l)+c);else d=o>0?-r:r,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),s&&s.copy(Od).addScaledVector(Qc,d),f}intersectSphere(e,t){if(e.radius<0)return null;cs.subVectors(e.center,this.origin);let n=cs.dot(this.direction),s=cs.dot(cs)-n*n,r=e.radius*e.radius;if(s>r)return null;let o=Math.sqrt(r-s),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,t):this.at(a,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,s,r,o,a,l,c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,s=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,s=(e.min.x-d.x)*c),h>=0?(r=(e.min.y-d.y)*h,o=(e.max.y-d.y)*h):(r=(e.max.y-d.y)*h,o=(e.min.y-d.y)*h),n>o||r>s||((r>n||isNaN(n))&&(n=r),(o<s||isNaN(s))&&(s=o),u>=0?(a=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(a=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),n>l||a>s)||((a>n||n!==n)&&(n=a),(l<s||s!==s)&&(s=l),s<0)?null:this.at(n>=0?n:s,t)}intersectsBox(e){return this.intersectBox(e,cs)!==null}intersectTriangle(e,t,n,s,r){let o=this.origin,a=this.direction,l=a.x,c=a.y,h=a.z,u=e.x-o.x,d=e.y-o.y,f=e.z-o.z,p=t.x-o.x,_=t.y-o.y,g=t.z-o.z,m=n.x-o.x,v=n.y-o.y,E=n.z-o.z,y=Math.abs(l),w=Math.abs(c),M=Math.abs(h),T,x,S,C,L,F,I,P,U,z,V,ie;if(y>=w&&y>=M?(S=l,F=u,U=p,ie=m,l>=0?(T=c,x=h,C=d,L=f,I=_,P=g,z=v,V=E):(T=h,x=c,C=f,L=d,I=g,P=_,z=E,V=v)):w>=M?(S=c,F=d,U=_,ie=v,c>=0?(T=h,x=l,C=f,L=u,I=g,P=p,z=E,V=m):(T=l,x=h,C=u,L=f,I=p,P=g,z=m,V=E)):(S=h,F=f,U=g,ie=E,h>=0?(T=l,x=c,C=u,L=d,I=p,P=_,z=m,V=v):(T=c,x=l,C=d,L=u,I=_,P=p,z=v,V=m)),S===0)return null;let $=T/S,se=x/S,te=1/S,Xe=C-$*F,Ue=L-se*F,Ge=I-$*U,He=P-se*U,rt=z-$*ie,j=V-se*ie,oe=rt*He-j*Ge,Ee=Xe*j-Ue*rt,ot=Ge*Ue-He*Xe;if(s){if(oe<0||Ee<0||ot<0)return null}else if((oe<0||Ee<0||ot<0)&&(oe>0||Ee>0||ot>0))return null;let Ne=oe+Ee+ot;if(Ne===0)return null;let lt=te*(oe*F+Ee*U+ot*ie);return(Ne>0?lt<0:lt>0)?null:this.at(lt/Ne,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Qe=class extends _n{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new q(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Gn,this.combine=Xo,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},wm=new nt,ir=new Fi,th=new gn,Rm=new A,nh=new A,ih=new A,sh=new A,Hd=new A,rh=new A,Am=new A,oh=new A,W=class extends _t{constructor(e=new ke,t=new Qe){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}getVertexPosition(e,t){let n=this.geometry,s=n.attributes.position,r=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(s,e);let a=this.morphTargetInfluences;if(r&&a){rh.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=a[l],u=r[l];h!==0&&(Hd.fromBufferAttribute(u,e),o?rh.addScaledVector(Hd,h):rh.addScaledVector(Hd.sub(t),h))}t.add(rh)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,s=this.material,r=this.matrixWorld;s!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),th.copy(n.boundingSphere),th.applyMatrix4(r),ir.copy(e.ray).recast(e.near),!(th.containsPoint(ir.origin)===!1&&(ir.intersectSphere(th,Rm)===null||ir.origin.distanceToSquared(Rm)>(e.far-e.near)**2))&&(wm.copy(r).invert(),ir.copy(e.ray).applyMatrix4(wm),!(n.boundingBox!==null&&ir.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,ir)))}_computeIntersections(e,t,n){let s,r=this.geometry,o=this.material,a=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,u=r.attributes.normal,d=r.groups,f=r.drawRange;if(a!==null)if(Array.isArray(o))for(let p=0,_=d.length;p<_;p++){let g=d[p],m=o[g.materialIndex],v=Math.max(g.start,f.start),E=Math.min(a.count,Math.min(g.start+g.count,f.start+f.count));for(let y=v,w=E;y<w;y+=3){let M=a.getX(y),T=a.getX(y+1),x=a.getX(y+2);s=ah(this,m,e,n,c,h,u,M,T,x),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=g.materialIndex,t.push(s))}}else{let p=Math.max(0,f.start),_=Math.min(a.count,f.start+f.count);for(let g=p,m=_;g<m;g+=3){let v=a.getX(g),E=a.getX(g+1),y=a.getX(g+2);s=ah(this,o,e,n,c,h,u,v,E,y),s&&(s.faceIndex=Math.floor(g/3),t.push(s))}}else if(l!==void 0)if(Array.isArray(o))for(let p=0,_=d.length;p<_;p++){let g=d[p],m=o[g.materialIndex],v=Math.max(g.start,f.start),E=Math.min(l.count,Math.min(g.start+g.count,f.start+f.count));for(let y=v,w=E;y<w;y+=3){let M=y,T=y+1,x=y+2;s=ah(this,m,e,n,c,h,u,M,T,x),s&&(s.faceIndex=Math.floor(y/3),s.face.materialIndex=g.materialIndex,t.push(s))}}else{let p=Math.max(0,f.start),_=Math.min(l.count,f.start+f.count);for(let g=p,m=_;g<m;g+=3){let v=g,E=g+1,y=g+2;s=ah(this,o,e,n,c,h,u,v,E,y),s&&(s.faceIndex=Math.floor(g/3),t.push(s))}}}};function Wx(i,e,t,n,s,r,o,a){let l;if(e.side===Ln?l=n.intersectTriangle(o,r,s,!0,a):l=n.intersectTriangle(s,r,o,e.side===zi,a),l===null)return null;oh.copy(a),oh.applyMatrix4(i.matrixWorld);let c=t.ray.origin.distanceTo(oh);return c<t.near||c>t.far?null:{distance:c,point:oh.clone(),object:i}}function ah(i,e,t,n,s,r,o,a,l,c){i.getVertexPosition(a,nh),i.getVertexPosition(l,ih),i.getVertexPosition(c,sh);let h=Wx(i,e,t,n,nh,ih,sh,Am);if(h){let u=new A;Li.getBarycoord(Am,nh,ih,sh,u),s&&(h.uv=Li.getInterpolatedAttribute(s,a,l,c,u,new J)),r&&(h.uv1=Li.getInterpolatedAttribute(r,a,l,c,u,new J)),o&&(h.normal=Li.getInterpolatedAttribute(o,a,l,c,u,new A),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));let d={a,b:l,c,normal:new A,materialIndex:0};Li.getNormal(nh,ih,sh,d.normal),h.face=d,h.barycoord=u}return h}var wa=new Ut,Cm=new Ut,Pm=new Ut,Xx=new Ut,Im=new nt,lh=new A,zd=new gn,Dm=new nt,kd=new Fi,$a=class extends W{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=Ih,this.bindMatrix=new nt,this.bindMatrixInverse=new nt,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){let e=this.geometry;this.boundingBox===null&&(this.boundingBox=new bn),this.boundingBox.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,lh),this.boundingBox.expandByPoint(lh)}computeBoundingSphere(){let e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new gn),this.boundingSphere.makeEmpty();let t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,lh),this.boundingSphere.expandByPoint(lh)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){let n=this.material,s=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),zd.copy(this.boundingSphere),zd.applyMatrix4(s),e.ray.intersectsSphere(zd)!==!1&&(Dm.copy(s).invert(),kd.copy(e.ray).applyMatrix4(Dm),!(this.boundingBox!==null&&kd.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,kd)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){let e=new Ut,t=this.geometry.attributes.skinWeight;for(let n=0,s=t.count;n<s;n++){e.fromBufferAttribute(t,n);let r=1/e.manhattanLength();r!==1/0?e.multiplyScalar(r):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===Ih?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===Of?this.bindMatrixInverse.copy(this.bindMatrix).invert():be("SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){let n=this.skeleton,s=this.geometry;Cm.fromBufferAttribute(s.attributes.skinIndex,e),Pm.fromBufferAttribute(s.attributes.skinWeight,e),t.isVector4?(wa.copy(t),t.set(0,0,0,0)):(wa.set(...t,1),t.set(0,0,0)),wa.applyMatrix4(this.bindMatrix);for(let r=0;r<4;r++){let o=Pm.getComponent(r);if(o!==0){let a=Cm.getComponent(r);Im.multiplyMatrices(n.bones[a].matrixWorld,n.boneInverses[a]),t.addScaledVector(Xx.copy(wa).applyMatrix4(Im),o)}}return t.isVector4&&(t.w=wa.w),t.applyMatrix4(this.bindMatrixInverse)}},wo=class extends _t{constructor(){super(),this.isBone=!0,this.type="Bone"}},Un=class extends an{constructor(e=null,t=1,n=1,s,r,o,a,l,c=jt,h=jt,u,d){super(null,o,a,l,c,h,s,r,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},Lm=new nt,Yx=new nt,ja=class i{constructor(e=[],t=[]){this.uuid=fi(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){let e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){be("Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,s=this.bones.length;n<s;n++)this.boneInverses.push(new nt)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){let n=new nt;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){let n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){let e=this.bones,t=this.boneInverses,n=this.boneMatrices,s=this.boneTexture;for(let r=0,o=e.length;r<o;r++){let a=e[r]?e[r].matrixWorld:Yx;Lm.multiplyMatrices(a,t[r]),Lm.toArray(n,r*16)}s!==null&&(s.needsUpdate=!0)}clone(){return new i(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);let t=new Float32Array(e*e*4);t.set(this.boneMatrices);let n=new Un(t,e,e,In,kn);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){let s=this.bones[t];if(s.name===e)return s}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,s=e.bones.length;n<s;n++){let r=e.bones[n],o=t[r];o===void 0&&(be("Skeleton: No bone found with UUID:",r),o=new wo),this.bones.push(o),this.boneInverses.push(new nt().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){let e={metadata:{version:4.7,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;let t=this.bones,n=this.boneInverses;for(let s=0,r=t.length;s<r;s++){let o=t[s];e.bones.push(o.uuid);let a=n[s];e.boneInverses.push(a.toArray())}return e}},Zi=class extends bt{constructor(e,t,n,s=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},ao=new nt,Nm=new nt,ch=[],Um=new bn,qx=new nt,Ra=new W,Aa=new gn,En=class extends W{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Zi(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let s=0;s<n;s++)this.setMatrixAt(s,qx)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new bn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,ao),Um.copy(e.boundingBox).applyMatrix4(ao),this.boundingBox.union(Um)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new gn),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,ao),Aa.copy(e.boundingSphere).applyMatrix4(ao),this.boundingSphere.union(Aa)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){let n=t.morphTargetInfluences,s=this.morphTexture.source.data.data,r=n.length+1,o=e*r+1;for(let a=0;a<n.length;a++)n[a]=s[o+a]}raycast(e,t){let n=this.matrixWorld,s=this.count;if(Ra.geometry=this.geometry,Ra.material=this.material,Ra.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Aa.copy(this.boundingSphere),Aa.applyMatrix4(n),e.ray.intersectsSphere(Aa)!==!1))for(let r=0;r<s;r++){this.getMatrixAt(r,ao),Nm.multiplyMatrices(n,ao),Ra.matrixWorld=Nm,Ra.raycast(e,ch);for(let o=0,a=ch.length;o<a;o++){let l=ch[o];l.instanceId=r,l.object=this,t.push(l)}ch.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new Zi(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){let n=t.morphTargetInfluences,s=n.length+1;this.morphTexture===null&&(this.morphTexture=new Un(new Float32Array(s*this.count),s,this.count,Xl,kn));let r=this.morphTexture.source.data.data,o=0;for(let c=0;c<n.length;c++)o+=n[c];let a=this.geometry.morphTargetsRelative?1:1-o,l=s*e;return r[l]=a,r.set(n,l+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}},sr=new gn,Zx=new J(.5,.5),hh=new A,Ji=class{constructor(e=new ii,t=new ii,n=new ii,s=new ii,r=new ii,o=new ii){this.planes=[e,t,n,s,r,o]}set(e,t,n,s,r,o){let a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(s),a[4].copy(r),a[5].copy(o),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=si,n=!1){let s=this.planes,r=e.elements,o=r[0],a=r[1],l=r[2],c=r[3],h=r[4],u=r[5],d=r[6],f=r[7],p=r[8],_=r[9],g=r[10],m=r[11],v=r[12],E=r[13],y=r[14],w=r[15];if(s[0].setComponents(c-o,f-h,m-p,w-v).normalize(),s[1].setComponents(c+o,f+h,m+p,w+v).normalize(),s[2].setComponents(c+a,f+u,m+_,w+E).normalize(),s[3].setComponents(c-a,f-u,m-_,w-E).normalize(),n)s[4].setComponents(l,d,g,y).normalize(),s[5].setComponents(c-l,f-d,m-g,w-y).normalize();else if(s[4].setComponents(c-l,f-d,m-g,w-y).normalize(),t===si)s[5].setComponents(c+l,f+d,m+g,w+y).normalize();else if(t===zs)s[5].setComponents(l,d,g,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),sr.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),sr.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(sr)}intersectsSprite(e){sr.center.set(0,0,0);let t=Zx.distanceTo(e.center);return sr.radius=.7071067811865476+t,sr.applyMatrix4(e.matrixWorld),this.intersectsSphere(sr)}intersectsSphere(e){let t=this.planes,n=e.center,s=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(n)<s)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let s=t[n];if(hh.x=s.normal.x>0?e.max.x:e.min.x,hh.y=s.normal.y>0?e.max.y:e.min.y,hh.z=s.normal.z>0?e.max.z:e.min.z,s.distanceToPoint(hh)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}},Fm=new nt,Qa=class i{constructor(){this.coordinateSystem=si,this._frustums=[],this._count=0}setFromArrayCamera(e){let t=e.cameras,n=this._frustums;for(let s=0;s<t.length;s++){let r=t[s];Fm.multiplyMatrices(r.projectionMatrix,r.matrixWorldInverse),n[s]===void 0&&(n[s]=new Ji),n[s].setFromProjectionMatrix(Fm,r.coordinateSystem,r.reversedDepth)}return this._count=t.length,this}intersectsObject(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsObject(e))return!0;return!1}intersectsSprite(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSprite(e))return!0;return!1}intersectsSphere(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsSphere(e))return!0;return!1}intersectsBox(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].intersectsBox(e))return!0;return!1}containsPoint(e){let t=this._frustums;for(let n=0;n<this._count;n++)if(t[n].containsPoint(e))return!0;return!1}copy(e){this.coordinateSystem=e.coordinateSystem;let t=this._frustums,n=e._frustums;for(let s=0;s<e._count;s++)t[s]===void 0&&(t[s]=new Ji),t[s].copy(n[s]);return this._count=e._count,this}clone(){return new i().copy(this)}};function Gd(i,e){return i-e}function Jx(i,e){return i.z-e.z}function Kx(i,e){return e.z-i.z}var nf=class{constructor(){this.index=0,this.pool=[],this.list=[]}push(e,t,n,s){let r=this.pool,o=this.list;this.index>=r.length&&r.push({start:-1,count:-1,z:-1,index:-1});let a=r[this.index];o.push(a),this.index++,a.start=e,a.count=t,a.z=n,a.index=s}reset(){this.list.length=0,this.index=0}},ti=new nt,$x=new q(1,1,1),jx=new Ji,Qx=new Qa,uh=new bn,rr=new gn,Ca=new A,Bm=new A,ev=new A,Vd=new nf,zn=new W,dh=[];function tv(i,e,t=0){let n=e.itemSize;if(i.isInterleavedBufferAttribute||i.array.constructor!==e.array.constructor){let s=i.count;for(let r=0;r<s;r++)for(let o=0;o<n;o++)e.setComponent(r+t,o,i.getComponent(r,o))}else e.array.set(i.array,t*n);e.needsUpdate=!0}function or(i,e){if(i.constructor!==e.constructor){let t=Math.min(i.length,e.length);for(let n=0;n<t;n++)e[n]=i[n]}else{let t=Math.min(i.length,e.length);e.set(new i.constructor(i.buffer,0,t))}}var el=class extends W{constructor(e,t,n=t*2,s){super(new ke,s),this.isBatchedMesh=!0,this.perObjectFrustumCulled=!0,this.sortObjects=!0,this.boundingBox=null,this.boundingSphere=null,this.customSort=null,this._instanceInfo=[],this._geometryInfo=[],this._availableInstanceIds=[],this._availableGeometryIds=[],this._nextIndexStart=0,this._nextVertexStart=0,this._geometryCount=0,this._visibilityChanged=!0,this._geometryInitialized=!1,this._maxInstanceCount=e,this._maxVertexCount=t,this._maxIndexCount=n,this._multiDrawCounts=new Int32Array(e),this._multiDrawStarts=new Int32Array(e),this._multiDrawCount=0,this._multiDrawBytesPerElement=1,this._matricesTexture=null,this._indirectTexture=null,this._colorsTexture=null,this._initMatricesTexture(),this._initIndirectTexture()}get maxInstanceCount(){return this._maxInstanceCount}get instanceCount(){return this._instanceInfo.length-this._availableInstanceIds.length}get unusedVertexCount(){return this._maxVertexCount-this._nextVertexStart}get unusedIndexCount(){return this._maxIndexCount-this._nextIndexStart}_initMatricesTexture(){let e=Math.sqrt(this._maxInstanceCount*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);let t=new Float32Array(e*e*4),n=new Un(t,e,e,In,kn);this._matricesTexture=n}_initIndirectTexture(){let e=Math.sqrt(this._maxInstanceCount);e=Math.ceil(e);let t=new Uint32Array(e*e),n=new Un(t,e,e,ea,_i);this._indirectTexture=n}_initColorsTexture(){let e=Math.sqrt(this._maxInstanceCount);e=Math.ceil(e);let t=new Float32Array(e*e*4).fill(1),n=new Un(t,e,e,In,kn);n.colorSpace=Mt.workingColorSpace,this._colorsTexture=n}_initializeGeometry(e){let t=this.geometry,n=this._maxVertexCount,s=this._maxIndexCount;if(this._geometryInitialized===!1){for(let r in e.attributes){let o=e.getAttribute(r),{array:a,itemSize:l,normalized:c}=o,h=new a.constructor(n*l),u=new bt(h,l,c);t.setAttribute(r,u)}if(e.getIndex()!==null){let r=n>65535?new Uint32Array(s):new Uint16Array(s);t.setIndex(new bt(r,1))}this._geometryInitialized=!0}}_validateGeometry(e){let t=this.geometry;if(!!e.getIndex()!=!!t.getIndex())throw new Error('THREE.BatchedMesh: All geometries must consistently have "index".');for(let n in t.attributes){if(!e.hasAttribute(n))throw new Error(`THREE.BatchedMesh: Added geometry missing "${n}". All geometries must have consistent attributes.`);let s=e.getAttribute(n),r=t.getAttribute(n);if(s.itemSize!==r.itemSize||s.normalized!==r.normalized)throw new Error("THREE.BatchedMesh: All attributes must have a consistent itemSize and normalized value.")}}validateInstanceId(e){let t=this._instanceInfo;if(e<0||e>=t.length||t[e].active===!1)throw new Error(`THREE.BatchedMesh: Invalid instanceId ${e}. Instance is either out of range or has been deleted.`)}validateGeometryId(e){let t=this._geometryInfo;if(e<0||e>=t.length||t[e].active===!1)throw new Error(`THREE.BatchedMesh: Invalid geometryId ${e}. Geometry is either out of range or has been deleted.`)}setCustomSort(e){return this.customSort=e,this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new bn);let e=this.boundingBox,t=this._instanceInfo;e.makeEmpty();for(let n=0,s=t.length;n<s;n++){if(t[n].active===!1)continue;let r=t[n].geometryIndex;this.getMatrixAt(n,ti),this.getBoundingBoxAt(r,uh).applyMatrix4(ti),e.union(uh)}}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new gn);let e=this.boundingSphere,t=this._instanceInfo;e.makeEmpty();for(let n=0,s=t.length;n<s;n++){if(t[n].active===!1)continue;let r=t[n].geometryIndex;this.getMatrixAt(n,ti),this.getBoundingSphereAt(r,rr).applyMatrix4(ti),e.union(rr)}}addInstance(e){if(this._instanceInfo.length>=this.maxInstanceCount&&this._availableInstanceIds.length===0)throw new Error("THREE.BatchedMesh: Maximum item count reached.");let n={visible:!0,active:!0,geometryIndex:e},s=null;this._availableInstanceIds.length>0?(this._availableInstanceIds.sort(Gd),s=this._availableInstanceIds.shift(),this._instanceInfo[s]=n):(s=this._instanceInfo.length,this._instanceInfo.push(n));let r=this._matricesTexture;ti.identity().toArray(r.image.data,s*16),r.needsUpdate=!0;let o=this._colorsTexture;return o&&($x.toArray(o.image.data,s*4),o.needsUpdate=!0),this._visibilityChanged=!0,s}addGeometry(e,t=-1,n=-1){this._initializeGeometry(e),this._validateGeometry(e);let s={vertexStart:-1,vertexCount:-1,reservedVertexCount:-1,indexStart:-1,indexCount:-1,reservedIndexCount:-1,start:-1,count:-1,boundingBox:null,boundingSphere:null,active:!0},r=this._geometryInfo;s.vertexStart=this._nextVertexStart,s.reservedVertexCount=t===-1?e.getAttribute("position").count:t;let o=e.getIndex();if(o!==null&&(s.indexStart=this._nextIndexStart,s.reservedIndexCount=n===-1?o.count:n),s.indexStart!==-1&&s.indexStart+s.reservedIndexCount>this._maxIndexCount||s.vertexStart+s.reservedVertexCount>this._maxVertexCount)throw new Error("THREE.BatchedMesh: Reserved space request exceeds the maximum buffer size.");let l;return this._availableGeometryIds.length>0?(this._availableGeometryIds.sort(Gd),l=this._availableGeometryIds.shift(),r[l]=s):(l=this._geometryCount,this._geometryCount++,r.push(s)),this.setGeometryAt(l,e),this._nextIndexStart=s.indexStart+s.reservedIndexCount,this._nextVertexStart=s.vertexStart+s.reservedVertexCount,l}setGeometryAt(e,t){if(e>=this._geometryCount)throw new Error("THREE.BatchedMesh: Maximum geometry count reached.");this._validateGeometry(t);let n=this.geometry,s=n.getIndex()!==null,r=n.getIndex(),o=t.getIndex(),a=this._geometryInfo[e];if(s&&o.count>a.reservedIndexCount||t.attributes.position.count>a.reservedVertexCount)throw new Error("THREE.BatchedMesh: Reserved space not large enough for provided geometry.");let l=a.vertexStart,c=a.reservedVertexCount;a.vertexCount=t.getAttribute("position").count;for(let h in n.attributes){let u=t.getAttribute(h),d=n.getAttribute(h);tv(u,d,l);let f=u.itemSize;for(let p=u.count,_=c;p<_;p++){let g=l+p;for(let m=0;m<f;m++)d.setComponent(g,m,0)}d.needsUpdate=!0,d.addUpdateRange(l*f,c*f)}if(s){let h=a.indexStart,u=a.reservedIndexCount;a.indexCount=t.getIndex().count;for(let d=0;d<o.count;d++)r.setX(h+d,l+o.getX(d));for(let d=o.count,f=u;d<f;d++)r.setX(h+d,l);r.needsUpdate=!0,r.addUpdateRange(h,a.reservedIndexCount)}return a.start=s?a.indexStart:a.vertexStart,a.count=s?a.indexCount:a.vertexCount,a.boundingBox=null,t.boundingBox!==null&&(a.boundingBox=t.boundingBox.clone()),a.boundingSphere=null,t.boundingSphere!==null&&(a.boundingSphere=t.boundingSphere.clone()),this._visibilityChanged=!0,e}deleteGeometry(e){let t=this._geometryInfo;if(e>=t.length||t[e].active===!1)return this;let n=this._instanceInfo;for(let s=0,r=n.length;s<r;s++)n[s].active&&n[s].geometryIndex===e&&this.deleteInstance(s);return t[e].active=!1,this._availableGeometryIds.push(e),this._visibilityChanged=!0,this}deleteInstance(e){return this.validateInstanceId(e),this._instanceInfo[e].active=!1,this._availableInstanceIds.push(e),this._visibilityChanged=!0,this}optimize(){let e=0,t=0,n=this._geometryInfo,s=n.map((o,a)=>a).sort((o,a)=>n[o].vertexStart-n[a].vertexStart),r=this.geometry;for(let o=0,a=n.length;o<a;o++){let l=s[o],c=n[l];if(c.active!==!1){if(r.index!==null){if(c.indexStart!==t){let{indexStart:h,vertexStart:u,reservedIndexCount:d}=c,f=r.index,p=f.array,_=e-u;for(let g=h;g<h+d;g++)p[g]=p[g]+_;f.array.copyWithin(t,h,h+d),f.addUpdateRange(t,d),f.needsUpdate=!0,c.indexStart=t}t+=c.reservedIndexCount}if(c.vertexStart!==e){let{vertexStart:h,reservedVertexCount:u}=c,d=r.attributes;for(let f in d){let p=d[f],{array:_,itemSize:g}=p;_.copyWithin(e*g,h*g,(h+u)*g),p.addUpdateRange(e*g,u*g),p.needsUpdate=!0}c.vertexStart=e}e+=c.reservedVertexCount,c.start=r.index?c.indexStart:c.vertexStart}}return this._nextIndexStart=t,this._nextVertexStart=e,this._visibilityChanged=!0,this}getBoundingBoxAt(e,t){if(e>=this._geometryCount)return null;let n=this.geometry,s=this._geometryInfo[e];if(s.boundingBox===null){let r=new bn,o=n.index,a=n.attributes.position;for(let l=s.start,c=s.start+s.count;l<c;l++){let h=l;o&&(h=o.getX(h)),r.expandByPoint(Ca.fromBufferAttribute(a,h))}s.boundingBox=r}return t.copy(s.boundingBox),t}getBoundingSphereAt(e,t){if(e>=this._geometryCount)return null;let n=this.geometry,s=this._geometryInfo[e];if(s.boundingSphere===null){let r=new gn;this.getBoundingBoxAt(e,uh),uh.getCenter(r.center);let o=n.index,a=n.attributes.position,l=0;for(let c=s.start,h=s.start+s.count;c<h;c++){let u=c;o&&(u=o.getX(u)),Ca.fromBufferAttribute(a,u),l=Math.max(l,r.center.distanceToSquared(Ca))}r.radius=Math.sqrt(l),s.boundingSphere=r}return t.copy(s.boundingSphere),t}setMatrixAt(e,t){this.validateInstanceId(e);let n=this._matricesTexture,s=this._matricesTexture.image.data;return t.toArray(s,e*16),n.needsUpdate=!0,this}getMatrixAt(e,t){return this.validateInstanceId(e),t.fromArray(this._matricesTexture.image.data,e*16)}setColorAt(e,t){return this.validateInstanceId(e),this._colorsTexture===null&&this._initColorsTexture(),t.toArray(this._colorsTexture.image.data,e*4),this._colorsTexture.needsUpdate=!0,this}getColorAt(e,t){return this.validateInstanceId(e),this._colorsTexture===null?t.isVector4?t.set(1,1,1,1):t.setRGB(1,1,1):t.fromArray(this._colorsTexture.image.data,e*4)}setVisibleAt(e,t){return this.validateInstanceId(e),this._instanceInfo[e].visible===t?this:(this._instanceInfo[e].visible=t,this._visibilityChanged=!0,this)}getVisibleAt(e){return this.validateInstanceId(e),this._instanceInfo[e].visible}setGeometryIdAt(e,t){return this.validateInstanceId(e),this.validateGeometryId(t),this._instanceInfo[e].geometryIndex=t,this._visibilityChanged=!0,this}getGeometryIdAt(e){return this.validateInstanceId(e),this._instanceInfo[e].geometryIndex}getGeometryRangeAt(e,t={}){this.validateGeometryId(e);let n=this._geometryInfo[e];return t.vertexStart=n.vertexStart,t.vertexCount=n.vertexCount,t.reservedVertexCount=n.reservedVertexCount,t.indexStart=n.indexStart,t.indexCount=n.indexCount,t.reservedIndexCount=n.reservedIndexCount,t.start=n.start,t.count=n.count,t}setInstanceCount(e){let t=this._availableInstanceIds,n=this._instanceInfo;for(t.sort(Gd);t[t.length-1]===n.length-1;)n.pop(),t.pop();if(e<n.length)throw new Error(`THREE.BatchedMesh: Instance ids outside the range ${e} are being used. Cannot shrink instance count.`);let s=new Int32Array(e),r=new Int32Array(e);or(this._multiDrawCounts,s),or(this._multiDrawStarts,r),this._multiDrawCounts=s,this._multiDrawStarts=r,this._maxInstanceCount=e;let o=this._indirectTexture,a=this._matricesTexture,l=this._colorsTexture;o.dispose(),this._initIndirectTexture(),or(o.image.data,this._indirectTexture.image.data),a.dispose(),this._initMatricesTexture(),or(a.image.data,this._matricesTexture.image.data),l&&(l.dispose(),this._initColorsTexture(),or(l.image.data,this._colorsTexture.image.data))}setGeometrySize(e,t){let n=[...this._geometryInfo].filter(a=>a.active);if(Math.max(...n.map(a=>a.vertexStart+a.reservedVertexCount))>e)throw new Error(`THREE.BatchedMesh: Geometry vertex values are being used outside the range ${t}. Cannot shrink further.`);if(this.geometry.index&&Math.max(...n.map(l=>l.indexStart+l.reservedIndexCount))>t)throw new Error(`THREE.BatchedMesh: Geometry index values are being used outside the range ${t}. Cannot shrink further.`);let r=this.geometry;r.dispose(),this._maxVertexCount=e,this._maxIndexCount=t,this._geometryInitialized&&(this._geometryInitialized=!1,this.geometry=new ke,this._initializeGeometry(r));let o=this.geometry;r.index&&or(r.index.array,o.index.array);for(let a in r.attributes)or(r.attributes[a].array,o.attributes[a].array)}raycast(e,t){let n=this._instanceInfo,s=this._geometryInfo,r=this.matrixWorld,o=this.geometry;zn.material=this.material,zn.geometry.index=o.index,zn.geometry.attributes=o.attributes,zn.geometry.boundingBox===null&&(zn.geometry.boundingBox=new bn),zn.geometry.boundingSphere===null&&(zn.geometry.boundingSphere=new gn);for(let a=0,l=n.length;a<l;a++){if(!n[a].visible||!n[a].active)continue;let c=n[a].geometryIndex,h=s[c];zn.geometry.setDrawRange(h.start,h.count),this.getMatrixAt(a,zn.matrixWorld).premultiply(r),this.getBoundingBoxAt(c,zn.geometry.boundingBox),this.getBoundingSphereAt(c,zn.geometry.boundingSphere),zn.raycast(e,dh);for(let u=0,d=dh.length;u<d;u++){let f=dh[u];f.object=this,f.batchId=a,t.push(f)}dh.length=0}zn.material=null,zn.geometry.index=null,zn.geometry.attributes={},zn.geometry.setDrawRange(0,1/0)}copy(e){return super.copy(e),this.geometry=e.geometry.clone(),this.perObjectFrustumCulled=e.perObjectFrustumCulled,this.sortObjects=e.sortObjects,this.boundingBox=e.boundingBox!==null?e.boundingBox.clone():null,this.boundingSphere=e.boundingSphere!==null?e.boundingSphere.clone():null,this._geometryInfo=e._geometryInfo.map(t=>({...t,boundingBox:t.boundingBox!==null?t.boundingBox.clone():null,boundingSphere:t.boundingSphere!==null?t.boundingSphere.clone():null})),this._instanceInfo=e._instanceInfo.map(t=>({...t})),this._availableInstanceIds=e._availableInstanceIds.slice(),this._availableGeometryIds=e._availableGeometryIds.slice(),this._nextIndexStart=e._nextIndexStart,this._nextVertexStart=e._nextVertexStart,this._geometryCount=e._geometryCount,this._maxInstanceCount=e._maxInstanceCount,this._maxVertexCount=e._maxVertexCount,this._maxIndexCount=e._maxIndexCount,this._geometryInitialized=e._geometryInitialized,this._multiDrawCounts=e._multiDrawCounts.slice(),this._multiDrawStarts=e._multiDrawStarts.slice(),this._multiDrawBytesPerElement=e._multiDrawBytesPerElement,this._indirectTexture=e._indirectTexture.clone(),this._indirectTexture.image.data=this._indirectTexture.image.data.slice(),this._matricesTexture=e._matricesTexture.clone(),this._matricesTexture.image.data=this._matricesTexture.image.data.slice(),this._colorsTexture!==null&&(this._colorsTexture=e._colorsTexture.clone(),this._colorsTexture.image.data=this._colorsTexture.image.data.slice()),this}dispose(){super.dispose(),this.geometry.dispose(),this._matricesTexture.dispose(),this._matricesTexture=null,this._indirectTexture.dispose(),this._indirectTexture=null,this._colorsTexture!==null&&(this._colorsTexture.dispose(),this._colorsTexture=null)}onBeforeRender(e,t,n,s,r){if(!this._visibilityChanged&&!this.perObjectFrustumCulled&&!this.sortObjects)return;let o=s.getIndex(),a=o===null?1:o.array.BYTES_PER_ELEMENT,l=1;r.wireframe&&(l=2,a=s.attributes.position.count>65535?4:2);let c=this._instanceInfo,h=this._multiDrawStarts,u=this._multiDrawCounts,d=this._geometryInfo,f=this.perObjectFrustumCulled,p=this._indirectTexture,_=p.image.data,g=n.isArrayCamera?Qx:jx;f&&(n.isArrayCamera?g.setFromArrayCamera(n):(ti.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse).multiply(this.matrixWorld),g.setFromProjectionMatrix(ti,n.coordinateSystem,n.reversedDepth)));let m=0;if(this.sortObjects){ti.copy(this.matrixWorld).invert(),Ca.setFromMatrixPosition(n.matrixWorld).applyMatrix4(ti),Bm.set(0,0,-1).transformDirection(n.matrixWorld).transformDirection(ti);for(let y=0,w=c.length;y<w;y++)if(c[y].visible&&c[y].active){let M=c[y].geometryIndex;this.getMatrixAt(y,ti),this.getBoundingSphereAt(M,rr).applyMatrix4(ti);let T=!1;if(f&&(T=!g.intersectsSphere(rr)),!T){let x=d[M],S=ev.subVectors(rr.center,Ca).dot(Bm);Vd.push(x.start,x.count,S,y)}}let v=Vd.list,E=this.customSort;E===null?v.sort(r.transparent?Kx:Jx):E.call(this,v,n);for(let y=0,w=v.length;y<w;y++){let M=v[y];h[m]=M.start*a*l,u[m]=M.count*l,_[m]=M.index,m++}Vd.reset()}else for(let v=0,E=c.length;v<E;v++)if(c[v].visible&&c[v].active){let y=c[v].geometryIndex,w=!1;if(f&&(this.getMatrixAt(v,ti),this.getBoundingSphereAt(y,rr).applyMatrix4(ti),w=!g.intersectsSphere(rr)),!w){let M=d[y];h[m]=M.start*a*l,u[m]=M.count*l,_[m]=v,m++}}p.needsUpdate=!0,this._multiDrawCount=m,this._multiDrawBytesPerElement=a,this._visibilityChanged=!1}onBeforeShadow(e,t,n,s,r,o){this.onBeforeRender(e,null,s,r,o)}},tn=class extends _n{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new q(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},Vh=new A,Wh=new A,Om=new nt,Pa=new Fi,fh=new gn,Wd=new A,Hm=new A,Bi=class extends _t{constructor(e=new ke,t=new tn){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let s=1,r=t.count;s<r;s++)Vh.fromBufferAttribute(t,s-1),Wh.fromBufferAttribute(t,s),n[s]=n[s-1],n[s]+=Vh.distanceTo(Wh);e.setAttribute("lineDistance",new _e(n,1))}else be("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,s=this.matrixWorld,r=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),fh.copy(n.boundingSphere),fh.applyMatrix4(s),fh.radius+=r,e.ray.intersectsSphere(fh)===!1)return;Om.copy(s).invert(),Pa.copy(e.ray).applyMatrix4(Om);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){let f=Math.max(0,o.start),p=Math.min(h.count,o.start+o.count);for(let _=f,g=p-1;_<g;_+=c){let m=h.getX(_),v=h.getX(_+1),E=ph(this,e,Pa,l,m,v,_);E&&t.push(E)}if(this.isLineLoop){let _=h.getX(p-1),g=h.getX(f),m=ph(this,e,Pa,l,_,g,p-1);m&&t.push(m)}}else{let f=Math.max(0,o.start),p=Math.min(d.count,o.start+o.count);for(let _=f,g=p-1;_<g;_+=c){let m=ph(this,e,Pa,l,_,_+1,_);m&&t.push(m)}if(this.isLineLoop){let _=ph(this,e,Pa,l,p-1,f,p-1);_&&t.push(_)}}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function ph(i,e,t,n,s,r,o){let a=i.geometry.attributes.position;if(Vh.fromBufferAttribute(a,s),Wh.fromBufferAttribute(a,r),t.distanceSqToSegment(Vh,Wh,Wd,Hm)>n)return;Wd.applyMatrix4(i.matrixWorld);let c=e.ray.origin.distanceTo(Wd);if(!(c<e.near||c>e.far))return{distance:c,point:Hm.clone().applyMatrix4(i.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:i}}var zm=new A,km=new A,Sn=class extends Bi{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let s=0,r=t.count;s<r;s+=2)zm.fromBufferAttribute(t,s),km.fromBufferAttribute(t,s+1),n[s]=s===0?0:n[s-1],n[s+1]=n[s]+zm.distanceTo(km);e.setAttribute("lineDistance",new _e(n,1))}else be("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}},tl=class extends Bi{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}},ps=class extends _n{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new q(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Gm=new nt,sf=new Fi,mh=new gn,gh=new A,ms=class extends _t{constructor(e=new ke,t=new ps){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,s=this.matrixWorld,r=e.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),mh.copy(n.boundingSphere),mh.applyMatrix4(s),mh.radius+=r,e.ray.intersectsSphere(mh)===!1)return;Gm.copy(s).invert(),sf.copy(e.ray).applyMatrix4(Gm);let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=n.index,u=n.attributes.position;if(c!==null){let d=Math.max(0,o.start),f=Math.min(c.count,o.start+o.count);for(let p=d,_=f;p<_;p++){let g=c.getX(p);gh.fromBufferAttribute(u,g),Vm(gh,g,l,s,e,t,this)}}else{let d=Math.max(0,o.start),f=Math.min(u.count,o.start+o.count);for(let p=d,_=f;p<_;p++)gh.fromBufferAttribute(u,p),Vm(gh,p,l,s,e,t,this)}}updateMorphTargets(){let t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){let s=t[n[0]];if(s!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let r=0,o=s.length;r<o;r++){let a=s[r].name||String(r);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=r}}}}};function Vm(i,e,t,n,s,r,o){let a=sf.distanceSqToPoint(i);if(a<t){let l=new A;sf.closestPointToPoint(i,l),l.applyMatrix4(n);let c=s.ray.origin.distanceTo(l);if(c<s.near||c>s.far)return;r.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:o})}}var nl=class extends an{constructor(e,t,n,s,r=Xt,o=Xt,a,l,c){super(e,t,n,s,r,o,a,l,c),this.isVideoTexture=!0,this.generateMipmaps=!1,this._requestVideoFrameCallbackId=0;let h=this;function u(){h.needsUpdate=!0,h._requestVideoFrameCallbackId=e.requestVideoFrameCallback(u)}"requestVideoFrameCallback"in e&&(this._requestVideoFrameCallbackId=e.requestVideoFrameCallback(u))}clone(){return new this.constructor(this.image).copy(this)}update(){let e=this.image;"requestVideoFrameCallback"in e===!1&&e.readyState>=e.HAVE_CURRENT_DATA&&(this.needsUpdate=!0)}dispose(){this._requestVideoFrameCallbackId!==0&&(this.source.data.cancelVideoFrameCallback(this._requestVideoFrameCallbackId),this._requestVideoFrameCallbackId=0),super.dispose()}},Xh=class extends nl{constructor(e,t,n,s,r,o,a,l){super({},e,t,n,s,r,o,a,l),this.isVideoFrameTexture=!0}update(){}clone(){return new this.constructor().copy(this)}setFrame(e){this.image=e,this.needsUpdate=!0}},Yh=class extends an{constructor(e,t){super({width:e,height:t}),this.isFramebufferTexture=!0,this.magFilter=jt,this.minFilter=jt,this.generateMipmaps=!1,this.needsUpdate=!0}},Mr=class extends an{constructor(e,t,n,s,r,o,a,l,c,h,u,d){super(null,o,a,l,c,h,s,r,u,d),this.isCompressedTexture=!0,this.image={width:t,height:n},this.mipmaps=e,this.flipY=!1,this.generateMipmaps=!1}},qh=class extends Mr{constructor(e,t,n,s,r,o){super(e,t,n,r,o),this.isCompressedArrayTexture=!0,this.image.depth=s,this.wrapR=$n,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}},Zh=class extends Mr{constructor(e,t,n){super(void 0,e[0].width,e[0].height,t,n,ki),this.isCompressedCubeTexture=!0,this.isCubeTexture=!0,this.image=e}},Vs=class extends an{constructor(e=[],t=ki,n,s,r,o,a,l,c,h){super(e,t,n,s,r,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},pi=class extends an{constructor(e,t,n,s,r,o,a,l,c){super(e,t,n,s,r,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Jh=class extends an{constructor(e,t,n,s,r,o,a,l,c){super(e,t,n,s,r,o,a,l,c),this.isHTMLTexture=!0,this.generateMipmaps=!1,this.needsUpdate=!0;let h=e?e.parentNode:null;h!==null&&"requestPaint"in h&&(h.onpaint=()=>{this.needsUpdate=!0},h.requestPaint())}dispose(){let e=this.image?this.image.parentNode:null;e!==null&&"onpaint"in e&&(e.onpaint=null),super.dispose()}},gs=class extends an{constructor(e,t,n=_i,s,r,o,a=jt,l=jt,c,h=Ui,u=1){if(h!==Ui&&h!==Ts)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");let d={width:e,height:t,depth:u};super(d,s,r,o,a,l,h,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new bi(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}},il=class extends gs{constructor(e,t=_i,n=ki,s,r,o=jt,a=jt,l,c=Ui){let h={width:e,height:e,depth:1},u=[h,h,h,h,h,h];super(e,e,t,n,s,r,o,a,l,c),this.image=u,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}},Ro=class extends an{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}},mi=class i extends ke{constructor(e=1,t=1,n=1,s=1,r=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:s,heightSegments:r,depthSegments:o};let a=this;s=Math.floor(s),r=Math.floor(r),o=Math.floor(o);let l=[],c=[],h=[],u=[],d=0,f=0;p("z","y","x",-1,-1,n,t,e,o,r,0),p("z","y","x",1,-1,n,t,-e,o,r,1),p("x","z","y",1,1,e,n,t,s,o,2),p("x","z","y",1,-1,e,n,-t,s,o,3),p("x","y","z",1,-1,e,t,n,s,r,4),p("x","y","z",-1,-1,e,t,-n,s,r,5),this.setIndex(l),this.setAttribute("position",new _e(c,3)),this.setAttribute("normal",new _e(h,3)),this.setAttribute("uv",new _e(u,2));function p(_,g,m,v,E,y,w,M,T,x,S){let C=y/T,L=w/x,F=y/2,I=w/2,P=M/2,U=T+1,z=x+1,V=0,ie=0,$=new A;for(let se=0;se<z;se++){let te=se*L-I;for(let Xe=0;Xe<U;Xe++){let Ue=Xe*C-F;$[_]=Ue*v,$[g]=te*E,$[m]=P,c.push($.x,$.y,$.z),$[_]=0,$[g]=0,$[m]=M>0?1:-1,h.push($.x,$.y,$.z),u.push(Xe/T),u.push(1-se/x),V+=1}}for(let se=0;se<x;se++)for(let te=0;te<T;te++){let Xe=d+te+U*se,Ue=d+te+U*(se+1),Ge=d+(te+1)+U*(se+1),He=d+(te+1)+U*se;l.push(Xe,Ue,He),l.push(Ue,Ge,He),ie+=6}a.addGroup(f,ie,S),f+=ie,d+=V}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}},sl=class i extends ke{constructor(e=1,t=1,n=4,s=8,r=1){super(),this.type="CapsuleGeometry",this.parameters={radius:e,height:t,capSegments:n,radialSegments:s,heightSegments:r},t=Math.max(0,t),n=Math.max(1,Math.floor(n)),s=Math.max(3,Math.floor(s)),r=Math.max(1,Math.floor(r));let o=[],a=[],l=[],c=[],h=t/2,u=Math.PI/2*e,d=t,f=2*u+d,p=n*2+r,_=s+1,g=new A,m=new A;for(let v=0;v<=p;v++){let E=0,y=0,w=0,M=0;if(v<=n){let S=v/n,C=S*Math.PI/2;y=-h-e*Math.cos(C),w=e*Math.sin(C),M=-e*Math.cos(C),E=S*u}else if(v<=n+r){let S=(v-n)/r;y=-h+S*t,w=e,M=0,E=u+S*d}else{let S=(v-n-r)/n,C=S*Math.PI/2;y=h+e*Math.sin(C),w=e*Math.cos(C),M=e*Math.sin(C),E=u+d+S*u}let T=Math.max(0,Math.min(1,E/f)),x=0;v===0?x=.5/s:v===p&&(x=-.5/s);for(let S=0;S<=s;S++){let C=S/s,L=C*Math.PI*2,F=Math.sin(L),I=Math.cos(L);m.x=-w*I,m.y=y,m.z=w*F,a.push(m.x,m.y,m.z),g.set(-w*I,M,w*F),g.normalize(),l.push(g.x,g.y,g.z),c.push(C+x,T)}if(v>0){let S=(v-1)*_;for(let C=0;C<s;C++){let L=S+C,F=S+C+1,I=v*_+C,P=v*_+C+1;o.push(L,F,I),o.push(F,P,I)}}}this.setIndex(o),this.setAttribute("position",new _e(a,3)),this.setAttribute("normal",new _e(l,3)),this.setAttribute("uv",new _e(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radius,e.height,e.capSegments,e.radialSegments,e.heightSegments)}},oi=class i extends ke{constructor(e=1,t=32,n=0,s=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:s},t=Math.max(3,t);let r=[],o=[],a=[],l=[],c=new A,h=new J;o.push(0,0,0),a.push(0,0,1),l.push(.5,.5);for(let u=0,d=3;u<=t;u++,d+=3){let f=n+u/t*s;c.x=e*Math.cos(f),c.y=e*Math.sin(f),o.push(c.x,c.y,c.z),a.push(0,0,1),h.x=(o[d]/e+1)/2,h.y=(o[d+1]/e+1)/2,l.push(h.x,h.y)}for(let u=1;u<=t;u++)r.push(u,u+1,0);this.setIndex(r),this.setAttribute("position",new _e(o,3)),this.setAttribute("normal",new _e(a,3)),this.setAttribute("uv",new _e(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radius,e.segments,e.thetaStart,e.thetaLength)}},xn=class i extends ke{constructor(e=1,t=1,n=1,s=32,r=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:s,heightSegments:r,openEnded:o,thetaStart:a,thetaLength:l};let c=this;s=Math.floor(s),r=Math.floor(r);let h=[],u=[],d=[],f=[],p=0,_=[],g=n/2,m=0;v(),o===!1&&(e>0&&E(!0),t>0&&E(!1)),this.setIndex(h),this.setAttribute("position",new _e(u,3)),this.setAttribute("normal",new _e(d,3)),this.setAttribute("uv",new _e(f,2));function v(){let y=new A,w=new A,M=0,T=(t-e)/n;for(let x=0;x<=r;x++){let S=[],C=x/r,L=C*(t-e)+e;for(let F=0;F<=s;F++){let I=F/s,P=I*l+a,U=Math.sin(P),z=Math.cos(P);w.x=L*U,w.y=-C*n+g,w.z=L*z,u.push(w.x,w.y,w.z),y.set(U,T,z).normalize(),d.push(y.x,y.y,y.z),f.push(I,1-C),S.push(p++)}_.push(S)}for(let x=0;x<s;x++)for(let S=0;S<r;S++){let C=_[S][x],L=_[S+1][x],F=_[S+1][x+1],I=_[S][x+1];(e>0||S!==0)&&(h.push(C,L,I),M+=3),(t>0||S!==r-1)&&(h.push(L,F,I),M+=3)}c.addGroup(m,M,0),m+=M}function E(y){let w=p,M=new J,T=new A,x=0,S=y===!0?e:t,C=y===!0?1:-1;for(let F=1;F<=s;F++)u.push(0,g*C,0),d.push(0,C,0),f.push(.5,.5),p++;let L=p;for(let F=0;F<=s;F++){let P=F/s*l+a,U=Math.cos(P),z=Math.sin(P);T.x=S*z,T.y=g*C,T.z=S*U,u.push(T.x,T.y,T.z),d.push(0,C,0),M.x=U*.5+.5,M.y=z*.5*C+.5,f.push(M.x,M.y),p++}for(let F=0;F<s;F++){let I=w+F,P=L+F;y===!0?h.push(P,P+1,I):h.push(P+1,P,I),x+=3}c.addGroup(m,x,y===!0?1:2),m+=x}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},vn=class i extends xn{constructor(e=1,t=1,n=32,s=1,r=!1,o=0,a=Math.PI*2){super(0,e,t,n,s,r,o,a),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:n,heightSegments:s,openEnded:r,thetaStart:o,thetaLength:a}}static fromJSON(e){return new i(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},_s=class i extends ke{constructor(e=[],t=[],n=1,s=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:s};let r=[],o=[];a(s),c(n),h(),this.setAttribute("position",new _e(r,3)),this.setAttribute("normal",new _e(r.slice(),3)),this.setAttribute("uv",new _e(o,2)),s===0?this.computeVertexNormals():this.normalizeNormals();function a(v){let E=new A,y=new A,w=new A;for(let M=0;M<t.length;M+=3)f(t[M+0],E),f(t[M+1],y),f(t[M+2],w),l(E,y,w,v)}function l(v,E,y,w){let M=w+1,T=[];for(let x=0;x<=M;x++){T[x]=[];let S=v.clone().lerp(y,x/M),C=E.clone().lerp(y,x/M),L=M-x;for(let F=0;F<=L;F++)F===0&&x===M?T[x][F]=S:T[x][F]=S.clone().lerp(C,F/L)}for(let x=0;x<M;x++)for(let S=0;S<2*(M-x)-1;S++){let C=Math.floor(S/2);S%2===0?(d(T[x][C+1]),d(T[x+1][C]),d(T[x][C])):(d(T[x][C+1]),d(T[x+1][C+1]),d(T[x+1][C]))}}function c(v){let E=new A;for(let y=0;y<r.length;y+=3)E.x=r[y+0],E.y=r[y+1],E.z=r[y+2],E.normalize().multiplyScalar(v),r[y+0]=E.x,r[y+1]=E.y,r[y+2]=E.z}function h(){let v=new A;for(let E=0;E<r.length;E+=3){v.x=r[E+0],v.y=r[E+1],v.z=r[E+2];let y=g(v)/2/Math.PI+.5,w=m(v)/Math.PI+.5;o.push(y,1-w)}p(),u()}function u(){for(let v=0;v<o.length;v+=6){let E=o[v+0],y=o[v+2],w=o[v+4],M=Math.max(E,y,w),T=Math.min(E,y,w);M>.9&&T<.1&&(E<.2&&(o[v+0]+=1),y<.2&&(o[v+2]+=1),w<.2&&(o[v+4]+=1))}}function d(v){r.push(v.x,v.y,v.z)}function f(v,E){let y=v*3;E.x=e[y+0],E.y=e[y+1],E.z=e[y+2]}function p(){let v=new A,E=new A,y=new A,w=new A,M=new J,T=new J,x=new J;for(let S=0,C=0;S<r.length;S+=9,C+=6){v.set(r[S+0],r[S+1],r[S+2]),E.set(r[S+3],r[S+4],r[S+5]),y.set(r[S+6],r[S+7],r[S+8]),M.set(o[C+0],o[C+1]),T.set(o[C+2],o[C+3]),x.set(o[C+4],o[C+5]),w.copy(v).add(E).add(y).divideScalar(3);let L=g(w);_(M,C+0,v,L),_(T,C+2,E,L),_(x,C+4,y,L)}}function _(v,E,y,w){w<0&&v.x===1&&(o[E]=v.x-1),y.x===0&&y.z===0&&(o[E]=w/2/Math.PI+.5)}function g(v){return Math.atan2(v.z,-v.x)}function m(v){return Math.atan2(-v.y,Math.sqrt(v.x*v.x+v.z*v.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.vertices,e.indices,e.radius,e.detail)}},rl=class i extends _s{constructor(e=1,t=0){let n=(1+Math.sqrt(5))/2,s=1/n,r=[-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-n,0,-s,n,0,s,-n,0,s,n,-s,-n,0,-s,n,0,s,-n,0,s,n,0,-n,0,-s,n,0,-s,-n,0,s,n,0,s],o=[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9];super(r,o,e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new i(e.radius,e.detail)}},_h=new A,xh=new A,Xd=new A,vh=new Li,ol=class extends ke{constructor(e=null,t=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:t},e!==null){let s=Math.pow(10,4),r=Math.cos(fr*t),o=e.getIndex(),a=e.getAttribute("position"),l=o?o.count:a.count,c=[0,0,0],h=["a","b","c"],u=new Array(3),d={},f=[];for(let p=0;p<l;p+=3){o?(c[0]=o.getX(p),c[1]=o.getX(p+1),c[2]=o.getX(p+2)):(c[0]=p,c[1]=p+1,c[2]=p+2);let{a:_,b:g,c:m}=vh;if(_.fromBufferAttribute(a,c[0]),g.fromBufferAttribute(a,c[1]),m.fromBufferAttribute(a,c[2]),vh.getNormal(Xd),u[0]=`${Math.round(_.x*s)},${Math.round(_.y*s)},${Math.round(_.z*s)}`,u[1]=`${Math.round(g.x*s)},${Math.round(g.y*s)},${Math.round(g.z*s)}`,u[2]=`${Math.round(m.x*s)},${Math.round(m.y*s)},${Math.round(m.z*s)}`,!(u[0]===u[1]||u[1]===u[2]||u[2]===u[0]))for(let v=0;v<3;v++){let E=(v+1)%3,y=u[v],w=u[E],M=vh[h[v]],T=vh[h[E]],x=`${y}_${w}`,S=`${w}_${y}`;S in d&&d[S]?(Xd.dot(d[S].normal)<=r&&(f.push(M.x,M.y,M.z),f.push(T.x,T.y,T.z)),d[S]=null):x in d||(d[x]={index0:c[v],index1:c[E],normal:Xd.clone()})}}for(let p in d)if(d[p]){let{index0:_,index1:g}=d[p];_h.fromBufferAttribute(a,_),xh.fromBufferAttribute(a,g),f.push(_h.x,_h.y,_h.z),f.push(xh.x,xh.y,xh.z)}this.setAttribute("position",new _e(f,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}},ai=class{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){be("Curve: .getPoint() not implemented.")}getPointAt(e,t){let n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){let t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],n,s=this.getPoint(0),r=0;t.push(0);for(let o=1;o<=e;o++)n=this.getPoint(o/e),r+=n.distanceTo(s),t.push(r),s=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){let n=this.getLengths(),s=0,r=n.length,o;t?o=t:o=e*n[r-1];let a=0,l=r-1,c;for(;a<=l;)if(s=Math.floor(a+(l-a)/2),c=n[s]-o,c<0)a=s+1;else if(c>0)l=s-1;else{l=s;break}if(s=l,n[s]===o)return s/(r-1);let h=n[s],d=n[s+1]-h,f=(o-h)/d;return(s+f)/(r-1)}getTangent(e,t){let s=e-1e-4,r=e+1e-4;s<0&&(s=0),r>1&&(r=1);let o=this.getPoint(s),a=this.getPoint(r),l=t||(o.isVector2?new J:new A);return l.copy(a).sub(o).normalize(),l}getTangentAt(e,t){let n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){let n=new A,s=[],r=[],o=[],a=new A,l=new nt;for(let f=0;f<=e;f++){let p=f/e;s[f]=this.getTangentAt(p,new A)}r[0]=new A,o[0]=new A;let c=Number.MAX_VALUE,h=Math.abs(s[0].x),u=Math.abs(s[0].y),d=Math.abs(s[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),a.crossVectors(s[0],n).normalize(),r[0].crossVectors(s[0],a),o[0].crossVectors(s[0],r[0]);for(let f=1;f<=e;f++){if(r[f]=r[f-1].clone(),o[f]=o[f-1].clone(),a.crossVectors(s[f-1],s[f]),a.length()>Number.EPSILON){a.normalize();let p=Math.acos(at(s[f-1].dot(s[f]),-1,1));r[f].applyMatrix4(l.makeRotationAxis(a,p))}o[f].crossVectors(s[f],r[f])}if(t===!0){let f=Math.acos(at(r[0].dot(r[e]),-1,1));f/=e,s[0].dot(a.crossVectors(r[0],r[e]))>0&&(f=-f);for(let p=1;p<=e;p++)r[p].applyMatrix4(l.makeRotationAxis(s[p],f*p)),o[p].crossVectors(s[p],r[p])}return{tangents:s,normals:r,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){let e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}},br=class extends ai{constructor(e=0,t=0,n=1,s=1,r=0,o=Math.PI*2,a=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=n,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=o,this.aClockwise=a,this.aRotation=l}getPoint(e,t=new J){let n=t,s=Math.PI*2,r=this.aEndAngle-this.aStartAngle,o=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=s;for(;r>s;)r-=s;r<Number.EPSILON&&(o?r=0:r=s),this.aClockwise===!0&&!o&&(r===s?r=-s:r=r-s);let a=this.aStartAngle+e*r,l=this.aX+this.xRadius*Math.cos(a),c=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){let h=Math.cos(this.aRotation),u=Math.sin(this.aRotation),d=l-this.aX,f=c-this.aY;l=d*h-f*u+this.aX,c=d*u+f*h+this.aY}return n.set(l,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){let e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}},al=class extends br{constructor(e,t,n,s,r,o){super(e,t,n,n,s,r,o),this.isArcCurve=!0,this.type="ArcCurve"}};function np(){let i=0,e=0,t=0,n=0;function s(r,o,a,l){i=r,e=a,t=-3*r+3*o-2*a-l,n=2*r-2*o+a+l}return{initCatmullRom:function(r,o,a,l,c){s(o,a,c*(a-r),c*(l-o))},initNonuniformCatmullRom:function(r,o,a,l,c,h,u){let d=(o-r)/c-(a-r)/(c+h)+(a-o)/h,f=(a-o)/h-(l-o)/(h+u)+(l-a)/u;d*=h,f*=h,s(o,a,d,f)},calc:function(r){let o=r*r,a=o*r;return i+e*r+t*o+n*a}}}var Wm=new A,Xm=new A,Yd=new np,qd=new np,Zd=new np,je=class extends ai{constructor(e=[],t=!1,n="centripetal",s=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=n,this.tension=s}getPoint(e,t=new A){let n=t,s=this.points,r=s.length,o=(r-(this.closed?0:1))*e,a=Math.floor(o),l=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/r)+1)*r:l===0&&a===r-1&&(a=r-2,l=1);let c,h;this.closed||a>0?c=s[(a-1)%r]:(Xm.subVectors(s[0],s[1]).add(s[0]),c=Xm);let u=s[a%r],d=s[(a+1)%r];if(this.closed||a+2<r?h=s[(a+2)%r]:(Wm.subVectors(s[r-1],s[r-2]).add(s[r-1]),h=Wm),this.curveType==="centripetal"||this.curveType==="chordal"){let f=this.curveType==="chordal"?.5:.25,p=Math.pow(c.distanceToSquared(u),f),_=Math.pow(u.distanceToSquared(d),f),g=Math.pow(d.distanceToSquared(h),f);_<1e-4&&(_=1),p<1e-4&&(p=_),g<1e-4&&(g=_),Yd.initNonuniformCatmullRom(c.x,u.x,d.x,h.x,p,_,g),qd.initNonuniformCatmullRom(c.y,u.y,d.y,h.y,p,_,g),Zd.initNonuniformCatmullRom(c.z,u.z,d.z,h.z,p,_,g)}else this.curveType==="catmullrom"&&(Yd.initCatmullRom(c.x,u.x,d.x,h.x,this.tension),qd.initCatmullRom(c.y,u.y,d.y,h.y,this.tension),Zd.initCatmullRom(c.z,u.z,d.z,h.z,this.tension));return n.set(Yd.calc(l),qd.calc(l),Zd.calc(l)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let s=e.points[t];this.points.push(s.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){let s=this.points[t];e.points.push(s.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let s=e.points[t];this.points.push(new A().fromArray(s))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}};function Ym(i,e,t,n,s){let r=(n-e)*.5,o=(s-t)*.5,a=i*i,l=i*a;return(2*t-2*n+r+o)*l+(-3*t+3*n-2*r-o)*a+r*i+t}function nv(i,e){let t=1-i;return t*t*e}function iv(i,e){return 2*(1-i)*i*e}function sv(i,e){return i*i*e}function Fa(i,e,t,n){return nv(i,e)+iv(i,t)+sv(i,n)}function rv(i,e){let t=1-i;return t*t*t*e}function ov(i,e){let t=1-i;return 3*t*t*i*e}function av(i,e){return 3*(1-i)*i*i*e}function lv(i,e){return i*i*i*e}function Ba(i,e,t,n,s){return rv(i,e)+ov(i,t)+av(i,n)+lv(i,s)}var Ao=class extends ai{constructor(e=new J,t=new J,n=new J,s=new J){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new J){let n=t,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(Ba(e,s.x,r.x,o.x,a.x),Ba(e,s.y,r.y,o.y,a.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},ll=class extends ai{constructor(e=new A,t=new A,n=new A,s=new A){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=n,this.v3=s}getPoint(e,t=new A){let n=t,s=this.v0,r=this.v1,o=this.v2,a=this.v3;return n.set(Ba(e,s.x,r.x,o.x,a.x),Ba(e,s.y,r.y,o.y,a.y),Ba(e,s.z,r.z,o.z,a.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},Co=class extends ai{constructor(e=new J,t=new J){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new J){let n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new J){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},cl=class extends ai{constructor(e=new A,t=new A){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new A){let n=t;return e===1?n.copy(this.v2):(n.copy(this.v2).sub(this.v1),n.multiplyScalar(e).add(this.v1)),n}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new A){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Po=class extends ai{constructor(e=new J,t=new J,n=new J){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new J){let n=t,s=this.v0,r=this.v1,o=this.v2;return n.set(Fa(e,s.x,r.x,o.x),Fa(e,s.y,r.y,o.y)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Io=class extends ai{constructor(e=new A,t=new A,n=new A){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=n}getPoint(e,t=new A){let n=t,s=this.v0,r=this.v1,o=this.v2;return n.set(Fa(e,s.x,r.x,o.x),Fa(e,s.y,r.y,o.y),Fa(e,s.z,r.z,o.z)),n}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Do=class extends ai{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new J){let n=t,s=this.points,r=(s.length-1)*e,o=Math.floor(r),a=r-o,l=s[o===0?o:o-1],c=s[o],h=s[o>s.length-2?s.length-1:o+1],u=s[o>s.length-3?s.length-1:o+2];return n.set(Ym(a,l.x,c.x,h.x,u.x),Ym(a,l.y,c.y,h.y,u.y)),n}copy(e){super.copy(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let s=e.points[t];this.points.push(s.clone())}return this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,n=this.points.length;t<n;t++){let s=this.points[t];e.points.push(s.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,n=e.points.length;t<n;t++){let s=e.points[t];this.points.push(new J().fromArray(s))}return this}},Kh=Object.freeze({__proto__:null,ArcCurve:al,CatmullRomCurve3:je,CubicBezierCurve:Ao,CubicBezierCurve3:ll,EllipseCurve:br,LineCurve:Co,LineCurve3:cl,QuadraticBezierCurve:Po,QuadraticBezierCurve3:Io,SplineCurve:Do}),hl=class extends ai{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){let e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){let n=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Kh[n](t,e))}return this}getPoint(e,t){let n=e*this.getLength(),s=this.getCurveLengths(),r=0;for(;r<s.length;){if(s[r]>=n){let o=s[r]-n,a=this.curves[r],l=a.getLength(),c=l===0?0:1-o/l;return a.getPointAt(c,t)}r++}return null}getLength(){let e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let e=[],t=0;for(let n=0,s=this.curves.length;n<s;n++)t+=this.curves[n].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){let t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){let t=[],n;for(let s=0,r=this.curves;s<r.length;s++){let o=r[s],a=o.isEllipseCurve?e*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?e*o.points.length:e,l=o.getPoints(a);for(let c=0;c<l.length;c++){let h=l[c];n&&n.equals(h)||(t.push(h),n=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){let s=e.curves[t];this.curves.push(s.clone())}return this.autoClose=e.autoClose,this}toJSON(){let e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,n=this.curves.length;t<n;t++){let s=this.curves[t];e.curves.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,n=e.curves.length;t<n;t++){let s=e.curves[t];this.curves.push(new Kh[s.type]().fromJSON(s))}return this}},li=class extends hl{constructor(e){super(),this.type="Path",this.currentPoint=new J,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,n=e.length;t<n;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){let n=new Co(this.currentPoint.clone(),new J(e,t));return this.curves.push(n),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,n,s){let r=new Po(this.currentPoint.clone(),new J(e,t),new J(n,s));return this.curves.push(r),this.currentPoint.set(n,s),this}bezierCurveTo(e,t,n,s,r,o){let a=new Ao(this.currentPoint.clone(),new J(e,t),new J(n,s),new J(r,o));return this.curves.push(a),this.currentPoint.set(r,o),this}splineThru(e){let t=[this.currentPoint.clone()].concat(e),n=new Do(t);return this.curves.push(n),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,n,s,r,o){let a=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(e+a,t+l,n,s,r,o),this}absarc(e,t,n,s,r,o){return this.absellipse(e,t,n,n,s,r,o),this}ellipse(e,t,n,s,r,o,a,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+c,t+h,n,s,r,o,a,l),this}absellipse(e,t,n,s,r,o,a,l){let c=new br(e,t,n,s,r,o,a,l);if(this.curves.length>0){let u=c.getPoint(0);u.equals(this.currentPoint)||this.lineTo(u.x,u.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){let e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}},kt=class extends li{constructor(e){super(e),this.uuid=fi(),this.type="Shape",this.holes=[]}getPointsHoles(e){let t=[];for(let n=0,s=this.holes.length;n<s;n++)t[n]=this.holes[n].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){let s=e.holes[t];this.holes.push(s.clone())}return this}toJSON(){let e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,n=this.holes.length;t<n;t++){let s=this.holes[t];e.holes.push(s.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,n=e.holes.length;t<n;t++){let s=e.holes[t];this.holes.push(new li().fromJSON(s))}return this}};function cv(i,e,t=2){let n=e&&e.length,s=n?e[0]*t:i.length,r=gg(i,0,s,t,!0),o=[];if(!r||r.next===r.prev)return o;let a,l,c;if(n&&(r=pv(i,e,r,t)),i.length>80*t){a=i[0],l=i[1];let h=a,u=l;for(let d=t;d<s;d+=t){let f=i[d],p=i[d+1];f<a&&(a=f),p<l&&(l=p),f>h&&(h=f),p>u&&(u=p)}c=Math.max(h-a,u-l),c=c!==0?32767/c:0}return ul(r,o,t,a,l,c,0),o}function gg(i,e,t,n,s){let r;if(s===Tv(i,e,t,n)>0)for(let o=e;o<t;o+=n)r=qm(o/n|0,i[o],i[o+1],r);else for(let o=t-n;o>=e;o-=n)r=qm(o/n|0,i[o],i[o+1],r);return r&&Lo(r,r.next)&&(fl(r),r=r.next),r}function Er(i,e){if(!i)return i;e||(e=i);let t=i,n;do if(n=!1,!t.steiner&&(Lo(t,t.next)||sn(t.prev,t,t.next)===0)){if(fl(t),t=e=t.prev,t===t.next)break;n=!0}else t=t.next;while(n||t!==e);return e}function ul(i,e,t,n,s,r,o){if(!i)return;!o&&r&&vv(i,n,s,r);let a=i;for(;i.prev!==i.next;){let l=i.prev,c=i.next;if(r?uv(i,n,s,r):hv(i)){e.push(l.i,i.i,c.i),fl(i),i=c.next,a=c.next;continue}if(i=c,i===a){o?o===1?(i=dv(Er(i),e),ul(i,e,t,n,s,r,2)):o===2&&fv(i,e,t,n,s,r):ul(Er(i),e,t,n,s,r,1);break}}}function hv(i){let e=i.prev,t=i,n=i.next;if(sn(e,t,n)>=0)return!1;let s=e.x,r=t.x,o=n.x,a=e.y,l=t.y,c=n.y,h=Math.min(s,r,o),u=Math.min(a,l,c),d=Math.max(s,r,o),f=Math.max(a,l,c),p=n.next;for(;p!==e;){if(p.x>=h&&p.x<=d&&p.y>=u&&p.y<=f&&Da(s,a,r,l,o,c,p.x,p.y)&&sn(p.prev,p,p.next)>=0)return!1;p=p.next}return!0}function uv(i,e,t,n){let s=i.prev,r=i,o=i.next;if(sn(s,r,o)>=0)return!1;let a=s.x,l=r.x,c=o.x,h=s.y,u=r.y,d=o.y,f=Math.min(a,l,c),p=Math.min(h,u,d),_=Math.max(a,l,c),g=Math.max(h,u,d),m=rf(f,p,e,t,n),v=rf(_,g,e,t,n),E=i.prevZ,y=i.nextZ;for(;E&&E.z>=m&&y&&y.z<=v;){if(E.x>=f&&E.x<=_&&E.y>=p&&E.y<=g&&E!==s&&E!==o&&Da(a,h,l,u,c,d,E.x,E.y)&&sn(E.prev,E,E.next)>=0||(E=E.prevZ,y.x>=f&&y.x<=_&&y.y>=p&&y.y<=g&&y!==s&&y!==o&&Da(a,h,l,u,c,d,y.x,y.y)&&sn(y.prev,y,y.next)>=0))return!1;y=y.nextZ}for(;E&&E.z>=m;){if(E.x>=f&&E.x<=_&&E.y>=p&&E.y<=g&&E!==s&&E!==o&&Da(a,h,l,u,c,d,E.x,E.y)&&sn(E.prev,E,E.next)>=0)return!1;E=E.prevZ}for(;y&&y.z<=v;){if(y.x>=f&&y.x<=_&&y.y>=p&&y.y<=g&&y!==s&&y!==o&&Da(a,h,l,u,c,d,y.x,y.y)&&sn(y.prev,y,y.next)>=0)return!1;y=y.nextZ}return!0}function dv(i,e){let t=i;do{let n=t.prev,s=t.next.next;!Lo(n,s)&&xg(n,t,t.next,s)&&dl(n,s)&&dl(s,n)&&(e.push(n.i,t.i,s.i),fl(t),fl(t.next),t=i=s),t=t.next}while(t!==i);return Er(t)}function fv(i,e,t,n,s,r){let o=i;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&bv(o,a)){let l=vg(o,a);o=Er(o,o.next),l=Er(l,l.next),ul(o,e,t,n,s,r,0),ul(l,e,t,n,s,r,0);return}a=a.next}o=o.next}while(o!==i)}function pv(i,e,t,n){let s=[];for(let r=0,o=e.length;r<o;r++){let a=e[r]*n,l=r<o-1?e[r+1]*n:i.length,c=gg(i,a,l,n,!1);c===c.next&&(c.steiner=!0),s.push(Mv(c))}s.sort(mv);for(let r=0;r<s.length;r++)t=gv(s[r],t);return t}function mv(i,e){let t=i.x-e.x;if(t===0&&(t=i.y-e.y,t===0)){let n=(i.next.y-i.y)/(i.next.x-i.x),s=(e.next.y-e.y)/(e.next.x-e.x);t=n-s}return t}function gv(i,e){let t=_v(i,e);if(!t)return e;let n=vg(t,i);return Er(n,n.next),Er(t,t.next)}function _v(i,e){let t=e,n=i.x,s=i.y,r=-1/0,o;if(Lo(i,t))return t;do{if(Lo(i,t.next))return t.next;if(s<=t.y&&s>=t.next.y&&t.next.y!==t.y){let u=t.x+(s-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(u<=n&&u>r&&(r=u,o=t.x<t.next.x?t:t.next,u===n))return o}t=t.next}while(t!==e);if(!o)return null;let a=o,l=o.x,c=o.y,h=1/0;t=o;do{if(n>=t.x&&t.x>=l&&n!==t.x&&_g(s<c?n:r,s,l,c,s<c?r:n,s,t.x,t.y)){let u=Math.abs(s-t.y)/(n-t.x);dl(t,i)&&(u<h||u===h&&(t.x>o.x||t.x===o.x&&xv(o,t)))&&(o=t,h=u)}t=t.next}while(t!==a);return o}function xv(i,e){return sn(i.prev,i,e.prev)<0&&sn(e.next,i,i.next)<0}function vv(i,e,t,n){let s=i;do s.z===0&&(s.z=rf(s.x,s.y,e,t,n)),s.prevZ=s.prev,s.nextZ=s.next,s=s.next;while(s!==i);s.prevZ.nextZ=null,s.prevZ=null,yv(s)}function yv(i){let e,t=1;do{let n=i,s;i=null;let r=null;for(e=0;n;){e++;let o=n,a=0;for(let c=0;c<t&&(a++,o=o.nextZ,!!o);c++);let l=t;for(;a>0||l>0&&o;)a!==0&&(l===0||!o||n.z<=o.z)?(s=n,n=n.nextZ,a--):(s=o,o=o.nextZ,l--),r?r.nextZ=s:i=s,s.prevZ=r,r=s;n=o}r.nextZ=null,t*=2}while(e>1);return i}function rf(i,e,t,n,s){return i=(i-t)*s|0,e=(e-n)*s|0,i=(i|i<<8)&16711935,i=(i|i<<4)&252645135,i=(i|i<<2)&858993459,i=(i|i<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,i|e<<1}function Mv(i){let e=i,t=i;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==i);return t}function _g(i,e,t,n,s,r,o,a){return(s-o)*(e-a)>=(i-o)*(r-a)&&(i-o)*(n-a)>=(t-o)*(e-a)&&(t-o)*(r-a)>=(s-o)*(n-a)}function Da(i,e,t,n,s,r,o,a){return!(i===o&&e===a)&&_g(i,e,t,n,s,r,o,a)}function bv(i,e){return i.next.i!==e.i&&i.prev.i!==e.i&&!Ev(i,e)&&(dl(i,e)&&dl(e,i)&&Sv(i,e)&&(sn(i.prev,i,e.prev)||sn(i,e.prev,e))||Lo(i,e)&&sn(i.prev,i,i.next)>0&&sn(e.prev,e,e.next)>0)}function sn(i,e,t){return(e.y-i.y)*(t.x-e.x)-(e.x-i.x)*(t.y-e.y)}function Lo(i,e){return i.x===e.x&&i.y===e.y}function xg(i,e,t,n){let s=Mh(sn(i,e,t)),r=Mh(sn(i,e,n)),o=Mh(sn(t,n,i)),a=Mh(sn(t,n,e));return!!(s!==r&&o!==a||s===0&&yh(i,t,e)||r===0&&yh(i,n,e)||o===0&&yh(t,i,n)||a===0&&yh(t,e,n))}function yh(i,e,t){return e.x<=Math.max(i.x,t.x)&&e.x>=Math.min(i.x,t.x)&&e.y<=Math.max(i.y,t.y)&&e.y>=Math.min(i.y,t.y)}function Mh(i){return i>0?1:i<0?-1:0}function Ev(i,e){let t=i;do{if(t.i!==i.i&&t.next.i!==i.i&&t.i!==e.i&&t.next.i!==e.i&&xg(t,t.next,i,e))return!0;t=t.next}while(t!==i);return!1}function dl(i,e){return sn(i.prev,i,i.next)<0?sn(i,e,i.next)>=0&&sn(i,i.prev,e)>=0:sn(i,e,i.prev)<0||sn(i,i.next,e)<0}function Sv(i,e){let t=i,n=!1,s=(i.x+e.x)/2,r=(i.y+e.y)/2;do t.y>r!=t.next.y>r&&t.next.y!==t.y&&s<(t.next.x-t.x)*(r-t.y)/(t.next.y-t.y)+t.x&&(n=!n),t=t.next;while(t!==i);return n}function vg(i,e){let t=of(i.i,i.x,i.y),n=of(e.i,e.x,e.y),s=i.next,r=e.prev;return i.next=e,e.prev=i,t.next=s,s.prev=t,n.next=t,t.prev=n,r.next=n,n.prev=r,n}function qm(i,e,t,n){let s=of(i,e,t);return n?(s.next=n.next,s.prev=n,n.next.prev=s,n.next=s):(s.prev=s,s.next=s),s}function fl(i){i.next.prev=i.prev,i.prev.next=i.next,i.prevZ&&(i.prevZ.nextZ=i.nextZ),i.nextZ&&(i.nextZ.prevZ=i.prevZ)}function of(i,e,t){return{i,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Tv(i,e,t,n){let s=0;for(let r=e,o=t-n;r<t;r+=n)s+=(i[o]-i[r])*(i[r+1]+i[o+1]),o=r;return s}var af=class{static triangulate(e,t,n=2){return cv(e,t,n)}},Ei=class i{static area(e){let t=e.length,n=0;for(let s=t-1,r=0;r<t;s=r++)n+=e[s].x*e[r].y-e[r].x*e[s].y;return n*.5}static isClockWise(e){return i.area(e)<0}static triangulateShape(e,t){let n=[],s=[],r=[];Zm(e),Jm(n,e);let o=e.length;t.forEach(Zm);for(let l=0;l<t.length;l++)s.push(o),o+=t[l].length,Jm(n,t[l]);let a=af.triangulate(n,s);for(let l=0;l<a.length;l+=3)r.push(a.slice(l,l+3));return r}};function Zm(i){let e=i.length;e>2&&i[e-1].equals(i[0])&&i.pop()}function Jm(i,e){for(let t=0;t<e.length;t++)i.push(e[t].x),i.push(e[t].y)}var en=class i extends ke{constructor(e=new kt([new J(.5,.5),new J(-.5,.5),new J(-.5,-.5),new J(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];let n=this,s=[],r=[];for(let a=0,l=e.length;a<l;a++){let c=e[a];o(c)}this.setAttribute("position",new _e(s,3)),this.setAttribute("uv",new _e(r,2)),this.computeVertexNormals();function o(a){let l=[],c=t.curveSegments!==void 0?t.curveSegments:12,h=t.steps!==void 0?t.steps:1,u=t.depth!==void 0?t.depth:1,d=t.bevelEnabled!==void 0?t.bevelEnabled:!0,f=t.bevelThickness!==void 0?t.bevelThickness:.2,p=t.bevelSize!==void 0?t.bevelSize:f-.1,_=t.bevelOffset!==void 0?t.bevelOffset:0,g=t.bevelSegments!==void 0?t.bevelSegments:3,m=t.extrudePath,v=t.UVGenerator!==void 0?t.UVGenerator:wv,E,y=!1,w,M,T,x;if(m){E=m.getSpacedPoints(h),y=!0,d=!1;let le=m.isCatmullRomCurve3?m.closed:!1;w=m.computeFrenetFrames(h,le),M=new A,T=new A,x=new A}d||(g=0,f=0,p=0,_=0);let S=a.extractPoints(c),C=S.shape,L=S.holes;if(!Ei.isClockWise(C)){C=C.reverse();for(let le=0,de=L.length;le<de;le++){let fe=L[le];Ei.isClockWise(fe)&&(L[le]=fe.reverse())}}function I(le){let fe=10000000000000001e-36,pe=le[0];for(let Me=1;Me<=le.length;Me++){let it=Me%le.length,tt=le[it],ct=tt.x-pe.x,ut=tt.y-pe.y,B=ct*ct+ut*ut,It=Math.max(Math.abs(tt.x),Math.abs(tt.y),Math.abs(pe.x),Math.abs(pe.y)),St=fe*It*It;if(B<=St){le.splice(it,1),Me--;continue}pe=tt}}I(C),L.forEach(I);let P=L.length,U=C;for(let le=0;le<P;le++){let de=L[le];C=C.concat(de)}function z(le,de,fe){return de||qe("ExtrudeGeometry: vec does not exist"),le.clone().addScaledVector(de,fe)}let V=C.length;function ie(le,de,fe){let pe,Me,it,tt=le.x-de.x,ct=le.y-de.y,ut=fe.x-le.x,B=fe.y-le.y,It=tt*tt+ct*ct,St=tt*B-ct*ut;if(Math.abs(St)>Number.EPSILON){let D=Math.sqrt(It),b=Math.sqrt(ut*ut+B*B),G=de.x-ct/D,Z=de.y+tt/D,Q=fe.x-B/b,ge=fe.y+ut/b,ye=((Q-G)*B-(ge-Z)*ut)/(tt*B-ct*ut);pe=G+tt*ye-le.x,Me=Z+ct*ye-le.y;let ee=pe*pe+Me*Me;if(ee<=2)return new J(pe,Me);it=Math.sqrt(ee/2)}else{let D=!1;tt>Number.EPSILON?ut>Number.EPSILON&&(D=!0):tt<-Number.EPSILON?ut<-Number.EPSILON&&(D=!0):Math.sign(ct)===Math.sign(B)&&(D=!0),D?(pe=-ct,Me=tt,it=Math.sqrt(It)):(pe=tt,Me=ct,it=Math.sqrt(It/2))}return new J(pe/it,Me/it)}let $=[];for(let le=0,de=U.length,fe=de-1,pe=le+1;le<de;le++,fe++,pe++)fe===de&&(fe=0),pe===de&&(pe=0),$[le]=ie(U[le],U[fe],U[pe]);let se=[],te,Xe=$.concat();for(let le=0,de=P;le<de;le++){let fe=L[le];te=[];for(let pe=0,Me=fe.length,it=Me-1,tt=pe+1;pe<Me;pe++,it++,tt++)it===Me&&(it=0),tt===Me&&(tt=0),te[pe]=ie(fe[pe],fe[it],fe[tt]);se.push(te),Xe=Xe.concat(te)}let Ue;if(g===0)Ue=Ei.triangulateShape(U,L);else{let le=[],de=[];for(let fe=0;fe<g;fe++){let pe=fe/g,Me=f*Math.cos(pe*Math.PI/2),it=p*Math.sin(pe*Math.PI/2)+_;for(let tt=0,ct=U.length;tt<ct;tt++){let ut=z(U[tt],$[tt],it);Ee(ut.x,ut.y,-Me),pe===0&&le.push(ut)}for(let tt=0,ct=P;tt<ct;tt++){let ut=L[tt];te=se[tt];let B=[];for(let It=0,St=ut.length;It<St;It++){let D=z(ut[It],te[It],it);Ee(D.x,D.y,-Me),pe===0&&B.push(D)}pe===0&&de.push(B)}}Ue=Ei.triangulateShape(le,de)}let Ge=Ue.length,He=p+_;for(let le=0;le<V;le++){let de=d?z(C[le],Xe[le],He):C[le];y?(T.copy(w.normals[0]).multiplyScalar(de.x),M.copy(w.binormals[0]).multiplyScalar(de.y),x.copy(E[0]).add(T).add(M),Ee(x.x,x.y,x.z)):Ee(de.x,de.y,0)}for(let le=1;le<=h;le++)for(let de=0;de<V;de++){let fe=d?z(C[de],Xe[de],He):C[de];y?(T.copy(w.normals[le]).multiplyScalar(fe.x),M.copy(w.binormals[le]).multiplyScalar(fe.y),x.copy(E[le]).add(T).add(M),Ee(x.x,x.y,x.z)):Ee(fe.x,fe.y,u/h*le)}for(let le=g-1;le>=0;le--){let de=le/g,fe=f*Math.cos(de*Math.PI/2),pe=p*Math.sin(de*Math.PI/2)+_;for(let Me=0,it=U.length;Me<it;Me++){let tt=z(U[Me],$[Me],pe);Ee(tt.x,tt.y,u+fe)}for(let Me=0,it=L.length;Me<it;Me++){let tt=L[Me];te=se[Me];for(let ct=0,ut=tt.length;ct<ut;ct++){let B=z(tt[ct],te[ct],pe);y?Ee(B.x,B.y+E[h-1].y,E[h-1].x+fe):Ee(B.x,B.y,u+fe)}}}rt(),j();function rt(){let le=s.length/3;if(d){let de=0,fe=V*de;for(let pe=0;pe<Ge;pe++){let Me=Ue[pe];ot(Me[2]+fe,Me[1]+fe,Me[0]+fe)}de=h+g*2,fe=V*de;for(let pe=0;pe<Ge;pe++){let Me=Ue[pe];ot(Me[0]+fe,Me[1]+fe,Me[2]+fe)}}else{for(let de=0;de<Ge;de++){let fe=Ue[de];ot(fe[2],fe[1],fe[0])}for(let de=0;de<Ge;de++){let fe=Ue[de];ot(fe[0]+V*h,fe[1]+V*h,fe[2]+V*h)}}n.addGroup(le,s.length/3-le,0)}function j(){let le=s.length/3,de=0;oe(U,de),de+=U.length;for(let fe=0,pe=L.length;fe<pe;fe++){let Me=L[fe];oe(Me,de),de+=Me.length}n.addGroup(le,s.length/3-le,1)}function oe(le,de){let fe=le.length;for(;--fe>=0;){let pe=fe,Me=fe-1;Me<0&&(Me=le.length-1);for(let it=0,tt=h+g*2;it<tt;it++){let ct=V*it,ut=V*(it+1),B=de+pe+ct,It=de+Me+ct,St=de+Me+ut,D=de+pe+ut;Ne(B,It,St,D)}}}function Ee(le,de,fe){l.push(le),l.push(de),l.push(fe)}function ot(le,de,fe){lt(le),lt(de),lt(fe);let pe=s.length/3,Me=v.generateTopUV(n,s,pe-3,pe-2,pe-1);Ft(Me[0]),Ft(Me[1]),Ft(Me[2])}function Ne(le,de,fe,pe){lt(le),lt(de),lt(pe),lt(de),lt(fe),lt(pe);let Me=s.length/3,it=v.generateSideWallUV(n,s,Me-6,Me-3,Me-2,Me-1);Ft(it[0]),Ft(it[1]),Ft(it[3]),Ft(it[1]),Ft(it[2]),Ft(it[3])}function lt(le){s.push(l[le*3+0]),s.push(l[le*3+1]),s.push(l[le*3+2])}function Ft(le){r.push(le.x),r.push(le.y)}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON(),t=this.parameters.shapes,n=this.parameters.options;return Rv(t,n,e)}static fromJSON(e,t){let n=[];for(let r=0,o=e.shapes.length;r<o;r++){let a=t[e.shapes[r]];n.push(a)}let s=e.options.extrudePath;return s!==void 0&&(e.options.extrudePath=new Kh[s.type]().fromJSON(s)),new i(n,e.options)}},wv={generateTopUV:function(i,e,t,n,s){let r=e[t*3],o=e[t*3+1],a=e[n*3],l=e[n*3+1],c=e[s*3],h=e[s*3+1];return[new J(r,o),new J(a,l),new J(c,h)]},generateSideWallUV:function(i,e,t,n,s,r){let o=e[t*3],a=e[t*3+1],l=e[t*3+2],c=e[n*3],h=e[n*3+1],u=e[n*3+2],d=e[s*3],f=e[s*3+1],p=e[s*3+2],_=e[r*3],g=e[r*3+1],m=e[r*3+2];return Math.abs(a-h)<Math.abs(o-c)?[new J(o,1-l),new J(c,1-u),new J(d,1-p),new J(_,1-m)]:[new J(a,1-l),new J(h,1-u),new J(f,1-p),new J(g,1-m)]}};function Rv(i,e,t){if(t.shapes=[],Array.isArray(i))for(let n=0,s=i.length;n<s;n++){let r=i[n];t.shapes.push(r.uuid)}else t.shapes.push(i.uuid);return t.options=Object.assign({},e),e.extrudePath!==void 0&&(t.options.extrudePath=e.extrudePath.toJSON()),t}var Tn=class i extends _s{constructor(e=1,t=0){let n=(1+Math.sqrt(5))/2,s=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],r=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(s,r,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new i(e.radius,e.detail)}},Oi=class i extends ke{constructor(e=[new J(0,-.5),new J(.5,0),new J(0,.5)],t=12,n=0,s=Math.PI*2){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:n,phiLength:s},t=Math.floor(t),s=at(s,0,Math.PI*2);let r=[],o=[],a=[],l=[],c=[],h=1/t,u=new A,d=new J,f=new A,p=new A,_=new A,g=0,m=0;for(let v=0;v<=e.length-1;v++)switch(v){case 0:g=e[v+1].x-e[v].x,m=e[v+1].y-e[v].y,f.x=m*1,f.y=-g,f.z=m*0,_.copy(f),f.normalize(),l.push(f.x,f.y,f.z);break;case e.length-1:l.push(_.x,_.y,_.z);break;default:g=e[v+1].x-e[v].x,m=e[v+1].y-e[v].y,f.x=m*1,f.y=-g,f.z=m*0,p.copy(f),f.x+=_.x,f.y+=_.y,f.z+=_.z,f.normalize(),l.push(f.x,f.y,f.z),_.copy(p)}for(let v=0;v<=t;v++){let E=n+v*h*s,y=Math.sin(E),w=Math.cos(E);for(let M=0;M<=e.length-1;M++){u.x=e[M].x*y,u.y=e[M].y,u.z=e[M].x*w,o.push(u.x,u.y,u.z),d.x=v/t,d.y=M/(e.length-1),a.push(d.x,d.y);let T=l[3*M+0]*y,x=l[3*M+1],S=l[3*M+0]*w;c.push(T,x,S)}}for(let v=0;v<t;v++)for(let E=0;E<e.length-1;E++){let y=E+v*e.length,w=y,M=y+e.length,T=y+e.length+1,x=y+1;r.push(w,M,x),r.push(T,x,M)}this.setIndex(r),this.setAttribute("position",new _e(o,3)),this.setAttribute("uv",new _e(a,2)),this.setAttribute("normal",new _e(c,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.points,e.segments,e.phiStart,e.phiLength)}},xs=class i extends _s{constructor(e=1,t=0){let n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],s=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,s,e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new i(e.radius,e.detail)}},cn=class i extends ke{constructor(e=1,t=1,n=1,s=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:s};let r=e/2,o=t/2,a=Math.floor(n),l=Math.floor(s),c=a+1,h=l+1,u=e/a,d=t/l,f=[],p=[],_=[],g=[];for(let m=0;m<h;m++){let v=m*d-o;for(let E=0;E<c;E++){let y=E*u-r;p.push(y,-v,0),_.push(0,0,1),g.push(E/a),g.push(1-m/l)}}for(let m=0;m<l;m++)for(let v=0;v<a;v++){let E=v+c*m,y=v+c*(m+1),w=v+1+c*(m+1),M=v+1+c*m;f.push(E,y,M),f.push(y,w,M)}this.setIndex(f),this.setAttribute("position",new _e(p,3)),this.setAttribute("normal",new _e(_,3)),this.setAttribute("uv",new _e(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.width,e.height,e.widthSegments,e.heightSegments)}},vs=class i extends ke{constructor(e=.5,t=1,n=32,s=1,r=0,o=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:s,thetaStart:r,thetaLength:o},n=Math.max(3,n),s=Math.max(1,s);let a=[],l=[],c=[],h=[],u=e,d=(t-e)/s,f=new A,p=new J;for(let _=0;_<=s;_++){for(let g=0;g<=n;g++){let m=r+g/n*o;f.x=u*Math.cos(m),f.y=u*Math.sin(m),l.push(f.x,f.y,f.z),c.push(0,0,1),p.x=(f.x/t+1)/2,p.y=(f.y/t+1)/2,h.push(p.x,p.y)}u+=d}for(let _=0;_<s;_++){let g=_*(n+1);for(let m=0;m<n;m++){let v=m+g,E=v,y=v+n+1,w=v+n+2,M=v+1;a.push(E,y,M),a.push(y,w,M)}}this.setIndex(a),this.setAttribute("position",new _e(l,3)),this.setAttribute("normal",new _e(c,3)),this.setAttribute("uv",new _e(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}},Sr=class i extends ke{constructor(e=new kt([new J(0,.5),new J(-.5,-.5),new J(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};let n=[],s=[],r=[],o=[],a=0,l=0;if(Array.isArray(e)===!1)c(e);else for(let h=0;h<e.length;h++)c(e[h]),this.addGroup(a,l,h),a+=l,l=0;this.setIndex(n),this.setAttribute("position",new _e(s,3)),this.setAttribute("normal",new _e(r,3)),this.setAttribute("uv",new _e(o,2));function c(h){let u=s.length/3,d=h.extractPoints(t),f=d.shape,p=d.holes;Ei.isClockWise(f)===!1&&(f=f.reverse());for(let g=0,m=p.length;g<m;g++){let v=p[g];Ei.isClockWise(v)===!0&&(p[g]=v.reverse())}let _=Ei.triangulateShape(f,p);for(let g=0,m=p.length;g<m;g++){let v=p[g];f=f.concat(v)}for(let g=0,m=f.length;g<m;g++){let v=f[g];s.push(v.x,v.y,0),r.push(0,0,1),o.push(v.x,v.y)}for(let g=0,m=_.length;g<m;g++){let v=_[g],E=v[0]+u,y=v[1]+u,w=v[2]+u;n.push(E,y,w),l+=3}}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON(),t=this.parameters.shapes;return Av(t,e)}static fromJSON(e,t){let n=[];for(let s=0,r=e.shapes.length;s<r;s++){let o=t[e.shapes[s]];n.push(o)}return new i(n,e.curveSegments)}};function Av(i,e){if(e.shapes=[],Array.isArray(i))for(let t=0,n=i.length;t<n;t++){let s=i[t];e.shapes.push(s.uuid)}else e.shapes.push(i.uuid);return e}var Rt=class i extends ke{constructor(e=1,t=32,n=16,s=0,r=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:s,phiLength:r,thetaStart:o,thetaLength:a},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));let l=Math.min(o+a,Math.PI),c=0,h=[],u=new A,d=new A,f=[],p=[],_=[],g=[];for(let m=0;m<=n;m++){let v=[],E=m/n,y=o+E*a,w=e*Math.cos(y),M=Math.sqrt(e*e-w*w),T=0;m===0&&o===0?T=.5/t:m===n&&l===Math.PI&&(T=-.5/t);for(let x=0;x<=t;x++){let S=x/t,C=s+S*r;u.x=-M*Math.cos(C),u.y=w,u.z=M*Math.sin(C),p.push(u.x,u.y,u.z),d.copy(u).normalize(),_.push(d.x,d.y,d.z),g.push(S+T,1-E),v.push(c++)}h.push(v)}for(let m=0;m<n;m++)for(let v=0;v<t;v++){let E=h[m][v+1],y=h[m][v],w=h[m+1][v],M=h[m+1][v+1];(m!==0||o>0)&&f.push(E,y,M),(m!==n-1||l<Math.PI)&&f.push(y,w,M)}this.setIndex(f),this.setAttribute("position",new _e(p,3)),this.setAttribute("normal",new _e(_,3)),this.setAttribute("uv",new _e(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}},pl=class i extends _s{constructor(e=1,t=0){let n=[1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],s=[2,1,0,0,3,2,1,3,0,2,3,1];super(n,s,e,t),this.type="TetrahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new i(e.radius,e.detail)}},dt=class i extends ke{constructor(e=1,t=.4,n=12,s=48,r=Math.PI*2,o=0,a=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:s,arc:r,thetaStart:o,thetaLength:a},n=Math.floor(n),s=Math.floor(s);let l=[],c=[],h=[],u=[],d=new A,f=new A,p=new A;for(let _=0;_<=n;_++){let g=o+_/n*a;for(let m=0;m<=s;m++){let v=m/s*r;f.x=(e+t*Math.cos(g))*Math.cos(v),f.y=(e+t*Math.cos(g))*Math.sin(v),f.z=t*Math.sin(g),c.push(f.x,f.y,f.z),d.x=e*Math.cos(v),d.y=e*Math.sin(v),p.subVectors(f,d).normalize(),h.push(p.x,p.y,p.z),u.push(m/s),u.push(_/n)}}for(let _=1;_<=n;_++)for(let g=1;g<=s;g++){let m=(s+1)*_+g-1,v=(s+1)*(_-1)+g-1,E=(s+1)*(_-1)+g,y=(s+1)*_+g;l.push(m,v,y),l.push(v,E,y)}this.setIndex(l),this.setAttribute("position",new _e(c,3)),this.setAttribute("normal",new _e(h,3)),this.setAttribute("uv",new _e(u,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc,e.thetaStart,e.thetaLength)}},ml=class i extends ke{constructor(e=1,t=.4,n=64,s=8,r=2,o=3){super(),this.type="TorusKnotGeometry",this.parameters={radius:e,tube:t,tubularSegments:n,radialSegments:s,p:r,q:o},n=Math.floor(n),s=Math.floor(s);let a=[],l=[],c=[],h=[],u=new A,d=new A,f=new A,p=new A,_=new A,g=new A,m=new A;for(let E=0;E<=n;++E){let y=E/n*r*Math.PI*2;v(y,r,o,e,f),v(y+.01,r,o,e,p),g.subVectors(p,f),m.addVectors(p,f),_.crossVectors(g,m),m.crossVectors(_,g),_.normalize(),m.normalize();for(let w=0;w<=s;++w){let M=w/s*Math.PI*2,T=-t*Math.cos(M),x=t*Math.sin(M);u.x=f.x+(T*m.x+x*_.x),u.y=f.y+(T*m.y+x*_.y),u.z=f.z+(T*m.z+x*_.z),l.push(u.x,u.y,u.z),d.subVectors(u,f).normalize(),c.push(d.x,d.y,d.z),h.push(E/n),h.push(w/s)}}for(let E=1;E<=n;E++)for(let y=1;y<=s;y++){let w=(s+1)*(E-1)+(y-1),M=(s+1)*E+(y-1),T=(s+1)*E+y,x=(s+1)*(E-1)+y;a.push(w,M,x),a.push(M,T,x)}this.setIndex(a),this.setAttribute("position",new _e(l,3)),this.setAttribute("normal",new _e(c,3)),this.setAttribute("uv",new _e(h,2));function v(E,y,w,M,T){let x=Math.cos(E),S=Math.sin(E),C=w/y*E,L=Math.cos(C);T.x=M*(2+L)*.5*x,T.y=M*(2+L)*S*.5,T.z=M*Math.sin(C)*.5}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new i(e.radius,e.tube,e.tubularSegments,e.radialSegments,e.p,e.q)}},et=class i extends ke{constructor(e=new Io(new A(-1,-1,0),new A(-1,1,0),new A(1,1,0)),t=64,n=1,s=8,r=!1){super(),this.type="TubeGeometry",this.parameters={path:e,tubularSegments:t,radius:n,radialSegments:s,closed:r};let o=e.computeFrenetFrames(t,r);this.tangents=o.tangents,this.normals=o.normals,this.binormals=o.binormals;let a=new A,l=new A,c=new J,h=new A,u=[],d=[],f=[],p=[];_(),this.setIndex(p),this.setAttribute("position",new _e(u,3)),this.setAttribute("normal",new _e(d,3)),this.setAttribute("uv",new _e(f,2));function _(){for(let E=0;E<t;E++)g(E);g(r===!1?t:0),v(),m()}function g(E){h=e.getPointAt(E/t,h);let y=o.normals[E],w=o.binormals[E];for(let M=0;M<=s;M++){let T=M/s*Math.PI*2,x=Math.sin(T),S=-Math.cos(T);l.x=S*y.x+x*w.x,l.y=S*y.y+x*w.y,l.z=S*y.z+x*w.z,l.normalize(),d.push(l.x,l.y,l.z),a.x=h.x+n*l.x,a.y=h.y+n*l.y,a.z=h.z+n*l.z,u.push(a.x,a.y,a.z)}}function m(){for(let E=1;E<=t;E++)for(let y=1;y<=s;y++){let w=(s+1)*(E-1)+(y-1),M=(s+1)*E+(y-1),T=(s+1)*E+y,x=(s+1)*(E-1)+y;p.push(w,M,x),p.push(M,T,x)}}function v(){for(let E=0;E<=t;E++)for(let y=0;y<=s;y++)c.x=E/t,c.y=y/s,f.push(c.x,c.y)}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return e.path=this.parameters.path.toJSON(),e}static fromJSON(e){return new i(new Kh[e.path.type]().fromJSON(e.path),e.tubularSegments,e.radius,e.radialSegments,e.closed)}},gl=class extends ke{constructor(e=null){if(super(),this.type="WireframeGeometry",this.parameters={geometry:e},e!==null){let t=[],n=new Set,s=new A,r=new A;if(e.index!==null){let o=e.attributes.position,a=e.index,l=e.groups;l.length===0&&(l=[{start:0,count:a.count,materialIndex:0}]);for(let c=0,h=l.length;c<h;++c){let u=l[c],d=u.start,f=u.count;for(let p=d,_=d+f;p<_;p+=3)for(let g=0;g<3;g++){let m=a.getX(p+g),v=a.getX(p+(g+1)%3);s.fromBufferAttribute(o,m),r.fromBufferAttribute(o,v),Km(s,r,n)===!0&&(t.push(s.x,s.y,s.z),t.push(r.x,r.y,r.z))}}}else{let o=e.attributes.position;for(let a=0,l=o.count/3;a<l;a++)for(let c=0;c<3;c++){let h=3*a+c,u=3*a+(c+1)%3;s.fromBufferAttribute(o,h),r.fromBufferAttribute(o,u),Km(s,r,n)===!0&&(t.push(s.x,s.y,s.z),t.push(r.x,r.y,r.z))}}this.setAttribute("position",new _e(t,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}};function Km(i,e,t){let n=`${i.x},${i.y},${i.z}-${e.x},${e.y},${e.z}`,s=`${e.x},${e.y},${e.z}-${i.x},${i.y},${i.z}`;return t.has(n)===!0||t.has(s)===!0?!1:(t.add(n),t.add(s),!0)}var $m=Object.freeze({__proto__:null,BoxGeometry:mi,CapsuleGeometry:sl,CircleGeometry:oi,ConeGeometry:vn,CylinderGeometry:xn,DodecahedronGeometry:rl,EdgesGeometry:ol,ExtrudeGeometry:en,IcosahedronGeometry:Tn,LatheGeometry:Oi,OctahedronGeometry:xs,PlaneGeometry:cn,PolyhedronGeometry:_s,RingGeometry:vs,ShapeGeometry:Sr,SphereGeometry:Rt,TetrahedronGeometry:pl,TorusGeometry:dt,TorusKnotGeometry:ml,TubeGeometry:et,WireframeGeometry:gl}),_l=class extends _n{constructor(e){super(),this.isShadowMaterial=!0,this.type="ShadowMaterial",this.color=new q(0),this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.fog=e.fog,this}};function Or(i){let e={};for(let t in i){e[t]={};for(let n in i[t]){let s=i[t][n];if(jm(s))s.isRenderTargetTexture?(be("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=s.clone();else if(Array.isArray(s))if(jm(s[0])){let r=[];for(let o=0,a=s.length;o<a;o++)r[o]=s[o].clone();e[t][n]=r}else e[t][n]=s.slice();else e[t][n]=s}}return e}function Wn(i){let e={};for(let t=0;t<i.length;t++){let n=Or(i[t]);for(let s in n)e[s]=n[s]}return e}function jm(i){return i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)}function Cv(i){let e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function ip(i){let e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Mt.workingColorSpace}var wi={clone:Or,merge:Wn},Pv=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Iv=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,xt=class extends _n{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Pv,this.fragmentShader=Iv,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Or(e.uniforms),this.uniformsGroups=Cv(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let s in this.uniforms){let o=this.uniforms[s].value;o&&o.isTexture?t.uniforms[s]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[s]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[s]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[s]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[s]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[s]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[s]={type:"m4",value:o.toArray()}:t.uniforms[s]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let s in this.extensions)this.extensions[s]===!0&&(n[s]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(let n in e.uniforms){let s=e.uniforms[n];switch(this.uniforms[n]={},s.type){case"t":this.uniforms[n].value=t[s.value]||null;break;case"c":this.uniforms[n].value=new q().setHex(s.value);break;case"v2":this.uniforms[n].value=new J().fromArray(s.value);break;case"v3":this.uniforms[n].value=new A().fromArray(s.value);break;case"v4":this.uniforms[n].value=new Ut().fromArray(s.value);break;case"m3":this.uniforms[n].value=new ht().fromArray(s.value);break;case"m4":this.uniforms[n].value=new nt().fromArray(s.value);break;default:this.uniforms[n].value=s.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(let n in e.extensions)this.extensions[n]=e.extensions[n];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}},Ws=class extends xt{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}},Xs=class extends _n{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new q(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new q(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Qi,this.normalScale=new J(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Gn,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},hn=class extends Xs{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new J(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return at(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(t){this.ior=(1+.4*t)/(1-.4*t)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new q(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new q(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new q(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._retroreflectivity=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get retroreflectivity(){return this._retroreflectivity}set retroreflectivity(e){this._retroreflectivity>0!=e>0&&this.version++,this._retroreflectivity=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.retroreflectivity=e.retroreflectivity,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}},xl=class extends _n{constructor(e){super(),this.isMeshPhongMaterial=!0,this.type="MeshPhongMaterial",this.color=new q(16777215),this.specular=new q(1118481),this.shininess=30,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new q(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Qi,this.normalScale=new J(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Gn,this.combine=Xo,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.specular.copy(e.specular),this.shininess=e.shininess,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.envMapIntensity=e.envMapIntensity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},Ht=class extends _n{constructor(e){super(),this.isMeshToonMaterial=!0,this.defines={TOON:""},this.type="MeshToonMaterial",this.color=new q(16777215),this.map=null,this.gradientMap=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new q(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Qi,this.normalScale=new J(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.alphaMap=null,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.gradientMap=e.gradientMap,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.alphaMap=e.alphaMap,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},vl=class extends _n{constructor(e){super(),this.isMeshNormalMaterial=!0,this.type="MeshNormalMaterial",this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Qi,this.normalScale=new J(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.flatShading=!1,this.setValues(e)}copy(e){return super.copy(e),this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.flatShading=e.flatShading,this}},yl=class extends _n{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new q(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new q(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Qi,this.normalScale=new J(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Gn,this.combine=Xo,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.envMapIntensity=e.envMapIntensity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},No=class extends _n{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Xf,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},Uo=class extends _n{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}},Ml=class extends _n{constructor(e){super(),this.isMeshMatcapMaterial=!0,this.defines={MATCAP:""},this.type="MeshMatcapMaterial",this.color=new q(16777215),this.matcap=null,this.map=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Qi,this.normalScale=new J(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.alphaMap=null,this.wireframe=!1,this.wireframeLinewidth=1,this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={MATCAP:""},this.color.copy(e.color),this.matcap=e.matcap,this.map=e.map,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.alphaMap=e.alphaMap,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.flatShading=e.flatShading,this.fog=e.fog,this}},bl=class extends tn{constructor(e){super(),this.isLineDashedMaterial=!0,this.type="LineDashedMaterial",this.scale=1,this.dashSize=3,this.gapSize=1,this.setValues(e)}copy(e){return super.copy(e),this.scale=e.scale,this.dashSize=e.dashSize,this.gapSize=e.gapSize,this}};function Di(i,e){return!i||i.constructor===e?i:typeof e.BYTES_PER_ELEMENT=="number"?new e(i):Array.prototype.slice.call(i)}function Oa(i){return i!==void 0&&i.inTangents!==void 0&&i.outTangents!==void 0}function yg(i){function e(s,r){return i[s]-i[r]}let t=i.length,n=new Array(t);for(let s=0;s!==t;++s)n[s]=s;return n.sort(e),n}function lf(i,e,t){let n=i.length,s=new i.constructor(n);for(let r=0,o=0;o!==n;++r){let a=t[r]*e;for(let l=0;l!==e;++l)s[o++]=i[a+l]}return s}function Mg(i,e,t,n){let s=1,r=i[0];for(;r!==void 0&&r[n]===void 0;)r=i[s++];if(r===void 0)return;let o=r[n];if(o!==void 0)if(Array.isArray(o))do o=r[n],o!==void 0&&(e.push(r.time),t.push(...o)),r=i[s++];while(r!==void 0);else if(o.toArray!==void 0)do o=r[n],o!==void 0&&(e.push(r.time),o.toArray(t,t.length)),r=i[s++];while(r!==void 0);else do o=r[n],o!==void 0&&(e.push(r.time),t.push(o)),r=i[s++];while(r!==void 0)}function Dv(i,e,t,n,s=30){let r=i.clone();r.name=e;let o=[];for(let l=0;l<r.tracks.length;++l){let c=r.tracks[l],h=c.getValueSize(),u=[],d=[];for(let f=0;f<c.times.length;++f){let p=c.times[f]*s;if(!(p<t||p>=n)){u.push(c.times[f]);for(let _=0;_<h;++_)d.push(c.values[f*h+_])}}u.length!==0&&(c.times=Di(u,c.times.constructor),c.values=Di(d,c.values.constructor),o.push(c))}r.tracks=o;let a=1/0;for(let l=0;l<r.tracks.length;++l)a>r.tracks[l].times[0]&&(a=r.tracks[l].times[0]);for(let l=0;l<r.tracks.length;++l)r.tracks[l].shift(-1*a);return r.resetDuration(),r}function Lv(i,e=0,t=i,n=30){n<=0&&(n=30);let s=t.tracks.length,r=e/n;for(let o=0;o<s;++o){let a=t.tracks[o],l=a.ValueTypeName;if(l==="bool"||l==="string")continue;let c=i.tracks.find(function(m){return m.name===a.name&&m.ValueTypeName===l});if(c===void 0)continue;let h=0,u=a.getValueSize();a.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline&&(h=u/3);let d=0,f=c.getValueSize();c.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline&&(d=f/3);let p=a.times.length-1,_;if(r<=a.times[0]){let m=h,v=u-h;_=a.values.slice(m,v)}else if(r>=a.times[p]){let m=p*u+h,v=m+u-h;_=a.values.slice(m,v)}else{let m=a.createInterpolant(),v=h,E=u-h;m.evaluate(r),_=m.resultBuffer.slice(v,E)}l==="quaternion"&&new $t().fromArray(_).normalize().conjugate().toArray(_);let g=c.times.length;for(let m=0;m<g;++m){let v=m*f+d;if(l==="quaternion")$t.multiplyQuaternionsFlat(c.values,v,_,0,c.values,v);else{let E=f-d*2;for(let y=0;y<E;++y)c.values[v+y]-=_[y]}}}return i.blendMode=Ku,i}var $h=class{static convertArray(e,t){return Di(e,t)}static isTypedArray(e){return lg(e)}static hasTangents(e){return Oa(e)}static getKeyframeOrder(e){return yg(e)}static sortedArray(e,t,n){return lf(e,t,n)}static flattenJSON(e,t,n,s){Mg(e,t,n,s)}static subclip(e,t,n,s,r=30){return Dv(e,t,n,s,r)}static makeClipAdditive(e,t=0,n=e,s=30){return Lv(e,t,n,s)}},ys=class{constructor(e,t,n,s){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=s!==void 0?s:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,s=t[n],r=t[n-1];e:{t:{let o;n:{i:if(!(e<s)){for(let a=n+2;;){if(s===void 0){if(e<r)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(r=s,s=t[++n],e<s)break t}o=t.length;break n}if(!(e>=r)){let a=t[1];e<a&&(n=2,r=a);for(let l=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(s=r,r=t[--n-1],e>=r)break t}o=n,n=0;break n}break e}for(;n<o;){let a=n+o>>>1;e<t[a]?o=a:n=a+1}if(s=t[n],r=t[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(s===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,s)}return this.interpolate_(n,r,e,s)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,s=this.valueSize,r=e*s;for(let o=0;o!==s;++o)t[o]=n[r+o];return t}interpolate_(){throw new Error("THREE.Interpolant: Call to abstract method.")}intervalChanged_(){}},El=class extends ys{constructor(e,t,n,s){super(e,t,n,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Bs,endingEnd:Bs}}intervalChanged_(e,t,n){let s=this.parameterPositions,r=e-2,o=e+1,a=s[r],l=s[o];if(a===void 0)switch(this.getSettings_().endingStart){case Os:r=e,a=2*t-n;break;case xo:r=s.length-2,a=t+s[r]-s[r+1];break;default:r=e,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case Os:o=e,l=2*n-t;break;case xo:o=1,l=n+s[1]-s[0];break;default:o=e-1,l=t}let c=(n-t)*.5,h=this.valueSize;this._weightPrev=c/(t-a),this._weightNext=c/(l-n),this._offsetPrev=r*h,this._offsetNext=o*h}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,p=(n-t)/(s-t),_=p*p,g=_*p,m=-d*g+2*d*_-d*p,v=(1+d)*g+(-1.5-2*d)*_+(-.5+d)*p+1,E=(-1-f)*g+(1.5+f)*_+.5*p,y=f*g-f*_;for(let w=0;w!==a;++w)r[w]=m*o[h+w]+v*o[c+w]+E*o[l+w]+y*o[u+w];return r}},Fo=class extends ys{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=(n-t)/(s-t),u=1-h;for(let d=0;d!==a;++d)r[d]=o[c+d]*u+o[l+d]*h;return r}},Sl=class extends ys{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e){return this.copySampleValue_(e-1)}},Tl=class extends ys{interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=this.inTangents,u=this.outTangents;if(!h||!u){let p=(n-t)/(s-t),_=1-p;for(let g=0;g!==a;++g)r[g]=o[c+g]*_+o[l+g]*p;return r}let d=a*2,f=e-1;for(let p=0;p!==a;++p){let _=o[c+p],g=o[l+p],m=f*d+p*2,v=u[m],E=u[m+1],y=e*d+p*2,w=h[y],M=h[y+1],T=Uv(n,t,v,w,s);r[p]=bg(T,_,E,M,g)}return r}};function bg(i,e,t,n,s){let r=1-i;return r*r*r*e+3*r*r*i*t+3*r*i*i*n+i*i*i*s}function Nv(i,e,t,n,s){let r=1-i;return 3*r*r*(t-e)+6*r*i*(n-t)+3*i*i*(s-n)}function Uv(i,e,t,n,s){let r=(i-e)/(s-e);for(let o=0;o<8;o++){let a=bg(r,e,t,n,s)-i;if(Math.abs(a)<1e-10)break;let l=Nv(r,e,t,n,s);if(Math.abs(l)<1e-10)break;r=Math.max(0,Math.min(1,r-a/l))}return r}var jn=class{constructor(e,t,n,s){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Di(t,this.TimeBufferType),this.values=Di(n,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Di(e.times,Array),values:Di(e.values,Array)};let s=e.getInterpolation();s!==e.DefaultInterpolation&&(n.interpolation=s),Oa(e.settings)&&(n.settings={inTangents:Di(e.settings.inTangents,Array),outTangents:Di(e.settings.outTangents,Array)})}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new Sl(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Fo(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new El(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){let t=new Tl(this.times,this.values,this.getValueSize(),e);return this.settings&&(t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents),t}setInterpolation(e){let t;switch(e){case _o:t=this.InterpolantFactoryMethodDiscrete;break;case Ya:t=this.InterpolantFactoryMethodLinear;break;case La:t=this.InterpolantFactoryMethodSmooth;break;case Dh:t=this.InterpolantFactoryMethodBezier;break}if(t===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return be("KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return _o;case this.InterpolantFactoryMethodLinear:return Ya;case this.InterpolantFactoryMethodSmooth:return La;case this.InterpolantFactoryMethodBezier:return Dh}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,s=t.length;n!==s;++n)t[n]*=e;Oa(this.settings)&&(Qm(this.settings.inTangents,e),Qm(this.settings.outTangents,e))}return this}trim(e,t){let n=this.times,s=n.length,r=0,o=s-1;for(;r!==s&&n[r]<e;)++r;for(;o!==-1&&n[o]>t;)--o;if(++o,r!==0||o!==s){r>=o&&(o=Math.max(o,1),r=o-1);let a=this.getValueSize();this.times=n.slice(r,o),this.values=this.values.slice(r*a,o*a)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(qe("KeyframeTrack: Invalid value size in track.",this),e=!1);let n=this.times,s=this.values,r=n.length;r===0&&(qe("KeyframeTrack: Track is empty.",this),e=!1);let o=null;for(let a=0;a!==r;a++){let l=n[a];if(typeof l=="number"&&isNaN(l)){qe("KeyframeTrack: Time is not a valid number.",this,a,l),e=!1;break}if(o!==null&&o>l){qe("KeyframeTrack: Out of order keys.",this,a,l,o),e=!1;break}o=l}if(s!==void 0&&lg(s))for(let a=0,l=s.length;a!==l;++a){let c=s[a];if(isNaN(c)){qe("KeyframeTrack: Value is not a valid number.",this,a,c),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),s=this.getInterpolation()===La,r=e.length-1,o=1;for(let a=1;a<r;++a){let l=!1,c=e[a],h=e[a+1];if(c!==h&&(a!==1||c!==e[0]))if(s)l=!0;else{let u=a*n,d=u-n,f=u+n;for(let p=0;p!==n;++p){let _=t[u+p];if(_!==t[d+p]||_!==t[f+p]){l=!0;break}}}if(l){if(a!==o){e[o]=e[a];let u=a*n,d=o*n;for(let f=0;f!==n;++f)t[d+f]=t[u+f]}++o}}if(r>0){e[o]=e[r];for(let a=r*n,l=o*n,c=0;c!==n;++c)t[l+c]=t[a+c];++o}return o!==e.length?(this.times=e.slice(0,o),this.values=t.slice(0,o*n)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,s=new n(this.name,e,t);return s.createInterpolant=this.createInterpolant,Oa(this.settings)&&(s.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()}),s}};function Qm(i,e){for(let t=0,n=i.length;t!==n;t+=2)i[t]*=e}jn.prototype.ValueTypeName="";jn.prototype.TimeBufferType=Float32Array;jn.prototype.ValueBufferType=Float32Array;jn.prototype.DefaultInterpolation=Ya;var Ki=class extends jn{constructor(e,t,n){super(e,t,n)}};Ki.prototype.ValueTypeName="bool";Ki.prototype.ValueBufferType=Array;Ki.prototype.DefaultInterpolation=_o;Ki.prototype.InterpolantFactoryMethodLinear=void 0;Ki.prototype.InterpolantFactoryMethodSmooth=void 0;var Bo=class extends jn{constructor(e,t,n,s){super(e,t,n,s)}};Bo.prototype.ValueTypeName="color";var Tr=class extends jn{constructor(e,t,n,s){super(e,t,n,s)}};Tr.prototype.ValueTypeName="number";var wl=class extends ys{constructor(e,t,n,s){super(e,t,n,s)}interpolate_(e,t,n,s){let r=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-t)/(s-t),c=e*a;for(let h=c+a;c!==h;c+=4)$t.slerpFlat(r,0,o,c-a,o,c,l);return r}},wr=class extends jn{constructor(e,t,n,s){super(e,t,n,s)}InterpolantFactoryMethodLinear(e){return new wl(this.times,this.values,this.getValueSize(),e)}};wr.prototype.ValueTypeName="quaternion";wr.prototype.InterpolantFactoryMethodSmooth=void 0;var $i=class extends jn{constructor(e,t,n){super(e,t,n)}};$i.prototype.ValueTypeName="string";$i.prototype.ValueBufferType=Array;$i.prototype.DefaultInterpolation=_o;$i.prototype.InterpolantFactoryMethodLinear=void 0;$i.prototype.InterpolantFactoryMethodSmooth=void 0;var Oo=class extends jn{constructor(e,t,n,s){super(e,t,n,s)}};Oo.prototype.ValueTypeName="vector";var Ys=class{constructor(e="",t=-1,n=[],s=Sc){this.name=e,this.tracks=n,this.duration=t,this.blendMode=s,this.uuid=fi(),this.userData={},this.duration<0&&this.resetDuration()}static parse(e){let t=[],n=e.tracks,s=1/(e.fps||1);for(let o=0,a=n.length;o!==a;++o)t.push(Bv(n[o]).scale(s));let r=new this(e.name,e.duration,t,e.blendMode);return r.uuid=e.uuid,r.userData=JSON.parse(e.userData||"{}"),r}static toJSON(e){let t=[],n=e.tracks,s={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode,userData:JSON.stringify(e.userData)};for(let r=0,o=n.length;r!==o;++r)t.push(jn.toJSON(n[r]));return s}static CreateFromMorphTargetSequence(e,t,n,s){let r=t.length,o=[];for(let a=0;a<r;a++){let l=[],c=[];l.push((a+r-1)%r,a,(a+1)%r),c.push(0,1,0);let h=yg(l);l=lf(l,1,h),c=lf(c,1,h),!s&&l[0]===0&&(l.push(r),c.push(c[0])),o.push(new Tr(".morphTargetInfluences["+t[a].name+"]",l,c).scale(1/n))}return new this(e,-1,o)}static findByName(e,t){let n=e;if(!Array.isArray(e)){let s=e;n=s.geometry&&s.geometry.animations||s.animations}for(let s=0;s<n.length;s++)if(n[s].name===t)return n[s];return null}static CreateClipsFromMorphTargetSequences(e,t,n){let s={},r=/^([\w-]*?)([\d]+)$/;for(let a=0,l=e.length;a<l;a++){let c=e[a],h=c.name.match(r);if(h&&h.length>1){let u=h[1],d=s[u];d||(s[u]=d=[]),d.push(c)}}let o=[];for(let a in s)o.push(this.CreateFromMorphTargetSequence(a,s[a],t,n));return o}resetDuration(){let e=this.tracks,t=0;for(let n=0,s=e.length;n!==s;++n){let r=this.tracks[n];t=Math.max(t,r.times[r.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){let e=[];for(let n=0;n<this.tracks.length;n++)e.push(this.tracks[n].clone());let t=new this.constructor(this.name,this.duration,e,this.blendMode);return t.userData=JSON.parse(JSON.stringify(this.userData)),t}toJSON(){return this.constructor.toJSON(this)}};function Fv(i){switch(i.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return Tr;case"vector":case"vector2":case"vector3":case"vector4":return Oo;case"color":return Bo;case"quaternion":return wr;case"bool":case"boolean":return Ki;case"string":return $i}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+i)}function Bv(i){if(i.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");let e=Fv(i.type);if(i.times===void 0){let n=[],s=[];Mg(i.keys,n,s,"value"),i.times=n,i.values=s}let t;return e.parse!==void 0?t=e.parse(i):t=new e(i.name,i.times,i.values,i.interpolation),Oa(i.settings)&&(t.settings={inTangents:Di(i.settings.inTangents,Float32Array),outTangents:Di(i.settings.outTangents,Float32Array)}),t}var Ni={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(e0(i)||(this.files[i]=e))},get:function(i){if(this.enabled!==!1&&!e0(i))return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};function e0(i){try{let e=i.slice(i.indexOf(":")+1);return new URL(e).protocol==="blob:"}catch{return!1}}var Ho=class{constructor(e,t,n){let s=this,r=!1,o=0,a=0,l,c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this._abortController=null,this.itemStart=function(h){a++,r===!1&&s.onStart!==void 0&&s.onStart(h,o,a),r=!0},this.itemEnd=function(h){o++,s.onProgress!==void 0&&s.onProgress(h,o,a),o===a&&(r=!1,s.onLoad!==void 0&&s.onLoad())},this.itemError=function(h){s.onError!==void 0&&s.onError(h)},this.resolveURL=function(h){return h=h.normalize("NFC"),l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){let u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){let f=c[u],p=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return p}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}},sp=new Ho,Fn=class{constructor(e){this.manager=e!==void 0?e:sp,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}load(){}loadAsync(e,t){let n=this;return new Promise(function(s,r){n.load(e,s,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}};Fn.DEFAULT_MATERIAL_NAME="__DEFAULT";var hs={},cf=class extends Error{constructor(e,t){super(e),this.response=t}},Si=class extends Fn{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=Ni.get(`file:${e}`);if(r!==void 0){this.manager.itemStart(e),setTimeout(()=>{t&&t(r),this.manager.itemEnd(e)},0);return}if(hs[e]!==void 0){hs[e].push({onLoad:t,onProgress:n,onError:s});return}hs[e]=[],hs[e].push({onLoad:t,onProgress:n,onError:s});let o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),a=this.mimeType,l=this.responseType;fetch(o).then(c=>{if(c.status===200||c.status===0){if(c.status===0&&be("FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||c.body===void 0||c.body.getReader===void 0)return c;let h=hs[e],u=c.body.getReader(),d=c.headers.get("X-File-Size")||c.headers.get("Content-Length"),f=d?parseInt(d):0,p=f!==0,_=0,g=new ReadableStream({start(m){v();function v(){u.read().then(({done:E,value:y})=>{if(E)m.close();else{_+=y.byteLength;let w=new ProgressEvent("progress",{lengthComputable:p,loaded:_,total:f});for(let M=0,T=h.length;M<T;M++){let x=h[M];x.onProgress&&x.onProgress(w)}m.enqueue(y),v()}},E=>{m.error(E)})}}});return new Response(g)}else throw new cf(`fetch for "${c.url}" responded with ${c.status}: ${c.statusText}`,c)}).then(c=>{switch(l){case"arraybuffer":return c.arrayBuffer();case"blob":return c.blob();case"document":return c.text().then(h=>new DOMParser().parseFromString(h,a));case"json":return c.json();default:if(a==="")return c.text();{let u=/charset="?([^;"\s]*)"?/i.exec(a),d=u&&u[1]?u[1].toLowerCase():void 0,f=new TextDecoder(d);return c.arrayBuffer().then(p=>f.decode(p))}}}).then(c=>{Ni.add(`file:${e}`,c);let h=hs[e];delete hs[e];for(let u=0,d=h.length;u<d;u++){let f=h[u];f.onLoad&&f.onLoad(c)}}).catch(c=>{let h=hs[e];if(h===void 0)throw this.manager.itemError(e),c;delete hs[e];for(let u=0,d=h.length;u<d;u++){let f=h[u];f.onError&&f.onError(c)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}},jh=class extends Fn{constructor(e){super(e)}load(e,t,n,s){let r=this,o=new Si(this.manager);o.setPath(this.path),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(a){try{t(r.parse(JSON.parse(a)))}catch(l){s?s(l):qe(l),r.manager.itemError(e)}},n,s)}parse(e){let t=[];for(let n=0;n<e.length;n++){let s=Ys.parse(e[n]);t.push(s)}return t}},Qh=class extends Fn{constructor(e){super(e)}load(e,t,n,s){let r=this,o=[],a=new Mr,l=new Si(this.manager);l.setPath(this.path),l.setResponseType("arraybuffer"),l.setRequestHeader(this.requestHeader),l.setWithCredentials(r.withCredentials);let c=0;function h(u){l.load(e[u],function(d){let f=r.parse(d,!0);o[u]={width:f.width,height:f.height,format:f.format,mipmaps:f.mipmaps},c+=1,c===6&&(f.mipmapCount===1&&(a.minFilter=Xt),a.image=o,a.format=f.format,a.needsUpdate=!0,t&&t(a))},n,s)}if(Array.isArray(e))for(let u=0,d=e.length;u<d;++u)h(u);else l.load(e,function(u){let d=r.parse(u,!0);if(d.isCubemap){let f=d.mipmaps.length/d.mipmapCount;for(let p=0;p<f;p++){o[p]={mipmaps:[]};for(let _=0;_<d.mipmapCount;_++)o[p].mipmaps.push(d.mipmaps[p*d.mipmapCount+_]),o[p].format=d.format,o[p].width=d.width,o[p].height=d.height}a.image=o}else a.image.width=d.width,a.image.height=d.height,a.mipmaps=d.mipmaps;d.mipmapCount===1&&(a.minFilter=Xt),a.format=d.format,a.needsUpdate=!0,t&&t(a)},n,s);return a}},lo=new WeakMap,qs=class extends Fn{constructor(e){super(e)}load(e,t,n,s){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=this,o=Ni.get(`image:${e}`);if(o!==void 0){if(o.complete===!0)r.manager.itemStart(e),setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0);else{let u=lo.get(o);u===void 0&&(u=[],lo.set(o,u)),u.push({onLoad:t,onError:s})}return o}let a=Mo("img");function l(){h(),t&&t(this);let u=lo.get(this)||[];for(let d=0;d<u.length;d++){let f=u[d];f.onLoad&&f.onLoad(this)}lo.delete(this),r.manager.itemEnd(e)}function c(u){h(),s&&s(u),Ni.remove(`image:${e}`);let d=lo.get(this)||[];for(let f=0;f<d.length;f++){let p=d[f];p.onError&&p.onError(u)}lo.delete(this),r.manager.itemError(e),r.manager.itemEnd(e)}function h(){a.removeEventListener("load",l,!1),a.removeEventListener("error",c,!1)}return a.addEventListener("load",l,!1),a.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),Ni.add(`image:${e}`,a),r.manager.itemStart(e),a.src=e,a}},eu=class extends Fn{constructor(e){super(e)}load(e,t,n,s){let r=new Vs;r.colorSpace=Wt;let o=new qs(this.manager);o.setCrossOrigin(this.crossOrigin),o.setPath(this.path);let a=0;function l(c){o.load(e[c],function(h){r.images[c]=h,a++,a===6&&(r.needsUpdate=!0,t&&t(r))},void 0,s)}for(let c=0;c<e.length;++c)l(c);return r}},tu=class extends Fn{constructor(e){super(e)}load(e,t,n,s){let r=this,o=new Un,a=new Si(this.manager);return a.setResponseType("arraybuffer"),a.setRequestHeader(this.requestHeader),a.setPath(this.path),a.setWithCredentials(r.withCredentials),a.load(e,function(l){let c;try{c=r.parse(l)}catch(h){s!==void 0?s(h):qe(h);return}r._applyTexData(o,c),t&&t(o,c)},n,s),o}createDataTexture(e){let t=new Un;return this._applyTexData(t,this.parse(e)),t}_applyTexData(e,t){t.image!==void 0?e.image=t.image:t.data!==void 0&&(e.image.width=t.width,e.image.height=t.height,e.image.data=t.data),e.wrapS=t.wrapS!==void 0?t.wrapS:$n,e.wrapT=t.wrapT!==void 0?t.wrapT:$n,e.magFilter=t.magFilter!==void 0?t.magFilter:Xt,e.minFilter=t.minFilter!==void 0?t.minFilter:Xt,e.anisotropy=t.anisotropy!==void 0?t.anisotropy:1,t.colorSpace!==void 0&&(e.colorSpace=t.colorSpace),t.flipY!==void 0&&(e.flipY=t.flipY),t.format!==void 0&&(e.format=t.format),t.type!==void 0&&(e.type=t.type),t.mipmaps!==void 0&&(e.mipmaps=t.mipmaps,e.minFilter=Gi),t.mipmapCount===1&&(e.minFilter=Xt),t.generateMipmaps!==void 0&&(e.generateMipmaps=t.generateMipmaps),e.needsUpdate=!0}},nu=class extends Fn{constructor(e){super(e)}load(e,t,n,s){let r=new an,o=new qs(this.manager);return o.setCrossOrigin(this.crossOrigin),o.setPath(this.path),o.load(e,function(a){r.image=a,r.needsUpdate=!0,t!==void 0&&t(r)},n,s),r}},Hi=class extends _t{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new q(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}},Rr=class extends Hi{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(_t.DEFAULT_UP),this.updateMatrix(),this.groundColor=new q(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){let t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}},Jd=new nt,t0=new A,n0=new A,Ar=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new J(512,512),this.mapType=Qn,this.map=null,this.mapPass=null,this.matrix=new nt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Ji,this._frameExtents=new J(1,1),this._viewportCount=1,this._viewports=[new Ut(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera;t0.setFromMatrixPosition(e.matrixWorld),t.position.copy(t0),n0.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(n0),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,s){Jd.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(Jd,e.coordinateSystem,e.reversedDepth);let r=this._frameExtents,o=s?s.z/r.x:1,a=s?s.w/r.y:1,l=s?s.x/r.x:0,c=s?s.y/r.y:0;e.coordinateSystem===zs||e.reversedDepth?t.set(.5*o,0,0,.5*o+l,0,.5*a,0,.5*a+c,0,0,1,0,0,0,0,1):t.set(.5*o,0,0,.5*o+l,0,.5*a,0,.5*a+c,0,0,.5,.5,0,0,0,1),t.multiply(Jd)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},bh=new A,Eh=new $t,Yi=new A,Cr=class extends _t{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new nt,this.projectionMatrix=new nt,this.projectionMatrixInverse=new nt,this.coordinateSystem=si,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(bh,Eh,Yi),Yi.x===1&&Yi.y===1&&Yi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(bh,Eh,Yi.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(bh,Eh,Yi),Yi.x===1&&Yi.y===1&&Yi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(bh,Eh,Yi.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}},Us=new A,i0=new J,s0=new J,on=class extends Cr{constructor(e=50,t=1,n=.1,s=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=s,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=mr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(fr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return mr*2*Math.atan(Math.tan(fr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Us.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Us.x,Us.y).multiplyScalar(-e/Us.z),Us.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Us.x,Us.y).multiplyScalar(-e/Us.z)}getViewSize(e,t){return this.getViewBounds(e,i0,s0),t.subVectors(s0,i0)}setViewOffset(e,t,n,s,r,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(fr*.5*this.fov)/this.zoom,n=2*t,s=this.aspect*n,r=-.5*s,o=this.view;if(this.view!==null&&this.view.enabled){let l=o.fullWidth,c=o.fullHeight;r+=o.offsetX*s/l,t-=o.offsetY*n/c,s*=o.width/l,n*=o.height/c}let a=this.filmOffset;a!==0&&(r+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},hf=class extends Ar{constructor(){super(new on(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1,this.aspect=1}updateMatrices(e){let t=this.camera,n=mr*2*e.angle*this.focus,s=this.mapSize.width/this.mapSize.height*this.aspect,r=e.distance||t.far;(n!==t.fov||s!==t.aspect||r!==t.far)&&(t.fov=n,t.aspect=s,t.far=r,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this.aspect=e.aspect,this}toJSON(){let e=super.toJSON();return e.focus=this.focus,e.aspect=this.aspect,e}},Rl=class extends Hi{constructor(e,t,n=0,s=Math.PI/3,r=0,o=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(_t.DEFAULT_UP),this.updateMatrix(),this.target=new _t,this.distance=n,this.angle=s,this.penumbra=r,this.decay=o,this.map=null,this.shadow=new hf}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.map=e.map,this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.distance=this.distance,t.object.angle=this.angle,t.object.decay=this.decay,t.object.penumbra=this.penumbra,t.object.target=this.target.uuid,this.map&&this.map.isTexture&&(t.object.map=this.map.toJSON(e).uuid),t.object.shadow=this.shadow.toJSON(),t}},uf=class extends Ar{constructor(){super(new on(90,1,.5,500)),this.isPointLightShadow=!0}},Yt=class extends Hi{constructor(e,t,n=0,s=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=s,this.shadow=new uf}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.distance=this.distance,t.object.decay=this.decay,t.object.shadow=this.shadow.toJSON(),t}},ji=class extends Cr{constructor(e=-1,t=1,n=1,s=-1,r=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=s,this.near=r,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,s,r,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=s,this.view.width=r,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=n-e,o=n+e,a=s+t,l=s-t;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,o=r+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(r,o,a,l,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},df=class extends Ar{constructor(){super(new ji(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Ms=class extends Hi{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(_t.DEFAULT_UP),this.updateMatrix(),this.target=new _t,this.shadow=new df}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}},Al=class extends Hi{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}},Cl=class extends Hi{constructor(e,t,n=10,s=10){super(e,t),this.isRectAreaLight=!0,this.type="RectAreaLight",this.width=n,this.height=s}get power(){return this.intensity*this.width*this.height*Math.PI}set power(e){this.intensity=e/(this.width*this.height*Math.PI)}copy(e){return super.copy(e),this.width=e.width,this.height=e.height,this}toJSON(e){let t=super.toJSON(e);return t.object.width=this.width,t.object.height=this.height,t}},zo=class{constructor(){this.isSphericalHarmonics3=!0,this.coefficients=[];for(let e=0;e<9;e++)this.coefficients.push(new A)}set(e){for(let t=0;t<9;t++)this.coefficients[t].copy(e[t]);return this}zero(){for(let e=0;e<9;e++)this.coefficients[e].set(0,0,0);return this}getAt(e,t){let n=e.x,s=e.y,r=e.z,o=this.coefficients;return t.copy(o[0]).multiplyScalar(.282095),t.addScaledVector(o[1],.488603*s),t.addScaledVector(o[2],.488603*r),t.addScaledVector(o[3],.488603*n),t.addScaledVector(o[4],1.092548*(n*s)),t.addScaledVector(o[5],1.092548*(s*r)),t.addScaledVector(o[6],.315392*(3*r*r-1)),t.addScaledVector(o[7],1.092548*(n*r)),t.addScaledVector(o[8],.546274*(n*n-s*s)),t}getIrradianceAt(e,t){let n=e.x,s=e.y,r=e.z,o=this.coefficients;return t.copy(o[0]).multiplyScalar(.886227),t.addScaledVector(o[1],2*.511664*s),t.addScaledVector(o[2],2*.511664*r),t.addScaledVector(o[3],2*.511664*n),t.addScaledVector(o[4],2*.429043*n*s),t.addScaledVector(o[5],2*.429043*s*r),t.addScaledVector(o[6],.743125*r*r-.247708),t.addScaledVector(o[7],2*.429043*n*r),t.addScaledVector(o[8],.429043*(n*n-s*s)),t}add(e){for(let t=0;t<9;t++)this.coefficients[t].add(e.coefficients[t]);return this}addScaledSH(e,t){for(let n=0;n<9;n++)this.coefficients[n].addScaledVector(e.coefficients[n],t);return this}scale(e){for(let t=0;t<9;t++)this.coefficients[t].multiplyScalar(e);return this}lerp(e,t){for(let n=0;n<9;n++)this.coefficients[n].lerp(e.coefficients[n],t);return this}equals(e){for(let t=0;t<9;t++)if(!this.coefficients[t].equals(e.coefficients[t]))return!1;return!0}copy(e){return this.set(e.coefficients)}clone(){return new this.constructor().copy(this)}fromArray(e,t=0){let n=this.coefficients;for(let s=0;s<9;s++)n[s].fromArray(e,t+s*3);return this}toArray(e=[],t=0){let n=this.coefficients;for(let s=0;s<9;s++)n[s].toArray(e,t+s*3);return e}static getBasisAt(e,t){let n=e.x,s=e.y,r=e.z;t[0]=.282095,t[1]=.488603*s,t[2]=.488603*r,t[3]=.488603*n,t[4]=1.092548*n*s,t[5]=1.092548*s*r,t[6]=.315392*(3*r*r-1),t[7]=1.092548*n*r,t[8]=.546274*(n*n-s*s)}},Pl=class extends Hi{constructor(e=new zo,t=1){super(void 0,t),this.isLightProbe=!0,this.sh=e}copy(e){return super.copy(e),this.sh.copy(e.sh),this}toJSON(e){let t=super.toJSON(e);return t.object.sh=this.sh.toArray(),t}},r0={},Il=class i extends Fn{constructor(e){super(e),this.textures={}}load(e,t,n,s){let r=this,o=new Si(r.manager);o.setPath(r.path),o.setRequestHeader(r.requestHeader),o.setWithCredentials(r.withCredentials),o.load(e,function(a){try{t(r.parse(JSON.parse(a)))}catch(l){s?s(l):qe(l),r.manager.itemError(e)}},n,s)}parse(e){let t=this.createMaterialFromType(e.type);return t.fromJSON(e,this.textures),t}setTextures(e){return this.textures=e,this}createMaterialFromType(e){return i.createMaterialFromType(e)}static createMaterialFromType(e){let n={ShadowMaterial:_l,SpriteMaterial:ln,RawShaderMaterial:Ws,ShaderMaterial:xt,PointsMaterial:ps,MeshPhysicalMaterial:hn,MeshStandardMaterial:Xs,MeshPhongMaterial:xl,MeshToonMaterial:Ht,MeshNormalMaterial:vl,MeshLambertMaterial:yl,MeshDepthMaterial:No,MeshDistanceMaterial:Uo,MeshBasicMaterial:Qe,MeshMatcapMaterial:Ml,LineDashedMaterial:bl,LineBasicMaterial:tn,Material:_n,...r0}[e],s;return n===void 0?(qi(`MaterialLoader: Unknown material type "${e}". Use .registerMaterial() before starting the deserialization process.`),s=new _n):s=new n,s}static registerMaterial(e,t){r0[e]=t}},ko=class{static extractUrlBase(e){let t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}},Dl=class extends ke{constructor(){super(),this.isInstancedBufferGeometry=!0,this.type="InstancedBufferGeometry",this.instanceCount=1/0}copy(e){return super.copy(e),this.instanceCount=e.instanceCount,this}toJSON(){let e=super.toJSON();return e.instanceCount=this.instanceCount,e.isInstancedBufferGeometry=!0,e}},Ll=class extends Fn{constructor(e){super(e)}load(e,t,n,s){let r=this,o=new Si(r.manager);o.setPath(r.path),o.setRequestHeader(r.requestHeader),o.setWithCredentials(r.withCredentials),o.load(e,function(a){try{t(r.parse(JSON.parse(a)))}catch(l){s?s(l):qe(l),r.manager.itemError(e)}},n,s)}parse(e){let t={},n={};function s(f,p){if(t[p]!==void 0)return t[p];let g=f.interleavedBuffers[p],m=r(f,g.buffer),v=po(g.type,m),E=new Gs(v,g.stride);return E.uuid=g.uuid,g.usage!==void 0&&E.setUsage(g.usage),t[p]=E,E}function r(f,p){if(n[p]!==void 0)return n[p];let g=f.arrayBuffers[p],m=new Uint32Array(g).buffer;return n[p]=m,m}let o=e.isInstancedBufferGeometry?new Dl:new ke,a=e.data.index;if(a!==void 0){let f=po(a.type,a.array);o.setIndex(new bt(f,1))}let l=e.data.attributes;for(let f in l){let p=l[f],_;if(p.isInterleavedBufferAttribute){let g=s(e.data,p.data);_=new fs(g,p.itemSize,p.offset,p.normalized)}else{let g=po(p.type,p.array),m=p.isInstancedBufferAttribute?Zi:bt;_=new m(g,p.itemSize,p.normalized)}p.name!==void 0&&(_.name=p.name),p.usage!==void 0&&_.setUsage(p.usage),p.gpuType!==void 0&&(_.gpuType=p.gpuType),o.setAttribute(f,_)}let c=e.data.morphAttributes;if(c)for(let f in c){let p=c[f],_=[];for(let g=0,m=p.length;g<m;g++){let v=p[g],E;if(v.isInterleavedBufferAttribute){let y=s(e.data,v.data);E=new fs(y,v.itemSize,v.offset,v.normalized)}else{let y=po(v.type,v.array);E=new bt(y,v.itemSize,v.normalized)}v.name!==void 0&&(E.name=v.name),v.usage!==void 0&&E.setUsage(v.usage),v.gpuType!==void 0&&(E.gpuType=v.gpuType),_.push(E)}o.morphAttributes[f]=_}e.data.morphTargetsRelative&&(o.morphTargetsRelative=!0);let u=e.data.groups||e.data.drawcalls||e.data.offsets;if(u!==void 0)for(let f=0,p=u.length;f!==p;++f){let _=u[f];o.addGroup(_.start,_.count,_.materialIndex)}let d=e.data.boundingSphere;return d!==void 0&&(o.boundingSphere=new gn().fromJSON(d)),e.name&&(o.name=e.name),e.userData&&(o.userData=e.userData),o}},Kd={},iu=class extends Fn{constructor(e){super(e)}load(e,t,n,s){let r=this,o=this.path===""?ko.extractUrlBase(e):this.path;this.resourcePath=this.resourcePath||o;let a=new Si(this.manager);a.setPath(this.path),a.setRequestHeader(this.requestHeader),a.setWithCredentials(this.withCredentials),a.load(e,function(l){let c=null;try{c=JSON.parse(l)}catch(u){s!==void 0&&s(u),qe("ObjectLoader: Can't parse "+e+".",u.message);return}let h=c.metadata;if(h===void 0||h.type===void 0||h.type.toLowerCase()==="geometry"){s!==void 0&&s(new Error("THREE.ObjectLoader: Can't load "+e)),qe("ObjectLoader: Can't load "+e);return}r.parse(c,t)},n,s)}async loadAsync(e,t){let n=this,s=this.path===""?ko.extractUrlBase(e):this.path;this.resourcePath=this.resourcePath||s;let r=new Si(this.manager);r.setPath(this.path),r.setRequestHeader(this.requestHeader),r.setWithCredentials(this.withCredentials);let o=await r.loadAsync(e,t),a;try{a=JSON.parse(o)}catch(c){throw new Error("THREE.ObjectLoader: Can't parse "+e+". "+c.message)}let l=a.metadata;if(l===void 0||l.type===void 0||l.type.toLowerCase()==="geometry")throw new Error("THREE.ObjectLoader: Can't load "+e);return await n.parseAsync(a)}parse(e,t){let n=this.parseAnimations(e.animations),s=this.parseShapes(e.shapes),r=this.parseGeometries(e.geometries,s),o=this.parseImages(e.images,function(){t!==void 0&&t(c)}),a=this.parseTextures(e.textures,o),l=this.parseMaterials(e.materials,a),c=this.parseObject(e.object,r,l,a,n),h=this.parseSkeletons(e.skeletons,c);if(this.bindSkeletons(c,h),this.bindLightTargets(c),t!==void 0){let u=!1;for(let d in o)if(o[d].data instanceof HTMLImageElement){u=!0;break}u===!1&&t(c)}return c}async parseAsync(e){let t=this.parseAnimations(e.animations),n=this.parseShapes(e.shapes),s=this.parseGeometries(e.geometries,n),r=await this.parseImagesAsync(e.images),o=this.parseTextures(e.textures,r),a=this.parseMaterials(e.materials,o),l=this.parseObject(e.object,s,a,o,t),c=this.parseSkeletons(e.skeletons,l);return this.bindSkeletons(l,c),this.bindLightTargets(l),l}static registerGeometry(e,t){Kd[e]=t}parseShapes(e){let t={};if(e!==void 0)for(let n=0,s=e.length;n<s;n++){let r=new kt().fromJSON(e[n]);t[r.uuid]=r}return t}parseSkeletons(e,t){let n={},s={};if(t.traverse(function(r){r.isBone&&(s[r.uuid]=r)}),e!==void 0)for(let r=0,o=e.length;r<o;r++){let a=new ja().fromJSON(e[r],s);n[a.uuid]=a}return n}parseGeometries(e,t){let n={};if(e!==void 0){let s=new Ll;for(let r=0,o=e.length;r<o;r++){let a,l=e[r];switch(l.type){case"BufferGeometry":case"InstancedBufferGeometry":a=s.parse(l);break;default:l.type in $m?a=$m[l.type].fromJSON(l,t):l.type in Kd?a=Kd[l.type].fromJSON(l,t):be(`ObjectLoader: Unknown geometry type "${l.type}". Use .registerGeometry() before starting the deserialization process.`)}a.uuid=l.uuid,l.name!==void 0&&(a.name=l.name),l.userData!==void 0&&(a.userData=l.userData),n[l.uuid]=a}}return n}parseMaterials(e,t){let n={},s={};if(e!==void 0){let r=new Il;r.setTextures(t);for(let o=0,a=e.length;o<a;o++){let l=e[o];n[l.uuid]===void 0&&(n[l.uuid]=r.parse(l)),s[l.uuid]=n[l.uuid]}}return s}parseAnimations(e){let t={};if(e!==void 0)for(let n=0;n<e.length;n++){let s=e[n],r=Ys.parse(s);t[r.uuid]=r}return t}parseImages(e,t){let n=this,s={},r;function o(l){return l=n.manager.resolveURL(l),n.manager.itemStart(l),r.load(l,function(){n.manager.itemEnd(l)},void 0,function(){n.manager.itemError(l),n.manager.itemEnd(l)})}function a(l){if(typeof l=="string"){let c=l,h=/^(\/\/)|([a-z]+:(\/\/)?)/i.test(c)?c:n.resourcePath+c;return o(h)}else return l.data?{data:po(l.type,l.data),width:l.width,height:l.height}:null}if(e!==void 0&&e.length>0){let l=new Ho(t);r=new qs(l),r.setCrossOrigin(this.crossOrigin);for(let c=0,h=e.length;c<h;c++){let u=e[c],d=u.url;if(Array.isArray(d)){let f=[];for(let p=0,_=d.length;p<_;p++){let g=d[p],m=a(g);m!==null&&(m instanceof HTMLImageElement?f.push(m):f.push(new Un(m.data,m.width,m.height)))}s[u.uuid]=new bi(f)}else{let f=a(u.url);s[u.uuid]=new bi(f)}}}return s}async parseImagesAsync(e){let t=this,n={},s;async function r(o){if(typeof o=="string"){let a=o,l=/^(\/\/)|([a-z]+:(\/\/)?)/i.test(a)?a:t.resourcePath+a;return await s.loadAsync(l)}else return o.data?{data:po(o.type,o.data),width:o.width,height:o.height}:null}if(e!==void 0&&e.length>0){s=new qs(this.manager),s.setCrossOrigin(this.crossOrigin);for(let o=0,a=e.length;o<a;o++){let l=e[o],c=l.url;if(Array.isArray(c)){let h=[];for(let u=0,d=c.length;u<d;u++){let f=c[u],p=await r(f);p!==null&&(p instanceof HTMLImageElement?h.push(p):h.push(new Un(p.data,p.width,p.height)))}n[l.uuid]=new bi(h)}else{let h=await r(l.url);n[l.uuid]=new bi(h)}}}return n}parseTextures(e,t){function n(r,o){return typeof r=="number"?r:(be("ObjectLoader.parseTexture: Constant should be in numeric form.",r),o[r])}let s={};if(e!==void 0)for(let r=0,o=e.length;r<o;r++){let a=e[r];a.image===void 0&&be('ObjectLoader: No "image" specified for',a.uuid),t[a.image]===void 0&&be("ObjectLoader: Undefined image",a.image);let l=t[a.image],c=l.data,h;Array.isArray(c)?(h=new Vs,c.length===6&&(h.needsUpdate=!0)):(c&&c.data?h=new Un:h=new an,c&&(h.needsUpdate=!0)),h.source=l,h.uuid=a.uuid,a.name!==void 0&&(h.name=a.name),a.mapping!==void 0&&(h.mapping=n(a.mapping,Ov)),a.channel!==void 0&&(h.channel=a.channel),a.offset!==void 0&&h.offset.fromArray(a.offset),a.repeat!==void 0&&h.repeat.fromArray(a.repeat),a.center!==void 0&&h.center.fromArray(a.center),a.rotation!==void 0&&(h.rotation=a.rotation),a.wrap!==void 0&&(h.wrapS=n(a.wrap[0],o0),h.wrapT=n(a.wrap[1],o0)),a.format!==void 0&&(h.format=a.format),a.internalFormat!==void 0&&(h.internalFormat=a.internalFormat),a.type!==void 0&&(h.type=a.type),a.colorSpace!==void 0&&(h.colorSpace=a.colorSpace),a.minFilter!==void 0&&(h.minFilter=n(a.minFilter,a0)),a.magFilter!==void 0&&(h.magFilter=n(a.magFilter,a0)),a.anisotropy!==void 0&&(h.anisotropy=a.anisotropy),a.flipY!==void 0&&(h.flipY=a.flipY),a.generateMipmaps!==void 0&&(h.generateMipmaps=a.generateMipmaps),a.premultiplyAlpha!==void 0&&(h.premultiplyAlpha=a.premultiplyAlpha),a.unpackAlignment!==void 0&&(h.unpackAlignment=a.unpackAlignment),a.compareFunction!==void 0&&(h.compareFunction=a.compareFunction),a.normalized!==void 0&&(h.normalized=a.normalized),a.userData!==void 0&&(h.userData=a.userData),s[a.uuid]=h}return s}parseObject(e,t,n,s,r){let o;function a(d){return t[d]===void 0&&be("ObjectLoader: Undefined geometry",d),t[d]}function l(d){if(d!==void 0){if(Array.isArray(d)){let f=[];for(let p=0,_=d.length;p<_;p++){let g=d[p];n[g]===void 0&&be("ObjectLoader: Undefined material",g),f.push(n[g])}return f}return n[d]===void 0&&be("ObjectLoader: Undefined material",d),n[d]}}function c(d){return s[d]===void 0&&be("ObjectLoader: Undefined texture",d),s[d]}let h,u;switch(e.type){case"Scene":o=new yr,e.background!==void 0&&(Number.isInteger(e.background)?o.background=new q(e.background):o.background=c(e.background)),e.environment!==void 0&&(o.environment=c(e.environment)),e.fog!==void 0&&(e.fog.type==="Fog"?o.fog=new Ja(e.fog.color,e.fog.near,e.fog.far):e.fog.type==="FogExp2"&&(o.fog=new Za(e.fog.color,e.fog.density)),e.fog.name!==""&&(o.fog.name=e.fog.name)),e.backgroundBlurriness!==void 0&&(o.backgroundBlurriness=e.backgroundBlurriness),e.backgroundIntensity!==void 0&&(o.backgroundIntensity=e.backgroundIntensity),e.backgroundRotation!==void 0&&o.backgroundRotation.fromArray(e.backgroundRotation),e.environmentIntensity!==void 0&&(o.environmentIntensity=e.environmentIntensity),e.environmentRotation!==void 0&&o.environmentRotation.fromArray(e.environmentRotation);break;case"PerspectiveCamera":o=new on(e.fov,e.aspect,e.near,e.far),e.focus!==void 0&&(o.focus=e.focus),e.zoom!==void 0&&(o.zoom=e.zoom),e.filmGauge!==void 0&&(o.filmGauge=e.filmGauge),e.filmOffset!==void 0&&(o.filmOffset=e.filmOffset),e.view!==void 0&&(o.view=Object.assign({},e.view));break;case"OrthographicCamera":o=new ji(e.left,e.right,e.top,e.bottom,e.near,e.far),e.zoom!==void 0&&(o.zoom=e.zoom),e.view!==void 0&&(o.view=Object.assign({},e.view));break;case"AmbientLight":o=new Al(e.color,e.intensity);break;case"DirectionalLight":o=new Ms(e.color,e.intensity),o.target=e.target||"";break;case"PointLight":o=new Yt(e.color,e.intensity,e.distance,e.decay);break;case"RectAreaLight":o=new Cl(e.color,e.intensity,e.width,e.height);break;case"SpotLight":o=new Rl(e.color,e.intensity,e.distance,e.angle,e.penumbra,e.decay),o.target=e.target||"";break;case"HemisphereLight":o=new Rr(e.color,e.groundColor,e.intensity);break;case"LightProbe":let d=new zo().fromArray(e.sh);o=new Pl(d,e.intensity);break;case"SkinnedMesh":h=a(e.geometry),u=l(e.material),o=new $a(h,u),e.bindMode!==void 0&&(o.bindMode=e.bindMode),e.bindMatrix!==void 0&&o.bindMatrix.fromArray(e.bindMatrix),e.skeleton!==void 0&&(o.skeleton=e.skeleton);break;case"Mesh":h=a(e.geometry),u=l(e.material),o=new W(h,u);break;case"InstancedMesh":h=a(e.geometry),u=l(e.material);let f=e.count,p=e.instanceMatrix,_=e.instanceColor;o=new En(h,u,f),o.instanceMatrix=new Zi(new Float32Array(p.array),16),_!==void 0&&(o.instanceColor=new Zi(new Float32Array(_.array),_.itemSize));break;case"BatchedMesh":h=a(e.geometry),u=l(e.material),o=new el(e.maxInstanceCount,e.maxVertexCount,e.maxIndexCount,u),o.geometry=h,o.perObjectFrustumCulled=e.perObjectFrustumCulled,o.sortObjects=e.sortObjects,o._drawRanges=e.drawRanges,o._reservedRanges=e.reservedRanges,o._geometryInfo=e.geometryInfo.map(g=>{let m=null,v=null;return g.boundingBox!==void 0&&(m=new bn().fromJSON(g.boundingBox)),g.boundingSphere!==void 0&&(v=new gn().fromJSON(g.boundingSphere)),{...g,boundingBox:m,boundingSphere:v}}),o._instanceInfo=e.instanceInfo,o._availableInstanceIds=e._availableInstanceIds,o._availableGeometryIds=e._availableGeometryIds,o._nextIndexStart=e.nextIndexStart,o._nextVertexStart=e.nextVertexStart,o._geometryCount=e.geometryCount,o._maxInstanceCount=e.maxInstanceCount,o._maxVertexCount=e.maxVertexCount,o._maxIndexCount=e.maxIndexCount,o._geometryInitialized=e.geometryInitialized,o._matricesTexture=c(e.matricesTexture.uuid),o._indirectTexture=c(e.indirectTexture.uuid),e.colorsTexture!==void 0&&(o._colorsTexture=c(e.colorsTexture.uuid)),e.boundingSphere!==void 0&&(o.boundingSphere=new gn().fromJSON(e.boundingSphere)),e.boundingBox!==void 0&&(o.boundingBox=new bn().fromJSON(e.boundingBox));break;case"LOD":o=new Ka;break;case"Line":o=new Bi(a(e.geometry),l(e.material));break;case"LineLoop":o=new tl(a(e.geometry),l(e.material));break;case"LineSegments":o=new Sn(a(e.geometry),l(e.material));break;case"PointCloud":case"Points":o=new ms(a(e.geometry),l(e.material));break;case"Sprite":o=new Dn(l(e.material));break;case"Group":o=new ce;break;case"Bone":o=new wo;break;default:o=new _t}if(o.uuid=e.uuid,e.name!==void 0&&(o.name=e.name),e.matrix!==void 0?(o.matrix.fromArray(e.matrix),e.matrixAutoUpdate!==void 0&&(o.matrixAutoUpdate=e.matrixAutoUpdate),o.matrixAutoUpdate&&o.matrix.decompose(o.position,o.quaternion,o.scale)):(e.position!==void 0&&o.position.fromArray(e.position),e.rotation!==void 0&&o.rotation.fromArray(e.rotation),e.quaternion!==void 0&&o.quaternion.fromArray(e.quaternion),e.scale!==void 0&&o.scale.fromArray(e.scale)),e.up!==void 0&&o.up.fromArray(e.up),e.pivot!==void 0&&(o.pivot=new A().fromArray(e.pivot)),e.morphTargetDictionary!==void 0&&(o.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),e.morphTargetInfluences!==void 0&&(o.morphTargetInfluences=e.morphTargetInfluences.slice()),e.castShadow!==void 0&&(o.castShadow=e.castShadow),e.receiveShadow!==void 0&&(o.receiveShadow=e.receiveShadow),e.shadow&&(e.shadow.intensity!==void 0&&(o.shadow.intensity=e.shadow.intensity),e.shadow.bias!==void 0&&(o.shadow.bias=e.shadow.bias),e.shadow.normalBias!==void 0&&(o.shadow.normalBias=e.shadow.normalBias),e.shadow.radius!==void 0&&(o.shadow.radius=e.shadow.radius),e.shadow.blurSamples!==void 0&&(o.shadow.blurSamples=e.shadow.blurSamples),e.shadow.focus!==void 0&&(o.shadow.focus=e.shadow.focus),e.shadow.aspect!==void 0&&(o.shadow.aspect=e.shadow.aspect),e.shadow.mapSize!==void 0&&o.shadow.mapSize.fromArray(e.shadow.mapSize),e.shadow.camera!==void 0&&(o.shadow.camera=this.parseObject(e.shadow.camera))),e.visible!==void 0&&(o.visible=e.visible),e.frustumCulled!==void 0&&(o.frustumCulled=e.frustumCulled),e.renderOrder!==void 0&&(o.renderOrder=e.renderOrder),e.static!==void 0&&(o.static=e.static),e.userData!==void 0&&(o.userData=e.userData),e.layers!==void 0&&(o.layers.mask=e.layers),e.children!==void 0){let d=e.children;for(let f=0;f<d.length;f++)o.add(this.parseObject(d[f],t,n,s,r))}if(e.animations!==void 0){let d=e.animations;for(let f=0;f<d.length;f++){let p=d[f];o.animations.push(r[p])}}if(e.type==="LOD"){e.autoUpdate!==void 0&&(o.autoUpdate=e.autoUpdate);let d=e.levels;for(let f=0;f<d.length;f++){let p=d[f],_=o.getObjectByProperty("uuid",p.object);_!==void 0&&o.addLevel(_,p.distance,p.hysteresis)}}return o}bindSkeletons(e,t){Object.keys(t).length!==0&&e.traverse(function(n){if(n.isSkinnedMesh===!0&&n.skeleton!==void 0){let s=t[n.skeleton];s===void 0?be("ObjectLoader: No skeleton found with UUID:",n.skeleton):n.bind(s,n.bindMatrix)}})}bindLightTargets(e){e.traverse(function(t){if(t.isDirectionalLight||t.isSpotLight){let n=t.target,s=e.getObjectByProperty("uuid",n);s!==void 0?t.target=s:t.target=new _t}})}},Ov={UVMapping:kl,CubeReflectionMapping:ki,CubeRefractionMapping:Ss,EquirectangularReflectionMapping:Ks,EquirectangularRefractionMapping:jo,CubeUVReflectionMapping:Lr},o0={RepeatWrapping:Hs,ClampToEdgeWrapping:$n,MirroredRepeatWrapping:go},a0={NearestFilter:jt,NearestMipmapNearestFilter:Vu,NearestMipmapLinearFilter:Nr,LinearFilter:Xt,LinearMipmapNearestFilter:Qo,LinearMipmapLinearFilter:Gi},$d=new WeakMap,su=class extends Fn{constructor(e){super(e),this.isImageBitmapLoader=!0,typeof createImageBitmap>"u"&&be("ImageBitmapLoader: createImageBitmap() not supported."),typeof fetch>"u"&&be("ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"},this._abortController=new AbortController}setOptions(e){return this.options=e,this}load(e,t,n,s){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let r=this,o=Ni.get(`image-bitmap:${e}`);if(o!==void 0){if(r.manager.itemStart(e),o.then){o.then(c=>{$d.has(o)===!0?(s&&s($d.get(o)),r.manager.itemError(e),r.manager.itemEnd(e)):(t&&t(c),r.manager.itemEnd(e))});return}setTimeout(function(){t&&t(o),r.manager.itemEnd(e)},0);return}let a={};a.credentials=this.crossOrigin==="anonymous"?"same-origin":"include",a.headers=this.requestHeader,a.signal=typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal;let l=fetch(e,a).then(function(c){return c.blob()}).then(function(c){return createImageBitmap(c,Object.assign({},r.options,{colorSpaceConversion:"none"}))}).then(function(c){return Ni.add(`image-bitmap:${e}`,c),t&&t(c),r.manager.itemEnd(e),c}).catch(function(c){s&&s(c),$d.set(l,c),Ni.remove(`image-bitmap:${e}`),r.manager.itemError(e),r.manager.itemEnd(e)});Ni.add(`image-bitmap:${e}`,l),r.manager.itemStart(e)}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}},Sh,Go=class{static getContext(){return Sh===void 0&&(Sh=new(window.AudioContext||window.webkitAudioContext)),Sh}static setContext(e){Sh=e}},ru=class extends Fn{constructor(e){super(e)}load(e,t,n,s){let r=this,o=new Si(this.manager);o.setResponseType("arraybuffer"),o.setPath(this.path),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(l){try{let c=l.slice(0),h=Go.getContext(),u=e+"#decode";r.manager.itemStart(u),h.decodeAudioData(c,function(d){t(d),r.manager.itemEnd(u)}).catch(function(d){a(d),r.manager.itemEnd(u)})}catch(c){a(c)}},n,s);function a(l){s?s(l):qe(l),r.manager.itemError(e)}}},l0=new nt,c0=new nt,ar=new nt,ou=class{constructor(){this.type="StereoCamera",this.aspect=1,this.eyeSep=.064,this.cameraL=new on,this.cameraL.layers.enable(1),this.cameraL.matrixAutoUpdate=!1,this.cameraR=new on,this.cameraR.layers.enable(2),this.cameraR.matrixAutoUpdate=!1,this._cache={focus:null,fov:null,aspect:null,near:null,far:null,zoom:null,eyeSep:null}}update(e){let t=this._cache;if(t.focus!==e.focus||t.fov!==e.fov||t.aspect!==e.aspect*this.aspect||t.near!==e.near||t.far!==e.far||t.zoom!==e.zoom||t.eyeSep!==this.eyeSep){t.focus=e.focus,t.fov=e.fov,t.aspect=e.aspect*this.aspect,t.near=e.near,t.far=e.far,t.zoom=e.zoom,t.eyeSep=this.eyeSep,ar.copy(e.projectionMatrix);let s=t.eyeSep/2,r=s*t.near/t.focus,o=t.near*Math.tan(fr*t.fov*.5)/t.zoom,a,l;c0.elements[12]=-s,l0.elements[12]=s,a=-o*t.aspect+r,l=o*t.aspect+r,ar.elements[0]=2*t.near/(l-a),ar.elements[8]=(l+a)/(l-a),this.cameraL.projectionMatrix.copy(ar),a=-o*t.aspect-r,l=o*t.aspect-r,ar.elements[0]=2*t.near/(l-a),ar.elements[8]=(l+a)/(l-a),this.cameraR.projectionMatrix.copy(ar)}this.cameraL.matrix.copy(e.matrixWorld).multiply(c0),this.cameraL.matrixWorldNeedsUpdate=!0,this.cameraR.matrix.copy(e.matrixWorld).multiply(l0),this.cameraR.matrixWorldNeedsUpdate=!0}},co=-90,ho=1,Nl=class extends _t{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let s=new on(co,ho,e,t);s.layers=this.layers,this.add(s);let r=new on(co,ho,e,t);r.layers=this.layers,this.add(r);let o=new on(co,ho,e,t);o.layers=this.layers,this.add(o);let a=new on(co,ho,e,t);a.layers=this.layers,this.add(a);let l=new on(co,ho,e,t);l.layers=this.layers,this.add(l);let c=new on(co,ho,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,s,r,o,a,l]=t;for(let c of t)this.remove(c);if(e===si)n.up.set(0,1,0),n.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===zs)n.up.set(0,-1,0),n.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(let c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:s}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[r,o,a,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),p=e.xr.enabled;e.xr.enabled=!1;let _=n.texture.generateMipmaps;n.texture.generateMipmaps=!1;let g=!1;e.isWebGLRenderer===!0?g=e.state.buffers.depth.getReversed():g=e.reversedDepthBuffer,e.setRenderTarget(n,0,s),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,r),e.setRenderTarget(n,1,s),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,2,s),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,3,s),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(n,4,s),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.generateMipmaps=_,e.setRenderTarget(n,5,s),g&&e.autoClear===!1&&e.clearDepth(),e.render(t,h),e.setRenderTarget(u,d,f),e.xr.enabled=p,n.texture.needsPMREMUpdate=!0}},Ul=class extends on{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}},Pr=class{constructor(){this._previousTime=0,this._currentTime=0,this._startTime=performance.now(),this._delta=0,this._elapsed=0,this._timescale=1,this._document=null,this._pageVisibilityHandler=null}connect(e){this._document=e,e.hidden!==void 0&&(this._pageVisibilityHandler=Hv.bind(this),e.addEventListener("visibilitychange",this._pageVisibilityHandler,!1))}disconnect(){this._pageVisibilityHandler!==null&&(this._document.removeEventListener("visibilitychange",this._pageVisibilityHandler),this._pageVisibilityHandler=null),this._document=null}getDelta(){return this._delta/1e3}getElapsed(){return this._elapsed/1e3}getTimescale(){return this._timescale}setTimescale(e){return this._timescale=e,this}reset(){return this._currentTime=performance.now()-this._startTime,this}dispose(){this.disconnect()}update(e){return this._pageVisibilityHandler!==null&&this._document.hidden===!0?this._delta=0:(this._previousTime=this._currentTime,this._currentTime=(e!==void 0?e:performance.now())-this._startTime,this._delta=(this._currentTime-this._previousTime)*this._timescale,this._elapsed+=this._delta),this}};function Hv(){this._document.hidden===!1&&this.reset()}var lr=new A,jd=new $t,zv=new A,cr=new A,hr=new A,au=class extends _t{constructor(){super(),this.type="AudioListener",this.context=Go.getContext(),this.gain=this.context.createGain(),this.gain.connect(this.context.destination),this.filter=null,this.timeDelta=0,this._timer=new Pr}getInput(){return this.gain}removeFilter(){return this.filter!==null&&(this.gain.disconnect(this.filter),this.filter.disconnect(this.context.destination),this.gain.connect(this.context.destination),this.filter=null),this}getFilter(){return this.filter}setFilter(e){return this.filter!==null?(this.gain.disconnect(this.filter),this.filter.disconnect(this.context.destination)):this.gain.disconnect(this.context.destination),this.filter=e,this.gain.connect(this.filter),this.filter.connect(this.context.destination),this}getMasterVolume(){return this.gain.gain.value}setMasterVolume(e){return this.gain.gain.setTargetAtTime(e,this.context.currentTime,.01),this}updateMatrixWorld(e){super.updateMatrixWorld(e),this._timer.update();let t=this.context.listener;if(this.timeDelta=this._timer.getDelta(),this.matrixWorld.decompose(lr,jd,zv),cr.set(0,0,-1).applyQuaternion(jd),hr.set(0,1,0).applyQuaternion(jd),t.positionX){let n=this.context.currentTime+this.timeDelta;t.positionX.linearRampToValueAtTime(lr.x,n),t.positionY.linearRampToValueAtTime(lr.y,n),t.positionZ.linearRampToValueAtTime(lr.z,n),t.forwardX.linearRampToValueAtTime(cr.x,n),t.forwardY.linearRampToValueAtTime(cr.y,n),t.forwardZ.linearRampToValueAtTime(cr.z,n),t.upX.linearRampToValueAtTime(hr.x,n),t.upY.linearRampToValueAtTime(hr.y,n),t.upZ.linearRampToValueAtTime(hr.z,n)}else t.setPosition(lr.x,lr.y,lr.z),t.setOrientation(cr.x,cr.y,cr.z,hr.x,hr.y,hr.z)}},Fl=class extends _t{constructor(e){super(),this.type="Audio",this.listener=e,this.context=e.context,this.gain=this.context.createGain(),this.gain.connect(e.getInput()),this.autoplay=!1,this.buffer=null,this.detune=0,this.loop=!1,this.loopStart=0,this.loopEnd=0,this.offset=0,this.duration=void 0,this.playbackRate=1,this.isPlaying=!1,this.hasPlaybackControl=!0,this.source=null,this.sourceType="empty",this._startedAt=0,this._progress=0,this._connected=!1,this.filters=[]}getOutput(){return this.gain}setNodeSource(e){return this.hasPlaybackControl=!1,this.sourceType="audioNode",this.source=e,this.connect(),this}setMediaElementSource(e){return this.hasPlaybackControl=!1,this.sourceType="mediaNode",this.source=this.context.createMediaElementSource(e),this.connect(),this}setMediaStreamSource(e){return this.hasPlaybackControl=!1,this.sourceType="mediaStreamNode",this.source=this.context.createMediaStreamSource(e),this.connect(),this}setBuffer(e){return this.buffer=e,this.sourceType="buffer",this.autoplay&&this.play(),this}play(e=0){if(this.isPlaying===!0){be("Audio: Audio is already playing.");return}if(this.hasPlaybackControl===!1){be("Audio: this Audio has no playback control.");return}this._startedAt=this.context.currentTime+e;let t=this.context.createBufferSource();return t.buffer=this.buffer,t.loop=this.loop,t.loopStart=this.loopStart,t.loopEnd=this.loopEnd,t.onended=this.onEnded.bind(this),t.start(this._startedAt,this._progress+this.offset,this.duration),this.isPlaying=!0,this.source=t,this.setDetune(this.detune),this.setPlaybackRate(this.playbackRate),this.connect()}pause(){if(this.hasPlaybackControl===!1){be("Audio: this Audio has no playback control.");return}return this.isPlaying===!0&&(this._progress+=Math.max(this.context.currentTime-this._startedAt,0)*this.playbackRate,this.loop===!0&&(this._progress=this._progress%(this.duration||this.buffer.duration)),this.source.stop(),this.source.onended=null,this.isPlaying=!1),this}stop(e=0){if(this.hasPlaybackControl===!1){be("Audio: this Audio has no playback control.");return}return this._progress=0,this.source!==null&&(this.source.stop(this.context.currentTime+e),this.source.onended=null),this.isPlaying=!1,this}connect(){if(this.filters.length>0){this.source.connect(this.filters[0]);for(let e=1,t=this.filters.length;e<t;e++)this.filters[e-1].connect(this.filters[e]);this.filters[this.filters.length-1].connect(this.getOutput())}else this.source.connect(this.getOutput());return this._connected=!0,this}disconnect(){if(this._connected!==!1){if(this.filters.length>0){this.source.disconnect(this.filters[0]);for(let e=1,t=this.filters.length;e<t;e++)this.filters[e-1].disconnect(this.filters[e]);this.filters[this.filters.length-1].disconnect(this.getOutput())}else this.source.disconnect(this.getOutput());return this._connected=!1,this}}getFilters(){return this.filters}setFilters(e){return e||(e=[]),this._connected===!0?(this.disconnect(),this.filters=e.slice(),this.connect()):this.filters=e.slice(),this}setDetune(e){return this.detune=e,this.isPlaying===!0&&this.source.detune!==void 0&&this.source.detune.setTargetAtTime(this.detune,this.context.currentTime,.01),this}getDetune(){return this.detune}getFilter(){return this.getFilters()[0]}setFilter(e){return this.setFilters(e?[e]:[])}setPlaybackRate(e){if(this.hasPlaybackControl===!1){be("Audio: this Audio has no playback control.");return}return this.playbackRate=e,this.isPlaying===!0&&this.source.playbackRate.setTargetAtTime(this.playbackRate,this.context.currentTime,.01),this}getPlaybackRate(){return this.playbackRate}onEnded(){this.isPlaying=!1,this._progress=0}getLoop(){return this.hasPlaybackControl===!1?(be("Audio: this Audio has no playback control."),!1):this.loop}setLoop(e){if(this.hasPlaybackControl===!1){be("Audio: this Audio has no playback control.");return}return this.loop=e,this.isPlaying===!0&&(this.source.loop=this.loop),this}setLoopStart(e){return this.loopStart=e,this}setLoopEnd(e){return this.loopEnd=e,this}getVolume(){return this.gain.gain.value}setVolume(e){return this.gain.gain.setTargetAtTime(e,this.context.currentTime,.01),this}copy(e,t){return super.copy(e,t),e.sourceType!=="buffer"?(be("Audio: Audio source type cannot be copied."),this):(this.autoplay=e.autoplay,this.buffer=e.buffer,this.detune=e.detune,this.loop=e.loop,this.loopStart=e.loopStart,this.loopEnd=e.loopEnd,this.offset=e.offset,this.duration=e.duration,this.playbackRate=e.playbackRate,this.hasPlaybackControl=e.hasPlaybackControl,this.sourceType=e.sourceType,this.filters=e.filters.slice(),this)}clone(e){return new this.constructor(this.listener).copy(this,e)}},ur=new A,h0=new $t,kv=new A,dr=new A,lu=class extends Fl{constructor(e){super(e),this.panner=this.context.createPanner(),this.panner.panningModel="HRTF",this.panner.connect(this.gain)}connect(){return super.connect(),this.panner.connect(this.gain),this}disconnect(){return super.disconnect(),this.panner.disconnect(this.gain),this}getOutput(){return this.panner}getRefDistance(){return this.panner.refDistance}setRefDistance(e){return this.panner.refDistance=e,this}getRolloffFactor(){return this.panner.rolloffFactor}setRolloffFactor(e){return this.panner.rolloffFactor=e,this}getDistanceModel(){return this.panner.distanceModel}setDistanceModel(e){return this.panner.distanceModel=e,this}getMaxDistance(){return this.panner.maxDistance}setMaxDistance(e){return this.panner.maxDistance=e,this}setDirectionalCone(e,t,n){return this.panner.coneInnerAngle=e,this.panner.coneOuterAngle=t,this.panner.coneOuterGain=n,this}updateMatrixWorld(e){if(super.updateMatrixWorld(e),this.hasPlaybackControl===!0&&this.isPlaying===!1)return;this.matrixWorld.decompose(ur,h0,kv),dr.set(0,0,1).applyQuaternion(h0);let t=this.panner;if(t.positionX){let n=this.context.currentTime+this.listener.timeDelta;t.positionX.linearRampToValueAtTime(ur.x,n),t.positionY.linearRampToValueAtTime(ur.y,n),t.positionZ.linearRampToValueAtTime(ur.z,n),t.orientationX.linearRampToValueAtTime(dr.x,n),t.orientationY.linearRampToValueAtTime(dr.y,n),t.orientationZ.linearRampToValueAtTime(dr.z,n)}else t.setPosition(ur.x,ur.y,ur.z),t.setOrientation(dr.x,dr.y,dr.z)}},cu=class{constructor(e,t=2048){this.analyser=e.context.createAnalyser(),this.analyser.fftSize=t,this.data=new Uint8Array(this.analyser.frequencyBinCount),e.getOutput().connect(this.analyser)}getFrequencyData(){return this.analyser.getByteFrequencyData(this.data),this.data}getAverageFrequency(){let e=0,t=this.getFrequencyData();for(let n=0;n<t.length;n++)e+=t[n];return e/t.length}},Bl=class{constructor(e,t,n){this.binding=e,this.valueSize=n;let s,r,o;switch(t){case"quaternion":s=this._slerp,r=this._slerpAdditive,o=this._setAdditiveIdentityQuaternion,this.buffer=new Float64Array(n*6),this._workIndex=5;break;case"string":case"bool":s=this._select,r=this._select,o=this._setAdditiveIdentityOther,this.buffer=new Array(n*5);break;default:s=this._lerp,r=this._lerpAdditive,o=this._setAdditiveIdentityNumeric,this.buffer=new Float64Array(n*5)}this._mixBufferRegion=s,this._mixBufferRegionAdditive=r,this._setIdentity=o,this._origIndex=3,this._addIndex=4,this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,this.useCount=0,this.referenceCount=0}accumulate(e,t){let n=this.buffer,s=this.valueSize,r=e*s+s,o=this.cumulativeWeight;if(o===0){for(let a=0;a!==s;++a)n[r+a]=n[a];o=t}else{o+=t;let a=t/o;this._mixBufferRegion(n,r,0,a,s)}this.cumulativeWeight=o}accumulateAdditive(e){let t=this.buffer,n=this.valueSize,s=n*this._addIndex;this.cumulativeWeightAdditive===0&&this._setIdentity(),this._mixBufferRegionAdditive(t,s,0,e,n),this.cumulativeWeightAdditive+=e}apply(e){let t=this.valueSize,n=this.buffer,s=e*t+t,r=this.cumulativeWeight,o=this.cumulativeWeightAdditive,a=this.binding;if(this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,r<1){let l=t*this._origIndex;this._mixBufferRegion(n,s,l,1-r,t)}o>0&&this._mixBufferRegionAdditive(n,s,this._addIndex*t,1,t);for(let l=t,c=t+t;l!==c;++l)if(n[l]!==n[l+t]){a.setValue(n,s);break}}saveOriginalState(){let e=this.binding,t=this.buffer,n=this.valueSize,s=n*this._origIndex;e.getValue(t,s);for(let r=n,o=s;r!==o;++r)t[r]=t[s+r%n];this._setIdentity(),this.cumulativeWeight=0,this.cumulativeWeightAdditive=0}restoreOriginalState(){let e=this.valueSize*3;this.binding.setValue(this.buffer,e)}_setAdditiveIdentityNumeric(){let e=this._addIndex*this.valueSize,t=e+this.valueSize;for(let n=e;n<t;n++)this.buffer[n]=0}_setAdditiveIdentityQuaternion(){this._setAdditiveIdentityNumeric(),this.buffer[this._addIndex*this.valueSize+3]=1}_setAdditiveIdentityOther(){let e=this._origIndex*this.valueSize,t=this._addIndex*this.valueSize;for(let n=0;n<this.valueSize;n++)this.buffer[t+n]=this.buffer[e+n]}_select(e,t,n,s,r){if(s>=.5)for(let o=0;o!==r;++o)e[t+o]=e[n+o]}_slerp(e,t,n,s){$t.slerpFlat(e,t,e,t,e,n,s)}_slerpAdditive(e,t,n,s,r){let o=this._workIndex*r;$t.multiplyQuaternionsFlat(e,o,e,t,e,n),$t.slerpFlat(e,t,e,t,e,o,s)}_lerp(e,t,n,s,r){let o=1-s;for(let a=0;a!==r;++a){let l=t+a;e[l]=e[l]*o+e[n+a]*s}}_lerpAdditive(e,t,n,s,r){for(let o=0;o!==r;++o){let a=t+o;e[a]=e[a]+e[n+o]*s}}},rp="\\[\\]\\.:\\/",Gv=new RegExp("["+rp+"]","g"),op="[^"+rp+"]",Vv="[^"+rp.replace("\\.","")+"]",Wv=/((?:WC+[\/:])*)/.source.replace("WC",op),Xv=/(WCOD+)?/.source.replace("WCOD",Vv),Yv=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",op),qv=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",op),Zv=new RegExp("^"+Wv+Xv+Yv+qv+"$"),Jv=["material","materials","bones","map"],ff=class{constructor(e,t,n){let s=n||Nt.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,s)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,s=this._bindings[n];s!==void 0&&s.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let s=this._targetGroup.nCachedObjects_,r=n.length;s!==r;++s)n[s].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},Nt=class i{constructor(e,t,n){this.path=t,this.parsedPath=n||i.parseTrackName(t),this.node=i.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new i.Composite(e,t,n):new i(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(Gv,"")}static parseTrackName(e){let t=Zv.exec(e);if(t===null)throw new Error("THREE.PropertyBinding: Cannot parse trackName: "+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},s=n.nodeName&&n.nodeName.lastIndexOf(".");if(s!==void 0&&s!==-1){let r=n.nodeName.substring(s+1);Jv.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,s),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("THREE.PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(r){for(let o=0;o<r.length;o++){let a=r[o];if(a.name===t||a.uuid===t)return a;let l=n(a.children);if(l)return l}return null},s=n(e.children);if(s)return s}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)e[t++]=n[s]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let s=0,r=n.length;s!==r;++s)n[s]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,n=t.objectName,s=t.propertyName,r=t.propertyIndex;if(e||(e=i.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){be("PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=t.objectIndex;switch(n){case"materials":if(!e.material){qe("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){qe("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){qe("PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===c){c=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){qe("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){qe("PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){qe("PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(c!==void 0){if(e[c]===void 0){qe("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[c]}}let o=e[s];if(o===void 0){let c=t.nodeName;qe("PropertyBinding: Trying to update property for track: "+c+"."+s+" but it wasn't found.",e);return}let a=this.Versioning.None;this.targetObject=e,e.isMaterial===!0?a=this.Versioning.NeedsUpdate:e.isObject3D===!0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(s==="morphTargetInfluences"){if(!e.geometry){qe("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){qe("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[r]!==void 0&&(r=e.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=r}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=s;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Nt.Composite=ff;Nt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Nt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Nt.prototype.GetterByBindingType=[Nt.prototype._getValue_direct,Nt.prototype._getValue_array,Nt.prototype._getValue_arrayElement,Nt.prototype._getValue_toArray];Nt.prototype.SetterByBindingTypeAndVersioning=[[Nt.prototype._setValue_direct,Nt.prototype._setValue_direct_setNeedsUpdate,Nt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Nt.prototype._setValue_array,Nt.prototype._setValue_array_setNeedsUpdate,Nt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Nt.prototype._setValue_arrayElement,Nt.prototype._setValue_arrayElement_setNeedsUpdate,Nt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Nt.prototype._setValue_fromArray,Nt.prototype._setValue_fromArray_setNeedsUpdate,Nt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var hu=class{constructor(){this.isAnimationObjectGroup=!0,this.uuid=fi(),this._objects=Array.prototype.slice.call(arguments),this.nCachedObjects_=0;let e={};this._indicesByUUID=e;for(let n=0,s=arguments.length;n!==s;++n)e[arguments[n].uuid]=n;this._paths=[],this._parsedPaths=[],this._bindings=[],this._bindingsIndicesByPath={};let t=this;this.stats={objects:{get total(){return t._objects.length},get inUse(){return this.total-t.nCachedObjects_}},get bindingsPerObject(){return t._bindings.length}}}add(){let e=this._objects,t=this._indicesByUUID,n=this._paths,s=this._parsedPaths,r=this._bindings,o=r.length,a,l=e.length,c=this.nCachedObjects_;for(let h=0,u=arguments.length;h!==u;++h){let d=arguments[h],f=d.uuid,p=t[f];if(p===void 0){p=l++,t[f]=p,e.push(d);for(let _=0,g=o;_!==g;++_)r[_].push(new Nt(d,n[_],s[_]))}else if(p<c){a=e[p];let _=--c,g=e[_];t[g.uuid]=p,e[p]=g,t[f]=_,e[_]=d;for(let m=0,v=o;m!==v;++m){let E=r[m],y=E[_],w=E[p];E[p]=y,w===void 0&&(w=new Nt(d,n[m],s[m])),E[_]=w}}else e[p]!==a&&qe("AnimationObjectGroup: Different objects with the same UUID detected. Clean the caches or recreate your infrastructure when reloading scenes.")}this.nCachedObjects_=c}remove(){let e=this._objects,t=this._indicesByUUID,n=this._bindings,s=n.length,r=this.nCachedObjects_;for(let o=0,a=arguments.length;o!==a;++o){let l=arguments[o],c=l.uuid,h=t[c];if(h!==void 0&&h>=r){let u=r++,d=e[u];t[d.uuid]=h,e[h]=d,t[c]=u,e[u]=l;for(let f=0,p=s;f!==p;++f){let _=n[f],g=_[u],m=_[h];_[h]=g,_[u]=m}}}this.nCachedObjects_=r}uncache(){let e=this._objects,t=this._indicesByUUID,n=this._bindings,s=n.length,r=this.nCachedObjects_,o=e.length;for(let a=0,l=arguments.length;a!==l;++a){let c=arguments[a],h=c.uuid,u=t[h];if(u!==void 0)if(delete t[h],u<r){let d=--r,f=e[d],p=--o,_=e[p];u!==d&&(t[f.uuid]=u),e[u]=f,d!==p&&(t[_.uuid]=d),e[d]=_,e.pop();for(let g=0,m=s;g!==m;++g){let v=n[g],E=v[d],y=v[p];v[u]=E,v[d]=y,v.pop()}}else{let d=--o,f=e[d];u!==d&&(t[f.uuid]=u),e[u]=f,e.pop();for(let p=0,_=s;p!==_;++p){let g=n[p];g[u]=g[d],g.pop()}}}this.nCachedObjects_=r}subscribe_(e,t){let n=this._bindingsIndicesByPath,s=n[e],r=this._bindings;if(s!==void 0)return r[s];let o=this._paths,a=this._parsedPaths,l=this._objects,c=l.length,h=this.nCachedObjects_,u=new Array(c);s=r.length,n[e]=s,o.push(e),a.push(t),r.push(u);for(let d=h,f=l.length;d!==f;++d){let p=l[d];u[d]=new Nt(p,e,t)}return u}unsubscribe_(e){let t=this._bindingsIndicesByPath,n=t[e];if(n!==void 0){let s=this._paths,r=this._parsedPaths,o=this._bindings,a=o.length-1,l=o[a],c=s[a];t[c]=n,o[n]=l,o.pop(),r[n]=r[a],r.pop(),s[n]=s[a],s.pop()}}},Ol=class{constructor(e,t,n=null,s=t.blendMode){this._mixer=e,this._clip=t,this._localRoot=n,this.blendMode=s;let r=t.tracks,o=r.length,a=new Array(o),l={endingStart:Bs,endingEnd:Bs};for(let c=0;c!==o;++c){let h=r[c].createInterpolant(null);a[c]=h,h.settings=l}this._interpolantSettings=l,this._interpolants=a,this._propertyBindings=new Array(o),this._cacheIndex=null,this._byClipCacheIndex=null,this._timeScaleInterpolant=null,this._restoreTimeScale=null,this._weightInterpolant=null,this.loop=zf,this._loopCount=-1,this._startTime=null,this.time=0,this.timeScale=1,this._effectiveTimeScale=1,this.weight=1,this._effectiveWeight=1,this.repetitions=1/0,this.paused=!1,this.enabled=!0,this.clampWhenFinished=!1,this.zeroSlopeAtStart=!0,this.zeroSlopeAtEnd=!0}play(){return this._mixer._activateAction(this),this}stop(){return this._mixer._deactivateAction(this),this.reset()}reset(){return this.paused=!1,this.enabled=!0,this.time=0,this._loopCount=-1,this._startTime=null,this.stopFading().stopWarping()}isRunning(){return this.enabled&&!this.paused&&this.timeScale!==0&&this._startTime===null&&this._mixer._isActiveAction(this)}isScheduled(){return this._mixer._isActiveAction(this)}startAt(e){return this._startTime=e,this}setLoop(e,t){return this.loop=e,this.repetitions=t,this}setEffectiveWeight(e){return this.weight=e,this._effectiveWeight=this.enabled?e:0,this.stopFading()}getEffectiveWeight(){return this._effectiveWeight}fadeIn(e){return this._scheduleFading(e,0,1)}fadeOut(e){return this._scheduleFading(e,1,0)}crossFadeFrom(e,t,n=!1){if(e.fadeOut(t),this.fadeIn(t),n===!0){let s=this._clip.duration,r=e._clip.duration,o=r/s,a=s/r;e._restoreTimeScale=e.timeScale,this._restoreTimeScale=this.timeScale,e.warp(1,o,t),this.warp(a,1,t)}return this}crossFadeTo(e,t,n=!1){return e.crossFadeFrom(this,t,n)}stopFading(){let e=this._weightInterpolant;return e!==null&&(this._weightInterpolant=null,this._mixer._takeBackControlInterpolant(e)),this}setEffectiveTimeScale(e){return this.timeScale=e,this._effectiveTimeScale=this.paused?0:e,this.stopWarping()}getEffectiveTimeScale(){return this._effectiveTimeScale}setDuration(e){return this.timeScale=this._clip.duration/e,this.stopWarping()}syncWith(e){return this.time=e.time,this.timeScale=e.timeScale,this.stopWarping()}halt(e){return this.warp(this._effectiveTimeScale,0,e)}warp(e,t,n){let s=this._mixer,r=s.time,o=this.timeScale,a=this._timeScaleInterpolant;a===null&&(a=s._lendControlInterpolant(),this._timeScaleInterpolant=a);let l=a.parameterPositions,c=a.sampleValues;return l[0]=r,l[1]=r+n,c[0]=e/o,c[1]=t/o,this}stopWarping(){let e=this._timeScaleInterpolant;return e!==null&&(this._timeScaleInterpolant=null,this._mixer._takeBackControlInterpolant(e)),this._restoreTimeScale=null,this}getMixer(){return this._mixer}getClip(){return this._clip}getRoot(){return this._localRoot||this._mixer._root}_update(e,t,n,s){if(!this.enabled){this._updateWeight(e);return}let r=this._startTime;if(r!==null){let l=(e-r)*n;l<0||n===0?t=0:(this._startTime=null,t=n*l)}t*=this._updateTimeScale(e);let o=this._updateTime(t),a=this._updateWeight(e);if(a>0){let l=this._interpolants,c=this._propertyBindings;switch(this.blendMode){case Ku:for(let h=0,u=l.length;h!==u;++h)l[h].evaluate(o),c[h].accumulateAdditive(a);break;case Sc:default:for(let h=0,u=l.length;h!==u;++h)l[h].evaluate(o),c[h].accumulate(s,a)}}}_updateWeight(e){let t=0;if(this.enabled){t=this.weight;let n=this._weightInterpolant;if(n!==null){let s=n.evaluate(e)[0];t*=s,e>n.parameterPositions[1]&&(this.stopFading(),s===0&&(this.enabled=!1))}}return this._effectiveWeight=t,t}_updateTimeScale(e){let t=0;if(!this.paused){t=this.timeScale;let n=this._timeScaleInterpolant;if(n!==null){let s=n.evaluate(e)[0];t*=s,e>n.parameterPositions[1]&&(t===0?this.paused=!0:(this._restoreTimeScale!==null&&(t=this._restoreTimeScale),this.timeScale=t),this.stopWarping())}}return this._effectiveTimeScale=t,t}_updateTime(e){let t=this._clip.duration,n=this.loop,s=this.time+e,r=this._loopCount,o=n===kf;if(e===0)return r===-1?s:o&&(r&1)===1?t-s:s;if(n===Hf){r===-1&&(this._loopCount=0,this._setEndings(!0,!0,!1));e:{if(s>=t)s=t;else if(s<0)s=0;else{this.time=s;break e}this.clampWhenFinished?this.paused=!0:this.enabled=!1,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:e<0?-1:1})}}else{if(r===-1&&(e>=0?(r=0,this._setEndings(!0,this.repetitions===0,o)):this._setEndings(this.repetitions===0,!0,o)),s>=t||s<0){let a=Math.floor(s/t);s-=t*a,r+=Math.abs(a);let l=this.repetitions-r;if(l<=0)this.clampWhenFinished?this.paused=!0:this.enabled=!1,s=e>0?t:0,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:e>0?1:-1});else{if(l===1){let c=e<0;this._setEndings(c,!c,o)}else this._setEndings(!1,!1,o);this._loopCount=r,this.time=s,this._mixer.dispatchEvent({type:"loop",action:this,loopDelta:a})}}else this._loopCount=r,this.time=s;if(o&&(r&1)===1)return t-s}return s}_setEndings(e,t,n){let s=this._interpolantSettings;n?(s.endingStart=Os,s.endingEnd=Os):(e?s.endingStart=this.zeroSlopeAtStart?Os:Bs:s.endingStart=xo,t?s.endingEnd=this.zeroSlopeAtEnd?Os:Bs:s.endingEnd=xo)}_scheduleFading(e,t,n){let s=this._mixer,r=s.time,o=this._weightInterpolant;o===null&&(o=s._lendControlInterpolant(),this._weightInterpolant=o);let a=o.parameterPositions,l=o.sampleValues;return a[0]=r,l[0]=t,a[1]=r+e,l[1]=n,this}},Kv=new Float32Array(1),uu=class extends ri{constructor(e){super(),this._root=e,this._initMemoryManager(),this._accuIndex=0,this.time=0,this.timeScale=1,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}_bindAction(e,t){let n=e._localRoot||this._root,s=e._clip.tracks,r=s.length,o=e._propertyBindings,a=e._interpolants,l=n.uuid,c=this._bindingsByRootAndName,h=c[l];h===void 0&&(h={},c[l]=h);for(let u=0;u!==r;++u){let d=s[u],f=d.name,p=h[f];if(p!==void 0)++p.referenceCount,o[u]=p;else{if(p=o[u],p!==void 0){p._cacheIndex===null&&(++p.referenceCount,this._addInactiveBinding(p,l,f));continue}let _=t&&t._propertyBindings[u].binding.parsedPath;p=new Bl(Nt.create(n,f,_),d.ValueTypeName,d.getValueSize()),++p.referenceCount,this._addInactiveBinding(p,l,f),o[u]=p}a[u].resultBuffer=p.buffer}}_activateAction(e){if(!this._isActiveAction(e)){if(e._cacheIndex===null){let n=(e._localRoot||this._root).uuid,s=e._clip.uuid,r=this._actionsByClip[s];this._bindAction(e,r&&r.knownActions[0]),this._addInactiveAction(e,s,n)}let t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){let r=t[n];r.useCount++===0&&(this._lendBinding(r),r.saveOriginalState())}this._lendAction(e)}}_deactivateAction(e){if(this._isActiveAction(e)){let t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){let r=t[n];--r.useCount===0&&(r.restoreOriginalState(),this._takeBackBinding(r))}this._takeBackAction(e)}}_initMemoryManager(){this._actions=[],this._nActiveActions=0,this._actionsByClip={},this._bindings=[],this._nActiveBindings=0,this._bindingsByRootAndName={},this._controlInterpolants=[],this._nActiveControlInterpolants=0;let e=this;this.stats={actions:{get total(){return e._actions.length},get inUse(){return e._nActiveActions}},bindings:{get total(){return e._bindings.length},get inUse(){return e._nActiveBindings}},controlInterpolants:{get total(){return e._controlInterpolants.length},get inUse(){return e._nActiveControlInterpolants}}}}_isActiveAction(e){let t=e._cacheIndex;return t!==null&&t<this._nActiveActions}_addInactiveAction(e,t,n){let s=this._actions,r=this._actionsByClip,o=r[t];if(o===void 0)o={knownActions:[e],actionByRoot:{}},e._byClipCacheIndex=0,r[t]=o;else{let a=o.knownActions;e._byClipCacheIndex=a.length,a.push(e)}e._cacheIndex=s.length,s.push(e),o.actionByRoot[n]=e}_removeInactiveAction(e){let t=this._actions,n=t[t.length-1],s=e._cacheIndex;n._cacheIndex=s,t[s]=n,t.pop(),e._cacheIndex=null;let r=e._clip.uuid,o=this._actionsByClip,a=o[r],l=a.knownActions,c=l[l.length-1],h=e._byClipCacheIndex;c._byClipCacheIndex=h,l[h]=c,l.pop(),e._byClipCacheIndex=null;let u=a.actionByRoot,d=(e._localRoot||this._root).uuid;delete u[d],l.length===0&&delete o[r],this._removeInactiveBindingsForAction(e)}_removeInactiveBindingsForAction(e){let t=e._propertyBindings;for(let n=0,s=t.length;n!==s;++n){let r=t[n];--r.referenceCount===0&&this._removeInactiveBinding(r)}}_lendAction(e){let t=this._actions,n=e._cacheIndex,s=this._nActiveActions++,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_takeBackAction(e){let t=this._actions,n=e._cacheIndex,s=--this._nActiveActions,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_addInactiveBinding(e,t,n){let s=this._bindingsByRootAndName,r=this._bindings,o=s[t];o===void 0&&(o={},s[t]=o),o[n]=e,e._cacheIndex=r.length,r.push(e)}_removeInactiveBinding(e){let t=this._bindings,n=e.binding,s=n.rootNode.uuid,r=n.path,o=this._bindingsByRootAndName,a=o[s],l=t[t.length-1],c=e._cacheIndex;l._cacheIndex=c,t[c]=l,t.pop(),delete a[r],Object.keys(a).length===0&&delete o[s]}_lendBinding(e){let t=this._bindings,n=e._cacheIndex,s=this._nActiveBindings++,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_takeBackBinding(e){let t=this._bindings,n=e._cacheIndex,s=--this._nActiveBindings,r=t[s];e._cacheIndex=s,t[s]=e,r._cacheIndex=n,t[n]=r}_lendControlInterpolant(){let e=this._controlInterpolants,t=this._nActiveControlInterpolants++,n=e[t];return n===void 0&&(n=new Fo(new Float32Array(2),new Float32Array(2),1,Kv),n.__cacheIndex=t,e[t]=n),n}_takeBackControlInterpolant(e){let t=this._controlInterpolants,n=e.__cacheIndex,s=--this._nActiveControlInterpolants,r=t[s];e.__cacheIndex=s,t[s]=e,r.__cacheIndex=n,t[n]=r}clipAction(e,t,n){let s=t||this._root,r=s.uuid,o=typeof e=="string"?Ys.findByName(s,e):e,a=o!==null?o.uuid:e,l=this._actionsByClip[a],c=null;if(n===void 0&&(o!==null?n=o.blendMode:n=Sc),l!==void 0){let u=l.actionByRoot[r];if(u!==void 0&&u.blendMode===n)return u;c=l.knownActions[0],o===null&&(o=c._clip)}if(o===null)return null;let h=new Ol(this,o,t,n);return this._bindAction(h,c),this._addInactiveAction(h,a,r),h}existingAction(e,t){let n=t||this._root,s=n.uuid,r=typeof e=="string"?Ys.findByName(n,e):e,o=r?r.uuid:e,a=this._actionsByClip[o];return a!==void 0&&a.actionByRoot[s]||null}stopAllAction(){let e=this._actions,t=this._nActiveActions;for(let n=t-1;n>=0;--n)e[n].stop();return this}update(e){e*=this.timeScale;let t=this._actions,n=this._nActiveActions,s=this.time+=e,r=Math.sign(e),o=this._accuIndex^=1;for(let c=0;c!==n;++c)t[c]._update(s,e,r,o);let a=this._bindings,l=this._nActiveBindings;for(let c=0;c!==l;++c)a[c].apply(o);return this}setTime(e){this.time=0;for(let t=0;t<this._actions.length;t++)this._actions[t].time=0;return this.update(e)}getRoot(){return this._root}uncacheClip(e){let t=this._actions,n=e.uuid,s=this._actionsByClip,r=s[n];if(r!==void 0){let o=r.knownActions;for(let a=0,l=o.length;a!==l;++a){let c=o[a];this._deactivateAction(c);let h=c._cacheIndex,u=t[t.length-1];c._cacheIndex=null,c._byClipCacheIndex=null,u._cacheIndex=h,t[h]=u,t.pop(),this._removeInactiveBindingsForAction(c)}delete s[n]}}uncacheRoot(e){let t=e.uuid,n=this._actionsByClip;for(let o in n){let a=n[o].actionByRoot,l=a[t];l!==void 0&&(this._deactivateAction(l),this._removeInactiveAction(l))}let s=this._bindingsByRootAndName,r=s[t];if(r!==void 0)for(let o in r){let a=r[o];a.restoreOriginalState(),this._removeInactiveBinding(a)}}uncacheAction(e,t){let n=this.existingAction(e,t);n!==null&&(this._deactivateAction(n),this._removeInactiveAction(n))}},du=class extends Eo{constructor(e=1,t=1,n=1,s={}){super(e,t,s),this.isRenderTarget3D=!0,this.depth=n;for(let r=0;r<this.textures.length;r++){let o=new _r(null,e,t,n);o.isRenderTargetTexture=!0,o.renderTarget=this,this.textures[r]=o}this._setTextureOptions(s)}},fu=class i{constructor(e){this.value=e}clone(){return new i(this.value.clone===void 0?this.value:this.value.clone())}},$v=0,pu=class extends ri{constructor(){super(),this.isUniformsGroup=!0,Object.defineProperty(this,"id",{value:$v++}),this.name="",this.usage=Rc,this.uniforms=[]}add(e){return this.uniforms.push(e),this}remove(e){let t=this.uniforms.indexOf(e);return t!==-1&&this.uniforms.splice(t,1),this}setName(e){return this.name=e,this}setUsage(e){return this.usage=e,this}dispose(){this.dispatchEvent({type:"dispose"})}copy(e){this.name=e.name,this.usage=e.usage;let t=e.uniforms;this.uniforms.length=0;for(let n=0,s=t.length;n<s;n++){let r=Array.isArray(t[n])?t[n]:[t[n]];for(let o=0;o<r.length;o++)this.uniforms.push(r[o].clone())}return this}clone(){return new this.constructor().copy(this)}},mu=class extends Gs{constructor(e,t,n=1){super(e,t),this.isInstancedInterleavedBuffer=!0,this.meshPerAttribute=n}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}clone(e){let t=super.clone(e);return t.meshPerAttribute=this.meshPerAttribute,t}toJSON(e){let t=super.toJSON(e);return t.isInstancedInterleavedBuffer=!0,t.meshPerAttribute=this.meshPerAttribute,t}},gu=class{constructor(e,t,n,s,r,o=!1){this.isGLBufferAttribute=!0,this.name="",this.buffer=e,this.type=t,this.itemSize=n,this.elementSize=s,this.count=r,this.normalized=o,this.version=0}set needsUpdate(e){e===!0&&this.version++}setBuffer(e){return this.buffer=e,this}setType(e,t){return this.type=e,this.elementSize=t,this}setItemSize(e){return this.itemSize=e,this}setCount(e){return this.count=e,this}},u0=new nt,_u=class{constructor(e,t,n=0,s=1/0){this.ray=new Fi(e,t),this.near=n,this.far=s,this.camera=null,this.layers=new xr,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,t.projectionMatrix.elements[14]).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):qe("Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return u0.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(u0),this}intersectObject(e,t=!0,n=[]){return pf(e,this,n,t),n.sort(d0),n}intersectObjects(e,t=!0,n=[]){for(let s=0,r=e.length;s<r;s++)pf(e[s],this,n,t);return n.sort(d0),n}};function d0(i,e){return i.distance-e.distance}function pf(i,e,t,n){let s=!0;if(i.layers.test(e.layers)&&i.raycast(e,t)===!1&&(s=!1),s===!0&&n===!0){let r=i.children;for(let o=0,a=r.length;o<a;o++)pf(r[o],e,t,!0)}}var xu=class{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1,be("Clock: This module has been deprecated. Please use THREE.Timer instead.")}start(){this.startTime=performance.now(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){let t=performance.now();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}},Ir=class{constructor(e=1,t=0,n=0){this.radius=e,this.phi=t,this.theta=n}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=at(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,n),this.phi=Math.acos(at(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}},vu=class{constructor(e=1,t=0,n=0){this.radius=e,this.theta=t,this.y=n}set(e,t,n){return this.radius=e,this.theta=t,this.y=n,this}copy(e){return this.radius=e.radius,this.theta=e.theta,this.y=e.y,this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+n*n),this.theta=Math.atan2(e,n),this.y=t,this}clone(){return new this.constructor().copy(this)}},up=class up{constructor(e,t,n,s){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,n,s)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let n=0;n<4;n++)this.elements[n]=e[n+t];return this}set(e,t,n,s){let r=this.elements;return r[0]=e,r[2]=t,r[1]=n,r[3]=s,this}};up.prototype.isMatrix2=!0;var yu=up,f0=new J,Hl=class{constructor(e=new J(1/0,1/0),t=new J(-1/0,-1/0)){this.isBox2=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=f0.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=1/0,this.max.x=this.max.y=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y}getCenter(e){return this.isEmpty()?e.set(0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,f0).distanceTo(e)}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},p0=new A,Th=new A,uo=new A,fo=new A,Qd=new A,jv=new A,Qv=new A,Mu=class{constructor(e=new A,t=new A){this.start=e,this.end=t}set(e,t){return this.start.copy(e),this.end.copy(t),this}copy(e){return this.start.copy(e.start),this.end.copy(e.end),this}getCenter(e){return e.addVectors(this.start,this.end).multiplyScalar(.5)}delta(e){return e.subVectors(this.end,this.start)}distanceSq(){return this.start.distanceToSquared(this.end)}distance(){return this.start.distanceTo(this.end)}at(e,t){return this.delta(t).multiplyScalar(e).add(this.start)}closestPointToPointParameter(e,t){p0.subVectors(e,this.start),Th.subVectors(this.end,this.start);let n=Th.dot(Th);if(n===0)return 0;let r=Th.dot(p0)/n;return t&&(r=at(r,0,1)),r}closestPointToPoint(e,t,n){let s=this.closestPointToPointParameter(e,t);return this.delta(n).multiplyScalar(s).add(this.start)}distanceSqToLine3(e,t=jv,n=Qv){let s=10000000000000001e-32,r,o,a=this.start,l=e.start,c=this.end,h=e.end;uo.subVectors(c,a),fo.subVectors(h,l),Qd.subVectors(a,l);let u=uo.dot(uo),d=fo.dot(fo),f=fo.dot(Qd);if(u<=s&&d<=s)return t.copy(a),n.copy(l),t.sub(n),t.dot(t);if(u<=s)r=0,o=f/d,o=at(o,0,1);else{let p=uo.dot(Qd);if(d<=s)o=0,r=at(-p/u,0,1);else{let _=uo.dot(fo),g=u*d-_*_;g!==0?r=at((_*f-p*d)/g,0,1):r=0,o=(_*r+f)/d,o<0?(o=0,r=at(-p/u,0,1)):o>1&&(o=1,r=at((_-p)/u,0,1))}}return t.copy(a).addScaledVector(uo,r),n.copy(l).addScaledVector(fo,o),t.distanceToSquared(n)}applyMatrix4(e){return this.start.applyMatrix4(e),this.end.applyMatrix4(e),this}equals(e){return e.start.equals(this.start)&&e.end.equals(this.end)}clone(){return new this.constructor().copy(this)}},m0=new A,bu=class extends _t{constructor(e,t){super(),this.light=e,this.matrixAutoUpdate=!1,this.color=t,this.type="SpotLightHelper";let n=new ke,s=[0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,-1,0,1,0,0,0,0,1,1,0,0,0,0,-1,1];for(let o=0,a=1,l=32;o<l;o++,a++){let c=o/l*Math.PI*2,h=a/l*Math.PI*2;s.push(Math.cos(c),Math.sin(c),1,Math.cos(h),Math.sin(h),1)}n.setAttribute("position",new _e(s,3));let r=new tn({fog:!1,toneMapped:!1});this.cone=new Sn(n,r),this.add(this.cone),this.update()}dispose(){super.dispose(),this.cone.geometry.dispose(),this.cone.material.dispose()}update(){this.light.updateWorldMatrix(!0,!1),this.light.target.updateWorldMatrix(!0,!1),this.parent?(this.parent.updateWorldMatrix(!0),this.matrix.copy(this.parent.matrixWorld).invert().multiply(this.light.matrixWorld)):this.matrix.copy(this.light.matrixWorld),this.matrixWorldNeedsUpdate=!0;let e=this.light.distance?this.light.distance:1e3,t=e*Math.tan(this.light.angle);this.cone.scale.set(t,t,e),m0.setFromMatrixPosition(this.light.target.matrixWorld),this.cone.lookAt(m0),this.color!==void 0?this.cone.material.color.set(this.color):this.cone.material.color.copy(this.light.color)}},Fs=new A,wh=new nt,ef=new nt,Eu=class extends Sn{constructor(e){let t=Eg(e),n=new ke,s=[],r=[];for(let c=0;c<t.length;c++){let h=t[c];h.parent&&h.parent.isBone&&(s.push(0,0,0),s.push(0,0,0),r.push(0,0,0),r.push(0,0,0))}n.setAttribute("position",new _e(s,3)),n.setAttribute("color",new _e(r,3));let o=new tn({vertexColors:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,transparent:!0});super(n,o),this.isSkeletonHelper=!0,this.type="SkeletonHelper",this.root=e,this.bones=t,this.matrix=e.matrixWorld,this.matrixAutoUpdate=!1;let a=new q(255),l=new q(65280);this.setColors(a,l)}updateMatrixWorld(e){let t=this.bones,n=this.geometry,s=n.getAttribute("position");ef.copy(this.root.matrixWorld).invert();for(let r=0,o=0;r<t.length;r++){let a=t[r];a.parent&&a.parent.isBone&&(wh.multiplyMatrices(ef,a.matrixWorld),Fs.setFromMatrixPosition(wh),s.setXYZ(o,Fs.x,Fs.y,Fs.z),wh.multiplyMatrices(ef,a.parent.matrixWorld),Fs.setFromMatrixPosition(wh),s.setXYZ(o+1,Fs.x,Fs.y,Fs.z),o+=2)}n.getAttribute("position").needsUpdate=!0,super.updateMatrixWorld(e)}setColors(e,t){let s=this.geometry.getAttribute("color");for(let r=0;r<s.count;r+=2)s.setXYZ(r,e.r,e.g,e.b),s.setXYZ(r+1,t.r,t.g,t.b);return s.needsUpdate=!0,this}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}};function Eg(i){let e=[];i.isBone===!0&&e.push(i);for(let t=0;t<i.children.length;t++)e.push(...Eg(i.children[t]));return e}var Su=class extends W{constructor(e,t,n){let s=new Rt(t,4,2),r=new Qe({wireframe:!0,fog:!1,toneMapped:!1});super(s,r),this.light=e,this.color=n,this.type="PointLightHelper",this.matrix=this.light.matrixWorld,this.matrixAutoUpdate=!1,this.update()}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}update(){this.matrixWorldNeedsUpdate=!0,this.light.updateWorldMatrix(!0,!1),this.color!==void 0?this.material.color.set(this.color):this.material.color.copy(this.light.color)}},ey=new A,g0=new q,_0=new q,Tu=class extends _t{constructor(e,t,n){super(),this.light=e,this.matrix=e.matrixWorld,this.matrixAutoUpdate=!1,this.color=n,this.type="HemisphereLightHelper";let s=new xs(t);s.rotateY(Math.PI*.5),this.material=new Qe({wireframe:!0,fog:!1,toneMapped:!1}),this.color===void 0&&(this.material.vertexColors=!0);let r=s.getAttribute("position"),o=new Float32Array(r.count*3);s.setAttribute("color",new bt(o,3)),this.add(new W(s,this.material)),this.update()}dispose(){super.dispose(),this.children[0].geometry.dispose(),this.children[0].material.dispose()}update(){let e=this.children[0];if(this.color!==void 0)this.material.color.set(this.color);else{let t=e.geometry.getAttribute("color");g0.copy(this.light.color),_0.copy(this.light.groundColor);for(let n=0,s=t.count;n<s;n++){let r=n<s/2?g0:_0;t.setXYZ(n,r.r,r.g,r.b)}t.needsUpdate=!0}this.matrixWorldNeedsUpdate=!0,this.light.updateWorldMatrix(!0,!1),e.lookAt(ey.setFromMatrixPosition(this.light.matrixWorld).negate())}},wu=class extends Sn{constructor(e=10,t=10,n=4473924,s=8947848){n=new q(n),s=new q(s);let r=t/2,o=e/t,a=e/2,l=[],c=[];for(let d=0,f=0,p=-a;d<=t;d++,p+=o){l.push(-a,0,p,a,0,p),l.push(p,0,-a,p,0,a);let _=d===r?n:s;_.toArray(c,f),f+=3,_.toArray(c,f),f+=3,_.toArray(c,f),f+=3,_.toArray(c,f),f+=3}let h=new ke;h.setAttribute("position",new _e(l,3)),h.setAttribute("color",new _e(c,3));let u=new tn({vertexColors:!0,toneMapped:!1});super(h,u),this.type="GridHelper"}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}},Ru=class extends Sn{constructor(e=10,t=16,n=8,s=64,r=4473924,o=8947848){r=new q(r),o=new q(o);let a=[],l=[];if(t>1)for(let u=0;u<t;u++){let d=u/t*(Math.PI*2),f=Math.sin(d)*e,p=Math.cos(d)*e;a.push(0,0,0),a.push(f,0,p);let _=u&1?r:o;l.push(_.r,_.g,_.b),l.push(_.r,_.g,_.b)}for(let u=0;u<n;u++){let d=u&1?r:o,f=e-e/n*u;for(let p=0;p<s;p++){let _=p/s*(Math.PI*2),g=Math.sin(_)*f,m=Math.cos(_)*f;a.push(g,0,m),l.push(d.r,d.g,d.b),_=(p+1)/s*(Math.PI*2),g=Math.sin(_)*f,m=Math.cos(_)*f,a.push(g,0,m),l.push(d.r,d.g,d.b)}}let c=new ke;c.setAttribute("position",new _e(a,3)),c.setAttribute("color",new _e(l,3));let h=new tn({vertexColors:!0,toneMapped:!1});super(c,h),this.type="PolarGridHelper"}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}},x0=new A,Rh=new A,v0=new A,Au=class extends _t{constructor(e,t,n){super(),this.light=e,this.matrix=e.matrixWorld,this.matrixAutoUpdate=!1,this.color=n,this.type="DirectionalLightHelper",t===void 0&&(t=1);let s=new ke;s.setAttribute("position",new _e([-t,t,0,t,t,0,t,-t,0,-t,-t,0,-t,t,0],3));let r=new tn({fog:!1,toneMapped:!1});this.lightPlane=new Bi(s,r),this.add(this.lightPlane),s=new ke,s.setAttribute("position",new _e([0,0,0,0,0,1],3)),this.targetLine=new Bi(s,r),this.add(this.targetLine),this.update()}dispose(){super.dispose(),this.lightPlane.geometry.dispose(),this.lightPlane.material.dispose(),this.targetLine.geometry.dispose(),this.targetLine.material.dispose()}update(){this.matrixWorldNeedsUpdate=!0,this.light.updateWorldMatrix(!0,!1),this.light.target.updateWorldMatrix(!0,!1),x0.setFromMatrixPosition(this.light.matrixWorld),Rh.setFromMatrixPosition(this.light.target.matrixWorld),v0.subVectors(Rh,x0),this.lightPlane.lookAt(Rh),this.color!==void 0?(this.lightPlane.material.color.set(this.color),this.targetLine.material.color.set(this.color)):(this.lightPlane.material.color.copy(this.light.color),this.targetLine.material.color.copy(this.light.color)),this.targetLine.lookAt(Rh),this.targetLine.scale.z=v0.length()}},Ah=new A,rn=new Cr,Cu=class extends Sn{constructor(e){let t=new ke,n=new tn({color:16777215,vertexColors:!0,toneMapped:!1}),s=[],r=[],o={};a("n1","n2"),a("n2","n4"),a("n4","n3"),a("n3","n1"),a("f1","f2"),a("f2","f4"),a("f4","f3"),a("f3","f1"),a("n1","f1"),a("n2","f2"),a("n3","f3"),a("n4","f4"),a("p","n1"),a("p","n2"),a("p","n3"),a("p","n4"),a("u1","u2"),a("u2","u3"),a("u3","u1"),a("c","t"),a("p","c"),a("cn1","cn2"),a("cn3","cn4"),a("cf1","cf2"),a("cf3","cf4");function a(p,_){l(p),l(_)}function l(p){s.push(0,0,0),r.push(0,0,0),o[p]===void 0&&(o[p]=[]),o[p].push(s.length/3-1)}t.setAttribute("position",new _e(s,3)),t.setAttribute("color",new _e(r,3)),super(t,n),this.type="CameraHelper",this.camera=e,this.camera.updateProjectionMatrix&&this.camera.updateProjectionMatrix(),this.matrix=e.matrixWorld,this.matrixAutoUpdate=!1,this.pointMap=o,this.update();let c=new q(16755200),h=new q(16711680),u=new q(43775),d=new q(16777215),f=new q(3355443);this.setColors(c,h,u,d,f)}setColors(e,t,n,s,r){let a=this.geometry.getAttribute("color");return a.setXYZ(0,e.r,e.g,e.b),a.setXYZ(1,e.r,e.g,e.b),a.setXYZ(2,e.r,e.g,e.b),a.setXYZ(3,e.r,e.g,e.b),a.setXYZ(4,e.r,e.g,e.b),a.setXYZ(5,e.r,e.g,e.b),a.setXYZ(6,e.r,e.g,e.b),a.setXYZ(7,e.r,e.g,e.b),a.setXYZ(8,e.r,e.g,e.b),a.setXYZ(9,e.r,e.g,e.b),a.setXYZ(10,e.r,e.g,e.b),a.setXYZ(11,e.r,e.g,e.b),a.setXYZ(12,e.r,e.g,e.b),a.setXYZ(13,e.r,e.g,e.b),a.setXYZ(14,e.r,e.g,e.b),a.setXYZ(15,e.r,e.g,e.b),a.setXYZ(16,e.r,e.g,e.b),a.setXYZ(17,e.r,e.g,e.b),a.setXYZ(18,e.r,e.g,e.b),a.setXYZ(19,e.r,e.g,e.b),a.setXYZ(20,e.r,e.g,e.b),a.setXYZ(21,e.r,e.g,e.b),a.setXYZ(22,e.r,e.g,e.b),a.setXYZ(23,e.r,e.g,e.b),a.setXYZ(24,t.r,t.g,t.b),a.setXYZ(25,t.r,t.g,t.b),a.setXYZ(26,t.r,t.g,t.b),a.setXYZ(27,t.r,t.g,t.b),a.setXYZ(28,t.r,t.g,t.b),a.setXYZ(29,t.r,t.g,t.b),a.setXYZ(30,t.r,t.g,t.b),a.setXYZ(31,t.r,t.g,t.b),a.setXYZ(32,n.r,n.g,n.b),a.setXYZ(33,n.r,n.g,n.b),a.setXYZ(34,n.r,n.g,n.b),a.setXYZ(35,n.r,n.g,n.b),a.setXYZ(36,n.r,n.g,n.b),a.setXYZ(37,n.r,n.g,n.b),a.setXYZ(38,s.r,s.g,s.b),a.setXYZ(39,s.r,s.g,s.b),a.setXYZ(40,r.r,r.g,r.b),a.setXYZ(41,r.r,r.g,r.b),a.setXYZ(42,r.r,r.g,r.b),a.setXYZ(43,r.r,r.g,r.b),a.setXYZ(44,r.r,r.g,r.b),a.setXYZ(45,r.r,r.g,r.b),a.setXYZ(46,r.r,r.g,r.b),a.setXYZ(47,r.r,r.g,r.b),a.setXYZ(48,r.r,r.g,r.b),a.setXYZ(49,r.r,r.g,r.b),a.needsUpdate=!0,this}update(){let e=this.geometry,t=this.pointMap,n=1,s=1,r,o;if(rn.projectionMatrixInverse.copy(this.camera.projectionMatrixInverse),this.camera.reversedDepth===!0)r=1,o=0;else if(this.camera.coordinateSystem===si)r=-1,o=1;else if(this.camera.coordinateSystem===zs)r=0,o=1;else throw new Error("THREE.CameraHelper.update(): Invalid coordinate system: "+this.camera.coordinateSystem);dn("c",t,e,rn,0,0,r),dn("t",t,e,rn,0,0,o),dn("n1",t,e,rn,-n,-s,r),dn("n2",t,e,rn,n,-s,r),dn("n3",t,e,rn,-n,s,r),dn("n4",t,e,rn,n,s,r),dn("f1",t,e,rn,-n,-s,o),dn("f2",t,e,rn,n,-s,o),dn("f3",t,e,rn,-n,s,o),dn("f4",t,e,rn,n,s,o),dn("u1",t,e,rn,n*.7,s*1.1,r),dn("u2",t,e,rn,-n*.7,s*1.1,r),dn("u3",t,e,rn,0,s*2,r),dn("cf1",t,e,rn,-n,0,o),dn("cf2",t,e,rn,n,0,o),dn("cf3",t,e,rn,0,-s,o),dn("cf4",t,e,rn,0,s,o),dn("cn1",t,e,rn,-n,0,r),dn("cn2",t,e,rn,n,0,r),dn("cn3",t,e,rn,0,-s,r),dn("cn4",t,e,rn,0,s,r),e.getAttribute("position").needsUpdate=!0}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}};function dn(i,e,t,n,s,r,o){Ah.set(s,r,o).unproject(n);let a=e[i];if(a!==void 0){let l=t.getAttribute("position");for(let c=0,h=a.length;c<h;c++)l.setXYZ(a[c],Ah.x,Ah.y,Ah.z)}}var Ch=new bn,Pu=class extends Sn{constructor(e,t=16776960){let n=new Uint16Array([0,1,1,2,2,3,3,0,4,5,5,6,6,7,7,4,0,4,1,5,2,6,3,7]),s=new Float32Array(8*3),r=new ke;r.setIndex(new bt(n,1)),r.setAttribute("position",new bt(s,3)),super(r,new tn({color:t,toneMapped:!1})),this.object=e,this.type="BoxHelper",this.matrixAutoUpdate=!1,this.update()}update(){if(this.object!==void 0&&Ch.setFromObject(this.object),Ch.isEmpty())return;let e=Ch.min,t=Ch.max,n=this.geometry.attributes.position,s=n.array;s[0]=t.x,s[1]=t.y,s[2]=t.z,s[3]=e.x,s[4]=t.y,s[5]=t.z,s[6]=e.x,s[7]=e.y,s[8]=t.z,s[9]=t.x,s[10]=e.y,s[11]=t.z,s[12]=t.x,s[13]=t.y,s[14]=e.z,s[15]=e.x,s[16]=t.y,s[17]=e.z,s[18]=e.x,s[19]=e.y,s[20]=e.z,s[21]=t.x,s[22]=e.y,s[23]=e.z,n.needsUpdate=!0,this.geometry.computeBoundingSphere()}setFromObject(e){return this.object=e,this.update(),this}copy(e,t){return super.copy(e,t),this.object=e.object,this}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}},Iu=class extends Sn{constructor(e,t=16776960){let n=new Uint16Array([0,1,1,2,2,3,3,0,4,5,5,6,6,7,7,4,0,4,1,5,2,6,3,7]),s=[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,-1,-1,1,-1,-1,-1,-1,1,-1,-1],r=new ke;r.setIndex(new bt(n,1)),r.setAttribute("position",new _e(s,3)),super(r,new tn({color:t,toneMapped:!1})),this.box=e,this.type="Box3Helper",this.geometry.computeBoundingSphere()}updateMatrixWorld(e){let t=this.box;t.isEmpty()||(t.getCenter(this.position),t.getSize(this.scale),this.scale.multiplyScalar(.5),super.updateMatrixWorld(e))}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}},Du=class extends Bi{constructor(e,t=1,n=16776960){let s=n,r=[1,-1,0,-1,1,0,-1,-1,0,1,1,0,-1,1,0,-1,-1,0,1,-1,0,1,1,0],o=new ke;o.setAttribute("position",new _e(r,3)),o.computeBoundingSphere(),super(o,new tn({color:s,toneMapped:!1})),this.type="PlaneHelper",this.plane=e,this.size=t;let a=[1,1,0,-1,1,0,-1,-1,0,1,1,0,-1,-1,0,1,-1,0],l=new ke;l.setAttribute("position",new _e(a,3)),l.computeBoundingSphere(),this.add(new W(l,new Qe({color:s,opacity:.2,transparent:!0,depthWrite:!1,toneMapped:!1})))}updateMatrixWorld(e){this.position.set(0,0,0),this.scale.set(.5*this.size,.5*this.size,1),this.lookAt(this.plane.normal),this.translateZ(-this.plane.constant),super.updateMatrixWorld(e)}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose(),this.children[0].geometry.dispose(),this.children[0].material.dispose()}},y0=new A,Ph,tf,Lu=class extends _t{constructor(e=new A(0,0,1),t=new A(0,0,0),n=1,s=16776960,r=n*.2,o=r*.2){super(),this.type="ArrowHelper",Ph===void 0&&(Ph=new ke,Ph.setAttribute("position",new _e([0,0,0,0,1,0],3)),tf=new vn(.5,1,5,1),tf.translate(0,-.5,0)),this.position.copy(t),this.line=new Bi(Ph,new tn({color:s,toneMapped:!1})),this.line.matrixAutoUpdate=!1,this.add(this.line),this.cone=new W(tf,new Qe({color:s,toneMapped:!1})),this.cone.matrixAutoUpdate=!1,this.add(this.cone),this.setDirection(e),this.setLength(n,r,o)}setDirection(e){if(e.y>.99999)this.quaternion.set(0,0,0,1);else if(e.y<-.99999)this.quaternion.set(1,0,0,0);else{y0.set(e.z,0,-e.x).normalize();let t=Math.acos(e.y);this.quaternion.setFromAxisAngle(y0,t)}}setLength(e,t=e*.2,n=t*.2){this.line.scale.set(1,Math.max(1e-4,e-t),1),this.line.updateMatrix(),this.cone.scale.set(n,t,n),this.cone.position.y=e,this.cone.updateMatrix()}setColor(e){this.line.material.color.set(e),this.cone.material.color.set(e)}copy(e){return super.copy(e,!1),this.line.copy(e.line),this.cone.copy(e.cone),this}dispose(){super.dispose(),this.line.geometry.dispose(),this.line.material.dispose(),this.cone.geometry.dispose(),this.cone.material.dispose()}},Nu=class extends Sn{constructor(e=1){let t=[0,0,0,e,0,0,0,0,0,0,e,0,0,0,0,0,0,e],n=[1,0,0,1,.6,0,0,1,0,.6,1,0,0,0,1,0,.6,1],s=new ke;s.setAttribute("position",new _e(t,3)),s.setAttribute("color",new _e(n,3));let r=new tn({vertexColors:!0,toneMapped:!1});super(s,r),this.type="AxesHelper"}setColors(e,t,n){let s=new q,r=this.geometry.attributes.color.array;return s.set(e),s.toArray(r,0),s.toArray(r,3),s.set(t),s.toArray(r,6),s.toArray(r,9),s.set(n),s.toArray(r,12),s.toArray(r,15),this.geometry.attributes.color.needsUpdate=!0,this}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}},Uu=class{constructor(){this.type="ShapePath",this.color=new q,this.subPaths=[],this.currentPath=null,this.userData={}}moveTo(e,t){return this.currentPath=new li,this.subPaths.push(this.currentPath),this.currentPath.moveTo(e,t),this}lineTo(e,t){return this.currentPath.lineTo(e,t),this}quadraticCurveTo(e,t,n,s){return this.currentPath.quadraticCurveTo(e,t,n,s),this}bezierCurveTo(e,t,n,s,r,o){return this.currentPath.bezierCurveTo(e,t,n,s,r,o),this}splineThru(e){return this.currentPath.splineThru(e),this}toShapes(){function e(l,c){let h=!1,u=c.length;for(let d=0,f=u-1;d<u;f=d++){let p=c[d],_=c[f];p.y>l.y!=_.y>l.y&&l.x<(_.x-p.x)*(l.y-p.y)/(_.y-p.y)+p.x&&(h=!h)}return h}function t(l,c){let h=c.getCenter(new J);if(e(h,l))return h;let u=h.y,d=[],f=l.length;for(let p=0;p<f;p++){let _=l[p],g=l[(p+1)%f];if(_.y>u!=g.y>u){let m=_.x+(u-_.y)*(g.x-_.x)/(g.y-_.y);d.push(m)}}return d.length>1&&(d.sort((p,_)=>p-_),h.x=(d[0]+d[1])/2),h}let n=this.userData.style&&this.userData.style.fillRule||"nonzero";n!=="nonzero"&&n!=="evenodd"&&(be('Fill-rule "'+n+'" is not supported, falling back to "nonzero".'),n="nonzero");let s=n==="nonzero"?l=>l!==0:l=>(l&1)!==0,r=[];for(let l of this.subPaths){let c=l.getPoints();if(c.length<3)continue;let h=Ei.area(c);if(h===0)continue;let u=new Hl;for(let d=0;d<c.length;d++)u.expandByPoint(c[d]);r.push({subPath:l,points:c,boundingBox:u,interiorPoint:t(c,u),absArea:Math.abs(h),winding:h<0?-1:1,container:null,exclude:!1,role:null})}r.sort((l,c)=>c.absArea-l.absArea);for(let l=0;l<r.length;l++){let c=r[l],h=0;for(let u=l-1;u>=0;u--){let d=r[u];if(d.boundingBox.containsBox(c.boundingBox)&&e(c.interiorPoint,d.points)){c.container=d.exclude?d.container:d,h=d.winding,c.winding+=h;break}}s(c.winding)===s(h)&&(c.exclude=!0)}for(let l of r)l.exclude||(l.role=l.container===null||l.container.role==="hole"?"outer":"hole");let o=[],a=new Map;for(let l of r){if(l.exclude||l.role!=="outer")continue;let c=new kt;c.curves=l.subPath.curves,o.push(c),a.set(l,c)}for(let l of r){if(l.exclude||l.role!=="hole")continue;let c=a.get(l.container);if(!c)continue;let h=new li;h.curves=l.subPath.curves,c.holes.push(h)}return o}},Vo=class extends ri{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}};function ty(i,e){let t=i.image&&i.image.width?i.image.width/i.image.height:1;return t>e?(i.repeat.x=1,i.repeat.y=t/e,i.offset.x=0,i.offset.y=(1-i.repeat.y)/2):(i.repeat.x=e/t,i.repeat.y=1,i.offset.x=(1-i.repeat.x)/2,i.offset.y=0),i}function ny(i,e){let t=i.image&&i.image.width?i.image.width/i.image.height:1;return t>e?(i.repeat.x=e/t,i.repeat.y=1,i.offset.x=(1-i.repeat.x)/2,i.offset.y=0):(i.repeat.x=1,i.repeat.y=t/e,i.offset.x=0,i.offset.y=(1-i.repeat.y)/2),i}function iy(i){return i.repeat.x=1,i.repeat.y=1,i.offset.x=0,i.offset.y=0,i}function ju(i,e,t,n){let s=sy(n);switch(t){case Zu:return i*e;case Xl:return i*e/s.components*s.byteLength;case ea:return i*e/s.components*s.byteLength;case ws:return i*e*2/s.components*s.byteLength;case Yl:return i*e*2/s.components*s.byteLength;case Ju:return i*e*3/s.components*s.byteLength;case In:return i*e*4/s.components*s.byteLength;case ql:return i*e*4/s.components*s.byteLength;case ta:case na:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case ia:case sa:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Jl:case $l:return Math.max(i,16)*Math.max(e,8)/4;case Zl:case Kl:return Math.max(i,8)*Math.max(e,8)/2;case jl:case Ql:case tc:case nc:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case ec:case ra:case ic:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case sc:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case rc:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case oc:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case ac:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case lc:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case cc:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case hc:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case uc:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case dc:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case fc:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case pc:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case mc:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case gc:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case _c:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case xc:case vc:case yc:return Math.ceil(i/4)*Math.ceil(e/4)*16;case Mc:case bc:return Math.ceil(i/4)*Math.ceil(e/4)*8;case oa:case Ec:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function sy(i){switch(i){case Qn:case Wu:return{byteLength:1,components:1};case Ur:case Xu:case yn:return{byteLength:2,components:1};case Vl:case Wl:return{byteLength:2,components:4};case _i:case Gl:case kn:return{byteLength:4,components:1};case Yu:case qu:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${i}.`)}var Fu=class{static contain(e,t){return ty(e,t)}static cover(e,t){return ny(e,t)}static fill(e){return iy(e)}static getByteLength(e,t,n,s){return ju(e,t,n,s)}};typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:zl}}));typeof window<"u"&&(window.__THREE__?be("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=zl);function Xg(){let i=null,e=!1,t=null,n=null;function s(r,o){n=i.requestAnimationFrame(s),t(r,o)}return{start:function(){e!==!0&&t!==null&&i!==null&&(n=i.requestAnimationFrame(s),e=!0)},stop:function(){i!==null&&i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){i=r}}}function ry(i){let e=new WeakMap;function t(a,l){let c=a.array,h=a.usage,u=c.byteLength,d=i.createBuffer();i.bindBuffer(l,d),i.bufferData(l,c,h),a.onUploadCallback();let f;if(c instanceof Float32Array)f=i.FLOAT;else if(typeof Float16Array<"u"&&c instanceof Float16Array)f=i.HALF_FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=i.SHORT;else if(c instanceof Uint32Array)f=i.UNSIGNED_INT;else if(c instanceof Int32Array)f=i.INT;else if(c instanceof Int8Array)f=i.BYTE;else if(c instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,l,c){let h=l.array,u=l.updateRanges;if(i.bindBuffer(c,a),u.length===0)i.bufferSubData(c,0,h);else{u.sort((f,p)=>f.start-p.start);let d=0;for(let f=1;f<u.length;f++){let p=u[d],_=u[f];_.start<=p.start+p.count+1?p.count=Math.max(p.count,_.start+_.count-p.start):(++d,u[d]=_)}u.length=d+1;for(let f=0,p=u.length;f<p;f++){let _=u[f];i.bufferSubData(c,_.start*h.BYTES_PER_ELEMENT,h,_.start,_.count)}l.clearUpdateRanges()}l.onUploadCallback()}function s(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function r(a){a.isInterleavedBufferAttribute&&(a=a.data);let l=e.get(a);l&&(i.deleteBuffer(l.buffer),e.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){let h=e.get(a);(!h||h.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}let c=e.get(a);if(c===void 0)e.set(a,t(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,a,l),c.version=a.version}}return{get:s,remove:r,update:o}}var oy=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,ay=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,ly=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,cy=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,hy=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,uy=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,dy=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,fy=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,py=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,my=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,gy=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,_y=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,xy=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,vy=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,yy=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,My=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,by=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Ey=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Sy=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ty=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,wy=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Ry=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,Ay=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Cy=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Py=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Iy=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,Dy=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Ly=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Ny=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Uy=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Fy="gl_FragColor = linearToOutputTexel( gl_FragColor );",By=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Oy=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Hy=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,zy=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,ky=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Gy=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Vy=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Wy=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Xy=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Yy=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,qy=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Zy=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Jy=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Ky=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,$y=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,jy=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,Qy=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,e1=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,t1=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,n1=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,i1=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,s1=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,r1=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,o1=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,a1=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,l1=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,c1=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,h1=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,u1=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,d1=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,f1=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,p1=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,m1=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,g1=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,_1=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,x1=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,v1=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,y1=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,M1=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,b1=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,E1=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,S1=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,T1=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,w1=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,R1=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,A1=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,C1=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,P1=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,I1=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,D1=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,L1=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,N1=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,U1=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,F1=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,B1=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,O1=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,H1=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,z1=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,k1=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,G1=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,V1=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,W1=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,X1=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Y1=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,q1=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Z1=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,J1=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,K1=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,$1=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,j1=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Q1=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,eM=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,tM=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,nM=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,iM=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,sM=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,rM=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,oM=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,aM=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,lM=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cM=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,hM=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,uM=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,dM=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,fM=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,pM=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,mM=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,gM=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,_M=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xM=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,vM=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,yM=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,MM=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,bM=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,EM=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,SM=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,TM=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,wM=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,RM=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,AM=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,CM=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,PM=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,IM=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,DM=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,LM=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,NM=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,UM=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,FM=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,BM=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,OM=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,HM=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,vt={alphahash_fragment:oy,alphahash_pars_fragment:ay,alphamap_fragment:ly,alphamap_pars_fragment:cy,alphatest_fragment:hy,alphatest_pars_fragment:uy,aomap_fragment:dy,aomap_pars_fragment:fy,batching_pars_vertex:py,batching_vertex:my,begin_vertex:gy,beginnormal_vertex:_y,bsdfs:xy,iridescence_fragment:vy,bumpmap_pars_fragment:yy,clipping_planes_fragment:My,clipping_planes_pars_fragment:by,clipping_planes_pars_vertex:Ey,clipping_planes_vertex:Sy,color_fragment:Ty,color_pars_fragment:wy,color_pars_vertex:Ry,color_vertex:Ay,common:Cy,cube_uv_reflection_fragment:Py,defaultnormal_vertex:Iy,displacementmap_pars_vertex:Dy,displacementmap_vertex:Ly,emissivemap_fragment:Ny,emissivemap_pars_fragment:Uy,colorspace_fragment:Fy,colorspace_pars_fragment:By,envmap_fragment:Oy,envmap_common_pars_fragment:Hy,envmap_pars_fragment:zy,envmap_pars_vertex:ky,envmap_physical_pars_fragment:jy,envmap_vertex:Gy,fog_vertex:Vy,fog_pars_vertex:Wy,fog_fragment:Xy,fog_pars_fragment:Yy,gradientmap_pars_fragment:qy,lightmap_pars_fragment:Zy,lights_lambert_fragment:Jy,lights_lambert_pars_fragment:Ky,lights_pars_begin:$y,lights_toon_fragment:Qy,lights_toon_pars_fragment:e1,lights_phong_fragment:t1,lights_phong_pars_fragment:n1,lights_physical_fragment:i1,lights_physical_pars_fragment:s1,lights_fragment_begin:r1,lights_fragment_maps:o1,lights_fragment_end:a1,lightprobes_pars_fragment:l1,logdepthbuf_fragment:c1,logdepthbuf_pars_fragment:h1,logdepthbuf_pars_vertex:u1,logdepthbuf_vertex:d1,map_fragment:f1,map_pars_fragment:p1,map_particle_fragment:m1,map_particle_pars_fragment:g1,metalnessmap_fragment:_1,metalnessmap_pars_fragment:x1,morphinstance_vertex:v1,morphcolor_vertex:y1,morphnormal_vertex:M1,morphtarget_pars_vertex:b1,morphtarget_vertex:E1,normal_fragment_begin:S1,normal_fragment_maps:T1,normal_pars_fragment:w1,normal_pars_vertex:R1,normal_vertex:A1,normalmap_pars_fragment:C1,clearcoat_normal_fragment_begin:P1,clearcoat_normal_fragment_maps:I1,clearcoat_pars_fragment:D1,iridescence_pars_fragment:L1,opaque_fragment:N1,packing:U1,premultiplied_alpha_fragment:F1,project_vertex:B1,dithering_fragment:O1,dithering_pars_fragment:H1,roughnessmap_fragment:z1,roughnessmap_pars_fragment:k1,shadowmap_pars_fragment:G1,shadowmap_pars_vertex:V1,shadowmap_vertex:W1,shadowmask_pars_fragment:X1,skinbase_vertex:Y1,skinning_pars_vertex:q1,skinning_vertex:Z1,skinnormal_vertex:J1,specularmap_fragment:K1,specularmap_pars_fragment:$1,tonemapping_fragment:j1,tonemapping_pars_fragment:Q1,transmission_fragment:eM,transmission_pars_fragment:tM,uv_pars_fragment:nM,uv_pars_vertex:iM,uv_vertex:sM,worldpos_vertex:rM,background_vert:oM,background_frag:aM,backgroundCube_vert:lM,backgroundCube_frag:cM,cube_vert:hM,cube_frag:uM,depth_vert:dM,depth_frag:fM,distance_vert:pM,distance_frag:mM,equirect_vert:gM,equirect_frag:_M,linedashed_vert:xM,linedashed_frag:vM,meshbasic_vert:yM,meshbasic_frag:MM,meshlambert_vert:bM,meshlambert_frag:EM,meshmatcap_vert:SM,meshmatcap_frag:TM,meshnormal_vert:wM,meshnormal_frag:RM,meshphong_vert:AM,meshphong_frag:CM,meshphysical_vert:PM,meshphysical_frag:IM,meshtoon_vert:DM,meshtoon_frag:LM,points_vert:NM,points_frag:UM,shadow_vert:FM,shadow_frag:BM,sprite_vert:OM,sprite_frag:HM},Ae={common:{diffuse:{value:new q(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ht},alphaMap:{value:null},alphaMapTransform:{value:new ht},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ht}},envmap:{envMap:{value:null},envMapRotation:{value:new ht},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ht}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ht}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ht},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ht},normalScale:{value:new J(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ht},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ht}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ht}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ht}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new q(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new A},probesMax:{value:new A},probesResolution:{value:new A}},points:{diffuse:{value:new q(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ht},alphaTest:{value:0},uvTransform:{value:new ht}},sprite:{diffuse:{value:new q(16777215)},opacity:{value:1},center:{value:new J(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ht},alphaMap:{value:null},alphaMapTransform:{value:new ht},alphaTest:{value:0}}},Vi={basic:{uniforms:Wn([Ae.common,Ae.specularmap,Ae.envmap,Ae.aomap,Ae.lightmap,Ae.fog]),vertexShader:vt.meshbasic_vert,fragmentShader:vt.meshbasic_frag},lambert:{uniforms:Wn([Ae.common,Ae.specularmap,Ae.envmap,Ae.aomap,Ae.lightmap,Ae.emissivemap,Ae.bumpmap,Ae.normalmap,Ae.displacementmap,Ae.fog,Ae.lights,{emissive:{value:new q(0)},envMapIntensity:{value:1}}]),vertexShader:vt.meshlambert_vert,fragmentShader:vt.meshlambert_frag},phong:{uniforms:Wn([Ae.common,Ae.specularmap,Ae.envmap,Ae.aomap,Ae.lightmap,Ae.emissivemap,Ae.bumpmap,Ae.normalmap,Ae.displacementmap,Ae.fog,Ae.lights,{emissive:{value:new q(0)},specular:{value:new q(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:vt.meshphong_vert,fragmentShader:vt.meshphong_frag},standard:{uniforms:Wn([Ae.common,Ae.envmap,Ae.aomap,Ae.lightmap,Ae.emissivemap,Ae.bumpmap,Ae.normalmap,Ae.displacementmap,Ae.roughnessmap,Ae.metalnessmap,Ae.fog,Ae.lights,{emissive:{value:new q(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:vt.meshphysical_vert,fragmentShader:vt.meshphysical_frag},toon:{uniforms:Wn([Ae.common,Ae.aomap,Ae.lightmap,Ae.emissivemap,Ae.bumpmap,Ae.normalmap,Ae.displacementmap,Ae.gradientmap,Ae.fog,Ae.lights,{emissive:{value:new q(0)}}]),vertexShader:vt.meshtoon_vert,fragmentShader:vt.meshtoon_frag},matcap:{uniforms:Wn([Ae.common,Ae.bumpmap,Ae.normalmap,Ae.displacementmap,Ae.fog,{matcap:{value:null}}]),vertexShader:vt.meshmatcap_vert,fragmentShader:vt.meshmatcap_frag},points:{uniforms:Wn([Ae.points,Ae.fog]),vertexShader:vt.points_vert,fragmentShader:vt.points_frag},dashed:{uniforms:Wn([Ae.common,Ae.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:vt.linedashed_vert,fragmentShader:vt.linedashed_frag},depth:{uniforms:Wn([Ae.common,Ae.displacementmap]),vertexShader:vt.depth_vert,fragmentShader:vt.depth_frag},normal:{uniforms:Wn([Ae.common,Ae.bumpmap,Ae.normalmap,Ae.displacementmap,{opacity:{value:1}}]),vertexShader:vt.meshnormal_vert,fragmentShader:vt.meshnormal_frag},sprite:{uniforms:Wn([Ae.sprite,Ae.fog]),vertexShader:vt.sprite_vert,fragmentShader:vt.sprite_frag},background:{uniforms:{uvTransform:{value:new ht},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:vt.background_vert,fragmentShader:vt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new ht}},vertexShader:vt.backgroundCube_vert,fragmentShader:vt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:vt.cube_vert,fragmentShader:vt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:vt.equirect_vert,fragmentShader:vt.equirect_frag},distance:{uniforms:Wn([Ae.common,Ae.displacementmap,{referencePosition:{value:new A},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:vt.distance_vert,fragmentShader:vt.distance_frag},shadow:{uniforms:Wn([Ae.lights,Ae.fog,{color:{value:new q(0)},opacity:{value:1}}]),vertexShader:vt.shadow_vert,fragmentShader:vt.shadow_frag}};Vi.physical={uniforms:Wn([Vi.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ht},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ht},clearcoatNormalScale:{value:new J(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ht},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ht},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ht},sheen:{value:0},sheenColor:{value:new q(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ht},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ht},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ht},transmissionSamplerSize:{value:new J},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ht},attenuationDistance:{value:0},attenuationColor:{value:new q(0)},specularColor:{value:new q(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ht},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ht},anisotropyVector:{value:new J},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ht}}]),vertexShader:vt.meshphysical_vert,fragmentShader:vt.meshphysical_frag};var Qu={r:0,b:0,g:0},zM=new nt,Yg=new ht;Yg.set(-1,0,0,0,1,0,0,0,1);function kM(i,e,t,n,s,r){let o=new q(0),a=s===!0?0:1,l,c,h=null,u=0,d=null;function f(v){let E=v.isScene===!0?v.background:null;if(E&&E.isTexture){let y=v.backgroundBlurriness>0;E=e.get(E,y)}return E}function p(v){let E=!1,y=f(v);y===null?g(o,a):y&&y.isColor&&(g(y,1),E=!0);let w=i.xr.getEnvironmentBlendMode();w==="additive"?t.buffers.color.setClear(0,0,0,1,r):w==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,r),(i.autoClear||E)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function _(v,E){let y=f(E);y&&(y.isCubeTexture||y.mapping===Lr)?(c===void 0&&(c=new W(new mi(1,1,1),new xt({name:"BackgroundCubeMaterial",uniforms:Or(Vi.backgroundCube.uniforms),vertexShader:Vi.backgroundCube.vertexShader,fragmentShader:Vi.backgroundCube.fragmentShader,side:Ln,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(w,M,T){this.matrixWorld.copyPosition(T.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),c.material.uniforms.envMap.value=y,c.material.uniforms.backgroundBlurriness.value=E.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(zM.makeRotationFromEuler(E.backgroundRotation)).transpose(),y.isCubeTexture&&y.isRenderTargetTexture===!1&&c.material.uniforms.backgroundRotation.value.premultiply(Yg),c.material.toneMapped=Mt.getTransfer(y.colorSpace)!==Ct,(h!==y||u!==y.version||d!==i.toneMapping)&&(c.material.needsUpdate=!0,h=y,u=y.version,d=i.toneMapping),c.layers.enableAll(),v.unshift(c,c.geometry,c.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new W(new cn(2,2),new xt({name:"BackgroundMaterial",uniforms:Or(Vi.background.uniforms),vertexShader:Vi.background.vertexShader,fragmentShader:Vi.background.fragmentShader,side:zi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=E.backgroundIntensity,l.material.toneMapped=Mt.getTransfer(y.colorSpace)!==Ct,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),(h!==y||u!==y.version||d!==i.toneMapping)&&(l.material.needsUpdate=!0,h=y,u=y.version,d=i.toneMapping),l.layers.enableAll(),v.unshift(l,l.geometry,l.material,0,0,null))}function g(v,E){v.getRGB(Qu,ip(i)),t.buffers.color.setClear(Qu.r,Qu.g,Qu.b,E,r)}function m(){c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0),l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0)}return{getClearColor:function(){return o},setClearColor:function(v,E=1){o.set(v),a=E,g(o,a)},getClearAlpha:function(){return a},setClearAlpha:function(v){a=v,g(o,a)},render:p,addToRenderList:_,dispose:m}}function GM(i,e){let t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},s=d(null),r=s,o=!1;function a(L,F,I,P,U){let z=!1,V=u(L,P,I,F);r!==V&&(r=V,c(r.object)),z=f(L,P,I,U),z&&p(L,P,I,U),U!==null&&e.update(U,i.ELEMENT_ARRAY_BUFFER),(z||o)&&(o=!1,y(L,F,I,P),U!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(U).buffer))}function l(){return i.createVertexArray()}function c(L){return i.bindVertexArray(L)}function h(L){return i.deleteVertexArray(L)}function u(L,F,I,P){let U=P.wireframe===!0,z=n[F.id];z===void 0&&(z={},n[F.id]=z);let V=L.isInstancedMesh===!0?L.id:0,ie=z[V];ie===void 0&&(ie={},z[V]=ie);let $=ie[I.id];$===void 0&&($={},ie[I.id]=$);let se=$[U];return se===void 0&&(se=d(l()),$[U]=se),se}function d(L){let F=[],I=[],P=[];for(let U=0;U<t;U++)F[U]=0,I[U]=0,P[U]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:F,enabledAttributes:I,attributeDivisors:P,object:L,attributes:{},index:null}}function f(L,F,I,P){let U=r.attributes,z=F.attributes,V=0,ie=I.getAttributes();for(let $ in ie)if(ie[$].location>=0){let te=U[$],Xe=z[$];if(Xe===void 0&&($==="instanceMatrix"&&L.instanceMatrix&&(Xe=L.instanceMatrix),$==="instanceColor"&&L.instanceColor&&(Xe=L.instanceColor)),te===void 0||te.attribute!==Xe||Xe&&te.data!==Xe.data)return!0;V++}return r.attributesNum!==V||r.index!==P}function p(L,F,I,P){let U={},z=F.attributes,V=0,ie=I.getAttributes();for(let $ in ie)if(ie[$].location>=0){let te=z[$];te===void 0&&($==="instanceMatrix"&&L.instanceMatrix&&(te=L.instanceMatrix),$==="instanceColor"&&L.instanceColor&&(te=L.instanceColor));let Xe={};Xe.attribute=te,te&&te.data&&(Xe.data=te.data),U[$]=Xe,V++}r.attributes=U,r.attributesNum=V,r.index=P}function _(){let L=r.newAttributes;for(let F=0,I=L.length;F<I;F++)L[F]=0}function g(L){m(L,0)}function m(L,F){let I=r.newAttributes,P=r.enabledAttributes,U=r.attributeDivisors;I[L]=1,P[L]===0&&(i.enableVertexAttribArray(L),P[L]=1),U[L]!==F&&(i.vertexAttribDivisor(L,F),U[L]=F)}function v(){let L=r.newAttributes,F=r.enabledAttributes;for(let I=0,P=F.length;I<P;I++)F[I]!==L[I]&&(i.disableVertexAttribArray(I),F[I]=0)}function E(L,F,I,P,U,z,V){V===!0?i.vertexAttribIPointer(L,F,I,U,z):i.vertexAttribPointer(L,F,I,P,U,z)}function y(L,F,I,P){_();let U=P.attributes,z=I.getAttributes(),V=F.defaultAttributeValues;for(let ie in z){let $=z[ie];if($.location>=0){let se=U[ie];if(se===void 0&&(ie==="instanceMatrix"&&L.instanceMatrix&&(se=L.instanceMatrix),ie==="instanceColor"&&L.instanceColor&&(se=L.instanceColor)),se!==void 0){let te=se.normalized,Xe=se.itemSize,Ue=e.get(se);if(Ue===void 0)continue;let Ge=Ue.buffer,He=Ue.type,rt=Ue.bytesPerElement,j=He===i.INT||He===i.UNSIGNED_INT||se.gpuType===Gl;if(se.isInterleavedBufferAttribute){let oe=se.data,Ee=oe.stride,ot=se.offset;if(oe.isInstancedInterleavedBuffer){for(let Ne=0;Ne<$.locationSize;Ne++)m($.location+Ne,oe.meshPerAttribute);L.isInstancedMesh!==!0&&P._maxInstanceCount===void 0&&(P._maxInstanceCount=oe.meshPerAttribute*oe.count)}else for(let Ne=0;Ne<$.locationSize;Ne++)g($.location+Ne);i.bindBuffer(i.ARRAY_BUFFER,Ge);for(let Ne=0;Ne<$.locationSize;Ne++)E($.location+Ne,Xe/$.locationSize,He,te,Ee*rt,(ot+Xe/$.locationSize*Ne)*rt,j)}else{if(se.isInstancedBufferAttribute){for(let oe=0;oe<$.locationSize;oe++)m($.location+oe,se.meshPerAttribute);L.isInstancedMesh!==!0&&P._maxInstanceCount===void 0&&(P._maxInstanceCount=se.meshPerAttribute*se.count)}else for(let oe=0;oe<$.locationSize;oe++)g($.location+oe);i.bindBuffer(i.ARRAY_BUFFER,Ge);for(let oe=0;oe<$.locationSize;oe++)E($.location+oe,Xe/$.locationSize,He,te,Xe*rt,Xe/$.locationSize*oe*rt,j)}}else if(V!==void 0){let te=V[ie];if(te!==void 0)switch(te.length){case 2:i.vertexAttrib2fv($.location,te);break;case 3:i.vertexAttrib3fv($.location,te);break;case 4:i.vertexAttrib4fv($.location,te);break;default:i.vertexAttrib1fv($.location,te)}}}}v()}function w(){S();for(let L in n){let F=n[L];for(let I in F){let P=F[I];for(let U in P){let z=P[U];for(let V in z)h(z[V].object),delete z[V];delete P[U]}}delete n[L]}}function M(L){if(n[L.id]===void 0)return;let F=n[L.id];for(let I in F){let P=F[I];for(let U in P){let z=P[U];for(let V in z)h(z[V].object),delete z[V];delete P[U]}}delete n[L.id]}function T(L){for(let F in n){let I=n[F];for(let P in I){let U=I[P];if(U[L.id]===void 0)continue;let z=U[L.id];for(let V in z)h(z[V].object),delete z[V];delete U[L.id]}}}function x(L){for(let F in n){let I=n[F],P=L.isInstancedMesh===!0?L.id:0,U=I[P];if(U!==void 0){for(let z in U){let V=U[z];for(let ie in V)h(V[ie].object),delete V[ie];delete U[z]}delete I[P],Object.keys(I).length===0&&delete n[F]}}}function S(){C(),o=!0,r!==s&&(r=s,c(r.object))}function C(){s.geometry=null,s.program=null,s.wireframe=!1}return{setup:a,reset:S,resetDefaultState:C,dispose:w,releaseStatesOfGeometry:M,releaseStatesOfObject:x,releaseStatesOfProgram:T,initAttributes:_,enableAttribute:g,disableUnusedAttributes:v}}function VM(i,e,t){let n;function s(l){n=l}function r(l,c){i.drawArrays(n,l,c),t.update(c,n,1)}function o(l,c,h){h!==0&&(i.drawArraysInstanced(n,l,c,h),t.update(c,n,h))}function a(l,c,h){if(h===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,l,0,c,0,h);let d=0;for(let f=0;f<h;f++)d+=c[f];t.update(d,n,1)}this.setMode=s,this.render=r,this.renderInstances=o,this.renderMultiDraw=a}function WM(i,e,t,n){let s;function r(){if(s!==void 0)return s;if(e.has("EXT_texture_filter_anisotropic")===!0){let T=e.get("EXT_texture_filter_anisotropic");s=i.getParameter(T.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else s=0;return s}function o(T){return!(T!==In&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(T){let x=T===yn&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(T!==Qn&&T!==kn&&!x&&n.convert(T)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE))}function l(T){if(T==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";T="mediump"}return T==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp",h=l(c);h!==c&&(be("WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);let u=t.logarithmicDepthBuffer===!0,d=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control");t.reversedDepthBuffer===!0&&d===!1&&be("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");let f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),p=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),_=i.getParameter(i.MAX_TEXTURE_SIZE),g=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),m=i.getParameter(i.MAX_VERTEX_ATTRIBS),v=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),E=i.getParameter(i.MAX_VARYING_VECTORS),y=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),w=i.getParameter(i.MAX_SAMPLES),M=i.getParameter(i.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:u,reversedDepthBuffer:d,maxTextures:f,maxVertexTextures:p,maxTextureSize:_,maxCubemapSize:g,maxAttributes:m,maxVertexUniforms:v,maxVaryings:E,maxFragmentUniforms:y,maxSamples:w,samples:M}}function XM(i){let e=this,t=null,n=0,s=!1,r=!1,o=new ii,a=new ht,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){let f=u.length!==0||d||n!==0||s;return s=d,n=u.length,f},this.beginShadows=function(){r=!0,h(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(u,d){t=h(u,d,0)},this.setState=function(u,d,f){let p=u.clippingPlanes,_=u.clipIntersection,g=u.clipShadows,m=i.get(u);if(!s||p===null||p.length===0||r&&!g)r?h(null):c();else{let v=r?0:n,E=v*4,y=m.clippingState||null;l.value=y,y=h(p,d,E,f);for(let w=0;w!==E;++w)y[w]=t[w];m.clippingState=y,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=v}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(u,d,f,p){let _=u!==null?u.length:0,g=null;if(_!==0){if(g=l.value,p!==!0||g===null){let m=f+_*4,v=d.matrixWorldInverse;a.getNormalMatrix(v),(g===null||g.length<m)&&(g=new Float32Array(m));for(let E=0,y=f;E!==_;++E,y+=4)o.copy(u[E]).applyMatrix4(v,a),o.normal.toArray(g,y),g[y+3]=o.constant}l.value=g,l.needsUpdate=!0}return e.numPlanes=_,e.numIntersection=0,g}}var la=4,YM=6,qM=20,ZM=256,Ac=new ji,Sg=new q,dp=null,fp=0,pp=0,mp=!1,JM=new A,Hr=new A,zr=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,s=100,r={}){let{size:o=256,position:a=JM}=r;dp=this._renderer.getRenderTarget(),fp=this._renderer.getActiveCubeFace(),pp=this._renderer.getActiveMipmapLevel(),mp=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);let l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(e,n,s,l,a),t>0&&this._blur(l,0,0,t),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Rg(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=wg(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(dp,fp,pp),this._renderer.xr.enabled=mp,e.scissorTest=!1,aa(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===ki||e.mapping===Ss?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),dp=this._renderer.getRenderTarget(),fp=this._renderer.getActiveCubeFace(),pp=this._renderer.getActiveMipmapLevel(),mp=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Xt,minFilter:Xt,generateMipmaps:!1,type:yn,format:In,colorSpace:vo,depthBuffer:!1},s=Tg(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Tg(e,t,n);let{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=KM(r)),this._blurMaterial=jM(r,e,t),this._ggxMaterial=$M(r,e,t)}return s}_compileMaterial(e){let t=new W(new ke,e);this._renderer.compile(t,Ac)}_sceneToCubeUV(e,t,n,s,r){let l=new on(90,1,t,n),c=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,f=u.toneMapping;u.getClearColor(Sg),u.toneMapping=Ti,u.autoClear=!1,u.state.buffers.depth.getReversed()&&(u.setRenderTarget(s),u.clearDepth(),u.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new W(new mi,new Qe({name:"PMREM.Background",side:Ln,depthWrite:!1,depthTest:!1})));let _=this._backgroundBox,g=_.material,m=!1,v=e.background;v?v.isColor&&(g.color.copy(v),e.background=null,m=!0):(g.color.copy(Sg),m=!0);for(let E=0;E<6;E++){let y=E%3;y===0?(l.up.set(0,c[E],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x+h[E],r.y,r.z)):y===1?(l.up.set(0,0,c[E]),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y+h[E],r.z)):(l.up.set(0,c[E],0),l.position.set(r.x,r.y,r.z),l.lookAt(r.x,r.y,r.z+h[E]));let w=this._cubeSize;aa(s,y*w,E>2?w:0,w,w),u.setRenderTarget(s),m&&u.render(_,l),u.render(e,l)}u.toneMapping=f,u.autoClear=d,e.background=v}_textureToCubeUV(e,t){let n=this._renderer,s=e.mapping===ki||e.mapping===Ss;s?(this._cubemapMaterial===null&&(this._cubemapMaterial=Rg()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=wg());let r=s?this._cubemapMaterial:this._equirectMaterial,o=this._lodMeshes[0];o.material=r;let a=r.uniforms;a.envMap.value=e;let l=this._cubeSize;aa(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(o,Ac)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;let s=this._lodMeshes.length;for(let r=1;r<s;r++)this._applyGGXFilter(e,r-1,r);t.autoClear=n}_applyGGXFilter(e,t,n){let s=this._renderer,r=this._pingPongRenderTarget,o=this._ggxMaterial,a=this._lodMeshes[n];a.material=o;let l=o.uniforms,c=n/(this._lodMeshes.length-1),h=t/(this._lodMeshes.length-1),u=Math.sqrt(c*c-h*h),d=c*1.25,f=u*d,{_lodMax:p}=this,_=this._sizeLods[n],g=3*_*(n>p-la?n-p+la:0),m=4*(this._cubeSize-_);l.envMap.value=e.texture,l.roughness.value=f,l.mipInt.value=p-t,aa(r,g,m,3*_,2*_),s.setRenderTarget(r),s.render(a,Ac),l.envMap.value=r.texture,l.roughness.value=0,l.mipInt.value=p-n,aa(e,g,m,3*_,2*_),s.setRenderTarget(e),s.render(a,Ac)}_blur(e,t,n,s){let r=this._pingPongRenderTarget,o=Math.min(s,Math.PI)/Math.SQRT2;this._blurPass(e,r,t,n,o),this._blurPass(r,e,n,n,o)}_blurPass(e,t,n,s,r){let o=this._renderer,a=this._blurMaterial,l=this._lodMeshes[s];l.material=a;let c=a.uniforms;c.envMap.value=e.texture,c.sigma.value=r,c.mipInt.value=this._lodMax-n;let h=this._sizeLods[s],u=3*h*(s>this._lodMax-la?s-this._lodMax+la:0),d=4*(this._cubeSize-h);aa(t,u,d,3*h,2*h),o.setRenderTarget(t),o.render(l,Ac)}};function KM(i){let e=[],t=[],n=i,s=i-la+1+YM;for(let r=0;r<s;r++){let o=Math.pow(2,n);e.push(o);let a=1/(o-2),l=-a,c=1+a,h=[l,l,c,l,c,c,l,l,c,c,l,c],u=6,d=6,f=3,p=new Float32Array(f*d*u),_=new Float32Array(f*d*u);for(let m=0;m<u;m++){let v=m%3*2/3-1,E=m>2?0:-1,y=[v,E,0,v+2/3,E,0,v+2/3,E+1,0,v,E,0,v+2/3,E+1,0,v,E+1,0];p.set(y,f*d*m);for(let w=0;w<d;w++){let M=h[w*2]*2-1,T=h[w*2+1]*2-1;m===0?Hr.set(1,T,M):m===1?Hr.set(-M,1,-T):m===2?Hr.set(-M,T,1):m===3?Hr.set(-1,T,-M):m===4?Hr.set(-M,-1,T):Hr.set(M,T,-1),Hr.toArray(_,(m*d+w)*f)}}let g=new ke;g.setAttribute("position",new bt(p,f)),g.setAttribute("outputDirection",new bt(_,f)),t.push(new W(g,null)),n>la&&n--}return{lodMeshes:t,sizeLods:e}}function Tg(i,e,t){let n=new Qt(i,e,t);return n.texture.mapping=Lr,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function aa(i,e,t,n,s){i.viewport.set(e,t,n,s),i.scissor.set(e,t,n,s)}function $M(i,e,t){return new xt({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:ZM,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:td(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:gi,depthTest:!1,depthWrite:!1})}function jM(i,e,t){return new xt({name:"SphericalGaussianBlur",defines:{SAMPLES:qM,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:td(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:gi,depthTest:!1,depthWrite:!1})}function wg(){return new xt({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:td(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:gi,depthTest:!1,depthWrite:!1})}function Rg(){return new xt({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:td(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:gi,depthTest:!1,depthWrite:!1})}function td(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}var Ic=class extends Qt{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},s=[n,n,n,n,n,n];this.texture=new Vs(s),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},s=new mi(5,5,5),r=new xt({name:"CubemapFromEquirect",uniforms:Or(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Ln,blending:gi});r.uniforms.tEquirect.value=t;let o=new W(s,r),a=t.minFilter;return t.minFilter===Gi&&(t.minFilter=Xt),new Nl(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t=!0,n=!0,s=!0){let r=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,s);e.setRenderTarget(r)}};function QM(i){let e=new WeakMap,t=new WeakMap,n=null;function s(d,f=!1){return d==null?null:f?o(d):r(d)}function r(d){if(d&&d.isTexture){let f=d.mapping;if(f===Ks||f===jo)if(e.has(d)){let p=e.get(d).texture;return a(p,d.mapping)}else{let p=d.image;if(p&&p.height>0){let _=new Ic(p.height);return _.fromEquirectangularTexture(i,d),e.set(d,_),d.addEventListener("dispose",c),a(_.texture,d.mapping)}else return null}}return d}function o(d){if(d&&d.isTexture){let f=d.mapping,p=f===Ks||f===jo,_=f===ki||f===Ss;if(p||_){let g=t.get(d),m=g!==void 0?g.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==m)return n===null&&(n=new zr(i)),g=p?n.fromEquirectangular(d,g):n.fromCubemap(d,g),g.texture.pmremVersion=d.pmremVersion,t.set(d,g),g.texture;if(g!==void 0)return g.texture;{let v=d.image;return p&&v&&v.height>0||_&&v&&l(v)?(n===null&&(n=new zr(i)),g=p?n.fromEquirectangular(d):n.fromCubemap(d),g.texture.pmremVersion=d.pmremVersion,t.set(d,g),d.addEventListener("dispose",h),g.texture):null}}}return d}function a(d,f){return f===Ks?d.mapping=ki:f===jo&&(d.mapping=Ss),d}function l(d){let f=0,p=6;for(let _=0;_<p;_++)d[_]!==void 0&&f++;return f===p}function c(d){let f=d.target;f.removeEventListener("dispose",c);let p=e.get(f);p!==void 0&&(e.delete(f),p.dispose())}function h(d){let f=d.target;f.removeEventListener("dispose",h);let p=t.get(f);p!==void 0&&(t.delete(f),p.dispose())}function u(){e=new WeakMap,t=new WeakMap,n!==null&&(n.dispose(),n=null)}return{get:s,dispose:u}}function eb(i){let e={};function t(n){if(e[n]!==void 0)return e[n];let s=i.getExtension(n);return e[n]=s,s}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){let s=t(n);return s===null&&qi("WebGLRenderer: "+n+" extension not supported."),s}}}function tb(i,e,t,n){let s={},r=new WeakMap;function o(u){let d=u.target;d.index!==null&&e.remove(d.index);for(let p in d.attributes)e.remove(d.attributes[p]);d.removeEventListener("dispose",o),delete s[d.id];let f=r.get(d);f&&(e.remove(f),r.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function a(u,d){return s[d.id]===!0||(d.addEventListener("dispose",o),s[d.id]=!0,t.memory.geometries++),d}function l(u){let d=u.attributes;for(let f in d)e.update(d[f],i.ARRAY_BUFFER)}function c(u){let d=[],f=u.index,p=u.attributes.position,_=0;if(p===void 0)return;if(f!==null){let v=f.array;_=f.version;for(let E=0,y=v.length;E<y;E+=3){let w=v[E+0],M=v[E+1],T=v[E+2];d.push(w,M,M,T,T,w)}}else{let v=p.array;_=p.version;for(let E=0,y=v.length/3-1;E<y;E+=3){let w=E+0,M=E+1,T=E+2;d.push(w,M,M,T,T,w)}}let g=new(p.count>=65535?To:So)(d,1);g.version=_;let m=r.get(u);m&&e.remove(m),r.set(u,g)}function h(u){let d=r.get(u);if(d){let f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return r.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function nb(i,e,t){let n;function s(u){n=u}let r,o;function a(u){r=u.type,o=u.bytesPerElement}function l(u,d){i.drawElements(n,d,r,u*o),t.update(d,n,1)}function c(u,d,f){f!==0&&(i.drawElementsInstanced(n,d,r,u*o,f),t.update(d,n,f))}function h(u,d,f){if(f===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,d,0,r,u,0,f);let _=0;for(let g=0;g<f;g++)_+=d[g];t.update(_,n,1)}this.setMode=s,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h}function ib(i){let e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(r,o,a){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=a*(r/3);break;case i.LINES:t.lines+=a*(r/2);break;case i.LINE_STRIP:t.lines+=a*(r-1);break;case i.LINE_LOOP:t.lines+=a*r;break;case i.POINTS:t.points+=a*r;break;default:qe("WebGLInfo: Unknown draw mode:",o);break}}function s(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:s,update:n}}function sb(i,e,t){let n=new WeakMap,s=new Ut;function r(o,a,l){let c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0,d=n.get(a);if(d===void 0||d.count!==u){let S=function(){T.dispose(),n.delete(a),a.removeEventListener("dispose",S)};d!==void 0&&d.texture.dispose();let f=a.morphAttributes.position!==void 0,p=a.morphAttributes.normal!==void 0,_=a.morphAttributes.color!==void 0,g=a.morphAttributes.position||[],m=a.morphAttributes.normal||[],v=a.morphAttributes.color||[],E=0;f===!0&&(E=1),p===!0&&(E=2),_===!0&&(E=3);let y=a.attributes.position.count*E,w=1;y>e.maxTextureSize&&(w=Math.ceil(y/e.maxTextureSize),y=e.maxTextureSize);let M=new Float32Array(y*w*4*u),T=new gr(M,y,w,u);T.type=kn,T.needsUpdate=!0;let x=E*4;for(let C=0;C<u;C++){let L=g[C],F=m[C],I=v[C],P=y*w*4*C;for(let U=0;U<L.count;U++){let z=U*x;f===!0&&(s.fromBufferAttribute(L,U),M[P+z+0]=s.x,M[P+z+1]=s.y,M[P+z+2]=s.z,M[P+z+3]=0),p===!0&&(s.fromBufferAttribute(F,U),M[P+z+4]=s.x,M[P+z+5]=s.y,M[P+z+6]=s.z,M[P+z+7]=0),_===!0&&(s.fromBufferAttribute(I,U),M[P+z+8]=s.x,M[P+z+9]=s.y,M[P+z+10]=s.z,M[P+z+11]=I.itemSize===4?s.w:1)}}d={count:u,texture:T,size:new J(y,w)},n.set(a,d),a.addEventListener("dispose",S)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",o.morphTexture,t);else{let f=0;for(let _=0;_<c.length;_++)f+=c[_];let p=a.morphTargetsRelative?1:1-f;l.getUniforms().setValue(i,"morphTargetBaseInfluence",p),l.getUniforms().setValue(i,"morphTargetInfluences",c)}l.getUniforms().setValue(i,"morphTargetsTexture",d.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",d.size)}return{update:r}}function rb(i,e,t,n,s){let r=new WeakMap;function o(c){let h=s.render.frame,u=c.geometry,d=e.get(c,u);if(r.get(d)!==h&&(e.update(d),r.set(d,h)),c.isInstancedMesh&&(c.hasEventListener("dispose",l)===!1&&c.addEventListener("dispose",l),r.get(c)!==h&&(t.update(c.instanceMatrix,i.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,i.ARRAY_BUFFER),r.set(c,h))),c.isSkinnedMesh){let f=c.skeleton;r.get(f)!==h&&(f.update(),r.set(f,h))}return d}function a(){r=new WeakMap}function l(c){let h=c.target;h.removeEventListener("dispose",l),n.releaseStatesOfObject(h),t.remove(h.instanceMatrix),h.instanceColor!==null&&t.remove(h.instanceColor)}return{update:o,dispose:a}}var ob={[Yo]:"LINEAR_TONE_MAPPING",[qo]:"REINHARD_TONE_MAPPING",[Zo]:"CINEON_TONE_MAPPING",[Jo]:"ACES_FILMIC_TONE_MAPPING",[$o]:"AGX_TONE_MAPPING",[Js]:"NEUTRAL_TONE_MAPPING",[Ko]:"CUSTOM_TONE_MAPPING"};function ab(i,e,t,n,s,r){let o=new Qt(e,t,{type:i,depthBuffer:s,stencilBuffer:r,samples:n?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1}),a=null,l=null,c=new ke;c.setAttribute("position",new _e([-1,3,0,-1,-1,0,3,-1,0],3)),c.setAttribute("uv",new _e([0,2,0,0,2,0],2));let h=new Ws({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new W(c,h),d=new ji(-1,1,1,-1,0,1),f=null,p=null,_=!1,g,m=null,v=[],E=!1;this.setSize=function(y,w){o.setSize(y,w),a!==null&&a.setSize(y,w),l!==null&&l.setSize(y,w);for(let M=0;M<v.length;M++){let T=v[M];T.setSize&&T.setSize(y,w)}},this.setEffects=function(y){v=y,E=v.length>0&&v[0].isRenderPass===!0;let w=o.width,M=o.height;v.length>0&&a===null&&(a=new Qt(w,M,{type:yn,depthBuffer:!1,stencilBuffer:!1}),l=new Qt(w,M,{type:yn,depthBuffer:!1,stencilBuffer:!1}));for(let T=0;T<v.length;T++){let x=v[T];x.setSize&&x.setSize(w,M)}},this.begin=function(y,w){if(_||y.toneMapping===Ti&&v.length===0)return!1;if(m=w,w!==null){let M=w.width,T=w.height;(o.width!==M||o.height!==T)&&this.setSize(M,T)}return E===!1&&y.setRenderTarget(o),g=y.toneMapping,y.toneMapping=Ti,!0},this.hasRenderPass=function(){return E},this.end=function(y,w){y.toneMapping=g,_=!0;let M=o,T=a;for(let x=0;x<v.length;x++){let S=v[x];S.enabled!==!1&&(S.render(y,T,M,w),S.needsSwap!==!1&&(M=T,T=T===a?l:a))}if(f!==y.outputColorSpace||p!==y.toneMapping){f=y.outputColorSpace,p=y.toneMapping,h.defines={},Mt.getTransfer(f)===Ct&&(h.defines.SRGB_TRANSFER="");let x=ob[p];x&&(h.defines[x]=""),h.needsUpdate=!0}h.uniforms.tDiffuse.value=M.texture,y.setRenderTarget(m),y.render(u,d),m=null,_=!1},this.isCompositing=function(){return _},this.dispose=function(){o.dispose(),a!==null&&a.dispose(),l!==null&&l.dispose(),c.dispose(),h.dispose()}}var qg=new an,xp=new gs(1,1),Zg=new gr,Jg=new _r,Kg=new Vs,Ag=[],Cg=[],Pg=new Float32Array(16),Ig=new Float32Array(9),Dg=new Float32Array(4);function ha(i,e,t){let n=i[0];if(n<=0||n>0)return i;let s=e*t,r=Ag[s];if(r===void 0&&(r=new Float32Array(s),Ag[s]=r),e!==0){n.toArray(r,0);for(let o=1,a=0;o!==e;++o)a+=t,i[o].toArray(r,a)}return r}function wn(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function Rn(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function nd(i,e){let t=Cg[e];t===void 0&&(t=new Int32Array(e),Cg[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function lb(i,e){let t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function cb(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wn(t,e))return;i.uniform2fv(this.addr,e),Rn(t,e)}}function hb(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(wn(t,e))return;i.uniform3fv(this.addr,e),Rn(t,e)}}function ub(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wn(t,e))return;i.uniform4fv(this.addr,e),Rn(t,e)}}function db(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(wn(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),Rn(t,e)}else{if(wn(t,n))return;Dg.set(n),i.uniformMatrix2fv(this.addr,!1,Dg),Rn(t,n)}}function fb(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(wn(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),Rn(t,e)}else{if(wn(t,n))return;Ig.set(n),i.uniformMatrix3fv(this.addr,!1,Ig),Rn(t,n)}}function pb(i,e){let t=this.cache,n=e.elements;if(n===void 0){if(wn(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),Rn(t,e)}else{if(wn(t,n))return;Pg.set(n),i.uniformMatrix4fv(this.addr,!1,Pg),Rn(t,n)}}function mb(i,e){let t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function gb(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wn(t,e))return;i.uniform2iv(this.addr,e),Rn(t,e)}}function _b(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(wn(t,e))return;i.uniform3iv(this.addr,e),Rn(t,e)}}function xb(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wn(t,e))return;i.uniform4iv(this.addr,e),Rn(t,e)}}function vb(i,e){let t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function yb(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wn(t,e))return;i.uniform2uiv(this.addr,e),Rn(t,e)}}function Mb(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(wn(t,e))return;i.uniform3uiv(this.addr,e),Rn(t,e)}}function bb(i,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wn(t,e))return;i.uniform4uiv(this.addr,e),Rn(t,e)}}function Eb(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s);let r;this.type===i.SAMPLER_2D_SHADOW?(xp.compareFunction=t.isReversedDepthBuffer()?wc:Tc,r=xp):r=qg,t.setTexture2D(e||r,s)}function Sb(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture3D(e||Jg,s)}function Tb(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTextureCube(e||Kg,s)}function wb(i,e,t){let n=this.cache,s=t.allocateTextureUnit();n[0]!==s&&(i.uniform1i(this.addr,s),n[0]=s),t.setTexture2DArray(e||Zg,s)}function Rb(i){switch(i){case 5126:return lb;case 35664:return cb;case 35665:return hb;case 35666:return ub;case 35674:return db;case 35675:return fb;case 35676:return pb;case 5124:case 35670:return mb;case 35667:case 35671:return gb;case 35668:case 35672:return _b;case 35669:case 35673:return xb;case 5125:return vb;case 36294:return yb;case 36295:return Mb;case 36296:return bb;case 35678:case 36198:case 36298:case 36306:case 35682:return Eb;case 35679:case 36299:case 36307:return Sb;case 35680:case 36300:case 36308:case 36293:return Tb;case 36289:case 36303:case 36311:case 36292:return wb}}function Ab(i,e){i.uniform1fv(this.addr,e)}function Cb(i,e){let t=ha(e,this.size,2);i.uniform2fv(this.addr,t)}function Pb(i,e){let t=ha(e,this.size,3);i.uniform3fv(this.addr,t)}function Ib(i,e){let t=ha(e,this.size,4);i.uniform4fv(this.addr,t)}function Db(i,e){let t=ha(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function Lb(i,e){let t=ha(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function Nb(i,e){let t=ha(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function Ub(i,e){i.uniform1iv(this.addr,e)}function Fb(i,e){i.uniform2iv(this.addr,e)}function Bb(i,e){i.uniform3iv(this.addr,e)}function Ob(i,e){i.uniform4iv(this.addr,e)}function Hb(i,e){i.uniform1uiv(this.addr,e)}function zb(i,e){i.uniform2uiv(this.addr,e)}function kb(i,e){i.uniform3uiv(this.addr,e)}function Gb(i,e){i.uniform4uiv(this.addr,e)}function Vb(i,e,t){let n=this.cache,s=e.length,r=nd(t,s);wn(n,r)||(i.uniform1iv(this.addr,r),Rn(n,r));let o;this.type===i.SAMPLER_2D_SHADOW?o=xp:o=qg;for(let a=0;a!==s;++a)t.setTexture2D(e[a]||o,r[a])}function Wb(i,e,t){let n=this.cache,s=e.length,r=nd(t,s);wn(n,r)||(i.uniform1iv(this.addr,r),Rn(n,r));for(let o=0;o!==s;++o)t.setTexture3D(e[o]||Jg,r[o])}function Xb(i,e,t){let n=this.cache,s=e.length,r=nd(t,s);wn(n,r)||(i.uniform1iv(this.addr,r),Rn(n,r));for(let o=0;o!==s;++o)t.setTextureCube(e[o]||Kg,r[o])}function Yb(i,e,t){let n=this.cache,s=e.length,r=nd(t,s);wn(n,r)||(i.uniform1iv(this.addr,r),Rn(n,r));for(let o=0;o!==s;++o)t.setTexture2DArray(e[o]||Zg,r[o])}function qb(i){switch(i){case 5126:return Ab;case 35664:return Cb;case 35665:return Pb;case 35666:return Ib;case 35674:return Db;case 35675:return Lb;case 35676:return Nb;case 5124:case 35670:return Ub;case 35667:case 35671:return Fb;case 35668:case 35672:return Bb;case 35669:case 35673:return Ob;case 5125:return Hb;case 36294:return zb;case 36295:return kb;case 36296:return Gb;case 35678:case 36198:case 36298:case 36306:case 35682:return Vb;case 35679:case 36299:case 36307:return Wb;case 35680:case 36300:case 36308:case 36293:return Xb;case 36289:case 36303:case 36311:case 36292:return Yb}}var vp=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=Rb(t.type)}},yp=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=qb(t.type)}},Mp=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let s=this.seq;for(let r=0,o=s.length;r!==o;++r){let a=s[r];a.setValue(e,t[a.id],n)}}},gp=/(\w+)(\])?(\[|\.)?/g;function Lg(i,e){i.seq.push(e),i.map[e.id]=e}function Zb(i,e,t){let n=i.name,s=n.length;for(gp.lastIndex=0;;){let r=gp.exec(n),o=gp.lastIndex,a=r[1],l=r[2]==="]",c=r[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===s){Lg(t,c===void 0?new vp(a,i,e):new yp(a,i,e));break}else{let u=t.map[a];u===void 0&&(u=new Mp(a),Lg(t,u)),t=u}}}var ca=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let o=0;o<n;++o){let a=e.getActiveUniform(t,o),l=e.getUniformLocation(t,a.name);Zb(a,l,this)}let s=[],r=[];for(let o of this.seq)o.type===e.SAMPLER_2D_SHADOW||o.type===e.SAMPLER_CUBE_SHADOW||o.type===e.SAMPLER_2D_ARRAY_SHADOW?s.push(o):r.push(o);s.length>0&&(this.seq=s.concat(r))}setValue(e,t,n,s){let r=this.map[t];r!==void 0&&r.setValue(e,n,s)}setOptional(e,t,n){let s=t[n];s!==void 0&&this.setValue(e,n,s)}static upload(e,t,n,s){for(let r=0,o=t.length;r!==o;++r){let a=t[r],l=n[a.id];l.needsUpdate!==!1&&a.setValue(e,l.value,s)}}static seqWithValue(e,t){let n=[];for(let s=0,r=e.length;s!==r;++s){let o=e[s];o.id in t&&n.push(o)}return n}};function Ng(i,e,t){let n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}var Jb=37297,Kb=0;function $b(i,e){let t=i.split(`
`),n=[],s=Math.max(e-6,0),r=Math.min(e+6,t.length);for(let o=s;o<r;o++){let a=o+1;n.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return n.join(`
`)}var Ug=new ht;function jb(i){Mt._getMatrix(Ug,Mt.workingColorSpace,i);let e=`mat3( ${Ug.elements.map(t=>t.toFixed(4))} )`;switch(Mt.getTransfer(i)){case yo:return[e,"LinearTransferOETF"];case Ct:return[e,"sRGBTransferOETF"];default:return be("WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function Fg(i,e,t){let n=i.getShaderParameter(e,i.COMPILE_STATUS),r=(i.getShaderInfoLog(e)||"").trim();if(n&&r==="")return"";let o=/ERROR: 0:(\d+)/.exec(r);if(o){let a=parseInt(o[1]);return t.toUpperCase()+`

`+r+`

`+$b(i.getShaderSource(e),a)}else return r}function Qb(i,e){let t=jb(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}var eE={[Yo]:"Linear",[qo]:"Reinhard",[Zo]:"Cineon",[Jo]:"ACESFilmic",[$o]:"AgX",[Js]:"Neutral",[Ko]:"Custom"};function tE(i,e){let t=eE[e];return t===void 0?(be("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+i+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}var ed=new A;function nE(){Mt.getLuminanceCoefficients(ed);let i=ed.x.toFixed(4),e=ed.y.toFixed(4),t=ed.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function iE(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Pc).join(`
`)}function sE(i){let e=[];for(let t in i){let n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function rE(i,e){let t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let s=0;s<n;s++){let r=i.getActiveAttrib(e,s),o=r.name,a=1;r.type===i.FLOAT_MAT2&&(a=2),r.type===i.FLOAT_MAT3&&(a=3),r.type===i.FLOAT_MAT4&&(a=4),t[o]={type:r.type,location:i.getAttribLocation(e,o),locationSize:a}}return t}function Pc(i){return i!==""}function Bg(i,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_SUN_LIGHTS/g,e.numSunLights).replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,e.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Og(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var oE=/^[ \t]*#include +<([\w\d./]+)>/gm;function bp(i){return i.replace(oE,lE)}var aE=new Map;function lE(i,e){let t=vt[e];if(t===void 0){let n=aE.get(e);if(n!==void 0)t=vt[n],be('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return bp(t)}var cE=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Hg(i){return i.replace(cE,hE)}function hE(i,e,t,n){let s="";for(let r=parseInt(e);r<parseInt(t);r++)s+=n.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return s}function zg(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}var uE={[Wo]:"SHADOWMAP_TYPE_PCF",[Dr]:"SHADOWMAP_TYPE_VSM"};function dE(i){return uE[i.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}var fE={[ki]:"ENVMAP_TYPE_CUBE",[Ss]:"ENVMAP_TYPE_CUBE",[Lr]:"ENVMAP_TYPE_CUBE_UV"};function pE(i){return i.envMap===!1?"ENVMAP_TYPE_CUBE":fE[i.envMapMode]||"ENVMAP_TYPE_CUBE"}var mE={[Ss]:"ENVMAP_MODE_REFRACTION"};function gE(i){return i.envMap===!1?"ENVMAP_MODE_REFLECTION":mE[i.envMapMode]||"ENVMAP_MODE_REFLECTION"}var _E={[Xo]:"ENVMAP_BLENDING_MULTIPLY",[Ff]:"ENVMAP_BLENDING_MIX",[Bf]:"ENVMAP_BLENDING_ADD"};function xE(i){return i.envMap===!1?"ENVMAP_BLENDING_NONE":_E[i.combine]||"ENVMAP_BLENDING_NONE"}function vE(i){let e=i.envMapCubeUVHeight;if(e===null)return null;let t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),7*16)),texelHeight:n,maxMip:t}}function yE(i,e,t,n){let s=i.getContext(),r=t.defines,o=t.vertexShader,a=t.fragmentShader,l=dE(t),c=pE(t),h=gE(t),u=xE(t),d=vE(t),f=iE(t),p=sE(r),_=s.createProgram(),g,m,v=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(g=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(Pc).join(`
`),g.length>0&&(g+=`
`),m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p].filter(Pc).join(`
`),m.length>0&&(m+=`
`)):(g=[zg(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Pc).join(`
`),m=[zg(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,p,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.retroreflection?"#define USE_RETROREFLECTION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ti?"#define TONE_MAPPING":"",t.toneMapping!==Ti?vt.tonemapping_pars_fragment:"",t.toneMapping!==Ti?tE("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",vt.colorspace_pars_fragment,Qb("linearToOutputTexel",t.outputColorSpace),nE(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Pc).join(`
`)),o=bp(o),o=Bg(o,t),o=Og(o,t),a=bp(a),a=Bg(a,t),a=Og(a,t),o=Hg(o),a=Hg(a),t.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+g,m=["#define varying in",t.glslVersion===$u?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===$u?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+m);let E=v+g+o,y=v+m+a,w=Ng(s,s.VERTEX_SHADER,E),M=Ng(s,s.FRAGMENT_SHADER,y);s.attachShader(_,w),s.attachShader(_,M),t.index0AttributeName!==void 0?s.bindAttribLocation(_,0,t.index0AttributeName):t.hasPositionAttribute===!0&&s.bindAttribLocation(_,0,"position"),s.linkProgram(_);function T(L){if(i.debug.checkShaderErrors){let F=s.getProgramInfoLog(_)||"",I=s.getShaderInfoLog(w)||"",P=s.getShaderInfoLog(M)||"",U=F.trim(),z=I.trim(),V=P.trim(),ie=!0,$=!0;if(s.getProgramParameter(_,s.LINK_STATUS)===!1)if(ie=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(s,_,w,M);else{let se=Fg(s,w,"vertex"),te=Fg(s,M,"fragment");qe("WebGLProgram: Shader Error "+s.getError()+" - VALIDATE_STATUS "+s.getProgramParameter(_,s.VALIDATE_STATUS)+`

Material Name: `+L.name+`
Material Type: `+L.type+`

Program Info Log: `+U+`
`+se+`
`+te)}else U!==""?be("WebGLProgram: Program Info Log:",U):(z===""||V==="")&&($=!1);$&&(L.diagnostics={runnable:ie,programLog:U,vertexShader:{log:z,prefix:g},fragmentShader:{log:V,prefix:m}})}s.deleteShader(w),s.deleteShader(M),x=new ca(s,_),S=rE(s,_)}let x;this.getUniforms=function(){return x===void 0&&T(this),x};let S;this.getAttributes=function(){return S===void 0&&T(this),S};let C=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return C===!1&&(C=s.getProgramParameter(_,Jb)),C},this.destroy=function(){n.releaseStatesOfProgram(this),s.deleteProgram(_),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Kb++,this.cacheKey=e,this.usedTimes=1,this.program=_,this.vertexShader=w,this.fragmentShader=M,this}var ME=0,Ep=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){let s=this._getShaderCacheForMaterial(e);return s.has(t)===!1&&(s.add(t),t.usedTimes++),s.has(n)===!1&&(s.add(n),n.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new Sp(e),t.set(e,n)),n}},Sp=class{constructor(e){this.id=ME++,this.code=e,this.usedTimes=0}};function bE(i){return i===ws||i===ra||i===oa}function EE(i,e,t,n,s,r){let o=new xr,a=new Ep,l=new Set,c=[],h=new Map,u=n.logarithmicDepthBuffer,d=n.precision,f={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function p(x){return l.add(x),x===0?"uv":`uv${x}`}function _(x,S,C,L,F,I){let P=L.fog,U=F.geometry,z=x.isMeshStandardMaterial||x.isMeshLambertMaterial||x.isMeshPhongMaterial?L.environment:null,V=x.isMeshStandardMaterial||x.isMeshLambertMaterial&&!x.envMap||x.isMeshPhongMaterial&&!x.envMap,ie=e.get(x.envMap||z,V),$=ie&&ie.mapping===Lr?ie.image.height:null,se=f[x.type];x.precision!==null&&(d=n.getMaxPrecision(x.precision),d!==x.precision&&be("WebGLProgram.getParameters:",x.precision,"not supported, using",d,"instead."));let te=U.morphAttributes.position||U.morphAttributes.normal||U.morphAttributes.color,Xe=te!==void 0?te.length:0,Ue=0;U.morphAttributes.position!==void 0&&(Ue=1),U.morphAttributes.normal!==void 0&&(Ue=2),U.morphAttributes.color!==void 0&&(Ue=3);let Ge,He,rt,j;if(se){let Gt=Vi[se];Ge=Gt.vertexShader,He=Gt.fragmentShader}else{Ge=x.vertexShader,He=x.fragmentShader;let Gt=a.getVertexShaderStage(x),Dt=a.getFragmentShaderStage(x);a.update(x,Gt,Dt),rt=Gt.id,j=Dt.id}let oe=i.getRenderTarget(),Ee=i.state.buffers.depth.getReversed(),ot=F.isInstancedMesh===!0,Ne=F.isBatchedMesh===!0,lt=!!x.map,Ft=!!x.matcap,le=!!ie,de=!!x.aoMap,fe=!!x.lightMap,pe=!!x.bumpMap&&x.wireframe===!1,Me=!!x.normalMap,it=!!x.displacementMap,tt=!!x.emissiveMap,ct=!!x.metalnessMap,ut=!!x.roughnessMap,B=x.anisotropy>0,It=x.clearcoat>0,St=x.dispersion>0,D=x.retroreflectivity>0,b=x.iridescence>0,G=x.sheen>0,Z=x.transmission>0,Q=B&&!!x.anisotropyMap,ge=It&&!!x.clearcoatMap,ye=It&&!!x.clearcoatNormalMap,ee=It&&!!x.clearcoatRoughnessMap,ae=b&&!!x.iridescenceMap,Se=b&&!!x.iridescenceThicknessMap,Je=G&&!!x.sheenColorMap,Ce=G&&!!x.sheenRoughnessMap,Te=!!x.specularMap,Ke=!!x.specularColorMap,st=!!x.specularIntensityMap,mt=Z&&!!x.transmissionMap,H=Z&&!!x.thicknessMap,we=!!x.gradientMap,re=!!x.alphaMap,Re=x.alphaTest>0,Le=!!x.alphaHash,ue=!!x.extensions,$e=Ti;x.toneMapped&&(oe===null||oe.isXRRenderTarget===!0)&&($e=i.toneMapping);let Ye={shaderID:se,shaderType:x.type,shaderName:x.name,vertexShader:Ge,fragmentShader:He,defines:x.defines,customVertexShaderID:rt,customFragmentShaderID:j,isRawShaderMaterial:x.isRawShaderMaterial===!0,glslVersion:x.glslVersion,precision:d,batching:Ne,batchingColor:Ne&&F._colorsTexture!==null,instancing:ot,instancingColor:ot&&F.instanceColor!==null,instancingMorph:ot&&F.morphTexture!==null,outputColorSpace:oe===null?i.outputColorSpace:oe.isXRRenderTarget===!0?oe.texture.colorSpace:Mt.workingColorSpace,alphaToCoverage:!!x.alphaToCoverage,map:lt,matcap:Ft,envMap:le,envMapMode:le&&ie.mapping,envMapCubeUVHeight:$,aoMap:de,lightMap:fe,bumpMap:pe,normalMap:Me,displacementMap:it,emissiveMap:tt,normalMapObjectSpace:Me&&x.normalMapType===Yf,normalMapTangentSpace:Me&&x.normalMapType===Qi,packedNormalMap:Me&&x.normalMapType===Qi&&bE(x.normalMap.format),metalnessMap:ct,roughnessMap:ut,anisotropy:B,anisotropyMap:Q,clearcoat:It,clearcoatMap:ge,clearcoatNormalMap:ye,clearcoatRoughnessMap:ee,dispersion:St,retroreflection:D,iridescence:b,iridescenceMap:ae,iridescenceThicknessMap:Se,sheen:G,sheenColorMap:Je,sheenRoughnessMap:Ce,specularMap:Te,specularColorMap:Ke,specularIntensityMap:st,transmission:Z,transmissionMap:mt,thicknessMap:H,gradientMap:we,opaque:x.transparent===!1&&x.blending===Vn&&x.alphaToCoverage===!1,alphaMap:re,alphaTest:Re,alphaHash:Le,combine:x.combine,mapUv:lt&&p(x.map.channel),aoMapUv:de&&p(x.aoMap.channel),lightMapUv:fe&&p(x.lightMap.channel),bumpMapUv:pe&&p(x.bumpMap.channel),normalMapUv:Me&&p(x.normalMap.channel),displacementMapUv:it&&p(x.displacementMap.channel),emissiveMapUv:tt&&p(x.emissiveMap.channel),metalnessMapUv:ct&&p(x.metalnessMap.channel),roughnessMapUv:ut&&p(x.roughnessMap.channel),anisotropyMapUv:Q&&p(x.anisotropyMap.channel),clearcoatMapUv:ge&&p(x.clearcoatMap.channel),clearcoatNormalMapUv:ye&&p(x.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ee&&p(x.clearcoatRoughnessMap.channel),iridescenceMapUv:ae&&p(x.iridescenceMap.channel),iridescenceThicknessMapUv:Se&&p(x.iridescenceThicknessMap.channel),sheenColorMapUv:Je&&p(x.sheenColorMap.channel),sheenRoughnessMapUv:Ce&&p(x.sheenRoughnessMap.channel),specularMapUv:Te&&p(x.specularMap.channel),specularColorMapUv:Ke&&p(x.specularColorMap.channel),specularIntensityMapUv:st&&p(x.specularIntensityMap.channel),transmissionMapUv:mt&&p(x.transmissionMap.channel),thicknessMapUv:H&&p(x.thicknessMap.channel),alphaMapUv:re&&p(x.alphaMap.channel),vertexTangents:!!U.attributes.tangent&&(Me||B),vertexNormals:!!U.attributes.normal,vertexColors:x.vertexColors,vertexAlphas:x.vertexColors===!0&&!!U.attributes.color&&U.attributes.color.itemSize===4,pointsUvs:F.isPoints===!0&&!!U.attributes.uv&&(lt||re),fog:!!P,useFog:x.fog===!0,fogExp2:!!P&&P.isFogExp2,flatShading:x.wireframe===!1&&(x.flatShading===!0||U.attributes.normal===void 0&&Me===!1&&(x.isMeshLambertMaterial||x.isMeshPhongMaterial||x.isMeshStandardMaterial||x.isMeshPhysicalMaterial)),sizeAttenuation:x.sizeAttenuation===!0,logarithmicDepthBuffer:u,reversedDepthBuffer:Ee,skinning:F.isSkinnedMesh===!0,hasPositionAttribute:U.attributes.position!==void 0,morphTargets:U.morphAttributes.position!==void 0,morphNormals:U.morphAttributes.normal!==void 0,morphColors:U.morphAttributes.color!==void 0,morphTargetsCount:Xe,morphTextureStride:Ue,numSunLights:S.sun.length,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numSunLightShadows:S.sunShadowMap.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numLightProbeGrids:I.length,numClippingPlanes:r.numPlanes,numClipIntersection:r.numIntersection,dithering:x.dithering,shadowMapEnabled:i.shadowMap.enabled&&C.length>0,shadowMapType:i.shadowMap.type,toneMapping:$e,decodeVideoTexture:lt&&x.map.isVideoTexture===!0&&Mt.getTransfer(x.map.colorSpace)===Ct,decodeVideoTextureEmissive:tt&&x.emissiveMap.isVideoTexture===!0&&Mt.getTransfer(x.emissiveMap.colorSpace)===Ct,premultipliedAlpha:x.premultipliedAlpha,doubleSided:x.side===De,flipSided:x.side===Ln,useDepthPacking:x.depthPacking>=0,depthPacking:x.depthPacking||0,index0AttributeName:x.index0AttributeName,extensionClipCullDistance:ue&&x.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(ue&&x.extensions.multiDraw===!0||Ne)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:x.customProgramCacheKey()};return Ye.vertexUv1s=l.has(1),Ye.vertexUv2s=l.has(2),Ye.vertexUv3s=l.has(3),l.clear(),Ye}function g(x){let S=[];if(x.shaderID?S.push(x.shaderID):(S.push(x.customVertexShaderID),S.push(x.customFragmentShaderID)),x.defines!==void 0)for(let C in x.defines)S.push(C),S.push(x.defines[C]);return x.isRawShaderMaterial===!1&&(m(S,x),v(S,x),S.push(i.outputColorSpace)),S.push(x.customProgramCacheKey),S.join()}function m(x,S){x.push(S.precision),x.push(S.outputColorSpace),x.push(S.envMapMode),x.push(S.envMapCubeUVHeight),x.push(S.mapUv),x.push(S.alphaMapUv),x.push(S.lightMapUv),x.push(S.aoMapUv),x.push(S.bumpMapUv),x.push(S.normalMapUv),x.push(S.displacementMapUv),x.push(S.emissiveMapUv),x.push(S.metalnessMapUv),x.push(S.roughnessMapUv),x.push(S.anisotropyMapUv),x.push(S.clearcoatMapUv),x.push(S.clearcoatNormalMapUv),x.push(S.clearcoatRoughnessMapUv),x.push(S.iridescenceMapUv),x.push(S.iridescenceThicknessMapUv),x.push(S.sheenColorMapUv),x.push(S.sheenRoughnessMapUv),x.push(S.specularMapUv),x.push(S.specularColorMapUv),x.push(S.specularIntensityMapUv),x.push(S.transmissionMapUv),x.push(S.thicknessMapUv),x.push(S.combine),x.push(S.fogExp2),x.push(S.sizeAttenuation),x.push(S.morphTargetsCount),x.push(S.morphAttributeCount),x.push(S.numSunLights),x.push(S.numDirLights),x.push(S.numPointLights),x.push(S.numSpotLights),x.push(S.numSpotLightMaps),x.push(S.numHemiLights),x.push(S.numRectAreaLights),x.push(S.numSunLightShadows),x.push(S.numDirLightShadows),x.push(S.numPointLightShadows),x.push(S.numSpotLightShadows),x.push(S.numSpotLightShadowsWithMaps),x.push(S.numLightProbes),x.push(S.shadowMapType),x.push(S.toneMapping),x.push(S.numClippingPlanes),x.push(S.numClipIntersection),x.push(S.depthPacking)}function v(x,S){o.disableAll(),S.instancing&&o.enable(0),S.instancingColor&&o.enable(1),S.instancingMorph&&o.enable(2),S.matcap&&o.enable(3),S.envMap&&o.enable(4),S.normalMapObjectSpace&&o.enable(5),S.normalMapTangentSpace&&o.enable(6),S.clearcoat&&o.enable(7),S.iridescence&&o.enable(8),S.alphaTest&&o.enable(9),S.vertexColors&&o.enable(10),S.vertexAlphas&&o.enable(11),S.vertexUv1s&&o.enable(12),S.vertexUv2s&&o.enable(13),S.vertexUv3s&&o.enable(14),S.vertexTangents&&o.enable(15),S.anisotropy&&o.enable(16),S.alphaHash&&o.enable(17),S.batching&&o.enable(18),S.dispersion&&o.enable(19),S.retroreflection&&o.enable(24),S.batchingColor&&o.enable(20),S.gradientMap&&o.enable(21),S.packedNormalMap&&o.enable(22),S.vertexNormals&&o.enable(23),x.push(o.mask),o.disableAll(),S.fog&&o.enable(0),S.useFog&&o.enable(1),S.flatShading&&o.enable(2),S.logarithmicDepthBuffer&&o.enable(3),S.reversedDepthBuffer&&o.enable(4),S.skinning&&o.enable(5),S.morphTargets&&o.enable(6),S.morphNormals&&o.enable(7),S.morphColors&&o.enable(8),S.premultipliedAlpha&&o.enable(9),S.shadowMapEnabled&&o.enable(10),S.doubleSided&&o.enable(11),S.flipSided&&o.enable(12),S.useDepthPacking&&o.enable(13),S.dithering&&o.enable(14),S.transmission&&o.enable(15),S.sheen&&o.enable(16),S.opaque&&o.enable(17),S.pointsUvs&&o.enable(18),S.decodeVideoTexture&&o.enable(19),S.decodeVideoTextureEmissive&&o.enable(20),S.alphaToCoverage&&o.enable(21),S.numLightProbeGrids>0&&o.enable(22),S.hasPositionAttribute&&o.enable(23),x.push(o.mask)}function E(x){let S=f[x.type],C;if(S){let L=Vi[S];C=wi.clone(L.uniforms)}else C=x.uniforms;return C}function y(x,S){let C=h.get(S);return C!==void 0?++C.usedTimes:(C=new yE(i,S,x,s),c.push(C),h.set(S,C)),C}function w(x){if(--x.usedTimes===0){let S=c.indexOf(x);c[S]=c[c.length-1],c.pop(),h.delete(x.cacheKey),x.destroy()}}function M(x){a.remove(x)}function T(){a.dispose()}return{getParameters:_,getProgramCacheKey:g,getUniforms:E,acquireProgram:y,releaseProgram:w,releaseShaderCache:M,programs:c,dispose:T}}function SE(){let i=new WeakMap;function e(o){return i.has(o)}function t(o){let a=i.get(o);return a===void 0&&(a={},i.set(o,a)),a}function n(o){i.delete(o)}function s(o,a,l){i.get(o)[a]=l}function r(){i=new WeakMap}return{has:e,get:t,remove:n,update:s,dispose:r}}function TE(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.materialVariant!==e.materialVariant?i.materialVariant-e.materialVariant:i.z!==e.z?i.z-e.z:i.id-e.id}function kg(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function Gg(){let i=[],e=0,t=[],n=[],s=[];function r(){e=0,t.length=0,n.length=0,s.length=0}function o(d){let f=0;return d.isInstancedMesh&&(f+=2),d.isSkinnedMesh&&(f+=1),f}function a(d,f,p,_,g,m){let v=i[e];return v===void 0?(v={id:d.id,object:d,geometry:f,material:p,materialVariant:o(d),groupOrder:_,renderOrder:d.renderOrder,z:g,group:m},i[e]=v):(v.id=d.id,v.object=d,v.geometry=f,v.material=p,v.materialVariant=o(d),v.groupOrder=_,v.renderOrder=d.renderOrder,v.z=g,v.group=m),e++,v}function l(d,f,p,_,g,m,v){v.reversedDepth===!0&&(g=-g);let E=a(d,f,p,_,g,m);p.transmission>0?n.push(E):p.transparent===!0?s.push(E):t.push(E)}function c(d,f,p,_,g,m){let v=a(d,f,p,_,g,m);p.transmission>0?n.unshift(v):p.transparent===!0?s.unshift(v):t.unshift(v)}function h(d,f){t.length>1&&t.sort(d||TE),n.length>1&&n.sort(f||kg),s.length>1&&s.sort(f||kg)}function u(){for(let d=e,f=i.length;d<f;d++){let p=i[d];if(p.id===null)break;p.id=null,p.object=null,p.geometry=null,p.material=null,p.group=null}}return{opaque:t,transmissive:n,transparent:s,init:r,push:l,unshift:c,finish:u,sort:h}}function wE(){let i=new WeakMap;function e(n,s){let r=i.get(n),o;return r===void 0?(o=new Gg,i.set(n,[o])):s>=r.length?(o=new Gg,r.push(o)):o=r[s],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function RE(){let i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={direction:new A,color:new q};break;case"SpotLight":t={position:new A,direction:new A,color:new q,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new A,color:new q,distance:0,decay:0};break;case"HemisphereLight":t={direction:new A,skyColor:new q,groundColor:new q};break;case"RectAreaLight":t={color:new q,position:new A,halfWidth:new A,halfHeight:new A};break}return i[e.id]=t,t}}}function AE(){let i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new J};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new J};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new J,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}var CE=0;function PE(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function IE(i){let e=new RE,t=AE(),n={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new A);let s=new A,r=new nt,o=new nt;function a(c){let h=0,u=0,d=0;for(let F=0;F<9;F++)n.probe[F].set(0,0,0);let f=0,p=0,_=0,g=0,m=0,v=0,E=0,y=0,w=0,M=0,T=0,x=0,S=0,C=0;c.sort(PE);for(let F=0,I=c.length;F<I;F++){let P=c[F],U=P.color,z=P.intensity,V=P.distance,ie=null;if(P.shadow&&P.shadow.map&&(P.shadow.map.texture.format===ws?ie=P.shadow.map.texture:ie=P.shadow.map.depthTexture||P.shadow.map.texture),P.isAmbientLight)h+=U.r*z,u+=U.g*z,d+=U.b*z;else if(P.isLightProbe){for(let $=0;$<9;$++)n.probe[$].addScaledVector(P.sh.coefficients[$],z);C++}else if(P.isSunLight){let $=e.get(P);if($.color.copy(P.color).multiplyScalar(P.intensity),P.castShadow){let se=P.shadow,te=t.get(P);te.shadowIntensity=se.intensity,te.shadowBias=se.bias,te.shadowNormalBias=se.normalBias,te.shadowRadius=se.radius,te.shadowMapSize.copy(se.mapSize).multiply(se.getFrameExtents()),n.sunShadow[p]=te,n.sunShadowMap[p]=ie;let Xe=se.getViewportCount();for(let Ue=0;Ue<Xe;Ue++)n.sunShadowMatrix[_+Ue]=se.getMatrix(Ue),n.sunShadowCascade[_+Ue]=se._cascadeData[Ue];_+=Xe,p++}n.sun[f]=$,f++}else if(P.isDirectionalLight){let $=e.get(P);if($.color.copy(P.color).multiplyScalar(P.intensity),P.castShadow){let se=P.shadow,te=t.get(P);te.shadowIntensity=se.intensity,te.shadowBias=se.bias,te.shadowNormalBias=se.normalBias,te.shadowRadius=se.radius,te.shadowMapSize=se.mapSize,n.directionalShadow[g]=te,n.directionalShadowMap[g]=ie,n.directionalShadowMatrix[g]=P.shadow.matrix,w++}n.directional[g]=$,g++}else if(P.isSpotLight){let $=e.get(P);$.position.setFromMatrixPosition(P.matrixWorld),$.color.copy(U).multiplyScalar(z),$.distance=V,$.coneCos=Math.cos(P.angle),$.penumbraCos=Math.cos(P.angle*(1-P.penumbra)),$.decay=P.decay,n.spot[v]=$;let se=P.shadow;if(P.map&&(n.spotLightMap[x]=P.map,x++,se.updateMatrices(P),P.castShadow&&S++),n.spotLightMatrix[v]=se.matrix,P.castShadow){let te=t.get(P);te.shadowIntensity=se.intensity,te.shadowBias=se.bias,te.shadowNormalBias=se.normalBias,te.shadowRadius=se.radius,te.shadowMapSize=se.mapSize,n.spotShadow[v]=te,n.spotShadowMap[v]=ie,T++}v++}else if(P.isRectAreaLight){let $=e.get(P);$.color.copy(U).multiplyScalar(z),$.halfWidth.set(P.width*.5,0,0),$.halfHeight.set(0,P.height*.5,0),n.rectArea[E]=$,E++}else if(P.isPointLight){let $=e.get(P);if($.color.copy(P.color).multiplyScalar(P.intensity),$.distance=P.distance,$.decay=P.decay,P.castShadow){let se=P.shadow,te=t.get(P);te.shadowIntensity=se.intensity,te.shadowBias=se.bias,te.shadowNormalBias=se.normalBias,te.shadowRadius=se.radius,te.shadowMapSize=se.mapSize,te.shadowCameraNear=se.camera.near,te.shadowCameraFar=se.camera.far,n.pointShadow[m]=te,n.pointShadowMap[m]=ie,n.pointShadowMatrix[m]=P.shadow.matrix,M++}n.point[m]=$,m++}else if(P.isHemisphereLight){let $=e.get(P);$.skyColor.copy(P.color).multiplyScalar(z),$.groundColor.copy(P.groundColor).multiplyScalar(z),n.hemi[y]=$,y++}}E>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=Ae.LTC_FLOAT_1,n.rectAreaLTC2=Ae.LTC_FLOAT_2):(n.rectAreaLTC1=Ae.LTC_HALF_1,n.rectAreaLTC2=Ae.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;let L=n.hash;(L.sunLength!==f||L.directionalLength!==g||L.pointLength!==m||L.spotLength!==v||L.rectAreaLength!==E||L.hemiLength!==y||L.numSunShadows!==p||L.numDirectionalShadows!==w||L.numPointShadows!==M||L.numSpotShadows!==T||L.numSpotMaps!==x||L.numLightProbes!==C)&&(n.sun.length=f,n.directional.length=g,n.spot.length=v,n.rectArea.length=E,n.point.length=m,n.hemi.length=y,n.sunShadow.length=p,n.sunShadowMap.length=p,n.sunShadowMatrix.length=_,n.sunShadowCascade.length=_,n.directionalShadow.length=w,n.directionalShadowMap.length=w,n.directionalShadowMatrix.length=w,n.pointShadow.length=M,n.pointShadowMap.length=M,n.pointShadowMatrix.length=M,n.spotShadow.length=T,n.spotShadowMap.length=T,n.spotLightMatrix.length=T+x-S,n.spotLightMap.length=x,n.numSpotLightShadowsWithMaps=S,n.numLightProbes=C,L.sunLength=f,L.directionalLength=g,L.pointLength=m,L.spotLength=v,L.rectAreaLength=E,L.hemiLength=y,L.numSunShadows=p,L.numDirectionalShadows=w,L.numPointShadows=M,L.numSpotShadows=T,L.numSpotMaps=x,L.numLightProbes=C,n.version=CE++)}function l(c,h){let u=0,d=0,f=0,p=0,_=0,g=0,m=h.matrixWorldInverse;for(let v=0,E=c.length;v<E;v++){let y=c[v];if(y.isSunLight){let w=n.sun[u];w.direction.setFromMatrixPosition(y.matrixWorld),w.direction.transformDirection(m),u++}else if(y.isDirectionalLight){let w=n.directional[d];w.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),w.direction.sub(s),w.direction.transformDirection(m),d++}else if(y.isSpotLight){let w=n.spot[p];w.position.setFromMatrixPosition(y.matrixWorld),w.position.applyMatrix4(m),w.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),w.direction.sub(s),w.direction.transformDirection(m),p++}else if(y.isRectAreaLight){let w=n.rectArea[_];w.position.setFromMatrixPosition(y.matrixWorld),w.position.applyMatrix4(m),o.identity(),r.copy(y.matrixWorld),r.premultiply(m),o.extractRotation(r),w.halfWidth.set(y.width*.5,0,0),w.halfHeight.set(0,y.height*.5,0),w.halfWidth.applyMatrix4(o),w.halfHeight.applyMatrix4(o),_++}else if(y.isPointLight){let w=n.point[f];w.position.setFromMatrixPosition(y.matrixWorld),w.position.applyMatrix4(m),f++}else if(y.isHemisphereLight){let w=n.hemi[g];w.direction.setFromMatrixPosition(y.matrixWorld),w.direction.transformDirection(m),g++}}}return{setup:a,setupView:l,state:n}}function Vg(i){let e=new IE(i),t=[],n=[],s=[];function r(d){u.camera=d,t.length=0,n.length=0,s.length=0}function o(d){t.push(d)}function a(d){n.push(d)}function l(d){s.push(d)}function c(){e.setup(t)}function h(d){e.setupView(t,d)}let u={lightsArray:t,shadowsArray:n,lightProbeGridArray:s,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:r,state:u,setupLights:c,setupLightsView:h,pushLight:o,pushShadow:a,pushLightProbeGrid:l}}function DE(i){let e=new WeakMap;function t(s,r=0){let o=e.get(s),a;return o===void 0?(a=new Vg(i),e.set(s,[a])):r>=o.length?(a=new Vg(i),o.push(a)):a=o[r],a}function n(){e=new WeakMap}return{get:t,dispose:n}}var LE=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,NE=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,UE=[new A(1,0,0),new A(-1,0,0),new A(0,1,0),new A(0,-1,0),new A(0,0,1),new A(0,0,-1)],FE=[new A(0,-1,0),new A(0,-1,0),new A(0,0,1),new A(0,0,-1),new A(0,-1,0),new A(0,-1,0)],Wg=new nt,Cc=new A,_p=new A;function BE(i,e,t){let n=new Ji,s=new J,r=new J,o=new Ut,a=new No,l=new Uo,c={},h=t.maxTextureSize,u={[zi]:Ln,[Ln]:zi,[De]:De},d=new xt({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new J},radius:{value:4}},vertexShader:LE,fragmentShader:NE}),f=d.clone();f.defines.HORIZONTAL_PASS=1;let p=new ke;p.setAttribute("position",new bt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let _=new W(p,d),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Wo;let m=this.type;this.render=function(M,T,x){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||M.length===0)return;this.type===_f&&(be("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=Wo);let S=i.getRenderTarget(),C=i.getActiveCubeFace(),L=i.getActiveMipmapLevel(),F=i.state;F.setBlending(gi),F.buffers.depth.getReversed()===!0?F.buffers.color.setClear(0,0,0,0):F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);let I=m!==this.type;I&&T.traverse(function(P){P.material&&(Array.isArray(P.material)?P.material.forEach(U=>U.needsUpdate=!0):P.material.needsUpdate=!0)});for(let P=0,U=M.length;P<U;P++){let z=M[P],V=z.shadow;if(V===void 0){be("WebGLShadowMap:",z,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;s.copy(V.mapSize);let ie=V.getFrameExtents();s.multiply(ie),r.copy(V.mapSize),(s.x>h||s.y>h)&&(s.x>h&&(r.x=Math.floor(h/ie.x),s.x=r.x*ie.x,V.mapSize.x=r.x),s.y>h&&(r.y=Math.floor(h/ie.y),s.y=r.y*ie.y,V.mapSize.y=r.y));let $=i.state.buffers.depth.getReversed();if(V.camera._reversedDepth=$,V.map===null||I===!0){if(V.map!==null&&(V.map.depthTexture!==null&&(V.map.depthTexture.dispose(),V.map.depthTexture=null),V.map.dispose()),this.type===Dr){if(z.isPointLight){be("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}V.map=new Qt(s.x,s.y,{format:ws,type:yn,minFilter:Xt,magFilter:Xt,generateMipmaps:!1}),V.map.texture.name=z.name+".shadowMap",V.map.depthTexture=new gs(s.x,s.y,kn),V.map.depthTexture.name=z.name+".shadowMapDepth",V.map.depthTexture.format=Ui,V.map.depthTexture.compareFunction=null,V.map.depthTexture.minFilter=jt,V.map.depthTexture.magFilter=jt}else z.isPointLight?(V.map=new Ic(s.x),V.map.depthTexture=new il(s.x,_i)):(V.map=new Qt(s.x,s.y),V.map.depthTexture=new gs(s.x,s.y,_i)),V.map.depthTexture.name=z.name+".shadowMap",V.map.depthTexture.format=Ui,this.type===Wo?(V.map.depthTexture.compareFunction=$?wc:Tc,V.map.depthTexture.minFilter=Xt,V.map.depthTexture.magFilter=Xt):(V.map.depthTexture.compareFunction=null,V.map.depthTexture.minFilter=jt,V.map.depthTexture.magFilter=jt);V.camera.updateProjectionMatrix()}V.map.isWebGLCubeRenderTarget!==!0&&(V.map.width!==s.x||V.map.height!==s.y)&&V.map.setSize(s.x,s.y);let se=V.map.isWebGLCubeRenderTarget?6:V.getViewportCount();z.isPointLight!==!0&&V.updateMatrices(z,x);for(let te=0;te<se;te++){let Xe=V.getCamera(te);if(z.isPointLight){let Ue=V.camera,Ge=V.matrix,He=z.distance||Ue.far;He!==Ue.far&&(Ue.far=He,Ue.updateProjectionMatrix()),Cc.setFromMatrixPosition(z.matrixWorld),Ue.position.copy(Cc),_p.copy(Ue.position),_p.add(UE[te]),Ue.up.copy(FE[te]),Ue.lookAt(_p),Ue.updateMatrixWorld(),Ge.makeTranslation(-Cc.x,-Cc.y,-Cc.z),Wg.multiplyMatrices(Ue.projectionMatrix,Ue.matrixWorldInverse),V._frustum.setFromProjectionMatrix(Wg,Ue.coordinateSystem,Ue.reversedDepth)}if(V.map.isWebGLCubeRenderTarget)i.setRenderTarget(V.map,te),i.clear();else{te===0&&(i.setRenderTarget(V.map),i.clear());let Ue=V.getViewport(te);o.set(r.x*Ue.x,r.y*Ue.y,r.x*Ue.z,r.y*Ue.w),F.viewport(o)}n=V.getFrustum(te),y(T,x,Xe,z,this.type)}V.isPointLightShadow!==!0&&this.type===Dr&&v(V,x),V.needsUpdate=!1}m=this.type,g.needsUpdate=!1,i.setRenderTarget(S,C,L)};function v(M,T){let x=e.update(_);d.defines.VSM_SAMPLES!==M.blurSamples&&(d.defines.VSM_SAMPLES=M.blurSamples,f.defines.VSM_SAMPLES=M.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),M.mapPass===null?M.mapPass=new Qt(s.x,s.y,{format:ws,type:yn}):(M.mapPass.width!==M.map.width||M.mapPass.height!==M.map.height)&&M.mapPass.setSize(M.map.width,M.map.height),d.uniforms.shadow_pass.value=M.map.depthTexture,d.uniforms.resolution.value.set(M.map.width,M.map.height),d.uniforms.radius.value=M.radius,i.setRenderTarget(M.mapPass),i.clear(),i.renderBufferDirect(T,null,x,d,_,null),f.uniforms.shadow_pass.value=M.mapPass.texture,f.uniforms.resolution.value.set(M.map.width,M.map.height),f.uniforms.radius.value=M.radius,i.setRenderTarget(M.map),i.clear(),i.renderBufferDirect(T,null,x,f,_,null)}function E(M,T,x,S){let C=null,L=x.isPointLight===!0?M.customDistanceMaterial:M.customDepthMaterial;if(L!==void 0)C=L;else if(C=x.isPointLight===!0?l:a,i.localClippingEnabled&&T.clipShadows===!0&&Array.isArray(T.clippingPlanes)&&T.clippingPlanes.length!==0||T.displacementMap&&T.displacementScale!==0||T.alphaMap&&T.alphaTest>0||T.map&&T.alphaTest>0||T.alphaToCoverage===!0){let F=C.uuid,I=T.uuid,P=c[F];P===void 0&&(P={},c[F]=P);let U=P[I];U===void 0&&(U=C.clone(),P[I]=U,T.addEventListener("dispose",w)),C=U}if(C.visible=T.visible,C.wireframe=T.wireframe,S===Dr?C.side=T.shadowSide!==null?T.shadowSide:T.side:C.side=T.shadowSide!==null?T.shadowSide:u[T.side],C.alphaMap=T.alphaMap,C.alphaTest=T.alphaToCoverage===!0?.5:T.alphaTest,C.map=T.map,C.clipShadows=T.clipShadows,C.clippingPlanes=T.clippingPlanes,C.clipIntersection=T.clipIntersection,C.displacementMap=T.displacementMap,C.displacementScale=T.displacementScale,C.displacementBias=T.displacementBias,C.wireframeLinewidth=T.wireframeLinewidth,C.linewidth=T.linewidth,x.isPointLight===!0&&C.isMeshDistanceMaterial===!0){let F=i.properties.get(C);F.light=x}return C}function y(M,T,x,S,C){if(M.visible===!1)return;if(M.layers.test(T.layers)&&(M.isMesh||M.isLine||M.isPoints)&&(M.castShadow||M.receiveShadow&&C===Dr)&&(!M.frustumCulled||M.intersectsFrustum(n))){M.modelViewMatrix.multiplyMatrices(x.matrixWorldInverse,M.matrixWorld);let I=e.update(M),P=M.material;if(Array.isArray(P)){let U=I.groups;for(let z=0,V=U.length;z<V;z++){let ie=U[z],$=P[ie.materialIndex];if($&&$.visible){let se=E(M,$,S,C);M.onBeforeShadow(i,M,T,x,I,se,ie),i.renderBufferDirect(x,null,I,se,M,ie),M.onAfterShadow(i,M,T,x,I,se,ie)}}}else if(P.visible){let U=E(M,P,S,C);M.onBeforeShadow(i,M,T,x,I,U,null),i.renderBufferDirect(x,null,I,U,M,null),M.onAfterShadow(i,M,T,x,I,U,null)}}let F=M.children;for(let I=0,P=F.length;I<P;I++)y(F[I],T,x,S,C)}function w(M){M.target.removeEventListener("dispose",w);for(let x in c){let S=c[x],C=M.target.uuid;C in S&&(S[C].dispose(),delete S[C])}}}function OE(i,e){function t(){let H=!1,we=new Ut,re=null,Re=new Ut(0,0,0,0);return{setMask:function(Le){re!==Le&&!H&&(i.colorMask(Le,Le,Le,Le),re=Le)},setLocked:function(Le){H=Le},setClear:function(Le,ue,$e,Ye,Gt){Gt===!0&&(Le*=Ye,ue*=Ye,$e*=Ye),we.set(Le,ue,$e,Ye),Re.equals(we)===!1&&(i.clearColor(Le,ue,$e,Ye),Re.copy(we))},reset:function(){H=!1,re=null,Re.set(-1,0,0,0)}}}function n(){let H=!1,we=!1,re=null,Re=null,Le=null;return{setReversed:function(ue){if(we!==ue){let $e=e.get("EXT_clip_control");ue?$e.clipControlEXT($e.LOWER_LEFT_EXT,$e.ZERO_TO_ONE_EXT):$e.clipControlEXT($e.LOWER_LEFT_EXT,$e.NEGATIVE_ONE_TO_ONE_EXT),we=ue;let Ye=Le;Le=null,this.setClear(Ye)}},getReversed:function(){return we},setTest:function(ue){ue?oe(i.DEPTH_TEST):Ee(i.DEPTH_TEST)},setMask:function(ue){re!==ue&&!H&&(i.depthMask(ue),re=ue)},setFunc:function(ue){if(we&&(ue=fg[ue]),Re!==ue){switch(ue){case Ha:i.depthFunc(i.NEVER);break;case za:i.depthFunc(i.ALWAYS);break;case ka:i.depthFunc(i.LESS);break;case pr:i.depthFunc(i.LEQUAL);break;case Ga:i.depthFunc(i.EQUAL);break;case Va:i.depthFunc(i.GEQUAL);break;case Wa:i.depthFunc(i.GREATER);break;case Xa:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}Re=ue}},setLocked:function(ue){H=ue},setClear:function(ue){Le!==ue&&(Le=ue,we&&(ue=1-ue),i.clearDepth(ue))},reset:function(){H=!1,re=null,Re=null,Le=null,we=!1}}}function s(){let H=!1,we=null,re=null,Re=null,Le=null,ue=null,$e=null,Ye=null,Gt=null;return{setTest:function(Dt){H||(Dt?oe(i.STENCIL_TEST):Ee(i.STENCIL_TEST))},setMask:function(Dt){we!==Dt&&!H&&(i.stencilMask(Dt),we=Dt)},setFunc:function(Dt,Ai,Wi){(re!==Dt||Re!==Ai||Le!==Wi)&&(i.stencilFunc(Dt,Ai,Wi),re=Dt,Re=Ai,Le=Wi)},setOp:function(Dt,Ai,Wi){(ue!==Dt||$e!==Ai||Ye!==Wi)&&(i.stencilOp(Dt,Ai,Wi),ue=Dt,$e=Ai,Ye=Wi)},setLocked:function(Dt){H=Dt},setClear:function(Dt){Gt!==Dt&&(i.clearStencil(Dt),Gt=Dt)},reset:function(){H=!1,we=null,re=null,Re=null,Le=null,ue=null,$e=null,Ye=null,Gt=null}}}let r=new t,o=new n,a=new s,l=new WeakMap,c=new WeakMap,h={},u={},d={},f=new WeakMap,p=[],_=null,g=!1,m=null,v=null,E=null,y=null,w=null,M=null,T=null,x=new q(0,0,0),S=0,C=!1,L=null,F=null,I=null,P=null,U=null,z=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS),V=!1,ie=0,$=i.getParameter(i.VERSION);$.indexOf("WebGL")!==-1?(ie=parseFloat(/^WebGL (\d)/.exec($)[1]),V=ie>=1):$.indexOf("OpenGL ES")!==-1&&(ie=parseFloat(/^OpenGL ES (\d)/.exec($)[1]),V=ie>=2);let se=null,te={},Xe=i.getParameter(i.SCISSOR_BOX),Ue=i.getParameter(i.VIEWPORT),Ge=new Ut().fromArray(Xe),He=new Ut().fromArray(Ue);function rt(H,we,re,Re){let Le=new Uint8Array(4),ue=i.createTexture();i.bindTexture(H,ue),i.texParameteri(H,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(H,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let $e=0;$e<re;$e++)H===i.TEXTURE_3D||H===i.TEXTURE_2D_ARRAY?i.texImage3D(we,0,i.RGBA,1,1,Re,0,i.RGBA,i.UNSIGNED_BYTE,Le):i.texImage2D(we+$e,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Le);return ue}let j={};j[i.TEXTURE_2D]=rt(i.TEXTURE_2D,i.TEXTURE_2D,1),j[i.TEXTURE_CUBE_MAP]=rt(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),j[i.TEXTURE_2D_ARRAY]=rt(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),j[i.TEXTURE_3D]=rt(i.TEXTURE_3D,i.TEXTURE_3D,1,1),r.setClear(0,0,0,1),o.setClear(1),a.setClear(0),oe(i.DEPTH_TEST),o.setFunc(pr),pe(!1),Me(Ou),oe(i.CULL_FACE),de(gi);function oe(H){h[H]!==!0&&(i.enable(H),h[H]=!0)}function Ee(H){h[H]!==!1&&(i.disable(H),h[H]=!1)}function ot(H,we){return d[H]!==we?(i.bindFramebuffer(H,we),d[H]=we,H===i.DRAW_FRAMEBUFFER&&(d[i.FRAMEBUFFER]=we),H===i.FRAMEBUFFER&&(d[i.DRAW_FRAMEBUFFER]=we),!0):!1}function Ne(H,we){let re=p,Re=!1;if(H){re=f.get(we),re===void 0&&(re=[],f.set(we,re));let Le=H.textures;if(re.length!==Le.length||re[0]!==i.COLOR_ATTACHMENT0){for(let ue=0,$e=Le.length;ue<$e;ue++)re[ue]=i.COLOR_ATTACHMENT0+ue;re.length=Le.length,Re=!0}}else re[0]!==i.BACK&&(re[0]=i.BACK,Re=!0);Re&&i.drawBuffers(re)}function lt(H){return _!==H?(i.useProgram(H),_=H,!0):!1}let Ft={[Zs]:i.FUNC_ADD,[vf]:i.FUNC_SUBTRACT,[yf]:i.FUNC_REVERSE_SUBTRACT};Ft[Mf]=i.MIN,Ft[bf]=i.MAX;let le={[Ef]:i.ZERO,[Sf]:i.ONE,[Tf]:i.SRC_COLOR,[ku]:i.SRC_ALPHA,[If]:i.SRC_ALPHA_SATURATE,[Cf]:i.DST_COLOR,[Rf]:i.DST_ALPHA,[wf]:i.ONE_MINUS_SRC_COLOR,[Gu]:i.ONE_MINUS_SRC_ALPHA,[Pf]:i.ONE_MINUS_DST_COLOR,[Af]:i.ONE_MINUS_DST_ALPHA,[Df]:i.CONSTANT_COLOR,[Lf]:i.ONE_MINUS_CONSTANT_COLOR,[Nf]:i.CONSTANT_ALPHA,[Uf]:i.ONE_MINUS_CONSTANT_ALPHA};function de(H,we,re,Re,Le,ue,$e,Ye,Gt,Dt){if(H===gi){g===!0&&(Ee(i.BLEND),g=!1);return}if(g===!1&&(oe(i.BLEND),g=!0),H!==xf){if(H!==m||Dt!==C){if((v!==Zs||w!==Zs)&&(i.blendEquation(i.FUNC_ADD),v=Zs,w=Zs),Dt)switch(H){case Vn:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case wt:i.blendFunc(i.ONE,i.ONE);break;case Hu:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case zu:i.blendFuncSeparate(i.DST_COLOR,i.ONE_MINUS_SRC_ALPHA,i.ZERO,i.ONE);break;default:qe("WebGLState: Invalid blending: ",H);break}else switch(H){case Vn:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case wt:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE,i.ONE,i.ONE);break;case Hu:qe("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case zu:qe("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:qe("WebGLState: Invalid blending: ",H);break}E=null,y=null,M=null,T=null,x.set(0,0,0),S=0,m=H,C=Dt}return}Le=Le||we,ue=ue||re,$e=$e||Re,(we!==v||Le!==w)&&(i.blendEquationSeparate(Ft[we],Ft[Le]),v=we,w=Le),(re!==E||Re!==y||ue!==M||$e!==T)&&(i.blendFuncSeparate(le[re],le[Re],le[ue],le[$e]),E=re,y=Re,M=ue,T=$e),(Ye.equals(x)===!1||Gt!==S)&&(i.blendColor(Ye.r,Ye.g,Ye.b,Gt),x.copy(Ye),S=Gt),m=H,C=!1}function fe(H,we){H.side===De?Ee(i.CULL_FACE):oe(i.CULL_FACE);let re=H.side===Ln;we&&(re=!re),pe(re),H.blending===Vn&&H.transparent===!1?de(gi):de(H.blending,H.blendEquation,H.blendSrc,H.blendDst,H.blendEquationAlpha,H.blendSrcAlpha,H.blendDstAlpha,H.blendColor,H.blendAlpha,H.premultipliedAlpha),o.setFunc(H.depthFunc),o.setTest(H.depthTest),o.setMask(H.depthWrite),r.setMask(H.colorWrite);let Re=H.stencilWrite;a.setTest(Re),Re&&(a.setMask(H.stencilWriteMask),a.setFunc(H.stencilFunc,H.stencilRef,H.stencilFuncMask),a.setOp(H.stencilFail,H.stencilZFail,H.stencilZPass)),tt(H.polygonOffset,H.polygonOffsetFactor,H.polygonOffsetUnits),H.alphaToCoverage===!0?oe(i.SAMPLE_ALPHA_TO_COVERAGE):Ee(i.SAMPLE_ALPHA_TO_COVERAGE)}function pe(H){L!==H&&(H?i.frontFace(i.CW):i.frontFace(i.CCW),L=H)}function Me(H){H!==mf?(oe(i.CULL_FACE),H!==F&&(H===Ou?i.cullFace(i.BACK):H===gf?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Ee(i.CULL_FACE),F=H}function it(H){H!==I&&(V&&i.lineWidth(H),I=H)}function tt(H,we,re){H?(oe(i.POLYGON_OFFSET_FILL),(P!==we||U!==re)&&(P=we,U=re,o.getReversed()&&(we=-we),i.polygonOffset(we,re))):Ee(i.POLYGON_OFFSET_FILL)}function ct(H){H?oe(i.SCISSOR_TEST):Ee(i.SCISSOR_TEST)}function ut(H){H===void 0&&(H=i.TEXTURE0+z-1),se!==H&&(i.activeTexture(H),se=H)}function B(H,we,re){re===void 0&&(se===null?re=i.TEXTURE0+z-1:re=se);let Re=te[re];Re===void 0&&(Re={type:void 0,texture:void 0},te[re]=Re),(Re.type!==H||Re.texture!==we)&&(se!==re&&(i.activeTexture(re),se=re),i.bindTexture(H,we||j[H]),Re.type=H,Re.texture=we)}function It(){let H=te[se];H!==void 0&&H.type!==void 0&&(i.bindTexture(H.type,null),H.type=void 0,H.texture=void 0)}function St(){try{i.compressedTexImage2D(...arguments)}catch(H){qe("WebGLState:",H)}}function D(){try{i.compressedTexImage3D(...arguments)}catch(H){qe("WebGLState:",H)}}function b(){try{i.texSubImage2D(...arguments)}catch(H){qe("WebGLState:",H)}}function G(){try{i.texSubImage3D(...arguments)}catch(H){qe("WebGLState:",H)}}function Z(){try{i.compressedTexSubImage2D(...arguments)}catch(H){qe("WebGLState:",H)}}function Q(){try{i.compressedTexSubImage3D(...arguments)}catch(H){qe("WebGLState:",H)}}function ge(){try{i.texStorage2D(...arguments)}catch(H){qe("WebGLState:",H)}}function ye(){try{i.texStorage3D(...arguments)}catch(H){qe("WebGLState:",H)}}function ee(){try{i.texImage2D(...arguments)}catch(H){qe("WebGLState:",H)}}function ae(){try{i.texImage3D(...arguments)}catch(H){qe("WebGLState:",H)}}function Se(H){return u[H]!==void 0?u[H]:i.getParameter(H)}function Je(H,we){u[H]!==we&&(i.pixelStorei(H,we),u[H]=we)}function Ce(H){Ge.equals(H)===!1&&(i.scissor(H.x,H.y,H.z,H.w),Ge.copy(H))}function Te(H){He.equals(H)===!1&&(i.viewport(H.x,H.y,H.z,H.w),He.copy(H))}function Ke(H,we){let re=c.get(we);re===void 0&&(re=new WeakMap,c.set(we,re));let Re=re.get(H);Re===void 0&&(Re=i.getUniformBlockIndex(we,H.name),re.set(H,Re))}function st(H,we){let Re=c.get(we).get(H);l.get(we)!==Re&&(i.uniformBlockBinding(we,Re,H.__bindingPointIndex),l.set(we,Re))}function mt(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),i.pixelStorei(i.PACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_ALIGNMENT,4),i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,!1),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,i.BROWSER_DEFAULT_WEBGL),i.pixelStorei(i.PACK_ROW_LENGTH,0),i.pixelStorei(i.PACK_SKIP_PIXELS,0),i.pixelStorei(i.PACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_ROW_LENGTH,0),i.pixelStorei(i.UNPACK_IMAGE_HEIGHT,0),i.pixelStorei(i.UNPACK_SKIP_PIXELS,0),i.pixelStorei(i.UNPACK_SKIP_ROWS,0),i.pixelStorei(i.UNPACK_SKIP_IMAGES,0),h={},u={},se=null,te={},d={},f=new WeakMap,p=[],_=null,g=!1,m=null,v=null,E=null,y=null,w=null,M=null,T=null,x=new q(0,0,0),S=0,C=!1,L=null,F=null,I=null,P=null,U=null,Ge.set(0,0,i.canvas.width,i.canvas.height),He.set(0,0,i.canvas.width,i.canvas.height),r.reset(),o.reset(),a.reset()}return{buffers:{color:r,depth:o,stencil:a},enable:oe,disable:Ee,bindFramebuffer:ot,drawBuffers:Ne,useProgram:lt,setBlending:de,setMaterial:fe,setFlipSided:pe,setCullFace:Me,setLineWidth:it,setPolygonOffset:tt,setScissorTest:ct,activeTexture:ut,bindTexture:B,unbindTexture:It,compressedTexImage2D:St,compressedTexImage3D:D,texImage2D:ee,texImage3D:ae,pixelStorei:Je,getParameter:Se,updateUBOMapping:Ke,uniformBlockBinding:st,texStorage2D:ge,texStorage3D:ye,texSubImage2D:b,texSubImage3D:G,compressedTexSubImage2D:Z,compressedTexSubImage3D:Q,scissor:Ce,viewport:Te,reset:mt}}function HE(i,e,t,n,s,r,o){let a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new J,h=new WeakMap,u=new Set,d,f=new WeakMap,p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function _(D,b){return p?new OffscreenCanvas(D,b):Mo("canvas")}function g(D,b,G){let Z=1,Q=St(D);if((Q.width>G||Q.height>G)&&(Z=G/Math.max(Q.width,Q.height)),Z<1)if(typeof HTMLImageElement<"u"&&D instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&D instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&D instanceof ImageBitmap||typeof VideoFrame<"u"&&D instanceof VideoFrame){let ge=Math.floor(Z*Q.width),ye=Math.floor(Z*Q.height);d===void 0&&(d=_(ge,ye));let ee=b?_(ge,ye):d;return ee.width=ge,ee.height=ye,ee.getContext("2d").drawImage(D,0,0,ge,ye),be("WebGLRenderer: Texture has been resized from ("+Q.width+"x"+Q.height+") to ("+ge+"x"+ye+")."),ee}else return"data"in D&&be("WebGLRenderer: Image in DataTexture is too big ("+Q.width+"x"+Q.height+")."),D;return D}function m(D){return D.generateMipmaps}function v(D){i.generateMipmap(D)}function E(D){return D.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:D.isWebGL3DRenderTarget?i.TEXTURE_3D:D.isWebGLArrayRenderTarget||D.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function y(D,b,G,Z,Q,ge=!1){if(D!==null){if(i[D]!==void 0)return i[D];be("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+D+"'")}let ye;Z&&(ye=e.get("EXT_texture_norm16"),ye||be("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let ee=b;if(b===i.RED&&(G===i.FLOAT&&(ee=i.R32F),G===i.HALF_FLOAT&&(ee=i.R16F),G===i.UNSIGNED_BYTE&&(ee=i.R8),G===i.UNSIGNED_SHORT&&ye&&(ee=ye.R16_EXT),G===i.SHORT&&ye&&(ee=ye.R16_SNORM_EXT)),b===i.RED_INTEGER&&(G===i.UNSIGNED_BYTE&&(ee=i.R8UI),G===i.UNSIGNED_SHORT&&(ee=i.R16UI),G===i.UNSIGNED_INT&&(ee=i.R32UI),G===i.BYTE&&(ee=i.R8I),G===i.SHORT&&(ee=i.R16I),G===i.INT&&(ee=i.R32I)),b===i.RG&&(G===i.FLOAT&&(ee=i.RG32F),G===i.HALF_FLOAT&&(ee=i.RG16F),G===i.UNSIGNED_BYTE&&(ee=i.RG8),G===i.UNSIGNED_SHORT&&ye&&(ee=ye.RG16_EXT),G===i.SHORT&&ye&&(ee=ye.RG16_SNORM_EXT)),b===i.RG_INTEGER&&(G===i.UNSIGNED_BYTE&&(ee=i.RG8UI),G===i.UNSIGNED_SHORT&&(ee=i.RG16UI),G===i.UNSIGNED_INT&&(ee=i.RG32UI),G===i.BYTE&&(ee=i.RG8I),G===i.SHORT&&(ee=i.RG16I),G===i.INT&&(ee=i.RG32I)),b===i.RGB_INTEGER&&(G===i.UNSIGNED_BYTE&&(ee=i.RGB8UI),G===i.UNSIGNED_SHORT&&(ee=i.RGB16UI),G===i.UNSIGNED_INT&&(ee=i.RGB32UI),G===i.BYTE&&(ee=i.RGB8I),G===i.SHORT&&(ee=i.RGB16I),G===i.INT&&(ee=i.RGB32I)),b===i.RGBA_INTEGER&&(G===i.UNSIGNED_BYTE&&(ee=i.RGBA8UI),G===i.UNSIGNED_SHORT&&(ee=i.RGBA16UI),G===i.UNSIGNED_INT&&(ee=i.RGBA32UI),G===i.BYTE&&(ee=i.RGBA8I),G===i.SHORT&&(ee=i.RGBA16I),G===i.INT&&(ee=i.RGBA32I)),b===i.RGB&&(G===i.UNSIGNED_SHORT&&ye&&(ee=ye.RGB16_EXT),G===i.SHORT&&ye&&(ee=ye.RGB16_SNORM_EXT),G===i.UNSIGNED_INT_5_9_9_9_REV&&(ee=i.RGB9_E5),G===i.UNSIGNED_INT_10F_11F_11F_REV&&(ee=i.R11F_G11F_B10F)),b===i.RGBA){let ae=ge?yo:Mt.getTransfer(Q);G===i.FLOAT&&(ee=i.RGBA32F),G===i.HALF_FLOAT&&(ee=i.RGBA16F),G===i.UNSIGNED_BYTE&&(ee=ae===Ct?i.SRGB8_ALPHA8:i.RGBA8),G===i.UNSIGNED_SHORT&&ye&&(ee=ye.RGBA16_EXT),G===i.SHORT&&ye&&(ee=ye.RGBA16_SNORM_EXT),G===i.UNSIGNED_SHORT_4_4_4_4&&(ee=i.RGBA4),G===i.UNSIGNED_SHORT_5_5_5_1&&(ee=i.RGB5_A1)}return(ee===i.R16F||ee===i.R32F||ee===i.RG16F||ee===i.RG32F||ee===i.RGBA16F||ee===i.RGBA32F)&&e.get("EXT_color_buffer_float"),ee}function w(D,b){let G;return D?b===null||b===_i||b===Fr?G=i.DEPTH24_STENCIL8:b===kn?G=i.DEPTH32F_STENCIL8:b===Ur&&(G=i.DEPTH24_STENCIL8,be("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):b===null||b===_i||b===Fr?G=i.DEPTH_COMPONENT24:b===kn?G=i.DEPTH_COMPONENT32F:b===Ur&&(G=i.DEPTH_COMPONENT16),G}function M(D,b){return m(D)===!0||D.isFramebufferTexture&&D.minFilter!==jt&&D.minFilter!==Xt?Math.log2(Math.max(b.width,b.height))+1:D.mipmaps!==void 0&&D.mipmaps.length>0?D.mipmaps.length:D.isCompressedTexture&&Array.isArray(D.image)?b.mipmaps.length:1}function T(D){let b=D.target;b.removeEventListener("dispose",T),S(b),b.isVideoTexture&&h.delete(b),b.isHTMLTexture&&u.delete(b)}function x(D){let b=D.target;b.removeEventListener("dispose",x),L(b)}function S(D){let b=n.get(D);if(b.__webglInit===void 0)return;let G=D.source,Z=f.get(G);if(Z){let Q=Z[b.__cacheKey];Q.usedTimes--,Q.usedTimes===0&&C(D),Object.keys(Z).length===0&&f.delete(G)}n.remove(D)}function C(D){let b=n.get(D);i.deleteTexture(b.__webglTexture);let G=D.source,Z=f.get(G);delete Z[b.__cacheKey],o.memory.textures--}function L(D){let b=n.get(D);if(D.depthTexture&&(D.depthTexture.dispose(),n.remove(D.depthTexture)),D.isWebGLCubeRenderTarget)for(let Z=0;Z<6;Z++){if(Array.isArray(b.__webglFramebuffer[Z]))for(let Q=0;Q<b.__webglFramebuffer[Z].length;Q++)i.deleteFramebuffer(b.__webglFramebuffer[Z][Q]);else i.deleteFramebuffer(b.__webglFramebuffer[Z]);b.__webglDepthbuffer&&i.deleteRenderbuffer(b.__webglDepthbuffer[Z])}else{if(Array.isArray(b.__webglFramebuffer))for(let Z=0;Z<b.__webglFramebuffer.length;Z++)i.deleteFramebuffer(b.__webglFramebuffer[Z]);else i.deleteFramebuffer(b.__webglFramebuffer);if(b.__webglDepthbuffer&&i.deleteRenderbuffer(b.__webglDepthbuffer),b.__webglMultisampledFramebuffer&&i.deleteFramebuffer(b.__webglMultisampledFramebuffer),b.__webglColorRenderbuffer)for(let Z=0;Z<b.__webglColorRenderbuffer.length;Z++)b.__webglColorRenderbuffer[Z]&&i.deleteRenderbuffer(b.__webglColorRenderbuffer[Z]);b.__webglDepthRenderbuffer&&i.deleteRenderbuffer(b.__webglDepthRenderbuffer)}let G=D.textures;for(let Z=0,Q=G.length;Z<Q;Z++){let ge=n.get(G[Z]);ge.__webglTexture&&(i.deleteTexture(ge.__webglTexture),o.memory.textures--),n.remove(G[Z])}n.remove(D)}let F=0;function I(){F=0}function P(){return F}function U(D){F=D}function z(){let D=F;return D>=s.maxTextures&&be("WebGLTextures: Trying to use "+(D+1)+" texture units while this GPU supports only "+s.maxTextures),F+=1,D}function V(D){let b=[];return b.push(D.wrapS),b.push(D.wrapT),b.push(D.wrapR||0),b.push(D.magFilter),b.push(D.minFilter),b.push(D.anisotropy),b.push(D.internalFormat),b.push(D.format),b.push(D.type),b.push(D.generateMipmaps),b.push(D.premultiplyAlpha),b.push(D.flipY),b.push(D.unpackAlignment),b.push(D.colorSpace),b.join()}function ie(D,b){let G=n.get(D);if(D.isVideoTexture&&B(D),D.isRenderTargetTexture===!1&&D.isExternalTexture!==!0&&D.version>0&&G.__version!==D.version){let Z=D.image;if(Z===null)be("WebGLRenderer: Texture marked for update but no image data found.");else if(Z.complete===!1)be("WebGLRenderer: Texture marked for update but image is incomplete");else{Ee(G,D,b);return}}else D.isExternalTexture&&(G.__webglTexture=D.sourceTexture?D.sourceTexture:null);t.bindTexture(i.TEXTURE_2D,G.__webglTexture,i.TEXTURE0+b)}function $(D,b){let G=n.get(D);if(D.isRenderTargetTexture===!1&&D.version>0&&G.__version!==D.version){Ee(G,D,b);return}else D.isExternalTexture&&(G.__webglTexture=D.sourceTexture?D.sourceTexture:null);t.bindTexture(i.TEXTURE_2D_ARRAY,G.__webglTexture,i.TEXTURE0+b)}function se(D,b){let G=n.get(D);if(D.isRenderTargetTexture===!1&&D.version>0&&G.__version!==D.version){Ee(G,D,b);return}t.bindTexture(i.TEXTURE_3D,G.__webglTexture,i.TEXTURE0+b)}function te(D,b){let G=n.get(D);if(D.isCubeDepthTexture!==!0&&D.version>0&&G.__version!==D.version){ot(G,D,b);return}t.bindTexture(i.TEXTURE_CUBE_MAP,G.__webglTexture,i.TEXTURE0+b)}let Xe={[Hs]:i.REPEAT,[$n]:i.CLAMP_TO_EDGE,[go]:i.MIRRORED_REPEAT},Ue={[jt]:i.NEAREST,[Vu]:i.NEAREST_MIPMAP_NEAREST,[Nr]:i.NEAREST_MIPMAP_LINEAR,[Xt]:i.LINEAR,[Qo]:i.LINEAR_MIPMAP_NEAREST,[Gi]:i.LINEAR_MIPMAP_LINEAR},Ge={[Zf]:i.NEVER,[Qf]:i.ALWAYS,[Jf]:i.LESS,[Tc]:i.LEQUAL,[Kf]:i.EQUAL,[wc]:i.GEQUAL,[$f]:i.GREATER,[jf]:i.NOTEQUAL};function He(D,b){if(b.type===kn&&e.has("OES_texture_float_linear")===!1&&(b.magFilter===Xt||b.magFilter===Qo||b.magFilter===Nr||b.magFilter===Gi||b.minFilter===Xt||b.minFilter===Qo||b.minFilter===Nr||b.minFilter===Gi)&&be("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(D,i.TEXTURE_WRAP_S,Xe[b.wrapS]),i.texParameteri(D,i.TEXTURE_WRAP_T,Xe[b.wrapT]),(D===i.TEXTURE_3D||D===i.TEXTURE_2D_ARRAY)&&i.texParameteri(D,i.TEXTURE_WRAP_R,Xe[b.wrapR]),i.texParameteri(D,i.TEXTURE_MAG_FILTER,Ue[b.magFilter]),i.texParameteri(D,i.TEXTURE_MIN_FILTER,Ue[b.minFilter]),b.compareFunction&&(i.texParameteri(D,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(D,i.TEXTURE_COMPARE_FUNC,Ge[b.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(b.magFilter===jt||b.minFilter!==Nr&&b.minFilter!==Gi||b.type===kn&&e.has("OES_texture_float_linear")===!1)return;if(b.anisotropy>1||n.get(b).__currentAnisotropy){let G=e.get("EXT_texture_filter_anisotropic");i.texParameterf(D,G.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,s.getMaxAnisotropy())),n.get(b).__currentAnisotropy=b.anisotropy}}}function rt(D,b){let G=!1;D.__webglInit===void 0&&(D.__webglInit=!0,b.addEventListener("dispose",T));let Z=b.source,Q=f.get(Z);Q===void 0&&(Q={},f.set(Z,Q));let ge=V(b);if(ge!==D.__cacheKey){Q[ge]===void 0&&(Q[ge]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,G=!0),Q[ge].usedTimes++;let ye=Q[D.__cacheKey];ye!==void 0&&(Q[D.__cacheKey].usedTimes--,ye.usedTimes===0&&C(b)),D.__cacheKey=ge,D.__webglTexture=Q[ge].texture}return G}function j(D,b,G){return Math.floor(Math.floor(D/G)/b)}function oe(D,b,G,Z){let ge=D.updateRanges;if(ge.length===0)t.texSubImage2D(i.TEXTURE_2D,0,0,0,b.width,b.height,G,Z,b.data);else{ge.sort((Je,Ce)=>Je.start-Ce.start);let ye=0;for(let Je=1;Je<ge.length;Je++){let Ce=ge[ye],Te=ge[Je],Ke=Ce.start+Ce.count,st=j(Te.start,b.width,4),mt=j(Ce.start,b.width,4);Te.start<=Ke+1&&st===mt&&j(Te.start+Te.count-1,b.width,4)===st?Ce.count=Math.max(Ce.count,Te.start+Te.count-Ce.start):(++ye,ge[ye]=Te)}ge.length=ye+1;let ee=t.getParameter(i.UNPACK_ROW_LENGTH),ae=t.getParameter(i.UNPACK_SKIP_PIXELS),Se=t.getParameter(i.UNPACK_SKIP_ROWS);t.pixelStorei(i.UNPACK_ROW_LENGTH,b.width);for(let Je=0,Ce=ge.length;Je<Ce;Je++){let Te=ge[Je],Ke=Math.floor(Te.start/4),st=Math.ceil(Te.count/4),mt=Ke%b.width,H=Math.floor(Ke/b.width),we=st,re=1;t.pixelStorei(i.UNPACK_SKIP_PIXELS,mt),t.pixelStorei(i.UNPACK_SKIP_ROWS,H),t.texSubImage2D(i.TEXTURE_2D,0,mt,H,we,re,G,Z,b.data)}D.clearUpdateRanges(),t.pixelStorei(i.UNPACK_ROW_LENGTH,ee),t.pixelStorei(i.UNPACK_SKIP_PIXELS,ae),t.pixelStorei(i.UNPACK_SKIP_ROWS,Se)}}function Ee(D,b,G){let Z=i.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(Z=i.TEXTURE_2D_ARRAY),b.isData3DTexture&&(Z=i.TEXTURE_3D);let Q=rt(D,b),ge=b.source;t.bindTexture(Z,D.__webglTexture,i.TEXTURE0+G);let ye=n.get(ge);if(ge.version!==ye.__version||Q===!0){if(t.activeTexture(i.TEXTURE0+G),(typeof ImageBitmap<"u"&&b.image instanceof ImageBitmap)===!1){let re=Mt.getPrimaries(Mt.workingColorSpace),Re=b.colorSpace===es?null:Mt.getPrimaries(b.colorSpace),Le=b.colorSpace===es||re===Re?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,Le)}t.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment);let ae=g(b.image,!1,s.maxTextureSize);ae=It(b,ae);let Se=r.convert(b.format,b.colorSpace),Je=r.convert(b.type),Ce=y(b.internalFormat,Se,Je,b.normalized,b.colorSpace,b.isVideoTexture);He(Z,b);let Te,Ke=b.mipmaps,st=b.isVideoTexture!==!0,mt=ye.__version===void 0||Q===!0,H=ge.dataReady,we=M(b,ae);if(b.isDepthTexture)Ce=w(b.format===Ts,b.type),mt&&(st?t.texStorage2D(i.TEXTURE_2D,1,Ce,ae.width,ae.height):t.texImage2D(i.TEXTURE_2D,0,Ce,ae.width,ae.height,0,Se,Je,null));else if(b.isDataTexture)if(Ke.length>0){st&&mt&&t.texStorage2D(i.TEXTURE_2D,we,Ce,Ke[0].width,Ke[0].height);for(let re=0,Re=Ke.length;re<Re;re++)Te=Ke[re],st?H&&t.texSubImage2D(i.TEXTURE_2D,re,0,0,Te.width,Te.height,Se,Je,Te.data):t.texImage2D(i.TEXTURE_2D,re,Ce,Te.width,Te.height,0,Se,Je,Te.data);b.generateMipmaps=!1}else st?(mt&&t.texStorage2D(i.TEXTURE_2D,we,Ce,ae.width,ae.height),H&&oe(b,ae,Se,Je)):t.texImage2D(i.TEXTURE_2D,0,Ce,ae.width,ae.height,0,Se,Je,ae.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){st&&mt&&t.texStorage3D(i.TEXTURE_2D_ARRAY,we,Ce,Ke[0].width,Ke[0].height,ae.depth);for(let re=0,Re=Ke.length;re<Re;re++)if(Te=Ke[re],b.format!==In)if(Se!==null)if(st){if(H)if(b.layerUpdates.size>0){let Le=ju(Te.width,Te.height,b.format,b.type);for(let ue of b.layerUpdates){let $e=Te.data.subarray(ue*Le/Te.data.BYTES_PER_ELEMENT,(ue+1)*Le/Te.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,re,0,0,ue,Te.width,Te.height,1,Se,$e)}}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,re,0,0,0,Te.width,Te.height,ae.depth,Se,Te.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,re,Ce,Te.width,Te.height,ae.depth,0,Te.data,0,0);else be("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else st?H&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,re,0,0,0,Te.width,Te.height,ae.depth,Se,Je,Te.data):t.texImage3D(i.TEXTURE_2D_ARRAY,re,Ce,Te.width,Te.height,ae.depth,0,Se,Je,Te.data);b.layerUpdates.size>0&&b.clearLayerUpdates()}else{st&&mt&&t.texStorage2D(i.TEXTURE_2D,we,Ce,Ke[0].width,Ke[0].height);for(let re=0,Re=Ke.length;re<Re;re++)Te=Ke[re],b.format!==In?Se!==null?st?H&&t.compressedTexSubImage2D(i.TEXTURE_2D,re,0,0,Te.width,Te.height,Se,Te.data):t.compressedTexImage2D(i.TEXTURE_2D,re,Ce,Te.width,Te.height,0,Te.data):be("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):st?H&&t.texSubImage2D(i.TEXTURE_2D,re,0,0,Te.width,Te.height,Se,Je,Te.data):t.texImage2D(i.TEXTURE_2D,re,Ce,Te.width,Te.height,0,Se,Je,Te.data)}else if(b.isDataArrayTexture)if(st){if(mt&&t.texStorage3D(i.TEXTURE_2D_ARRAY,we,Ce,ae.width,ae.height,ae.depth),H)if(b.layerUpdates.size>0){let re=ju(ae.width,ae.height,b.format,b.type);for(let Re of b.layerUpdates){let Le=ae.data.subarray(Re*re/ae.data.BYTES_PER_ELEMENT,(Re+1)*re/ae.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,Re,ae.width,ae.height,1,Se,Je,Le)}b.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,ae.width,ae.height,ae.depth,Se,Je,ae.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Ce,ae.width,ae.height,ae.depth,0,Se,Je,ae.data);else if(b.isData3DTexture)st?(mt&&t.texStorage3D(i.TEXTURE_3D,we,Ce,ae.width,ae.height,ae.depth),H&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,ae.width,ae.height,ae.depth,Se,Je,ae.data)):t.texImage3D(i.TEXTURE_3D,0,Ce,ae.width,ae.height,ae.depth,0,Se,Je,ae.data);else if(b.isFramebufferTexture){if(mt)if(st)t.texStorage2D(i.TEXTURE_2D,we,Ce,ae.width,ae.height);else{let re=ae.width,Re=ae.height;for(let Le=0;Le<we;Le++)t.texImage2D(i.TEXTURE_2D,Le,Ce,re,Re,0,Se,Je,null),re>>=1,Re>>=1}}else if(b.isHTMLTexture){if("texElementImage2D"in i){let re=i.canvas;if(re.hasAttribute("layoutsubtree")||re.setAttribute("layoutsubtree","true"),ae.parentNode!==re){re.appendChild(ae),u.add(b),re.onpaint=Re=>{let Le=Re.changedElements;for(let ue of u)Le.includes(ue.image)&&(ue.needsUpdate=!0)},re.requestPaint();return}if(i.texElementImage2D.length===3)i.texElementImage2D(i.TEXTURE_2D,i.RGBA8,ae);else{let Le=i.RGBA,ue=i.RGBA,$e=i.UNSIGNED_BYTE;i.texElementImage2D(i.TEXTURE_2D,0,Le,ue,$e,ae)}i.texParameteri(i.TEXTURE_2D,i.TEXTURE_MIN_FILTER,i.LINEAR),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_S,i.CLAMP_TO_EDGE),i.texParameteri(i.TEXTURE_2D,i.TEXTURE_WRAP_T,i.CLAMP_TO_EDGE)}}else if(Ke.length>0){if(st&&mt){let re=St(Ke[0]);t.texStorage2D(i.TEXTURE_2D,we,Ce,re.width,re.height)}for(let re=0,Re=Ke.length;re<Re;re++)Te=Ke[re],st?H&&t.texSubImage2D(i.TEXTURE_2D,re,0,0,Se,Je,Te):t.texImage2D(i.TEXTURE_2D,re,Ce,Se,Je,Te);b.generateMipmaps=!1}else if(st){if(mt){let re=St(ae);t.texStorage2D(i.TEXTURE_2D,we,Ce,re.width,re.height)}H&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,Se,Je,ae)}else t.texImage2D(i.TEXTURE_2D,0,Ce,Se,Je,ae);m(b)&&v(Z),ye.__version=ge.version,b.onUpdate&&b.onUpdate(b)}D.__version=b.version}function ot(D,b,G){if(b.image.length!==6)return;let Z=rt(D,b),Q=b.source;t.bindTexture(i.TEXTURE_CUBE_MAP,D.__webglTexture,i.TEXTURE0+G);let ge=n.get(Q);if(Q.version!==ge.__version||Z===!0){t.activeTexture(i.TEXTURE0+G);let ye=Mt.getPrimaries(Mt.workingColorSpace),ee=b.colorSpace===es?null:Mt.getPrimaries(b.colorSpace),ae=b.colorSpace===es||ye===ee?i.NONE:i.BROWSER_DEFAULT_WEBGL;t.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,b.flipY),t.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),t.pixelStorei(i.UNPACK_ALIGNMENT,b.unpackAlignment),t.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,ae);let Se=b.isCompressedTexture||b.image[0].isCompressedTexture,Je=b.image[0]&&b.image[0].isDataTexture,Ce=[];for(let ue=0;ue<6;ue++)!Se&&!Je?Ce[ue]=g(b.image[ue],!0,s.maxCubemapSize):Ce[ue]=Je?b.image[ue].image:b.image[ue],Ce[ue]=It(b,Ce[ue]);let Te=Ce[0],Ke=r.convert(b.format,b.colorSpace),st=r.convert(b.type),mt=y(b.internalFormat,Ke,st,b.normalized,b.colorSpace),H=b.isVideoTexture!==!0,we=ge.__version===void 0||Z===!0,re=Q.dataReady,Re=M(b,Te);He(i.TEXTURE_CUBE_MAP,b);let Le;if(Se){H&&we&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Re,mt,Te.width,Te.height);for(let ue=0;ue<6;ue++){Le=Ce[ue].mipmaps;for(let $e=0;$e<Le.length;$e++){let Ye=Le[$e];b.format!==In?Ke!==null?H?re&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,$e,0,0,Ye.width,Ye.height,Ke,Ye.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,$e,mt,Ye.width,Ye.height,0,Ye.data):be("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):H?re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,$e,0,0,Ye.width,Ye.height,Ke,st,Ye.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,$e,mt,Ye.width,Ye.height,0,Ke,st,Ye.data)}}}else{if(Le=b.mipmaps,H&&we){Le.length>0&&Re++;let ue=St(Ce[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Re,mt,ue.width,ue.height)}for(let ue=0;ue<6;ue++)if(Je){H?re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,0,0,0,Ce[ue].width,Ce[ue].height,Ke,st,Ce[ue].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,0,mt,Ce[ue].width,Ce[ue].height,0,Ke,st,Ce[ue].data);for(let $e=0;$e<Le.length;$e++){let Gt=Le[$e].image[ue].image;H?re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,$e+1,0,0,Gt.width,Gt.height,Ke,st,Gt.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,$e+1,mt,Gt.width,Gt.height,0,Ke,st,Gt.data)}}else{H?re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,0,0,0,Ke,st,Ce[ue]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,0,mt,Ke,st,Ce[ue]);for(let $e=0;$e<Le.length;$e++){let Ye=Le[$e];H?re&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,$e+1,0,0,Ke,st,Ye.image[ue]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ue,$e+1,mt,Ke,st,Ye.image[ue])}}}m(b)&&v(i.TEXTURE_CUBE_MAP),ge.__version=Q.version,b.onUpdate&&b.onUpdate(b)}D.__version=b.version}function Ne(D,b,G,Z,Q,ge){let ye=r.convert(G.format,G.colorSpace),ee=r.convert(G.type),ae=y(G.internalFormat,ye,ee,G.normalized,G.colorSpace),Se=n.get(b),Je=n.get(G);if(Je.__renderTarget=b,!Se.__hasExternalTextures){let Ce=Math.max(1,b.width>>ge),Te=Math.max(1,b.height>>ge);Q===i.TEXTURE_3D||Q===i.TEXTURE_2D_ARRAY?t.texImage3D(Q,ge,ae,Ce,Te,b.depth,0,ye,ee,null):t.texImage2D(Q,ge,ae,Ce,Te,0,ye,ee,null)}t.bindFramebuffer(i.FRAMEBUFFER,D),ut(b)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,Z,Q,Je.__webglTexture,0,ct(b)):(Q===i.TEXTURE_2D||Q>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&Q<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,Z,Q,Je.__webglTexture,ge),t.bindFramebuffer(i.FRAMEBUFFER,null)}function lt(D,b,G){if(i.bindRenderbuffer(i.RENDERBUFFER,D),b.depthBuffer){let Z=b.depthTexture,Q=Z&&Z.isDepthTexture?Z.type:null,ge=w(b.stencilBuffer,Q),ye=b.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;ut(b)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ct(b),ge,b.width,b.height):G?i.renderbufferStorageMultisample(i.RENDERBUFFER,ct(b),ge,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,ge,b.width,b.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,ye,i.RENDERBUFFER,D)}else{let Z=b.textures;for(let Q=0;Q<Z.length;Q++){let ge=Z[Q],ye=r.convert(ge.format,ge.colorSpace),ee=r.convert(ge.type),ae=y(ge.internalFormat,ye,ee,ge.normalized,ge.colorSpace);ut(b)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ct(b),ae,b.width,b.height):G?i.renderbufferStorageMultisample(i.RENDERBUFFER,ct(b),ae,b.width,b.height):i.renderbufferStorage(i.RENDERBUFFER,ae,b.width,b.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Ft(D,b,G){let Z=b.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(i.FRAMEBUFFER,D),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");let Q=n.get(b.depthTexture);if(Q.__renderTarget=b,(!Q.__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),Z){if(Q.__webglInit===void 0&&(Q.__webglInit=!0,b.depthTexture.addEventListener("dispose",T)),Q.__webglTexture===void 0){Q.__webglTexture=i.createTexture(),t.bindTexture(i.TEXTURE_CUBE_MAP,Q.__webglTexture),He(i.TEXTURE_CUBE_MAP,b.depthTexture);let Se=r.convert(b.depthTexture.format),Je=r.convert(b.depthTexture.type),Ce;b.depthTexture.format===Ui?Ce=i.DEPTH_COMPONENT24:b.depthTexture.format===Ts&&(Ce=i.DEPTH24_STENCIL8);for(let Te=0;Te<6;Te++)i.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+Te,0,Ce,b.width,b.height,0,Se,Je,null)}}else ie(b.depthTexture,0);let ge=Q.__webglTexture,ye=ct(b),ee=Z?i.TEXTURE_CUBE_MAP_POSITIVE_X+G:i.TEXTURE_2D,ae=b.depthTexture.format===Ts?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;if(b.depthTexture.format===Ui)ut(b)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ae,ee,ge,0,ye):i.framebufferTexture2D(i.FRAMEBUFFER,ae,ee,ge,0);else if(b.depthTexture.format===Ts)ut(b)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,ae,ee,ge,0,ye):i.framebufferTexture2D(i.FRAMEBUFFER,ae,ee,ge,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function le(D){let b=n.get(D),G=D.isWebGLCubeRenderTarget===!0;if(b.__boundDepthTexture!==D.depthTexture){let Z=D.depthTexture;if(b.__depthDisposeCallback&&b.__depthDisposeCallback(),Z){let Q=()=>{delete b.__boundDepthTexture,delete b.__depthDisposeCallback,Z.removeEventListener("dispose",Q)};Z.addEventListener("dispose",Q),b.__depthDisposeCallback=Q}b.__boundDepthTexture=Z}if(D.depthTexture&&!b.__autoAllocateDepthBuffer)if(G)for(let Z=0;Z<6;Z++)Ft(b.__webglFramebuffer[Z],D,Z);else{let Z=D.texture.mipmaps;Z&&Z.length>0?Ft(b.__webglFramebuffer[0],D,0):Ft(b.__webglFramebuffer,D,0)}else if(G){b.__webglDepthbuffer=[];for(let Z=0;Z<6;Z++)if(t.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer[Z]),b.__webglDepthbuffer[Z]===void 0)b.__webglDepthbuffer[Z]=i.createRenderbuffer(),lt(b.__webglDepthbuffer[Z],D,!1);else{let Q=D.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ge=b.__webglDepthbuffer[Z];i.bindRenderbuffer(i.RENDERBUFFER,ge),i.framebufferRenderbuffer(i.FRAMEBUFFER,Q,i.RENDERBUFFER,ge)}}else{let Z=D.texture.mipmaps;if(Z&&Z.length>0?t.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer[0]):t.bindFramebuffer(i.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer===void 0)b.__webglDepthbuffer=i.createRenderbuffer(),lt(b.__webglDepthbuffer,D,!1);else{let Q=D.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ge=b.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,ge),i.framebufferRenderbuffer(i.FRAMEBUFFER,Q,i.RENDERBUFFER,ge)}}t.bindFramebuffer(i.FRAMEBUFFER,null)}function de(D,b,G){let Z=n.get(D);b!==void 0&&Ne(Z.__webglFramebuffer,D,D.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),G!==void 0&&le(D)}function fe(D){let b=D.texture,G=n.get(D),Z=n.get(b);D.addEventListener("dispose",x);let Q=D.textures,ge=D.isWebGLCubeRenderTarget===!0,ye=Q.length>1;if(ye||(Z.__webglTexture===void 0&&(Z.__webglTexture=i.createTexture()),Z.__version=b.version,o.memory.textures++),ge){G.__webglFramebuffer=[];for(let ee=0;ee<6;ee++)if(b.mipmaps&&b.mipmaps.length>0){G.__webglFramebuffer[ee]=[];for(let ae=0;ae<b.mipmaps.length;ae++)G.__webglFramebuffer[ee][ae]=i.createFramebuffer()}else G.__webglFramebuffer[ee]=i.createFramebuffer()}else{if(b.mipmaps&&b.mipmaps.length>0){G.__webglFramebuffer=[];for(let ee=0;ee<b.mipmaps.length;ee++)G.__webglFramebuffer[ee]=i.createFramebuffer()}else G.__webglFramebuffer=i.createFramebuffer();if(ye)for(let ee=0,ae=Q.length;ee<ae;ee++){let Se=n.get(Q[ee]);Se.__webglTexture===void 0&&(Se.__webglTexture=i.createTexture(),o.memory.textures++)}if(D.samples>0&&ut(D)===!1){G.__webglMultisampledFramebuffer=i.createFramebuffer(),G.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,G.__webglMultisampledFramebuffer);for(let ee=0;ee<Q.length;ee++){let ae=Q[ee];G.__webglColorRenderbuffer[ee]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,G.__webglColorRenderbuffer[ee]);let Se=r.convert(ae.format,ae.colorSpace),Je=r.convert(ae.type),Ce=y(ae.internalFormat,Se,Je,ae.normalized,ae.colorSpace,D.isXRRenderTarget===!0),Te=ct(D);i.renderbufferStorageMultisample(i.RENDERBUFFER,Te,Ce,D.width,D.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ee,i.RENDERBUFFER,G.__webglColorRenderbuffer[ee])}i.bindRenderbuffer(i.RENDERBUFFER,null),D.depthBuffer&&(G.__webglDepthRenderbuffer=i.createRenderbuffer(),lt(G.__webglDepthRenderbuffer,D,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(ge){t.bindTexture(i.TEXTURE_CUBE_MAP,Z.__webglTexture),He(i.TEXTURE_CUBE_MAP,b);for(let ee=0;ee<6;ee++)if(b.mipmaps&&b.mipmaps.length>0)for(let ae=0;ae<b.mipmaps.length;ae++)Ne(G.__webglFramebuffer[ee][ae],D,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,ae);else Ne(G.__webglFramebuffer[ee],D,b,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ee,0);m(b)&&v(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ye){for(let ee=0,ae=Q.length;ee<ae;ee++){let Se=Q[ee],Je=n.get(Se),Ce=i.TEXTURE_2D;(D.isWebGL3DRenderTarget||D.isWebGLArrayRenderTarget)&&(Ce=D.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(Ce,Je.__webglTexture),He(Ce,Se),Ne(G.__webglFramebuffer,D,Se,i.COLOR_ATTACHMENT0+ee,Ce,0),m(Se)&&v(Ce)}t.unbindTexture()}else{let ee=i.TEXTURE_2D;if((D.isWebGL3DRenderTarget||D.isWebGLArrayRenderTarget)&&(ee=D.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(ee,Z.__webglTexture),He(ee,b),b.mipmaps&&b.mipmaps.length>0)for(let ae=0;ae<b.mipmaps.length;ae++)Ne(G.__webglFramebuffer[ae],D,b,i.COLOR_ATTACHMENT0,ee,ae);else Ne(G.__webglFramebuffer,D,b,i.COLOR_ATTACHMENT0,ee,0);m(b)&&v(ee),t.unbindTexture()}D.depthBuffer&&le(D)}function pe(D){let b=D.textures;for(let G=0,Z=b.length;G<Z;G++){let Q=b[G];if(m(Q)){let ge=E(D),ye=n.get(Q).__webglTexture;t.bindTexture(ge,ye),v(ge),t.unbindTexture()}}}let Me=[],it=[];function tt(D){if(D.samples>0){if(ut(D)===!1){let b=D.textures,G=D.width,Z=D.height,Q=i.COLOR_BUFFER_BIT,ge=D.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ye=n.get(D),ee=b.length>1;if(ee)for(let Se=0;Se<b.length;Se++)t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,ye.__webglMultisampledFramebuffer);let ae=D.texture.mipmaps;ae&&ae.length>0?t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglFramebuffer[0]):t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglFramebuffer);for(let Se=0;Se<b.length;Se++){if(D.resolveDepthBuffer&&(D.depthBuffer&&(Q|=i.DEPTH_BUFFER_BIT),D.stencilBuffer&&D.resolveStencilBuffer&&(Q|=i.STENCIL_BUFFER_BIT)),ee){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,ye.__webglColorRenderbuffer[Se]);let Je=n.get(b[Se]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,Je,0)}i.blitFramebuffer(0,0,G,Z,0,0,G,Z,Q,i.NEAREST),l===!0&&(Me.length=0,it.length=0,Me.push(i.COLOR_ATTACHMENT0+Se),D.depthBuffer&&D.storeMultisampledDepthBuffer===!1&&(Me.push(ge),it.push(ge),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,it)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,Me))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),ee)for(let Se=0;Se<b.length;Se++){t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.RENDERBUFFER,ye.__webglColorRenderbuffer[Se]);let Je=n.get(b[Se]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,ye.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+Se,i.TEXTURE_2D,Je,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,ye.__webglMultisampledFramebuffer)}else if(D.depthBuffer&&D.storeMultisampledDepthBuffer===!1&&l){let b=D.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[b])}}}function ct(D){return Math.min(s.maxSamples,D.samples)}function ut(D){let b=n.get(D);return D.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function B(D){let b=o.render.frame;h.get(D)!==b&&(h.set(D,b),D.update())}function It(D,b){let G=D.colorSpace,Z=D.format,Q=D.type;return D.isCompressedTexture===!0||D.isVideoTexture===!0||G!==vo&&G!==es&&(Mt.getTransfer(G)===Ct?(Z!==In||Q!==Qn)&&be("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):qe("WebGLTextures: Unsupported texture color space:",G)),b}function St(D){return typeof HTMLImageElement<"u"&&D instanceof HTMLImageElement?(c.width=D.naturalWidth||D.width,c.height=D.naturalHeight||D.height):typeof VideoFrame<"u"&&D instanceof VideoFrame?(c.width=D.displayWidth,c.height=D.displayHeight):(c.width=D.width,c.height=D.height),c}this.allocateTextureUnit=z,this.resetTextureUnits=I,this.getTextureUnits=P,this.setTextureUnits=U,this.setTexture2D=ie,this.setTexture2DArray=$,this.setTexture3D=se,this.setTextureCube=te,this.rebindTextures=de,this.setupRenderTarget=fe,this.updateRenderTargetMipmap=pe,this.updateMultisampleRenderTarget=tt,this.setupDepthRenderbuffer=le,this.setupFrameBufferTexture=Ne,this.useMultisampledRTT=ut,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function $g(i,e){function t(n,s=es){let r,o=Mt.getTransfer(s);if(n===Qn)return i.UNSIGNED_BYTE;if(n===Vl)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Wl)return i.UNSIGNED_SHORT_5_5_5_1;if(n===Yu)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===qu)return i.UNSIGNED_INT_10F_11F_11F_REV;if(n===Wu)return i.BYTE;if(n===Xu)return i.SHORT;if(n===Ur)return i.UNSIGNED_SHORT;if(n===Gl)return i.INT;if(n===_i)return i.UNSIGNED_INT;if(n===kn)return i.FLOAT;if(n===yn)return i.HALF_FLOAT;if(n===Zu)return i.ALPHA;if(n===Ju)return i.RGB;if(n===In)return i.RGBA;if(n===Ui)return i.DEPTH_COMPONENT;if(n===Ts)return i.DEPTH_STENCIL;if(n===Xl)return i.RED;if(n===ea)return i.RED_INTEGER;if(n===ws)return i.RG;if(n===Yl)return i.RG_INTEGER;if(n===ql)return i.RGBA_INTEGER;if(n===ta||n===na||n===ia||n===sa)if(o===Ct)if(r=e.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(n===ta)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===na)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===ia)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===sa)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=e.get("WEBGL_compressed_texture_s3tc"),r!==null){if(n===ta)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===na)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===ia)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===sa)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Zl||n===Jl||n===Kl||n===$l)if(r=e.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(n===Zl)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Jl)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Kl)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===$l)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===jl||n===Ql||n===ec||n===tc||n===nc||n===ra||n===ic)if(r=e.get("WEBGL_compressed_texture_etc"),r!==null){if(n===jl||n===Ql)return o===Ct?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(n===ec)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC;if(n===tc)return r.COMPRESSED_R11_EAC;if(n===nc)return r.COMPRESSED_SIGNED_R11_EAC;if(n===ra)return r.COMPRESSED_RG11_EAC;if(n===ic)return r.COMPRESSED_SIGNED_RG11_EAC}else return null;if(n===sc||n===rc||n===oc||n===ac||n===lc||n===cc||n===hc||n===uc||n===dc||n===fc||n===pc||n===mc||n===gc||n===_c)if(r=e.get("WEBGL_compressed_texture_astc"),r!==null){if(n===sc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===rc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===oc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===ac)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===lc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===cc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===hc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===uc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===dc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===fc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===pc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===mc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===gc)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===_c)return o===Ct?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===xc||n===vc||n===yc)if(r=e.get("EXT_texture_compression_bptc"),r!==null){if(n===xc)return o===Ct?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===vc)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===yc)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Mc||n===bc||n===oa||n===Ec)if(r=e.get("EXT_texture_compression_rgtc"),r!==null){if(n===Mc)return r.COMPRESSED_RED_RGTC1_EXT;if(n===bc)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===oa)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Ec)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Fr?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}var zE=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,kE=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,Tp=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let n=new Ro(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,n=new xt({vertexShader:zE,fragmentShader:kE,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new W(new cn(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},wp=class extends ri{constructor(e,t){super();let n=this,s=null,r=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,p=null,_=typeof XRWebGLBinding<"u",g=new Tp,m={},v=t.getContextAttributes(),E=null,y=null,w=[],M=[],T=new J,x=null,S=null,C=new on;C.viewport=new Ut;let L=new on;L.viewport=new Ut;let F=[C,L],I=new Ul,P=null,U=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(j){let oe=w[j];return oe===void 0&&(oe=new vr,w[j]=oe),oe.getTargetRaySpace()},this.getControllerGrip=function(j){let oe=w[j];return oe===void 0&&(oe=new vr,w[j]=oe),oe.getGripSpace()},this.getHand=function(j){let oe=w[j];return oe===void 0&&(oe=new vr,w[j]=oe),oe.getHandSpace()};function z(j){let oe=M.indexOf(j.inputSource);if(oe===-1)return;let Ee=w[oe];Ee!==void 0&&(Ee.update(j.inputSource,j.frame,c||o),Ee.dispatchEvent({type:j.type,data:j.inputSource}))}function V(){s.removeEventListener("select",z),s.removeEventListener("selectstart",z),s.removeEventListener("selectend",z),s.removeEventListener("squeeze",z),s.removeEventListener("squeezestart",z),s.removeEventListener("squeezeend",z),s.removeEventListener("end",V),s.removeEventListener("inputsourceschange",ie);for(let j=0;j<w.length;j++){let oe=M[j];oe!==null&&(M[j]=null,w[j].disconnect(oe))}P=null,U=null,g.reset();for(let j in m)delete m[j];if(e.setRenderTarget(E),f=null,d=null,u=null,s=null,y=null,rt.stop(),n.isPresenting=!1,e.setPixelRatio(x),e.setSize(T.width,T.height,!1),S!==null){let j=S.camera;j.fov=S.fov,j.zoom=S.zoom,j.updateProjectionMatrix(),S=null}n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(j){r=j,n.isPresenting===!0&&be("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(j){a=j,n.isPresenting===!0&&be("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(j){c=j},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u===null&&_&&(u=new XRWebGLBinding(s,t)),u},this.getFrame=function(){return p},this.getSession=function(){return s},this.setSession=async function(j){if(s=j,s!==null){if(E=e.getRenderTarget(),s.addEventListener("select",z),s.addEventListener("selectstart",z),s.addEventListener("selectend",z),s.addEventListener("squeeze",z),s.addEventListener("squeezestart",z),s.addEventListener("squeezeend",z),s.addEventListener("end",V),s.addEventListener("inputsourceschange",ie),v.xrCompatible!==!0&&await t.makeXRCompatible(),x=e.getPixelRatio(),e.getSize(T),_&&"createProjectionLayer"in XRWebGLBinding.prototype){let Ee=null,ot=null,Ne=null;v.depth&&(Ne=v.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Ee=v.stencil?Ts:Ui,ot=v.stencil?Fr:_i);let lt={colorFormat:t.RGBA8,depthFormat:Ne,scaleFactor:r};u=this.getBinding(),d=u.createProjectionLayer(lt),s.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),y=new Qt(d.textureWidth,d.textureHeight,{format:In,type:Qn,depthTexture:new gs(d.textureWidth,d.textureHeight,ot,void 0,void 0,void 0,void 0,void 0,void 0,Ee),stencilBuffer:v.stencil,colorSpace:e.outputColorSpace,samples:v.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1,storeMultisampledDepthBuffer:d.ignoreDepthValues===!1,storeMultisampledStencilBuffer:d.ignoreDepthValues===!1})}else{let Ee={antialias:v.antialias,alpha:!0,depth:v.depth,stencil:v.stencil,framebufferScaleFactor:r};f=new XRWebGLLayer(s,t,Ee),s.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),y=new Qt(f.framebufferWidth,f.framebufferHeight,{format:In,type:Qn,colorSpace:e.outputColorSpace,stencilBuffer:v.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await s.requestReferenceSpace(a),rt.setContext(s),rt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(s!==null)return s.environmentBlendMode},this.getDepthTexture=function(){return g.getDepthTexture()};function ie(j){for(let oe=0;oe<j.removed.length;oe++){let Ee=j.removed[oe],ot=M.indexOf(Ee);ot>=0&&(M[ot]=null,w[ot].disconnect(Ee))}for(let oe=0;oe<j.added.length;oe++){let Ee=j.added[oe],ot=M.indexOf(Ee);if(ot===-1){for(let lt=0;lt<w.length;lt++)if(lt>=M.length){M.push(Ee),ot=lt;break}else if(M[lt]===null){M[lt]=Ee,ot=lt;break}if(ot===-1)break}let Ne=w[ot];Ne&&Ne.connect(Ee)}}let $=new A,se=new A;function te(j,oe,Ee){$.setFromMatrixPosition(oe.matrixWorld),se.setFromMatrixPosition(Ee.matrixWorld);let ot=$.distanceTo(se),Ne=oe.projectionMatrix.elements,lt=Ee.projectionMatrix.elements,Ft=Ne[14]/(Ne[10]-1),le=Ne[14]/(Ne[10]+1),de=(Ne[9]+1)/Ne[5],fe=(Ne[9]-1)/Ne[5],pe=(Ne[8]-1)/Ne[0],Me=(lt[8]+1)/lt[0],it=Ft*pe,tt=Ft*Me,ct=ot/(-pe+Me),ut=ct*-pe;if(oe.matrixWorld.decompose(j.position,j.quaternion,j.scale),j.translateX(ut),j.translateZ(ct),j.matrixWorld.compose(j.position,j.quaternion,j.scale),j.matrixWorldInverse.copy(j.matrixWorld).invert(),Ne[10]===-1)j.projectionMatrix.copy(oe.projectionMatrix),j.projectionMatrixInverse.copy(oe.projectionMatrixInverse);else{let B=Ft+ct,It=le+ct,St=it-ut,D=tt+(ot-ut),b=de*le/It*B,G=fe*le/It*B;j.projectionMatrix.makePerspective(St,D,b,G,B,It),j.projectionMatrixInverse.copy(j.projectionMatrix).invert()}}function Xe(j,oe){oe===null?j.matrixWorld.copy(j.matrix):j.matrixWorld.multiplyMatrices(oe.matrixWorld,j.matrix),j.matrixWorldInverse.copy(j.matrixWorld).invert()}this.updateCamera=function(j){if(s===null)return;let oe=j.near,Ee=j.far;g.texture!==null&&(g.depthNear>0&&(oe=g.depthNear),g.depthFar>0&&(Ee=g.depthFar)),I.near=L.near=C.near=oe,I.far=L.far=C.far=Ee,(P!==I.near||U!==I.far)&&(s.updateRenderState({depthNear:I.near,depthFar:I.far}),P=I.near,U=I.far),I.layers.mask=j.layers.mask|6,C.layers.mask=I.layers.mask&-5,L.layers.mask=I.layers.mask&-3;let ot=j.parent,Ne=I.cameras;Xe(I,ot);for(let lt=0;lt<Ne.length;lt++)Xe(Ne[lt],ot);Ne.length===2?te(I,C,L):I.projectionMatrix.copy(C.projectionMatrix),S===null&&j.isPerspectiveCamera&&(S={camera:j,fov:j.fov,zoom:j.zoom}),Ue(j,I,ot)};function Ue(j,oe,Ee){Ee===null?j.matrix.copy(oe.matrixWorld):(j.matrix.copy(Ee.matrixWorld),j.matrix.invert(),j.matrix.multiply(oe.matrixWorld)),j.matrix.decompose(j.position,j.quaternion,j.scale),j.updateMatrixWorld(!0),j.projectionMatrix.copy(oe.projectionMatrix),j.projectionMatrixInverse.copy(oe.projectionMatrixInverse),j.isPerspectiveCamera&&(j.fov=mr*2*Math.atan(1/j.projectionMatrix.elements[5]),j.zoom=1)}this.getCamera=function(){return I},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(j){l=j,d!==null&&(d.fixedFoveation=j),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=j)},this.hasDepthSensing=function(){return g.texture!==null},this.getDepthSensingMesh=function(){return g.getMesh(I)},this.getCameraTexture=function(j){return m[j]};let Ge=null;function He(j,oe){if(h=oe.getViewerPose(c||o),p=oe,h!==null){let Ee=h.views;f!==null&&(e.setRenderTargetFramebuffer(y,f.framebuffer),e.setRenderTarget(y));let ot=!1;Ee.length!==I.cameras.length&&(I.cameras.length=0,ot=!0);for(let le=0;le<Ee.length;le++){let de=Ee[le],fe=null;if(f!==null)fe=f.getViewport(de);else{let Me=u.getViewSubImage(d,de);fe=Me.viewport,le===0&&(e.setRenderTargetTextures(y,Me.colorTexture,Me.depthStencilTexture),e.setRenderTarget(y))}let pe=F[le];pe===void 0&&(pe=new on,pe.layers.enable(le),pe.viewport=new Ut,F[le]=pe),pe.matrix.fromArray(de.transform.matrix),pe.matrix.decompose(pe.position,pe.quaternion,pe.scale),pe.projectionMatrix.fromArray(de.projectionMatrix),pe.projectionMatrixInverse.copy(pe.projectionMatrix).invert(),pe.viewport.set(fe.x,fe.y,fe.width,fe.height),le===0&&(I.matrix.copy(pe.matrix),I.matrix.decompose(I.position,I.quaternion,I.scale)),ot===!0&&I.cameras.push(pe)}let Ne=s.enabledFeatures;if(Ne&&Ne.includes("depth-sensing")&&s.depthUsage=="gpu-optimized"&&_){u=n.getBinding();let le=u.getDepthInformation(Ee[0]);le&&le.isValid&&le.texture&&g.init(le,s.renderState)}if(Ne&&Ne.includes("camera-access")&&_){e.state.unbindTexture(),u=n.getBinding();for(let le=0;le<Ee.length;le++){let de=Ee[le].camera;if(de){let fe=m[de];fe||(fe=new Ro,m[de]=fe);let pe=u.getCameraImage(de);fe.sourceTexture=pe}}}}for(let Ee=0;Ee<w.length;Ee++){let ot=M[Ee],Ne=w[Ee];ot!==null&&Ne!==void 0&&Ne.update(ot,oe,c||o)}Ge&&Ge(j,oe),oe.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:oe}),p=null}let rt=new Xg;rt.setAnimationLoop(He),this.setAnimationLoop=function(j){Ge=j},this.dispose=function(){}}},GE=new nt,jg=new ht;jg.set(-1,0,0,0,1,0,0,0,1);function VE(i,e){function t(g,m){g.matrixAutoUpdate===!0&&g.updateMatrix(),m.value.copy(g.matrix)}function n(g,m){m.color.getRGB(g.fogColor.value,ip(i)),m.isFog?(g.fogNear.value=m.near,g.fogFar.value=m.far):m.isFogExp2&&(g.fogDensity.value=m.density)}function s(g,m,v,E,y){m.isNodeMaterial?m.uniformsNeedUpdate=!1:m.isMeshBasicMaterial?r(g,m):m.isMeshLambertMaterial?(r(g,m),m.envMap&&(g.envMapIntensity.value=m.envMapIntensity)):m.isMeshToonMaterial?(r(g,m),u(g,m)):m.isMeshPhongMaterial?(r(g,m),h(g,m),m.envMap&&(g.envMapIntensity.value=m.envMapIntensity)):m.isMeshStandardMaterial?(r(g,m),d(g,m),m.isMeshPhysicalMaterial&&f(g,m,y)):m.isMeshMatcapMaterial?(r(g,m),p(g,m)):m.isMeshDepthMaterial?r(g,m):m.isMeshDistanceMaterial?(r(g,m),_(g,m)):m.isMeshNormalMaterial?r(g,m):m.isLineBasicMaterial?(o(g,m),m.isLineDashedMaterial&&a(g,m)):m.isPointsMaterial?l(g,m,v,E):m.isSpriteMaterial?c(g,m):m.isShadowMaterial?(g.color.value.copy(m.color),g.opacity.value=m.opacity):m.isShaderMaterial&&(m.uniformsNeedUpdate=!1)}function r(g,m){g.opacity.value=m.opacity,m.color&&g.diffuse.value.copy(m.color),m.emissive&&g.emissive.value.copy(m.emissive).multiplyScalar(m.emissiveIntensity),m.map&&(g.map.value=m.map,t(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,t(m.alphaMap,g.alphaMapTransform)),m.bumpMap&&(g.bumpMap.value=m.bumpMap,t(m.bumpMap,g.bumpMapTransform),g.bumpScale.value=m.bumpScale,m.side===Ln&&(g.bumpScale.value*=-1)),m.normalMap&&(g.normalMap.value=m.normalMap,t(m.normalMap,g.normalMapTransform),g.normalScale.value.copy(m.normalScale),m.side===Ln&&g.normalScale.value.negate()),m.displacementMap&&(g.displacementMap.value=m.displacementMap,t(m.displacementMap,g.displacementMapTransform),g.displacementScale.value=m.displacementScale,g.displacementBias.value=m.displacementBias),m.emissiveMap&&(g.emissiveMap.value=m.emissiveMap,t(m.emissiveMap,g.emissiveMapTransform)),m.specularMap&&(g.specularMap.value=m.specularMap,t(m.specularMap,g.specularMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest);let v=e.get(m),E=v.envMap,y=v.envMapRotation;E&&(g.envMap.value=E,g.envMapRotation.value.setFromMatrix4(GE.makeRotationFromEuler(y)).transpose(),E.isCubeTexture&&E.isRenderTargetTexture===!1&&g.envMapRotation.value.premultiply(jg),g.reflectivity.value=m.reflectivity,g.ior.value=m.ior,g.refractionRatio.value=m.refractionRatio),m.lightMap&&(g.lightMap.value=m.lightMap,g.lightMapIntensity.value=m.lightMapIntensity,t(m.lightMap,g.lightMapTransform)),m.aoMap&&(g.aoMap.value=m.aoMap,g.aoMapIntensity.value=m.aoMapIntensity,t(m.aoMap,g.aoMapTransform))}function o(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,m.map&&(g.map.value=m.map,t(m.map,g.mapTransform))}function a(g,m){g.dashSize.value=m.dashSize,g.totalSize.value=m.dashSize+m.gapSize,g.scale.value=m.scale}function l(g,m,v,E){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.size.value=m.size*v,g.scale.value=E*.5,m.map&&(g.map.value=m.map,t(m.map,g.uvTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,t(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function c(g,m){g.diffuse.value.copy(m.color),g.opacity.value=m.opacity,g.rotation.value=m.rotation,m.map&&(g.map.value=m.map,t(m.map,g.mapTransform)),m.alphaMap&&(g.alphaMap.value=m.alphaMap,t(m.alphaMap,g.alphaMapTransform)),m.alphaTest>0&&(g.alphaTest.value=m.alphaTest)}function h(g,m){g.specular.value.copy(m.specular),g.shininess.value=Math.max(m.shininess,1e-4)}function u(g,m){m.gradientMap&&(g.gradientMap.value=m.gradientMap)}function d(g,m){g.metalness.value=m.metalness,m.metalnessMap&&(g.metalnessMap.value=m.metalnessMap,t(m.metalnessMap,g.metalnessMapTransform)),g.roughness.value=m.roughness,m.roughnessMap&&(g.roughnessMap.value=m.roughnessMap,t(m.roughnessMap,g.roughnessMapTransform)),m.envMap&&(g.envMapIntensity.value=m.envMapIntensity)}function f(g,m,v){g.ior.value=m.ior,m.sheen>0&&(g.sheenColor.value.copy(m.sheenColor).multiplyScalar(m.sheen),g.sheenRoughness.value=m.sheenRoughness,m.sheenColorMap&&(g.sheenColorMap.value=m.sheenColorMap,t(m.sheenColorMap,g.sheenColorMapTransform)),m.sheenRoughnessMap&&(g.sheenRoughnessMap.value=m.sheenRoughnessMap,t(m.sheenRoughnessMap,g.sheenRoughnessMapTransform))),m.clearcoat>0&&(g.clearcoat.value=m.clearcoat,g.clearcoatRoughness.value=m.clearcoatRoughness,m.clearcoatMap&&(g.clearcoatMap.value=m.clearcoatMap,t(m.clearcoatMap,g.clearcoatMapTransform)),m.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=m.clearcoatRoughnessMap,t(m.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),m.clearcoatNormalMap&&(g.clearcoatNormalMap.value=m.clearcoatNormalMap,t(m.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(m.clearcoatNormalScale),m.side===Ln&&g.clearcoatNormalScale.value.negate())),m.dispersion>0&&(g.dispersion.value=m.dispersion),m.retroreflectivity>0&&(g.retroreflectivity.value=m.retroreflectivity),m.iridescence>0&&(g.iridescence.value=m.iridescence,g.iridescenceIOR.value=m.iridescenceIOR,g.iridescenceThicknessMinimum.value=m.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=m.iridescenceThicknessRange[1],m.iridescenceMap&&(g.iridescenceMap.value=m.iridescenceMap,t(m.iridescenceMap,g.iridescenceMapTransform)),m.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=m.iridescenceThicknessMap,t(m.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),m.transmission>0&&(g.transmission.value=m.transmission,g.transmissionSamplerMap.value=v.texture,g.transmissionSamplerSize.value.set(v.width,v.height),m.transmissionMap&&(g.transmissionMap.value=m.transmissionMap,t(m.transmissionMap,g.transmissionMapTransform)),g.thickness.value=m.thickness,m.thicknessMap&&(g.thicknessMap.value=m.thicknessMap,t(m.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=m.attenuationDistance,g.attenuationColor.value.copy(m.attenuationColor)),m.anisotropy>0&&(g.anisotropyVector.value.set(m.anisotropy*Math.cos(m.anisotropyRotation),m.anisotropy*Math.sin(m.anisotropyRotation)),m.anisotropyMap&&(g.anisotropyMap.value=m.anisotropyMap,t(m.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=m.specularIntensity,g.specularColor.value.copy(m.specularColor),m.specularColorMap&&(g.specularColorMap.value=m.specularColorMap,t(m.specularColorMap,g.specularColorMapTransform)),m.specularIntensityMap&&(g.specularIntensityMap.value=m.specularIntensityMap,t(m.specularIntensityMap,g.specularIntensityMapTransform))}function p(g,m){m.matcap&&(g.matcap.value=m.matcap)}function _(g,m){let v=e.get(m).light;g.referencePosition.value.setFromMatrixPosition(v.matrixWorld),g.nearDistance.value=v.shadow.camera.near,g.farDistance.value=v.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:s}}function WE(i,e,t,n){let s={},r={},o=[],a=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(y,w){let M=w.program;n.uniformBlockBinding(y,M)}function c(y,w){let M=s[y.id];M===void 0&&(g(y),M=h(y),s[y.id]=M,y.addEventListener("dispose",v));let T=w.program;n.updateUBOMapping(y,T);let x=e.render.frame;r[y.id]!==x&&(d(y),r[y.id]=x)}function h(y){let w=u();y.__bindingPointIndex=w;let M=i.createBuffer(),T=y.__size,x=y.usage;return i.bindBuffer(i.UNIFORM_BUFFER,M),i.bufferData(i.UNIFORM_BUFFER,T,x),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,w,M),M}function u(){for(let y=0;y<a;y++)if(o.indexOf(y)===-1)return o.push(y),y;return qe("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(y){let w=s[y.id],M=y.uniforms,T=y.__cache;i.bindBuffer(i.UNIFORM_BUFFER,w);for(let x=0,S=M.length;x<S;x++){let C=M[x];if(Array.isArray(C))for(let L=0,F=C.length;L<F;L++)f(C[L],x,L,T);else f(C,x,0,T)}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(y,w,M,T){if(_(y,w,M,T)===!0){let x=y.__offset,S=y.value;if(Array.isArray(S)){let C=0;for(let L=0;L<S.length;L++){let F=S[L],I=m(F);p(F,y.__data,C),typeof F!="number"&&typeof F!="boolean"&&!F.isMatrix3&&!ArrayBuffer.isView(F)&&(C+=I.storage/Float32Array.BYTES_PER_ELEMENT)}}else p(S,y.__data,0);i.bufferSubData(i.UNIFORM_BUFFER,x,y.__data)}}function p(y,w,M){typeof y=="number"||typeof y=="boolean"?w[0]=y:y.isMatrix3?(w[0]=y.elements[0],w[1]=y.elements[1],w[2]=y.elements[2],w[3]=0,w[4]=y.elements[3],w[5]=y.elements[4],w[6]=y.elements[5],w[7]=0,w[8]=y.elements[6],w[9]=y.elements[7],w[10]=y.elements[8],w[11]=0):ArrayBuffer.isView(y)?w.set(new y.constructor(y.buffer,y.byteOffset,w.length)):y.toArray(w,M)}function _(y,w,M,T){let x=y.value,S=w+"_"+M;if(T[S]===void 0)return typeof x=="number"||typeof x=="boolean"?T[S]=x:ArrayBuffer.isView(x)?T[S]=x.slice():T[S]=x.clone(),!0;{let C=T[S];if(typeof x=="number"||typeof x=="boolean"){if(C!==x)return T[S]=x,!0}else{if(ArrayBuffer.isView(x))return!0;if(C.equals(x)===!1)return C.copy(x),!0}}return!1}function g(y){let w=y.uniforms,M=0,T=16;for(let S=0,C=w.length;S<C;S++){let L=Array.isArray(w[S])?w[S]:[w[S]];for(let F=0,I=L.length;F<I;F++){let P=L[F],U=Array.isArray(P.value)?P.value:[P.value];for(let z=0,V=U.length;z<V;z++){let ie=U[z],$=m(ie),se=M%T,te=se%$.boundary,Xe=se+te;M+=te,Xe!==0&&T-Xe<$.storage&&(M+=T-Xe),P.__data=new Float32Array($.storage/Float32Array.BYTES_PER_ELEMENT),P.__offset=M,M+=$.storage}}}let x=M%T;return x>0&&(M+=T-x),y.__size=M,y.__cache={},this}function m(y){let w={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(w.boundary=4,w.storage=4):y.isVector2?(w.boundary=8,w.storage=8):y.isVector3||y.isColor?(w.boundary=16,w.storage=12):y.isVector4?(w.boundary=16,w.storage=16):y.isMatrix3?(w.boundary=48,w.storage=48):y.isMatrix4?(w.boundary=64,w.storage=64):y.isTexture?be("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(y)?(w.boundary=16,w.storage=y.byteLength):be("WebGLRenderer: Unsupported uniform value type.",y),w}function v(y){let w=y.target;w.removeEventListener("dispose",v);let M=o.indexOf(w.__bindingPointIndex);o.splice(M,1),i.deleteBuffer(s[w.id]),delete s[w.id],delete r[w.id]}function E(){for(let y in s)i.deleteBuffer(s[y]);o=[],s={},r={}}return{bind:l,update:c,dispose:E}}var XE=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),ts=null;function YE(){return ts===null&&(ts=new Un(XE,16,16,ws,yn),ts.name="DFG_LUT",ts.minFilter=Xt,ts.magFilter=Xt,ts.wrapS=$n,ts.wrapT=$n,ts.generateMipmaps=!1,ts.needsUpdate=!0),ts}var Dc=class{constructor(e={}){let{canvas:t=ep(),context:n=null,depth:s=!0,stencil:r=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1,outputBufferType:f=Qn}=e;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=n.getContextAttributes().alpha}else p=o;let _=f,g=new Set([ql,Yl,ea]),m=new Set([Qn,_i,Ur,Fr,Vl,Wl]),v=new Uint32Array(4),E=new Int32Array(4),y=new A,w=null,M=null,T=[],x=[],S=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Ti,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let C=this,L=!1,F=null,I=null,P=null,U=null;this._outputColorSpace=Wt;let z=0,V=0,ie=null,$=-1,se=null,te=new Ut,Xe=new Ut,Ue=null,Ge=new q(0),He=0,rt=t.width,j=t.height,oe=1,Ee=null,ot=null,Ne=new Ut(0,0,rt,j),lt=new Ut(0,0,rt,j),Ft=!1,le=new Ji,de=!1,fe=!1,pe=new nt,Me=new A,it=new Ut,tt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},ct=!1;function ut(){return ie===null?oe:1}let B=n;function It(R,O){return t.getContext(R,O)}let St,D,b,G,Z,Q,ge,ye,ee,ae,Se,Je,Ce,Te,Ke,st,mt,H,we,re,Re,Le,ue;try{let R={alpha:!0,depth:s,stencil:r,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${zl}`),t.addEventListener("webglcontextlost",Gt,!1),t.addEventListener("webglcontextrestored",Dt,!1),t.addEventListener("webglcontextcreationerror",Ai,!1),B===null){let O="webgl2";if(B=It(O,R),B===null)throw It(O)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}$e()}catch(R){throw t.removeEventListener("webglcontextlost",Gt,!1),t.removeEventListener("webglcontextrestored",Dt,!1),t.removeEventListener("webglcontextcreationerror",Ai,!1),qe("WebGLRenderer: "+R.message),R}function $e(){St=new eb(B),St.init(),Re=new $g(B,St),D=new WM(B,St,e,Re),b=new OE(B,St),D.reversedDepthBuffer&&d&&b.buffers.depth.setReversed(!0),I=B.createFramebuffer(),P=B.createFramebuffer(),U=B.createFramebuffer(),G=new ib(B),Z=new SE,Q=new HE(B,St,b,Z,D,Re,G),ge=new QM(C),ye=new ry(B),Le=new GM(B,ye),ee=new tb(B,ye,G,Le),ae=new rb(B,ee,ye,Le,G),H=new sb(B,D,Q),Ke=new XM(Z),Se=new EE(C,ge,St,D,Le,Ke),Je=new VE(C,Z),Ce=new wE,Te=new DE(St),mt=new kM(C,ge,b,ae,p,l),st=new BE(C,ae,D),ue=new WE(B,G,D,b),we=new VM(B,St,G),re=new nb(B,St,G),G.programs=Se.programs,C.capabilities=D,C.extensions=St,C.properties=Z,C.renderLists=Ce,C.shadowMap=st,C.state=b,C.info=G}_!==Qn&&(S=new ab(_,t.width,t.height,a,s,r));let Ye=new wp(C,B);this.xr=Ye,this.getContext=function(){return B},this.getContextAttributes=function(){return B.getContextAttributes()},this.forceContextLoss=function(){let R=St.get("WEBGL_lose_context");R&&R.loseContext()},this.forceContextRestore=function(){let R=St.get("WEBGL_lose_context");R&&R.restoreContext()},this.getPixelRatio=function(){return oe},this.setPixelRatio=function(R){R!==void 0&&(oe=R,this.setSize(rt,j,!1))},this.getSize=function(R){return R.set(rt,j)},this.setSize=function(R,O,K=!0){if(Ye.isPresenting){be("WebGLRenderer: Can't change size while VR device is presenting.");return}rt=R,j=O,t.width=Math.floor(R*oe),t.height=Math.floor(O*oe),K===!0&&(t.style.width=R+"px",t.style.height=O+"px"),S!==null&&S.setSize(t.width,t.height),this.setViewport(0,0,R,O)},this.getDrawingBufferSize=function(R){return R.set(rt*oe,j*oe).floor()},this.setDrawingBufferSize=function(R,O,K){rt=R,j=O,oe=K,t.width=Math.floor(R*K),t.height=Math.floor(O*K),this.setViewport(0,0,R,O)},this.setEffects=function(R){if(_===Qn){qe("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(R){for(let O=0;O<R.length;O++)if(R[O].isOutputPass===!0){be("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}S.setEffects(R||[])},this.getCurrentViewport=function(R){return R.copy(te)},this.getViewport=function(R){return R.copy(Ne)},this.setViewport=function(R,O,K,X){R.isVector4?Ne.set(R.x,R.y,R.z,R.w):Ne.set(R,O,K,X),b.viewport(te.copy(Ne).multiplyScalar(oe).round())},this.getScissor=function(R){return R.copy(lt)},this.setScissor=function(R,O,K,X){R.isVector4?lt.set(R.x,R.y,R.z,R.w):lt.set(R,O,K,X),b.scissor(Xe.copy(lt).multiplyScalar(oe).round())},this.getScissorTest=function(){return Ft},this.setScissorTest=function(R){b.setScissorTest(Ft=R)},this.setOpaqueSort=function(R){Ee=R},this.setTransparentSort=function(R){ot=R},this.getClearColor=function(R){return R.copy(mt.getClearColor())},this.setClearColor=function(){mt.setClearColor(...arguments)},this.getClearAlpha=function(){return mt.getClearAlpha()},this.setClearAlpha=function(){mt.setClearAlpha(...arguments)},this.clear=function(R=!0,O=!0,K=!0){let X=0;if(R){let Y=!1;if(ie!==null){let Ie=ie.texture.format;Y=g.has(Ie)}if(Y){let Ie=ie.texture.type,Be=m.has(Ie),Pe=mt.getClearColor(),Ve=mt.getClearAlpha(),Ze=Pe.r,yt=Pe.g,Tt=Pe.b;Be?(v[0]=Ze,v[1]=yt,v[2]=Tt,v[3]=Ve,B.clearBufferuiv(B.COLOR,0,v)):(E[0]=Ze,E[1]=yt,E[2]=Tt,E[3]=Ve,B.clearBufferiv(B.COLOR,0,E))}else X|=B.COLOR_BUFFER_BIT}O&&(X|=B.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),K&&(X|=B.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),X!==0&&B.clear(X)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(R){R.setRenderer(this),F=R},this.dispose=function(){t.removeEventListener("webglcontextlost",Gt,!1),t.removeEventListener("webglcontextrestored",Dt,!1),t.removeEventListener("webglcontextcreationerror",Ai,!1),mt.dispose(),Ce.dispose(),Te.dispose(),Z.dispose(),ge.dispose(),ae.dispose(),Le.dispose(),ue.dispose(),Se.dispose(),Ye.dispose(),Ye.removeEventListener("sessionstart",tm),Ye.removeEventListener("sessionend",nm),er.stop()};function Gt(R){R.preventDefault(),bo("WebGLRenderer: Context Lost."),L=!0}function Dt(){bo("WebGLRenderer: Context Restored."),L=!1;let R=G.autoReset,O=st.enabled,K=st.autoUpdate,X=st.needsUpdate,Y=st.type;$e(),G.autoReset=R,st.enabled=O,st.autoUpdate=K,st.needsUpdate=X,st.type=Y}function Ai(R){qe("WebGLRenderer: A WebGL context could not be created. Reason: ",R.statusMessage)}function Wi(R){let O=R.target;O.removeEventListener("dispose",Wi),ex(O)}function ex(R){tx(R),Z.remove(R)}function tx(R){let O=Z.get(R).programs;O!==void 0&&(O.forEach(function(K){Se.releaseProgram(K)}),R.isShaderMaterial&&Se.releaseShaderCache(R))}this.renderBufferDirect=function(R,O,K,X,Y,Ie){O===null&&(O=tt);let Be=Y.isMesh&&Y.matrixWorld.determinantAffine()<0,Pe=sx(R,O,K,X,Y);b.setMaterial(X,Be);let Ve=K.index,Ze=1;if(X.wireframe===!0){if(Ve=ee.getWireframeAttribute(K),Ve===void 0)return;Ze=2}let yt=K.drawRange,Tt=K.attributes.position,We=yt.start*Ze,Lt=(yt.start+yt.count)*Ze;Ie!==null&&(We=Math.max(We,Ie.start*Ze),Lt=Math.min(Lt,(Ie.start+Ie.count)*Ze)),Ve!==null?(We=Math.max(We,0),Lt=Math.min(Lt,Ve.count)):Tt!=null&&(We=Math.max(We,0),Lt=Math.min(Lt,Tt.count));let pn=Lt-We;if(pn<0||pn===1/0)return;Le.setup(Y,X,Pe,K,Ve);let Kt,zt=we;if(Ve!==null&&(Kt=ye.get(Ve),zt=re,zt.setIndex(Kt)),Y.isMesh)X.wireframe===!0?(b.setLineWidth(X.wireframeLinewidth*ut()),zt.setMode(B.LINES)):zt.setMode(B.TRIANGLES);else if(Y.isLine){let Bn=X.linewidth;Bn===void 0&&(Bn=1),b.setLineWidth(Bn*ut()),Y.isLineSegments?zt.setMode(B.LINES):Y.isLineLoop?zt.setMode(B.LINE_LOOP):zt.setMode(B.LINE_STRIP)}else Y.isPoints?zt.setMode(B.POINTS):Y.isSprite&&zt.setMode(B.TRIANGLES);if(Y.isBatchedMesh)if(St.get("WEBGL_multi_draw"))zt.renderMultiDraw(Y._multiDrawStarts,Y._multiDrawCounts,Y._multiDrawCount);else{let Bn=Y._multiDrawStarts,Fe=Y._multiDrawCounts,Zn=Y._multiDrawCount,At=Ve?ye.get(Ve).bytesPerElement:1,yi=Z.get(X).currentProgram.getUniforms();for(let Xi=0;Xi<Zn;Xi++)yi.setValue(B,"_gl_DrawID",Xi),zt.render(Bn[Xi]/At,Fe[Xi])}else if(Y.isInstancedMesh)zt.renderInstances(We,pn,Y.count);else if(K.isInstancedBufferGeometry){let Bn=K._maxInstanceCount!==void 0?K._maxInstanceCount:1/0,Fe=Math.min(K.instanceCount,Bn);zt.renderInstances(We,pn,Fe)}else zt.render(We,pn)};function em(R,O,K,X){F!==null&&R.isNodeMaterial&&F.setObject(X,R),de===!0&&Ke.setState(R,K,!1),R.transparent===!0&&R.side===De&&R.forceSinglePass===!1?(R.side=Ln,R.needsUpdate=!0,kc(R,O,X),R.side=zi,R.needsUpdate=!0,kc(R,O,X),R.side=De):kc(R,O,X)}this.compile=function(R,O,K=null){K===null&&(K=R),F!==null&&F.renderStart(R,O,K),M=Te.get(K),M.init(O),x.push(M),K.traverseVisible(function(Y){Y.isLight&&Y.layers.test(O.layers)&&(M.pushLight(Y),Y.castShadow&&M.pushShadow(Y))}),R!==K&&R.traverseVisible(function(Y){Y.isLight&&Y.layers.test(O.layers)&&(M.pushLight(Y),Y.castShadow&&M.pushShadow(Y))}),M.setupLights(),F!==null&&F.updateLights(M.state.lightsArray),fe=this.localClippingEnabled,de=Ke.init(this.clippingPlanes,fe),de===!0&&Ke.setGlobalState(this.clippingPlanes,O),F!==null&&st.render(M.state.shadowsArray,K,O);let X=new Set;return R.traverse(function(Y){if(!(Y.isMesh||Y.isPoints||Y.isLine||Y.isSprite))return;let Ie=Y.material;if(Ie)if(Array.isArray(Ie))for(let Be=0;Be<Ie.length;Be++){let Pe=Ie[Be];em(Pe,K,O,Y),X.add(Pe)}else em(Ie,K,O,Y),X.add(Ie)}),M=x.pop(),F!==null&&F.renderEnd(),X},this.compileAsync=function(R,O,K=null){let X=this.compile(R,O,K);return new Promise(Y=>{function Ie(){if(X.forEach(function(Be){let Ve=Z.get(Be).currentProgram;(Ve===void 0||Ve.isReady())&&X.delete(Be)}),X.size===0){Y(R);return}setTimeout(Ie,10)}St.get("KHR_parallel_shader_compile")!==null?Ie():setTimeout(Ie,10)})};let xd=null;function nx(R){xd&&xd(R)}function tm(){er.stop()}function nm(){er.start()}let er=new Xg;er.setAnimationLoop(nx),typeof self<"u"&&er.setContext(self),this.setAnimationLoop=function(R){xd=R,Ye.setAnimationLoop(R),R===null?er.stop():er.start()},Ye.addEventListener("sessionstart",tm),Ye.addEventListener("sessionend",nm),this.render=function(R,O){if(O!==void 0&&O.isCamera!==!0){qe("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(L===!0)return;F!==null&&F.renderStart(R,O);let K=Ye.enabled===!0&&Ye.isPresenting===!0,X=S!==null&&(ie===null||K)&&S.begin(C,ie);if(R.matrixWorldAutoUpdate===!0&&R.updateMatrixWorld(),O.parent===null&&O.matrixWorldAutoUpdate===!0&&O.updateMatrixWorld(),Ye.enabled===!0&&Ye.isPresenting===!0&&(S===null||S.isCompositing()===!1)&&(Ye.cameraAutoUpdate===!0&&Ye.updateCamera(O),O=Ye.getCamera()),R.isScene===!0&&R.onBeforeRender(C,R,O,ie),M=Te.get(R,x.length),M.init(O),M.state.textureUnits=Q.getTextureUnits(),x.push(M),pe.multiplyMatrices(O.projectionMatrix,O.matrixWorldInverse),le.setFromProjectionMatrix(pe,si,O.reversedDepth),fe=this.localClippingEnabled,de=Ke.init(this.clippingPlanes,fe),w=Ce.get(R,T.length),w.init(),T.push(w),Ye.enabled===!0&&Ye.isPresenting===!0){let Be=C.xr.getDepthSensingMesh();Be!==null&&vd(Be,O,-1/0,C.sortObjects)}vd(R,O,0,C.sortObjects),w.finish(),F!==null&&F.updateLights(M.state.lightsArray),C.sortObjects===!0&&w.sort(Ee,ot),ct=Ye.enabled===!1||Ye.isPresenting===!1||Ye.hasDepthSensing()===!1,ct&&mt.addToRenderList(w,R),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),de===!0&&Ke.beginShadows();let Y=M.state.shadowsArray;if(st.render(Y,R,O),de===!0&&Ke.endShadows(),(X&&S.hasRenderPass())===!1){let Be=w.opaque,Pe=w.transmissive;if(M.setupLights(),O.isArrayCamera){let Ve=O.cameras;if(Pe.length>0)for(let Ze=0,yt=Ve.length;Ze<yt;Ze++){let Tt=Ve[Ze];sm(Be,Pe,R,Tt)}ct&&mt.render(R);for(let Ze=0,yt=Ve.length;Ze<yt;Ze++){let Tt=Ve[Ze];im(w,R,Tt,Tt.viewport)}}else Pe.length>0&&sm(Be,Pe,R,O),ct&&mt.render(R),im(w,R,O)}ie!==null&&V===0&&(Q.updateMultisampleRenderTarget(ie),Q.updateRenderTargetMipmap(ie)),X&&S.end(C),R.isScene===!0&&R.onAfterRender(C,R,O),Le.resetDefaultState(),$=-1,se=null,x.pop(),x.length>0?(M=x[x.length-1],Q.setTextureUnits(M.state.textureUnits),de===!0&&Ke.setGlobalState(C.clippingPlanes,M.state.camera)):M=null,T.pop(),T.length>0?w=T[T.length-1]:w=null,F!==null&&F.renderEnd()};function vd(R,O,K,X){if(R.visible===!1)return;if(R.layers.test(O.layers)){if(R.isGroup)K=R.renderOrder;else if(R.isLOD)R.autoUpdate===!0&&R.update(O);else if(R.isLightProbeGrid)M.pushLightProbeGrid(R);else if(R.isLight)M.pushLight(R),R.castShadow&&M.pushShadow(R);else if(R.isSprite){if(!R.frustumCulled||R.intersectsFrustum(le)){X&&it.setFromMatrixPosition(R.matrixWorld).applyMatrix4(pe);let Be=ae.update(R),Pe=R.material;Pe.visible&&w.push(R,Be,Pe,K,it.z,null,O)}}else if((R.isMesh||R.isLine||R.isPoints)&&(!R.frustumCulled||R.intersectsFrustum(le))){let Be=ae.update(R),Pe=R.material;if(X&&(R.boundingSphere!==void 0?(R.boundingSphere===null&&R.computeBoundingSphere(),it.copy(R.boundingSphere.center)):(Be.boundingSphere===null&&Be.computeBoundingSphere(),it.copy(Be.boundingSphere.center)),it.applyMatrix4(R.matrixWorld).applyMatrix4(pe)),Array.isArray(Pe)){let Ve=Be.groups;for(let Ze=0,yt=Ve.length;Ze<yt;Ze++){let Tt=Ve[Ze],We=Pe[Tt.materialIndex];We&&We.visible&&w.push(R,Be,We,K,it.z,Tt,O)}}else Pe.visible&&w.push(R,Be,Pe,K,it.z,null,O)}}let Ie=R.children;for(let Be=0,Pe=Ie.length;Be<Pe;Be++)vd(Ie[Be],O,K,X)}function im(R,O,K,X){let{opaque:Y,transmissive:Ie,transparent:Be}=R;M.setupLightsView(K),de===!0&&Ke.setGlobalState(C.clippingPlanes,K),X&&b.viewport(te.copy(X)),Y.length>0&&zc(Y,O,K),Ie.length>0&&zc(Ie,O,K),Be.length>0&&zc(Be,O,K),b.buffers.depth.setTest(!0),b.buffers.depth.setMask(!0),b.buffers.color.setMask(!0),b.setPolygonOffset(!1)}function sm(R,O,K,X){if((K.isScene===!0?K.overrideMaterial:null)!==null)return;if(M.state.transmissionRenderTarget[X.id]===void 0){let We=St.has("EXT_color_buffer_half_float")||St.has("EXT_color_buffer_float");M.state.transmissionRenderTarget[X.id]=new Qt(1,1,{generateMipmaps:!0,type:We?yn:Qn,minFilter:Gi,samples:Math.max(4,D.samples),stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Mt.workingColorSpace})}let Ie=M.state.transmissionRenderTarget[X.id],Be=X.viewport||te;Ie.setSize(Be.z*C.transmissionResolutionScale,Be.w*C.transmissionResolutionScale);let Pe=C.getRenderTarget(),Ve=C.getActiveCubeFace(),Ze=C.getActiveMipmapLevel();C.setRenderTarget(Ie),C.getClearColor(Ge),He=C.getClearAlpha(),He<1&&C.setClearColor(16777215,.5),C.clear(),ct&&mt.render(K);let yt=C.toneMapping;C.toneMapping=Ti;let Tt=X.viewport;if(X.viewport!==void 0&&(X.viewport=void 0),M.setupLightsView(X),de===!0&&Ke.setGlobalState(C.clippingPlanes,X),zc(R,K,X),Q.updateMultisampleRenderTarget(Ie),Q.updateRenderTargetMipmap(Ie),St.has("WEBGL_multisampled_render_to_texture")===!1){let We=!1;for(let Lt=0,pn=O.length;Lt<pn;Lt++){let Kt=O[Lt],{object:zt,geometry:Bn,material:Fe,group:Zn}=Kt;if(Fe.side===De&&zt.layers.test(X.layers)){let At=Fe.side;Fe.side=Ln,Fe.needsUpdate=!0,rm(zt,K,X,Bn,Fe,Zn),Fe.side=At,Fe.needsUpdate=!0,We=!0}}We===!0&&(Q.updateMultisampleRenderTarget(Ie),Q.updateRenderTargetMipmap(Ie))}C.setRenderTarget(Pe,Ve,Ze),C.setClearColor(Ge,He),Tt!==void 0&&(X.viewport=Tt),C.toneMapping=yt}function zc(R,O,K){let X=O.isScene===!0?O.overrideMaterial:null;for(let Y=0,Ie=R.length;Y<Ie;Y++){let Be=R[Y],{object:Pe,geometry:Ve,group:Ze}=Be,yt=Be.material;yt.allowOverride===!0&&X!==null&&(yt=X),Pe.layers.test(K.layers)&&rm(Pe,O,K,Ve,yt,Ze)}}function rm(R,O,K,X,Y,Ie){F!==null&&Y.isNodeMaterial&&F.setObject(R,Y),R.onBeforeRender(C,O,K,X,Y,Ie),R.modelViewMatrix.multiplyMatrices(K.matrixWorldInverse,R.matrixWorld),R.normalMatrix.getNormalMatrix(R.modelViewMatrix),Y.onBeforeRender(C,O,K,X,R,Ie),Y.transparent===!0&&Y.side===De&&Y.forceSinglePass===!1?(Y.side=Ln,Y.needsUpdate=!0,C.renderBufferDirect(K,O,X,Y,R,Ie),Y.side=zi,Y.needsUpdate=!0,C.renderBufferDirect(K,O,X,Y,R,Ie),Y.side=De):C.renderBufferDirect(K,O,X,Y,R,Ie),R.onAfterRender(C,O,K,X,Y,Ie)}function kc(R,O,K){O.isScene!==!0&&(O=tt);let X=Z.get(R),Y=M.state.lights,Ie=M.state.shadowsArray,Be=Y.state.version,Pe=Se.getParameters(R,Y.state,Ie,O,K,M.state.lightProbeGridArray),Ve=Se.getProgramCacheKey(Pe),Ze=X.programs;X.environment=R.isMeshStandardMaterial||R.isMeshLambertMaterial||R.isMeshPhongMaterial?O.environment:null,X.fog=O.fog;let yt=R.isMeshStandardMaterial||R.isMeshLambertMaterial&&!R.envMap||R.isMeshPhongMaterial&&!R.envMap;X.envMap=ge.get(R.envMap||X.environment,yt),X.envMapRotation=X.environment!==null&&R.envMap===null?O.environmentRotation:R.envMapRotation,Ze===void 0&&(R.addEventListener("dispose",Wi),Ze=new Map,X.programs=Ze);let Tt=Ze.get(Ve);if(Tt!==void 0){if(X.currentProgram===Tt&&X.lightsStateVersion===Be)return am(R,Pe),Tt}else Pe.uniforms=Se.getUniforms(R),F!==null&&R.isNodeMaterial&&F.build(R,K,Pe),R.onBeforeCompile(Pe,C),Tt=Se.acquireProgram(Pe,Ve),Ze.set(Ve,Tt),X.uniforms=Pe.uniforms;let We=X.uniforms;return(!R.isShaderMaterial&&!R.isRawShaderMaterial||R.clipping===!0)&&(We.clippingPlanes=Ke.uniform),am(R,Pe),X.needsLights=ox(R),X.lightsStateVersion=Be,X.needsLights&&(We.ambientLightColor.value=Y.state.ambient,We.lightProbe.value=Y.state.probe,We.sunLights.value=Y.state.sun,We.sunLightShadows.value=Y.state.sunShadow,We.directionalLights.value=Y.state.directional,We.directionalLightShadows.value=Y.state.directionalShadow,We.spotLights.value=Y.state.spot,We.spotLightShadows.value=Y.state.spotShadow,We.rectAreaLights.value=Y.state.rectArea,We.ltc_1.value=Y.state.rectAreaLTC1,We.ltc_2.value=Y.state.rectAreaLTC2,We.pointLights.value=Y.state.point,We.pointLightShadows.value=Y.state.pointShadow,We.hemisphereLights.value=Y.state.hemi,We.sunShadowMatrix.value=Y.state.sunShadowMatrix,We.sunShadowCascade.value=Y.state.sunShadowCascade,We.directionalShadowMatrix.value=Y.state.directionalShadowMatrix,We.spotLightMatrix.value=Y.state.spotLightMatrix,We.spotLightMap.value=Y.state.spotLightMap,We.pointShadowMatrix.value=Y.state.pointShadowMatrix),X.lightProbeGrid=M.state.lightProbeGridArray.length>0,X.currentProgram=Tt,X.uniformsList=null,Tt}function om(R){if(R.uniformsList===null){let O=R.currentProgram.getUniforms();R.uniformsList=ca.seqWithValue(O.seq,R.uniforms)}return R.uniformsList}function am(R,O){let K=Z.get(R);K.outputColorSpace=O.outputColorSpace,K.batching=O.batching,K.batchingColor=O.batchingColor,K.instancing=O.instancing,K.instancingColor=O.instancingColor,K.instancingMorph=O.instancingMorph,K.skinning=O.skinning,K.morphTargets=O.morphTargets,K.morphNormals=O.morphNormals,K.morphColors=O.morphColors,K.morphTargetsCount=O.morphTargetsCount,K.numClippingPlanes=O.numClippingPlanes,K.numIntersection=O.numClipIntersection,K.vertexAlphas=O.vertexAlphas,K.vertexTangents=O.vertexTangents,K.toneMapping=O.toneMapping}function ix(R,O){if(R.length===0)return null;if(R.length===1)return R[0].texture!==null?R[0]:null;y.setFromMatrixPosition(O.matrixWorld);for(let K=0,X=R.length;K<X;K++){let Y=R[K];if(Y.texture!==null&&Y.boundingBox.containsPoint(y))return Y}return null}function sx(R,O,K,X,Y){O.isScene!==!0&&(O=tt),Q.resetTextureUnits();let Ie=O.fog,Be=X.isMeshStandardMaterial||X.isMeshLambertMaterial||X.isMeshPhongMaterial?O.environment:null,Pe=ie===null?C.outputColorSpace:ie.isXRRenderTarget===!0?ie.texture.colorSpace:Mt.workingColorSpace,Ve=X.isMeshStandardMaterial||X.isMeshLambertMaterial&&!X.envMap||X.isMeshPhongMaterial&&!X.envMap,Ze=ge.get(X.envMap||Be,Ve),yt=X.vertexColors===!0&&!!K.attributes.color&&K.attributes.color.itemSize===4,Tt=!!K.attributes.tangent&&(!!X.normalMap||X.anisotropy>0),We=!!K.morphAttributes.position,Lt=!!K.morphAttributes.normal,pn=!!K.morphAttributes.color,Kt=Ti;X.toneMapped&&(ie===null||ie.isXRRenderTarget===!0)&&(Kt=C.toneMapping);let zt=K.morphAttributes.position||K.morphAttributes.normal||K.morphAttributes.color,Bn=zt!==void 0?zt.length:0,Fe=Z.get(X),Zn=M.state.lights;if(de===!0&&(fe===!0||R!==se)){let Vt=R===se&&X.id===$;Ke.setState(X,R,Vt)}let At=!1;X.version===Fe.__version?(Fe.needsLights&&Fe.lightsStateVersion!==Zn.state.version||Fe.outputColorSpace!==Pe||Y.isBatchedMesh&&Fe.batching===!1||!Y.isBatchedMesh&&Fe.batching===!0||Y.isBatchedMesh&&Fe.batchingColor===!0&&Y._colorsTexture===null||Y.isBatchedMesh&&Fe.batchingColor===!1&&Y._colorsTexture!==null||Y.isInstancedMesh&&Fe.instancing===!1||!Y.isInstancedMesh&&Fe.instancing===!0||Y.isSkinnedMesh&&Fe.skinning===!1||!Y.isSkinnedMesh&&Fe.skinning===!0||Y.isInstancedMesh&&Fe.instancingColor===!0&&Y.instanceColor===null||Y.isInstancedMesh&&Fe.instancingColor===!1&&Y.instanceColor!==null||Y.isInstancedMesh&&Fe.instancingMorph===!0&&Y.morphTexture===null||Y.isInstancedMesh&&Fe.instancingMorph===!1&&Y.morphTexture!==null||Fe.envMap!==Ze||X.fog===!0&&Fe.fog!==Ie||Fe.numClippingPlanes!==void 0&&(Fe.numClippingPlanes!==Ke.numPlanes||Fe.numIntersection!==Ke.numIntersection)||Fe.vertexAlphas!==yt||Fe.vertexTangents!==Tt||Fe.morphTargets!==We||Fe.morphNormals!==Lt||Fe.morphColors!==pn||Fe.toneMapping!==Kt||Fe.morphTargetsCount!==Bn||!!Fe.lightProbeGrid!=M.state.lightProbeGridArray.length>0)&&(At=!0):(At=!0,Fe.__version=X.version);let yi=Fe.currentProgram;At===!0&&(yi=kc(X,O,Y),F&&X.isNodeMaterial&&F.onUpdateProgram(X,yi,Fe));let Xi=!1,As=!1,Xr=!1,Ot=yi.getUniforms(),un=Fe.uniforms;if(b.useProgram(yi.program)&&(Xi=!0,As=!0,Xr=!0),X.id!==$&&($=X.id,As=!0),Fe.needsLights){let Vt=ix(M.state.lightProbeGridArray,Y);Fe.lightProbeGrid!==Vt&&(Fe.lightProbeGrid=Vt,As=!0)}if(Xi||se!==R){b.buffers.depth.getReversed()&&R.reversedDepth!==!0&&(R._reversedDepth=!0,R.updateProjectionMatrix()),Ot.setValue(B,"projectionMatrix",R.projectionMatrix),Ot.setValue(B,"viewMatrix",R.matrixWorldInverse);let Ps=Ot.map.cameraPosition;Ps!==void 0&&Ps.setValue(B,Me.setFromMatrixPosition(R.matrixWorld)),D.logarithmicDepthBuffer&&Ot.setValue(B,"logDepthBufFC",2/(Math.log(R.far+1)/Math.LN2)),(X.isMeshPhongMaterial||X.isMeshToonMaterial||X.isMeshLambertMaterial||X.isMeshBasicMaterial||X.isMeshStandardMaterial||X.isShaderMaterial)&&Ot.setValue(B,"isOrthographic",R.isOrthographicCamera===!0),se!==R&&(se=R,As=!0,Xr=!0)}if(Fe.needsLights&&(Zn.state.sunShadowMap.length>0&&Ot.setValue(B,"sunShadowMap",Zn.state.sunShadowMap,Q),Zn.state.directionalShadowMap.length>0&&Ot.setValue(B,"directionalShadowMap",Zn.state.directionalShadowMap,Q),Zn.state.spotShadowMap.length>0&&Ot.setValue(B,"spotShadowMap",Zn.state.spotShadowMap,Q),Zn.state.pointShadowMap.length>0&&Ot.setValue(B,"pointShadowMap",Zn.state.pointShadowMap,Q)),Y.isSkinnedMesh){Ot.setOptional(B,Y,"bindMatrix"),Ot.setOptional(B,Y,"bindMatrixInverse");let Vt=Y.skeleton;Vt&&(Vt.boneTexture===null&&Vt.computeBoneTexture(),Ot.setValue(B,"boneTexture",Vt.boneTexture,Q))}Y.isBatchedMesh&&(Ot.setOptional(B,Y,"batchingTexture"),Ot.setValue(B,"batchingTexture",Y._matricesTexture,Q),Ot.setOptional(B,Y,"batchingIdTexture"),Ot.setValue(B,"batchingIdTexture",Y._indirectTexture,Q),Ot.setOptional(B,Y,"batchingColorTexture"),Y._colorsTexture!==null&&Ot.setValue(B,"batchingColorTexture",Y._colorsTexture,Q));let Cs=K.morphAttributes;if((Cs.position!==void 0||Cs.normal!==void 0||Cs.color!==void 0)&&H.update(Y,K,yi),(As||Fe.receiveShadow!==Y.receiveShadow)&&(Fe.receiveShadow=Y.receiveShadow,Ot.setValue(B,"receiveShadow",Y.receiveShadow)),(X.isMeshStandardMaterial||X.isMeshLambertMaterial||X.isMeshPhongMaterial)&&X.envMap===null&&O.environment!==null&&(un.envMapIntensity.value=O.environmentIntensity),un.dfgLUT!==void 0&&(un.dfgLUT.value=YE()),As){if(Ot.setValue(B,"toneMappingExposure",C.toneMappingExposure),Fe.needsLights&&rx(un,Xr),Ie&&X.fog===!0&&Je.refreshFogUniforms(un,Ie),Je.refreshMaterialUniforms(un,X,oe,j,M.state.transmissionRenderTarget[R.id]),Fe.needsLights&&Fe.lightProbeGrid){let Vt=Fe.lightProbeGrid;un.probesSH.value=Vt.texture,un.probesMin.value.copy(Vt.boundingBox.min),un.probesMax.value.copy(Vt.boundingBox.max),un.probesResolution.value.copy(Vt.resolution)}ca.upload(B,om(Fe),un,Q)}if(X.isShaderMaterial&&X.uniformsNeedUpdate===!0&&(ca.upload(B,om(Fe),un,Q),X.uniformsNeedUpdate=!1),X.isSpriteMaterial&&Ot.setValue(B,"center",Y.center),Ot.setValue(B,"modelViewMatrix",Y.modelViewMatrix),Ot.setValue(B,"normalMatrix",Y.normalMatrix),Ot.setValue(B,"modelMatrix",Y.matrixWorld),X.uniformsGroups!==void 0){let Vt=X.uniformsGroups;for(let Ps=0,Yr=Vt.length;Ps<Yr;Ps++){let cm=Vt[Ps];ue.update(cm,yi),ue.bind(cm,yi)}}return yi}function rx(R,O){R.ambientLightColor.needsUpdate=O,R.lightProbe.needsUpdate=O,R.sunLights.needsUpdate=O,R.sunLightShadows.needsUpdate=O,R.directionalLights.needsUpdate=O,R.directionalLightShadows.needsUpdate=O,R.pointLights.needsUpdate=O,R.pointLightShadows.needsUpdate=O,R.spotLights.needsUpdate=O,R.spotLightShadows.needsUpdate=O,R.rectAreaLights.needsUpdate=O,R.hemisphereLights.needsUpdate=O}function ox(R){return R.isMeshLambertMaterial||R.isMeshToonMaterial||R.isMeshPhongMaterial||R.isMeshStandardMaterial||R.isShadowMaterial||R.isShaderMaterial&&R.lights===!0}this.getActiveCubeFace=function(){return z},this.getActiveMipmapLevel=function(){return V},this.getRenderTarget=function(){return ie},this.setRenderTargetTextures=function(R,O,K){let X=Z.get(R);X.__autoAllocateDepthBuffer=R.resolveDepthBuffer===!1,X.__autoAllocateDepthBuffer===!1&&(X.__useRenderToTexture=!1),Z.get(R.texture).__webglTexture=O,Z.get(R.depthTexture).__webglTexture=X.__autoAllocateDepthBuffer?void 0:K,X.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(R,O){let K=Z.get(R);K.__webglFramebuffer=O,K.__useDefaultFramebuffer=O===void 0},this.setRenderTarget=function(R,O=0,K=0){ie=R,z=O,V=K;let X=null,Y=!1,Ie=!1;if(R){let Pe=Z.get(R);if(Pe.__useDefaultFramebuffer!==void 0){b.bindFramebuffer(B.FRAMEBUFFER,Pe.__webglFramebuffer),te.copy(R.viewport),Xe.copy(R.scissor),Ue=R.scissorTest,b.viewport(te),b.scissor(Xe),b.setScissorTest(Ue),$=-1;return}else if(Pe.__webglFramebuffer===void 0)Q.setupRenderTarget(R);else if(Pe.__hasExternalTextures)Q.rebindTextures(R,Z.get(R.texture).__webglTexture,Z.get(R.depthTexture).__webglTexture);else if(R.depthBuffer){let yt=R.depthTexture;if(Pe.__boundDepthTexture!==yt){if(yt!==null&&Z.has(yt)&&(R.width!==yt.image.width||R.height!==yt.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");Q.setupDepthRenderbuffer(R)}}let Ve=R.texture;(Ve.isData3DTexture||Ve.isDataArrayTexture||Ve.isCompressedArrayTexture)&&(Ie=!0);let Ze=Z.get(R).__webglFramebuffer;R.isWebGLCubeRenderTarget?(Array.isArray(Ze[O])?X=Ze[O][K]:X=Ze[O],Y=!0):R.samples>0&&Q.useMultisampledRTT(R)===!1?X=Z.get(R).__webglMultisampledFramebuffer:Array.isArray(Ze)?X=Ze[K]:X=Ze,te.copy(R.viewport),Xe.copy(R.scissor),Ue=R.scissorTest}else te.copy(Ne).multiplyScalar(oe).floor(),Xe.copy(lt).multiplyScalar(oe).floor(),Ue=Ft;if(K!==0&&(X=I),b.bindFramebuffer(B.FRAMEBUFFER,X)&&b.drawBuffers(R,X),b.viewport(te),b.scissor(Xe),b.setScissorTest(Ue),Y){let Pe=Z.get(R.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_CUBE_MAP_POSITIVE_X+O,Pe.__webglTexture,K)}else if(Ie){let Pe=O;for(let Ve=0;Ve<R.textures.length;Ve++){let Ze=Z.get(R.textures[Ve]);B.framebufferTextureLayer(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0+Ve,Ze.__webglTexture,K,Pe)}}else if(R!==null&&K!==0){let Pe=Z.get(R.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,Pe.__webglTexture,K)}$=-1};function lm(R){let O=Z.get(R);return(O.__readFormat!==R.format||O.__readType!==R.type)&&(O.__readFormat=R.format,O.__readType=R.type,O.__formatReadable=D.textureFormatReadable(R.format),O.__typeReadable=D.textureTypeReadable(R.type)),O}this.readRenderTargetPixels=function(R,O,K,X,Y,Ie,Be,Pe=0){if(!(R&&R.isWebGLRenderTarget)){qe("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Ve=Z.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&Be!==void 0&&(Ve=Ve[Be]),Ve){b.bindFramebuffer(B.FRAMEBUFFER,Ve);try{let Ze=R.textures[Pe],yt=Ze.format,Tt=Ze.type;R.textures.length>1&&B.readBuffer(B.COLOR_ATTACHMENT0+Pe);let We=lm(Ze);if(We.__formatReadable===!1){qe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(We.__typeReadable===!1){qe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}O>=0&&O<=R.width-X&&K>=0&&K<=R.height-Y&&B.readPixels(O,K,X,Y,Re.convert(yt),Re.convert(Tt),Ie)}finally{let Ze=ie!==null?Z.get(ie).__webglFramebuffer:null;b.bindFramebuffer(B.FRAMEBUFFER,Ze)}}},this.readRenderTargetPixelsAsync=async function(R,O,K,X,Y,Ie,Be,Pe=0){if(!(R&&R.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Ve=Z.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&Be!==void 0&&(Ve=Ve[Be]),Ve)if(O>=0&&O<=R.width-X&&K>=0&&K<=R.height-Y){b.bindFramebuffer(B.FRAMEBUFFER,Ve);let Ze=R.textures[Pe],yt=Ze.format,Tt=Ze.type;R.textures.length>1&&B.readBuffer(B.COLOR_ATTACHMENT0+Pe);let We=lm(Ze);if(We.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(We.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");let Lt=B.createBuffer();B.bindBuffer(B.PIXEL_PACK_BUFFER,Lt),B.bufferData(B.PIXEL_PACK_BUFFER,Ie.byteLength,B.STREAM_READ),B.readPixels(O,K,X,Y,Re.convert(yt),Re.convert(Tt),0),B.bindBuffer(B.PIXEL_PACK_BUFFER,null);let pn=ie!==null?Z.get(ie).__webglFramebuffer:null;b.bindFramebuffer(B.FRAMEBUFFER,pn);let Kt=B.fenceSync(B.SYNC_GPU_COMMANDS_COMPLETE,0);return B.flush(),await dg(B,Kt,4),B.bindBuffer(B.PIXEL_PACK_BUFFER,Lt),B.getBufferSubData(B.PIXEL_PACK_BUFFER,0,Ie),B.bindBuffer(B.PIXEL_PACK_BUFFER,null),B.deleteBuffer(Lt),B.deleteSync(Kt),Ie}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(R,O=null,K=0){let X=Math.pow(2,-K),Y=Math.floor(R.image.width*X),Ie=Math.floor(R.image.height*X),Be=O!==null?O.x:0,Pe=O!==null?O.y:0;Q.setTexture2D(R,0),B.copyTexSubImage2D(B.TEXTURE_2D,K,0,0,Be,Pe,Y,Ie),b.unbindTexture()},this.copyTextureToTexture=function(R,O,K=null,X=null,Y=0,Ie=0){let Be,Pe,Ve,Ze,yt,Tt,We,Lt,pn,Kt=R.isCompressedTexture?R.mipmaps[Ie]:R.image;if(K!==null)Be=K.max.x-K.min.x,Pe=K.max.y-K.min.y,Ve=K.isBox3?K.max.z-K.min.z:1,Ze=K.min.x,yt=K.min.y,Tt=K.isBox3?K.min.z:0;else{let un=Math.pow(2,-Y);Be=Math.floor(Kt.width*un),Pe=Math.floor(Kt.height*un),R.isDataArrayTexture?Ve=Kt.depth:R.isData3DTexture?Ve=Math.floor(Kt.depth*un):Ve=1,Ze=0,yt=0,Tt=0}X!==null?(We=X.x,Lt=X.y,pn=X.z):(We=0,Lt=0,pn=0);let zt=Re.convert(O.format),Bn=Re.convert(O.type),Fe;O.isData3DTexture?(Q.setTexture3D(O,0),Fe=B.TEXTURE_3D):O.isDataArrayTexture||O.isCompressedArrayTexture?(Q.setTexture2DArray(O,0),Fe=B.TEXTURE_2D_ARRAY):(Q.setTexture2D(O,0),Fe=B.TEXTURE_2D),b.activeTexture(B.TEXTURE0),b.pixelStorei(B.UNPACK_FLIP_Y_WEBGL,O.flipY),b.pixelStorei(B.UNPACK_PREMULTIPLY_ALPHA_WEBGL,O.premultiplyAlpha),b.pixelStorei(B.UNPACK_ALIGNMENT,O.unpackAlignment);let Zn=b.getParameter(B.UNPACK_ROW_LENGTH),At=b.getParameter(B.UNPACK_IMAGE_HEIGHT),yi=b.getParameter(B.UNPACK_SKIP_PIXELS),Xi=b.getParameter(B.UNPACK_SKIP_ROWS),As=b.getParameter(B.UNPACK_SKIP_IMAGES);b.pixelStorei(B.UNPACK_ROW_LENGTH,Kt.width),b.pixelStorei(B.UNPACK_IMAGE_HEIGHT,Kt.height),b.pixelStorei(B.UNPACK_SKIP_PIXELS,Ze),b.pixelStorei(B.UNPACK_SKIP_ROWS,yt),b.pixelStorei(B.UNPACK_SKIP_IMAGES,Tt);let Xr=R.isDataArrayTexture||R.isData3DTexture,Ot=O.isDataArrayTexture||O.isData3DTexture;if(R.isDepthTexture){let un=Z.get(R),Cs=Z.get(O),Vt=Z.get(un.__renderTarget),Ps=Z.get(Cs.__renderTarget);b.bindFramebuffer(B.READ_FRAMEBUFFER,Vt.__webglFramebuffer),b.bindFramebuffer(B.DRAW_FRAMEBUFFER,Ps.__webglFramebuffer);for(let Yr=0;Yr<Ve;Yr++)Xr&&(B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,Z.get(R).__webglTexture,Y,Tt+Yr),B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,Z.get(O).__webglTexture,Ie,pn+Yr)),B.blitFramebuffer(Ze,yt,Be,Pe,We,Lt,Be,Pe,B.DEPTH_BUFFER_BIT,B.NEAREST);b.bindFramebuffer(B.READ_FRAMEBUFFER,null),b.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else if(Y!==0||R.isRenderTargetTexture||Z.has(R)){let un=Z.get(R),Cs=Z.get(O);b.bindFramebuffer(B.READ_FRAMEBUFFER,P),b.bindFramebuffer(B.DRAW_FRAMEBUFFER,U);for(let Vt=0;Vt<Ve;Vt++)Xr?B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,un.__webglTexture,Y,Tt+Vt):B.framebufferTexture2D(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,un.__webglTexture,Y),Ot?B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,Cs.__webglTexture,Ie,pn+Vt):B.framebufferTexture2D(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,Cs.__webglTexture,Ie),Y!==0?B.blitFramebuffer(Ze,yt,Be,Pe,We,Lt,Be,Pe,B.COLOR_BUFFER_BIT,B.NEAREST):Ot?B.copyTexSubImage3D(Fe,Ie,We,Lt,pn+Vt,Ze,yt,Be,Pe):B.copyTexSubImage2D(Fe,Ie,We,Lt,Ze,yt,Be,Pe);b.bindFramebuffer(B.READ_FRAMEBUFFER,null),b.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else Ot?R.isDataTexture||R.isData3DTexture?B.texSubImage3D(Fe,Ie,We,Lt,pn,Be,Pe,Ve,zt,Bn,Kt.data):O.isCompressedArrayTexture?B.compressedTexSubImage3D(Fe,Ie,We,Lt,pn,Be,Pe,Ve,zt,Kt.data):B.texSubImage3D(Fe,Ie,We,Lt,pn,Be,Pe,Ve,zt,Bn,Kt):R.isDataTexture?B.texSubImage2D(B.TEXTURE_2D,Ie,We,Lt,Be,Pe,zt,Bn,Kt.data):R.isCompressedTexture?B.compressedTexSubImage2D(B.TEXTURE_2D,Ie,We,Lt,Kt.width,Kt.height,zt,Kt.data):B.texSubImage2D(B.TEXTURE_2D,Ie,We,Lt,Be,Pe,zt,Bn,Kt);b.pixelStorei(B.UNPACK_ROW_LENGTH,Zn),b.pixelStorei(B.UNPACK_IMAGE_HEIGHT,At),b.pixelStorei(B.UNPACK_SKIP_PIXELS,yi),b.pixelStorei(B.UNPACK_SKIP_ROWS,Xi),b.pixelStorei(B.UNPACK_SKIP_IMAGES,As),Ie===0&&O.generateMipmaps&&B.generateMipmap(Fe),b.unbindTexture()},this.initRenderTarget=function(R){Z.get(R).__webglFramebuffer===void 0&&Q.setupRenderTarget(R)},this.initTexture=function(R){R.isCubeTexture?Q.setTextureCube(R,0):R.isData3DTexture?Q.setTexture3D(R,0):R.isDataArrayTexture||R.isCompressedArrayTexture?Q.setTexture2DArray(R,0):Q.setTexture2D(R,0),b.unbindTexture()},this.resetState=function(){z=0,V=0,ie=null,b.reset(),Le.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return si}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=Mt._getDrawingBufferColorSpace(e),t.unpackColorSpace=Mt._getUnpackColorSpace()}};var Qg={type:"change"},Ap={type:"start"},t_={type:"end"},id=new Fi,e_=new ii,qE=Math.cos(70*Br.DEG2RAD),An=new A,ci=2*Math.PI,Bt={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},Rp=1e-6,sd=class extends Vo{constructor(e,t=null){super(e,t),this.state=Bt.NONE,this.target=new A,this.cursor=new A,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:bs.ROTATE,MIDDLE:bs.DOLLY,RIGHT:bs.PAN},this.touches={ONE:Es.ROTATE,TWO:Es.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="auto",this._domElementKeyEvents=null,this._lastPosition=new A,this._lastQuaternion=new $t,this._lastTargetPosition=new A,this._quat=new $t().setFromUnitVectors(e.up,new A(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new Ir,this._sphericalDelta=new Ir,this._scale=1,this._panOffset=new A,this._rotateStart=new J,this._rotateEnd=new J,this._rotateDelta=new J,this._panStart=new J,this._panEnd=new J,this._panDelta=new J,this._dollyStart=new J,this._dollyEnd=new J,this._dollyDelta=new J,this._dollyDirection=new A,this._mouse=new J,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=JE.bind(this),this._onPointerDown=ZE.bind(this),this._onPointerUp=KE.bind(this),this._onContextMenu=iS.bind(this),this._onMouseWheel=QE.bind(this),this._onKeyDown=eS.bind(this),this._onTouchStart=tS.bind(this),this._onTouchMove=nS.bind(this),this._onMouseDown=$E.bind(this),this._onMouseMove=jE.bind(this),this._interceptControlDown=sS.bind(this),this._interceptControlUp=rS.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}set cursorStyle(e){this._cursorStyle=e,e==="grab"?this.domElement.style.cursor="grab":this.domElement.style.cursor="auto"}get cursorStyle(){return this._cursorStyle}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.state=Bt.NONE,this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents();let e=this.domElement.getRootNode();e.removeEventListener("keydown",this._interceptControlDown,{capture:!0}),e.removeEventListener("keyup",this._interceptControlUp,{capture:!0}),this._controlActive=!1,this._pointers.length=0,this._pointerPositions={},this.domElement.style.touchAction="",this.domElement.style.cursor="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Qg),this.update(),this.state=Bt.NONE}pan(e,t){this._pan(e,t),this.update()}dollyIn(e){this._dollyIn(e),this.update()}dollyOut(e){this._dollyOut(e),this.update()}rotateLeft(e){this._rotateLeft(e),this.update()}rotateUp(e){this._rotateUp(e),this.update()}update(e=null){let t=this.object.position;An.copy(t).sub(this.target),An.applyQuaternion(this._quat),this._spherical.setFromVector3(An),this.autoRotate&&this.state===Bt.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,s=this.maxAzimuthAngle;isFinite(n)&&isFinite(s)&&(n<-Math.PI?n+=ci:n>Math.PI&&(n-=ci),s<-Math.PI?s+=ci:s>Math.PI&&(s-=ci),n<=s?this._spherical.theta=Math.max(n,Math.min(s,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+s)/2?Math.max(n,this._spherical.theta):Math.min(s,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let r=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{let o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),r=o!=this._spherical.radius}if(An.setFromSpherical(this._spherical),An.applyQuaternion(this._quatInverse),t.copy(this.target).add(An),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){let a=An.length();o=this._clampDistance(a*this._scale);let l=a-o;this.object.position.addScaledVector(this._dollyDirection,l),this.object.updateMatrixWorld(),r=!!l}else if(this.object.isOrthographicCamera){let a=new A(this._mouse.x,this._mouse.y,0);a.unproject(this.object);let l=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),r=l!==this.object.zoom;let c=new A(this._mouse.x,this._mouse.y,0);c.unproject(this.object),this.object.position.sub(c).add(a),this.object.updateMatrixWorld(),o=An.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(id.origin.copy(this.object.position),id.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(id.direction))<qE?this.object.lookAt(this.target):(e_.setFromNormalAndCoplanarPoint(this.object.up,this.target),id.intersectPlane(e_,this.target))))}else if(this.object.isOrthographicCamera){let o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),r=!0)}return this._scale=1,this._performCursorZoom=!1,r||this._lastPosition.distanceToSquared(this.object.position)>Rp||8*(1-this._lastQuaternion.dot(this.object.quaternion))>Rp||this._lastTargetPosition.distanceToSquared(this.target)>Rp?(this.dispatchEvent(Qg),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?ci/60*this.autoRotateSpeed*e:ci/60/60*this.autoRotateSpeed}_getZoomScale(e){let t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){An.setFromMatrixColumn(t,0),An.multiplyScalar(-e),this._panOffset.add(An)}_panUp(e,t){this.screenSpacePanning===!0?An.setFromMatrixColumn(t,1):(An.setFromMatrixColumn(t,0),An.crossVectors(this.object.up,An)),An.multiplyScalar(e),this._panOffset.add(An)}_pan(e,t){let n=this.domElement;if(this.object.isPerspectiveCamera){let s=this.object.position;An.copy(s).sub(this.target);let r=An.length();r*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*r/n.clientHeight,this.object.matrix),this._panUp(2*t*r/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;let n=this.domElement.getBoundingClientRect(),s=e-n.left,r=t-n.top,o=n.width,a=n.height;this._mouse.x=s/o*2-1,this._mouse.y=-(r/a)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(ci*this._rotateDelta.x/t.clientHeight),this._rotateUp(ci*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(ci*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-ci*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(ci*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-ci*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._rotateStart.set(n,s)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panStart.set(n,s)}}_handleTouchStartDolly(e){let t=this._getSecondPointerPosition(e),n=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(n*n+s*s);this._dollyStart.set(0,r)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{let n=this._getSecondPointerPosition(e),s=.5*(e.pageX+n.x),r=.5*(e.pageY+n.y);this._rotateEnd.set(s,r)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(ci*this._rotateDelta.x/t.clientHeight),this._rotateUp(ci*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),s=.5*(e.pageY+t.y);this._panEnd.set(n,s)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){let t=this._getSecondPointerPosition(e),n=e.pageX-t.x,s=e.pageY-t.y,r=Math.sqrt(n*n+s*s);this._dollyEnd.set(0,r),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);let o=(e.pageX+t.x)*.5,a=(e.pageY+t.y)*.5;this._updateZoomParameters(o,a)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new J,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){let t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){let t=e.deltaMode,n={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}};function ZE(i){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(i.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(i)&&(this._addPointer(i),i.pointerType==="touch"?this._onTouchStart(i):this._onMouseDown(i),this._cursorStyle==="grab"&&(this.domElement.style.cursor="grabbing")))}function JE(i){this.enabled!==!1&&(i.pointerType==="touch"?this._onTouchMove(i):this._onMouseMove(i))}function KE(i){switch(this._removePointer(i),this._pointers.length){case 0:this.domElement.releasePointerCapture(i.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(t_),this.state=Bt.NONE,this._cursorStyle==="grab"&&(this.domElement.style.cursor="grab");break;case 1:let e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function $E(i){let e;switch(i.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case bs.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(i),this.state=Bt.DOLLY;break;case bs.ROTATE:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=Bt.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=Bt.ROTATE}break;case bs.PAN:if(i.ctrlKey||i.metaKey||i.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(i),this.state=Bt.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(i),this.state=Bt.PAN}break;default:this.state=Bt.NONE}this.state!==Bt.NONE&&this.dispatchEvent(Ap)}function jE(i){switch(this.state){case Bt.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(i);break;case Bt.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(i);break;case Bt.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(i);break}}function QE(i){this.enabled===!1||this.enableZoom===!1||this.state!==Bt.NONE||(i.preventDefault(),this.dispatchEvent(Ap),this._handleMouseWheel(this._customWheelEvent(i)),this.dispatchEvent(t_))}function eS(i){this.enabled!==!1&&this._handleKeyDown(i)}function tS(i){switch(this._trackPointer(i),this._pointers.length){case 1:switch(this.touches.ONE){case Es.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(i),this.state=Bt.TOUCH_ROTATE;break;case Es.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(i),this.state=Bt.TOUCH_PAN;break;default:this.state=Bt.NONE}break;case 2:switch(this.touches.TWO){case Es.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(i),this.state=Bt.TOUCH_DOLLY_PAN;break;case Es.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(i),this.state=Bt.TOUCH_DOLLY_ROTATE;break;default:this.state=Bt.NONE}break;default:this.state=Bt.NONE}this.state!==Bt.NONE&&this.dispatchEvent(Ap)}function nS(i){switch(this._trackPointer(i),this.state){case Bt.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(i),this.update();break;case Bt.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(i),this.update();break;case Bt.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(i),this.update();break;case Bt.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(i),this.update();break;default:this.state=Bt.NONE}}function iS(i){this.enabled!==!1&&i.preventDefault()}function sS(i){i.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function rS(i){i.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}var ua={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};var xi=class{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}},oS=new ji(-1,1,1,-1,0,1),Cp=class extends ke{constructor(){super(),this.setAttribute("position",new _e([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new _e([0,2,0,0,2,0],2))}},aS=new Cp,js=class{constructor(e){this._mesh=new W(aS,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,oS)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}};var rd=class extends xi{constructor(e,t="tDiffuse"){super(),this.textureID=t,this.uniforms=null,this.material=null,e instanceof xt?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=wi.clone(e.uniforms),this.material=new xt({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this._fsQuad=new js(this.material)}render(e,t,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this._fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}};var Lc=class extends xi{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,n){let s=e.getContext(),r=e.state;r.buffers.color.setMask(!1),r.buffers.depth.setMask(!1),r.buffers.color.setLocked(!0),r.buffers.depth.setLocked(!0);let o,a;this.inverse?(o=0,a=1):(o=1,a=0),r.buffers.stencil.setTest(!0),r.buffers.stencil.setOp(s.REPLACE,s.REPLACE,s.REPLACE),r.buffers.stencil.setFunc(s.ALWAYS,o,4294967295),r.buffers.stencil.setClear(a),r.buffers.stencil.setLocked(!0),e.setRenderTarget(n),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),r.buffers.color.setLocked(!1),r.buffers.depth.setLocked(!1),r.buffers.color.setMask(!0),r.buffers.depth.setMask(!0),r.buffers.stencil.setLocked(!1),r.buffers.stencil.setFunc(s.EQUAL,1,4294967295),r.buffers.stencil.setOp(s.KEEP,s.KEEP,s.KEEP),r.buffers.stencil.setLocked(!0)}},od=class extends xi{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}};var ad=class{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){let n=e.getSize(new J);this._width=n.width,this._height=n.height,t=new Qt(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:yn}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new rd(ua),this.copyPass.material.blending=gi,this.timer=new Pr}swapBuffers(){let e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){let t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){this.timer.update(),e===void 0&&(e=this.timer.getDelta());let t=this.renderer.getRenderTarget(),n=!1;for(let s=0,r=this.passes.length;s<r;s++){let o=this.passes[s];if(o.enabled!==!1){if(o.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(s),o.render(this.renderer,this.writeBuffer,this.readBuffer,e,n),o.needsSwap){if(n){let a=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(a.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),l.setFunc(a.EQUAL,1,4294967295)}this.swapBuffers()}Lc!==void 0&&(o instanceof Lc?n=!0:o instanceof od&&(n=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){let t=this.renderer.getSize(new J);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;let n=this._width*this._pixelRatio,s=this._height*this._pixelRatio;this.renderTarget1.setSize(n,s),this.renderTarget2.setSize(n,s);for(let r=0;r<this.passes.length;r++)this.passes[r].setSize(n,s)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}};var ld=class extends xi{constructor(e,t,n=null,s=null,r=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=n,this.clearColor=s,this.clearAlpha=r,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this.isRenderPass=!0,this._oldClearColor=new q}render(e,t,n){let s=e.autoClear;e.autoClear=!1;let r,o;this.overrideMaterial!==null&&(o=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(r=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(r),this.overrideMaterial!==null&&(this.scene.overrideMaterial=o),e.autoClear=s}};var n_={name:"LuminosityHighPassShader",uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new q(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};var da=class i extends xi{constructor(e,t=1,n,s){super(),this.strength=t,this.radius=n,this.threshold=s,this.resolution=e!==void 0?new J(e.x,e.y):new J(256,256),this.clearColor=new q(0,0,0),this.needsSwap=!1,this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);this.renderTargetBright=new Qt(r,o,{type:yn,depthBuffer:!1}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let h=0;h<this.nMips;h++){let u=new Qt(r,o,{type:yn,depthBuffer:!1});u.texture.name="UnrealBloomPass.h"+h,u.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(u);let d=new Qt(r,o,{type:yn,depthBuffer:!1});d.texture.name="UnrealBloomPass.v"+h,d.texture.generateMipmaps=!1,this.renderTargetsVertical.push(d),r=Math.round(r/2),o=Math.round(o/2)}let a=n_;this.highPassUniforms=wi.clone(a.uniforms),this.highPassUniforms.luminosityThreshold.value=s,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new xt({uniforms:this.highPassUniforms,vertexShader:a.vertexShader,fragmentShader:a.fragmentShader}),this.separableBlurMaterials=[];let l=[6,10,14,18,22];r=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);for(let h=0;h<this.nMips;h++)this.separableBlurMaterials.push(this._getSeparableBlurMaterial(l[h])),this.separableBlurMaterials[h].uniforms.invSize.value=new J(1/r,1/o),r=Math.round(r/2),o=Math.round(o/2);this.compositeMaterial=this._getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;let c=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=c,this.bloomTintColors=[new A(1,1,1),new A(1,1,1),new A(1,1,1),new A(1,1,1),new A(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,this.copyUniforms=wi.clone(ua.uniforms),this.blendMaterial=new xt({uniforms:this.copyUniforms,vertexShader:ua.vertexShader,fragmentShader:ua.fragmentShader,premultipliedAlpha:!0,blending:wt,depthTest:!1,depthWrite:!1,transparent:!0}),this._oldClearColor=new q,this._oldClearAlpha=1,this._basic=new Qe,this._fsQuad=new js(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this._basic.dispose(),this._fsQuad.dispose()}setSize(e,t){let n=Math.round(e/2),s=Math.round(t/2);this.renderTargetBright.setSize(n,s);for(let r=0;r<this.nMips;r++)this.renderTargetsHorizontal[r].setSize(n,s),this.renderTargetsVertical[r].setSize(n,s),this.separableBlurMaterials[r].uniforms.invSize.value=new J(1/n,1/s),n=Math.round(n/2),s=Math.round(s/2)}render(e,t,n,s,r){e.getClearColor(this._oldClearColor),this._oldClearAlpha=e.getClearAlpha();let o=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),r&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this._fsQuad.material=this._basic,this._basic.map=n.texture,e.setRenderTarget(null),e.clear(),this._fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this._fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this._fsQuad.render(e);let a=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this._fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=a.texture,this.separableBlurMaterials[l].uniforms.direction.value=i.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[l]),e.clear(),this._fsQuad.render(e),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=i.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[l]),e.clear(),this._fsQuad.render(e),a=this.renderTargetsVertical[l];this._fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this._fsQuad.render(e),this._fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,r&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(n),this._fsQuad.render(e)),e.setClearColor(this._oldClearColor,this._oldClearAlpha),e.autoClear=o}_getSeparableBlurMaterial(e){let t=[],n=e/3;for(let o=0;o<e;o++)t.push(.39894*Math.exp(-.5*o*o/(n*n))/n);let s=[],r=[];for(let o=1;o<e;o+=2){let a=t[o],l=o+1<e?t[o+1]:0,c=a+l;s.push((o*a+(o+1)*l)/c),r.push(c)}return new xt({defines:{KERNEL_PAIRS:s.length},uniforms:{colorTexture:{value:null},invSize:{value:new J(.5,.5)},direction:{value:new J(.5,.5)},centerWeight:{value:t[0]},gaussianOffsets:{value:s},gaussianWeights:{value:r}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				#include <common>

				varying vec2 vUv;

				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float centerWeight;
				uniform float gaussianOffsets[KERNEL_PAIRS];
				uniform float gaussianWeights[KERNEL_PAIRS];

				void main() {

					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * centerWeight;

					for ( int i = 0; i < KERNEL_PAIRS; i ++ ) {

						vec2 uvOffset = direction * invSize * gaussianOffsets[ i ];
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += ( sample1 + sample2 ) * gaussianWeights[ i ];

					}

					gl_FragColor = vec4( diffuseSum, 1.0 );

				}`})}_getCompositeMaterial(e){return new xt({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`

				varying vec2 vUv;

				void main() {

					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

				}`,fragmentShader:`

				varying vec2 vUv;

				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor( const in float factor ) {

					float mirrorFactor = 1.2 - factor;
					return mix( factor, mirrorFactor, bloomRadius );

				}

				void main() {

					// 3.0 for backwards compatibility with previous alpha-based intensity
					vec3 bloom = 3.0 * bloomStrength * (
						lerpBloomFactor( bloomFactors[ 0 ] ) * bloomTintColors[ 0 ] * texture2D( blurTexture1, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 1 ] ) * bloomTintColors[ 1 ] * texture2D( blurTexture2, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 2 ] ) * bloomTintColors[ 2 ] * texture2D( blurTexture3, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 3 ] ) * bloomTintColors[ 3 ] * texture2D( blurTexture4, vUv ).rgb +
						lerpBloomFactor( bloomFactors[ 4 ] ) * bloomTintColors[ 4 ] * texture2D( blurTexture5, vUv ).rgb
					);

					float bloomAlpha = max( bloom.r, max( bloom.g, bloom.b ) );
					gl_FragColor = vec4( bloom, bloomAlpha );

				}`})}};da.BlurDirectionX=new J(1,0);da.BlurDirectionY=new J(0,1);var Nc={name:"OutputShader",uniforms:{tDiffuse:{value:null},toneMappingExposure:{value:1}},vertexShader:`
		precision highp float;

		uniform mat4 modelViewMatrix;
		uniform mat4 projectionMatrix;

		attribute vec3 position;
		attribute vec2 uv;

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		precision highp float;

		uniform sampler2D tDiffuse;

		#include <tonemapping_pars_fragment>
		#include <colorspace_pars_fragment>

		varying vec2 vUv;

		void main() {

			gl_FragColor = texture2D( tDiffuse, vUv );

			// tone mapping

			#ifdef LINEAR_TONE_MAPPING

				gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );

			#elif defined( REINHARD_TONE_MAPPING )

				gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );

			#elif defined( CINEON_TONE_MAPPING )

				gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );

			#elif defined( ACES_FILMIC_TONE_MAPPING )

				gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );

			#elif defined( AGX_TONE_MAPPING )

				gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );

			#elif defined( NEUTRAL_TONE_MAPPING )

				gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );

			#elif defined( CUSTOM_TONE_MAPPING )

				gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );

			#endif

			// color space

			#ifdef SRGB_TRANSFER

				gl_FragColor = sRGBTransferOETF( gl_FragColor );

			#endif

		}`};var cd=class extends xi{constructor(){super(),this.isOutputPass=!0,this.uniforms=wi.clone(Nc.uniforms),this.material=new Ws({name:Nc.name,uniforms:this.uniforms,vertexShader:Nc.vertexShader,fragmentShader:Nc.fragmentShader}),this._fsQuad=new js(this.material),this._outputColorSpace=null,this._toneMapping=null}render(e,t,n){this.uniforms.tDiffuse.value=n.texture,this.uniforms.toneMappingExposure.value=e.toneMappingExposure,(this._outputColorSpace!==e.outputColorSpace||this._toneMapping!==e.toneMapping)&&(this._outputColorSpace=e.outputColorSpace,this._toneMapping=e.toneMapping,this.material.defines={},Mt.getTransfer(this._outputColorSpace)===Ct&&(this.material.defines.SRGB_TRANSFER=""),this._toneMapping===Yo?this.material.defines.LINEAR_TONE_MAPPING="":this._toneMapping===qo?this.material.defines.REINHARD_TONE_MAPPING="":this._toneMapping===Zo?this.material.defines.CINEON_TONE_MAPPING="":this._toneMapping===Jo?this.material.defines.ACES_FILMIC_TONE_MAPPING="":this._toneMapping===$o?this.material.defines.AGX_TONE_MAPPING="":this._toneMapping===Js?this.material.defines.NEUTRAL_TONE_MAPPING="":this._toneMapping===Ko&&(this.material.defines.CUSTOM_TONE_MAPPING=""),this.material.needsUpdate=!0),this.renderToScreen===!0?(e.setRenderTarget(null),this._fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this._fsQuad.render(e))}dispose(){this.material.dispose(),this._fsQuad.dispose()}};var qt={skyTop:"#8fd6ee",skyUpper:"#b9e2f5",skyMid:"#efd1ea",skyLow:"#ffd4c8",skyFloor:"#ffc6ae",sun:"#fff4c9",sunGlow:"#ffcf9a",cloudCream:"#fff8ee",cloudMilk:"#fff1e8",cloudPeach:"#ffd7c9",cloudPink:"#ffd2df",cloudRose:"#ffb9c8",cloudLilac:"#e4d8ff",cloudLav:"#d6c9f4",cloudBlue:"#d9f1fa",cloudMint:"#d9f2e8",cloudShade:"#c9b4d6",wood:"#c98d63",woodMid:"#b97956",woodLight:"#e9ba8a",woodPale:"#f6d5a7",woodDark:"#885546",woodInk:"#74463e",brass:"#f2bf68",brassDeep:"#c9893f",gold:"#ffd27c",goldPale:"#ffe8b7",cream:"#fff2dc",creamCool:"#f8efe5",plaster:"#ffe9cf",plasterShade:"#f3cfb2",roof:"#ee9a9d",roofLight:"#ffc2b6",roofDeep:"#c87588",roofBlue:"#91c8d5",roofMint:"#a9d7cc",ink:"#624b5d",inkSoft:"#8d6f7f",blush:"#ff9fb8",rose:"#f27998",coral:"#ff9b7f",peach:"#ffc49a",honey:"#ffd076",lavender:"#bda6f4",periwinkle:"#99b5f2",mint:"#9bdcc9",cyan:"#82dbe8",dyePink:"#ff75ac",dyeRose:"#ffafc5",dyeViolet:"#a77bff",dyeLilac:"#d2b6ff",dyeSky:"#68d8df",dyeGold:"#ffc94f",dyeSun:"#ffe38b",glass:"#dff7f6",pearl:"#f5f1eb",whaleTop:"#eef7ed",whaleSide:"#dcebe6",whaleBelly:"#ffd8d3",whaleVein:"#f4c2c9",whaleRim:"#fff1d5",whaleShade:"#afc7c9",vignette:"#593c52"};var Uc=new A;function Ri(i,e,t,n,s,r){let o=2*Math.PI*s/4,a=Math.max(r-2*s,0),l=Math.PI/4;Uc.copy(e),Uc[n]=0,Uc.normalize();let c=.5*o/(o+a),h=1-Uc.angleTo(i)/l;return Math.sign(Uc[t])===1?h*c:a/(o+a)+c+c*(1-h)}var kr=class i extends mi{constructor(e=1,t=1,n=1,s=2,r=.1){let o=s*2+1;if(r=Math.min(e/2,t/2,n/2,r),super(1,1,1,o,o,o),this.type="RoundedBoxGeometry",this.parameters={width:e,height:t,depth:n,segments:s,radius:r},o===1)return;let a=this.toNonIndexed();this.index=null,this.attributes.position=a.attributes.position,this.attributes.normal=a.attributes.normal,this.attributes.uv=a.attributes.uv;let l=new A,c=new A,h=new A(e,t,n).divideScalar(2).subScalar(r),u=this.attributes.position.array,d=this.attributes.normal.array,f=this.attributes.uv.array,p=u.length/6,_=new A,g=.5/o;for(let m=0,v=0;m<u.length;m+=3,v+=2)switch(l.fromArray(u,m),c.copy(l),c.x-=Math.sign(c.x)*g,c.y-=Math.sign(c.y)*g,c.z-=Math.sign(c.z)*g,c.normalize(),u[m+0]=h.x*Math.sign(l.x)+c.x*r,u[m+1]=h.y*Math.sign(l.y)+c.y*r,u[m+2]=h.z*Math.sign(l.z)+c.z*r,d[m+0]=c.x,d[m+1]=c.y,d[m+2]=c.z,Math.floor(m/p)){case 0:_.set(1,0,0),f[v+0]=Ri(_,c,"z","y",r,n),f[v+1]=1-Ri(_,c,"y","z",r,t);break;case 1:_.set(-1,0,0),f[v+0]=1-Ri(_,c,"z","y",r,n),f[v+1]=1-Ri(_,c,"y","z",r,t);break;case 2:_.set(0,1,0),f[v+0]=1-Ri(_,c,"x","z",r,e),f[v+1]=Ri(_,c,"z","x",r,n);break;case 3:_.set(0,-1,0),f[v+0]=1-Ri(_,c,"x","z",r,e),f[v+1]=1-Ri(_,c,"z","x",r,n);break;case 4:_.set(0,0,1),f[v+0]=1-Ri(_,c,"x","y",r,e),f[v+1]=1-Ri(_,c,"y","x",r,t);break;case 5:_.set(0,0,-1),f[v+0]=Ri(_,c,"x","y",r,e),f[v+1]=1-Ri(_,c,"y","x",r,t);break}}static fromJSON(e){return new i(e.width,e.height,e.depth,e.segments,e.radius)}};function ft(i=1){let e=i>>>0;return function(){e|=0,e=e+1831565813|0;let t=Math.imul(e^e>>>15,1|e);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}var ww=ft(20241029);var Rw=Br.lerp,Fc=Br.clamp;function ne(i,e,t){return new A(i,e,t)}function Dp(i,e,t){let n=Fc((t-i)/(e-i),0,1);return n*n*(3-2*n)}function Cn(i,e,t,n={}){let s=document.createElement("canvas");s.width=i,s.height=e;let r=s.getContext("2d");t(r,i,e);let o=new pi(s);return o.colorSpace=Wt,o.wrapS=o.wrapT=Hs,n.repeat&&o.repeat.set(n.repeat[0],n.repeat[1]),o.anisotropy=8,o}function i_(i=128,e="rgba(255,255,255,1)",t="rgba(255,215,210,.42)"){let n=document.createElement("canvas");n.width=n.height=i;let s=n.getContext("2d"),r=s.createRadialGradient(i/2,i/2,0,i/2,i/2,i/2);r.addColorStop(0,e),r.addColorStop(.18,"rgba(255,247,232,.82)"),r.addColorStop(.42,t),r.addColorStop(1,"rgba(255,190,190,0)"),s.fillStyle=r,s.fillRect(0,0,i,i);let o=new pi(n);return o.colorSpace=Wt,o}function hd(i=256){let e=document.createElement("canvas");e.width=e.height=i;let t=e.getContext("2d");t.clearRect(0,0,i,i);let n=(r,o,a,l)=>{let c=t.createRadialGradient(r,o,0,r,o,a);c.addColorStop(0,`rgba(255,252,247,${l})`),c.addColorStop(.45,`rgba(255,232,232,${l*.58})`),c.addColorStop(1,"rgba(255,220,230,0)"),t.fillStyle=c,t.fillRect(r-a,o-a,a*2,a*2)};n(i*.45,i*.55,i*.46,.55),n(i*.28,i*.8,i*.3,.4),n(i*.7,i*.42,i*.33,.46),n(i*.6,i*.82,i*.26,.34);let s=new pi(e);return s.colorSpace=Wt,s}function s_(i=128){let e=document.createElement("canvas");e.width=e.height=i;let t=e.getContext("2d"),n=t.createRadialGradient(i/2,i/2,0,i/2,i/2,i/2);n.addColorStop(0,"rgba(255,255,255,1)"),n.addColorStop(.25,"rgba(255,240,200,.75)"),n.addColorStop(1,"rgba(255,220,190,0)"),t.fillStyle=n,t.fillRect(0,0,i,i),t.globalCompositeOperation="lighter",t.strokeStyle="rgba(255,255,255,.9)",t.lineWidth=2.4,t.beginPath(),t.moveTo(i/2,i*.1),t.lineTo(i/2,i*.9),t.moveTo(i*.1,i/2),t.lineTo(i*.9,i/2),t.stroke();let s=new pi(e);return s.colorSpace=Wt,s}function ve(i,e,t,n=.06,s=3){return new kr(i,e,t,s,Math.min(n,i*.45,e*.45,t*.45))}function ze(i=1,e=1){return new Tn(i,e)}function Oe(i,e,t,n=16){return new xn(i,e,t,n)}function fa(i,e,t=1,n=1){return new cn(i,e,t,n)}function N(i,e,t={}){let n=new W(i,e);return t.pos&&n.position.set(t.pos[0],t.pos[1],t.pos[2]),t.rot&&n.rotation.set(t.rot[0],t.rot[1],t.rot[2]),t.scale&&n.scale.set(t.scale[0],t.scale[1],t.scale[2]),n.castShadow=t.castShadow??!0,n.receiveShadow=t.receiveShadow??!0,t.name&&(n.name=t.name),t.renderOrder!=null&&(n.renderOrder=t.renderOrder),n}function r_(i,e,t,n,s=0){let r=t/2,o=e+n-r,a=new li;return a.moveTo(i-r,e-s),a.lineTo(i-r,o-s),a.absarc(i,o-s,r,Math.PI,0,!0),a.lineTo(i+r,e-s),a.closePath(),a}function Lp(i,e,t,n,s=0){let r=t/2,o=e+n-r,a=[];a.push(ne(i-r,e,s)),a.push(ne(i-r,o,s));for(let l=1;l<=14;l++){let c=Math.PI-l/14*Math.PI;a.push(ne(i+Math.cos(c)*r,o+Math.sin(c)*r,s))}return a.push(ne(i+r,e,s)),a}var Pp=new Map;function lS(i="#6d536a",e=.018,t=1){let n=i+"|"+e+"|"+t;if(Pp.has(n))return Pp.get(n);let s=new xt({uniforms:{uColor:{value:new q(i)},uThickness:{value:e},uOpacity:{value:t}},vertexShader:`
      uniform float uThickness;
      void main() {
        vec3 p = position + normal * uThickness;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }
    `,fragmentShader:`
      uniform vec3 uColor;
      uniform float uOpacity;
      void main() {
        gl_FragColor = vec4(uColor, uOpacity);
      }
    `,side:Ln,transparent:t<.999,depthWrite:t>=.999});return Pp.set(n,s),s}function ns(i,e="#6d536a",t=.018,n=1){if(!i.isMesh)return;let s=new W(i.geometry,lS(e,t,n));return s.name=(i.name||"mesh")+"_ink",s.userData.isOutline=!0,s.castShadow=!1,s.receiveShadow=!1,s.renderOrder=-1,i.add(s),s}var Ip=null;function Np(){return Cn(256,256,(i,e,t)=>{let n=i.createRadialGradient(e*.5,t*.5,0,e*.5,t*.5,e*.5);n.addColorStop(0,"rgba(68,40,58,.46)"),n.addColorStop(.38,"rgba(88,53,72,.26)"),n.addColorStop(1,"rgba(100,70,90,0)"),i.fillStyle=n,i.fillRect(0,0,e,t)})}function o_(i,e,t=1){Ip||(Ip=new Qe({map:Np(),transparent:!0,opacity:t,depthWrite:!1,blending:Vn,toneMapped:!1}));let n=new W(new cn(i,e),Ip.clone());return n.material.opacity=t,n.rotation.x=-Math.PI/2,n.renderOrder=2,n}var xe=Math.PI*2;var cS=new Uint8Array([105,105,105,255,148,148,148,255,186,186,186,255,218,218,218,255,240,240,240,255,255,255,255,255]),Zt=new Un(cS,6,1,In);Zt.minFilter=jt;Zt.magFilter=jt;Zt.generateMipmaps=!1;Zt.needsUpdate=!0;var Up=new Map;function me(i,e={}){let t=i+"|"+JSON.stringify(e);if(Up.has(t))return Up.get(t);let n=new Ht({color:i,gradientMap:Zt,...e});return e.emissive&&(n.emissive=new q(e.emissive)),Up.set(t,n),n}function a_(i,e={}){return new Qe({color:i,...e})}function Yn(i,e=1.6,t=1){let n=new q(i);return n.multiplyScalar(e),new Qe({color:n,transparent:t<1,opacity:t,toneMapped:!1,depthWrite:t>=1,blending:t<1?wt:Vn,side:De})}function nn(i=qt.brass){return new Xs({color:i,metalness:.68,roughness:.27,envMapIntensity:1.35})}function Bc(i=qt.dyeRose,e=.5){return new hn({color:i,transparent:!0,opacity:e,roughness:.08,metalness:0,clearcoat:1,clearcoatRoughness:.08,iridescence:.9,iridescenceIOR:1.28,iridescenceThicknessRange:[120,700],envMapIntensity:1.8,side:De,depthWrite:!1})}var Pt={};Pt.wood=Cn(512,512,(i,e,t)=>{let n=i.createLinearGradient(0,0,e,0);n.addColorStop(0,"#e0aa7d"),n.addColorStop(.28,"#f2c696"),n.addColorStop(.55,"#dba173"),n.addColorStop(.8,"#efbd8c"),n.addColorStop(1,"#d3966b"),i.fillStyle=n,i.fillRect(0,0,e,t);let s=ft(42);for(let o=0;o<110;o++){let a=s()*t;i.strokeStyle=`rgba(${100+s()*70},${58+s()*46},${44+s()*33},${.03+s()*.075})`,i.lineWidth=.5+s()*2.2,i.beginPath(),i.moveTo(0,a);for(let l=0;l<=e;l+=22)i.lineTo(l,a+Math.sin(l*.02+s()*6)*(1.5+s()*4));i.stroke()}let r=i.createLinearGradient(0,0,0,t);r.addColorStop(0,"rgba(255,244,224,.18)"),r.addColorStop(.5,"rgba(255,255,255,0)"),r.addColorStop(1,"rgba(111,54,39,.1)"),i.fillStyle=r,i.fillRect(0,0,e,t)},{repeat:[1,1]});Pt.woodDark=Cn(512,512,(i,e,t)=>{i.fillStyle="#a96f53",i.fillRect(0,0,e,t);let n=ft(7);for(let s=0;s<90;s++){let r=n()*t;i.strokeStyle=`rgba(${55+n()*70},${28+n()*45},${22+n()*35},${.06+n()*.12})`,i.lineWidth=.7+n()*2,i.beginPath(),i.moveTo(0,r);for(let o=0;o<=e;o+=30)i.lineTo(o,r+Math.sin(o*.023+n())*3);i.stroke()}},{repeat:[1,1]});Pt.deck=Cn(1024,1024,(i,e,t)=>{i.fillStyle="#efc597",i.fillRect(0,0,e,t);let n=ft(11),s=14,r=t/s;for(let o=0;o<s;o++){let a=o*r,l=["#f2c89c","#e8b789","#f5cda2","#e2ad7d","#f0bf91"][o%5];i.fillStyle=l,i.fillRect(0,a+2,e,r-4);let c=o%3*e*.25;i.strokeStyle="rgba(106,65,48,.22)",i.lineWidth=2.4,i.beginPath(),i.moveTo(c+e*.1,a),i.lineTo(c+e*.1,a+r),i.stroke();for(let h=0;h<12;h++){i.strokeStyle=`rgba(107,66,46,${.025+n()*.045})`,i.lineWidth=.7+n()*1.3,i.beginPath(),i.moveTo(0,a+4+n()*(r-8));for(let u=0;u<=e;u+=30)i.lineTo(u,a+r*.5+Math.sin(u*.008+n()*5)*r*.12);i.stroke()}i.strokeStyle="rgba(255,245,225,.45)",i.lineWidth=1.3,i.beginPath(),i.moveTo(0,a+3),i.lineTo(e,a+3),i.stroke(),i.strokeStyle="rgba(86,49,43,.34)",i.beginPath(),i.moveTo(0,a+r-2),i.lineTo(e,a+r-2),i.stroke()}},{repeat:[1,1]});Pt.roof=Cn(512,512,(i,e,t)=>{let n=i.createLinearGradient(0,0,e,t);n.addColorStop(0,"#ffc2b0"),n.addColorStop(.45,"#ec979b"),n.addColorStop(1,"#e98b98"),i.fillStyle=n,i.fillRect(0,0,e,t);let s=8,r=6,o=e/r,a=t/s;for(let l=0;l<s;l++)for(let c=0;c<r;c++){let h=c*o+(l%2?o*.5:0),u=l*a,d=i.createLinearGradient(h,u,h,u+a);d.addColorStop(0,"rgba(255,237,210,.28)"),d.addColorStop(.62,"rgba(255,186,176,.03)"),d.addColorStop(1,"rgba(114,54,89,.16)"),i.fillStyle=d,i.beginPath(),i.moveTo(h-o*.52,u),i.lineTo(h+o*.52,u),i.lineTo(h+o*.52,u+a*.8),i.quadraticCurveTo(h,u+a*1.08,h-o*.52,u+a*.8),i.closePath(),i.fill(),i.strokeStyle="rgba(116,65,87,.22)",i.lineWidth=1.8,i.stroke(),i.strokeStyle="rgba(255,226,200,.27)",i.lineWidth=1.1,i.stroke()}i.globalAlpha=.22;for(let l=0;l<=r;l++)i.strokeStyle="#ffe4a5",i.lineWidth=2,i.beginPath(),i.moveTo(l*o,0),i.lineTo(l*o,t),i.stroke();i.globalAlpha=1},{repeat:[1.8,1.2]});Pt.washi=Cn(256,256,(i,e,t)=>{i.fillStyle="#fff3dc",i.fillRect(0,0,e,t);let n=ft(19);for(let s=0;s<120;s++){i.strokeStyle=`rgba(230,187,146,${.04+n()*.08})`,i.lineWidth=.6,i.beginPath();let r=n()*e,o=n()*t;i.moveTo(r,o),i.lineTo(r+(n()-.5)*50,o+(n()-.5)*50),i.stroke()}for(let s=0;s<6;s++){let r=n()*e,o=n()*t,a=5+n()*17,l=i.createRadialGradient(r,o,0,r,o,a);l.addColorStop(0,"rgba(255,200,175,.3)"),l.addColorStop(1,"rgba(255,200,175,0)"),i.fillStyle=l,i.fillRect(r-a,o-a,a*2,a*2)}},{repeat:[1,1]});Pt.basket=Cn(512,512,(i,e,t)=>{i.fillStyle="#d6a66e",i.fillRect(0,0,e,t);let n=18;for(let s=0;s<n;s++){let r=s/n*t;i.strokeStyle=s%2?"rgba(255,229,183,.7)":"rgba(118,74,46,.45)",i.lineWidth=8,i.beginPath(),i.moveTo(0,r),i.lineTo(e,r),i.stroke()}for(let s=-6;s<22;s++)i.strokeStyle=s%2?"rgba(255,223,172,.36)":"rgba(102,59,40,.35)",i.lineWidth=7,i.beginPath(),i.moveTo(s*34,0),i.lineTo(s*34+e*.55,t),i.stroke(),i.beginPath(),i.moveTo(s*34,t),i.lineTo(s*34+e*.55,0),i.stroke();i.strokeStyle="rgba(255,243,210,.25)",i.lineWidth=3;for(let s=0;s<5;s++)i.beginPath(),i.moveTo(0,40+s*110),i.lineTo(e,40+s*110),i.stroke()},{repeat:[1,1]});Pt.starCloth=Cn(512,512,(i,e,t)=>{let n=i.createLinearGradient(0,0,e,t);n.addColorStop(0,"#2e3268"),n.addColorStop(.35,"#514f9d"),n.addColorStop(.7,"#8b6fb7"),n.addColorStop(1,"#d4a0c8"),i.fillStyle=n,i.fillRect(0,0,e,t);let s=ft(88);for(let r=0;r<25;r++){let o=s()*e,a=s()*t,l=30+s()*110,c=i.createRadialGradient(o,a,0,o,a,l),h=["255,170,194","180,162,255","255,225,164","144,225,232"][Math.floor(s()*4)];c.addColorStop(0,`rgba(${h},.2)`),c.addColorStop(1,`rgba(${h},0)`),i.fillStyle=c,i.fillRect(0,0,e,t)}i.strokeStyle="rgba(255,225,176,.35)",i.lineWidth=2;for(let r=0;r<3;r++){i.beginPath();for(let o=0;o<80;o++){let a=o*.16+r,l=15+o*2.2,c=e*.5+Math.cos(a)*l,h=t*.5+Math.sin(a)*l*.75;o===0?i.moveTo(c,h):i.lineTo(c,h)}i.stroke()}for(let r=0;r<150;r++){let o=s()*e,a=s()*t,l=s()<.13?2.5+s()*3.5:.7+s()*1.6,c=.35+s()*.6;if(i.fillStyle=s()<.25?`rgba(255,215,143,${c})`:`rgba(255,246,235,${c})`,i.beginPath(),s()<.25){let u=l*2,d=l*.46;for(let f=0;f<4*2;f++){let p=f*Math.PI/4-Math.PI/2,_=f%2?d:u,g=o+Math.cos(p)*_,m=a+Math.sin(p)*_;f===0?i.moveTo(g,m):i.lineTo(g,m)}i.closePath()}else i.arc(o,a,l,0,7);i.fill()}},{repeat:[1,1]});Pt.rug=Cn(512,512,(i,e,t)=>{let n=i.createRadialGradient(e*.5,t*.5,e*.1,e*.5,t*.5,e*.7);n.addColorStop(0,"#ffe8da"),n.addColorStop(.35,"#ffc8d1"),n.addColorStop(.72,"#d8c4ff"),n.addColorStop(1,"#b8dff1"),i.fillStyle=n,i.fillRect(0,0,e,t);let s=ft(31);for(let r=0;r<22;r++)i.strokeStyle=`rgba(255,251,233,${.15+s()*.24})`,i.lineWidth=2+s()*4,i.beginPath(),i.arc(e*.5,t*.5,30+r*11,0,Math.PI*2),i.stroke();for(let r=0;r<180;r++)i.fillStyle=["rgba(255,255,255,.4)","rgba(255,225,166,.44)","rgba(164,214,255,.28)"][r%3],i.beginPath(),i.arc(s()*e,s()*t,.8+s()*2.3,0,7),i.fill();i.strokeStyle="rgba(255,246,226,.8)",i.lineWidth=9,i.setLineDash([5,9]),i.beginPath(),i.arc(e*.5,t*.5,e*.46,0,7),i.stroke()},{repeat:[1,1]});Pt.waterFoam=Cn(256,256,(i,e,t)=>{i.fillStyle="#ffffff",i.fillRect(0,0,e,t);let n=i.createRadialGradient(e/2,t/2,0,e/2,t/2,e/2);n.addColorStop(0,"rgba(255,255,255,.85)"),n.addColorStop(.6,"rgba(255,255,255,.1)"),n.addColorStop(1,"rgba(255,255,255,0)"),i.fillStyle=n,i.fillRect(0,0,e,t)},{repeat:[1,1]});var Oc=i_(256),ud=s_(128),Iw=Np(),k={wood:me("#f0d0af",{map:Pt.wood}),woodWarm:me("#d7a075",{map:Pt.wood}),woodDark:me("#9b6551",{map:Pt.woodDark}),deck:me("#ffe6c6",{map:Pt.deck}),cream:me(qt.cream),plaster:me(qt.plaster),plasterShade:me(qt.plasterShade),roof:me("#ffffff",{map:Pt.roof}),washi:a_("#ffe8c9",{map:Pt.washi,transparent:!0,opacity:.65,side:De,toneMapped:!1}),brass:nn(),brassSoft:nn("#e6bd7f"),goldGlow:a_("#ffd884",{toneMapped:!1}),leaf:me("#acd9c4",{side:De}),leafPink:me("#f7b9d0",{side:De}),cloud:me(qt.cloudCream,{emissive:"#ffcfba",emissiveIntensity:.1}),cloudPink:me(qt.cloudPink,{emissive:"#ffb8ae",emissiveIntensity:.12}),cloudLilac:me(qt.cloudLilac,{emissive:"#d7b7e9",emissiveIntensity:.1}),cloudBlue:me(qt.cloudBlue,{emissive:"#b8e5ef",emissiveIntensity:.08}),basket:me("#ffffff",{map:Pt.basket}),starCloth:new Ht({map:Pt.starCloth,gradientMap:Zt,emissive:"#8a67d4",emissiveMap:Pt.starCloth,emissiveIntensity:.38}),clothPlain:me("#ffe4d2",{side:De}),ink:me(qt.ink),inkSoft:me(qt.inkSoft),white:me("#fff9ef"),creamTrans:new hn({color:"#fff7e9",transparent:!0,opacity:.34,roughness:.3,metalness:0,clearcoat:1,clearcoatRoughness:.2,iridescence:.5,side:De,depthWrite:!1})},fn={pink:Bc("#ffb3d0",.4),lilac:Bc("#c9bdff",.4),blue:Bc("#b6ebf2",.35),peach:Bc("#ffc7aa",.38),gold:Bc("#ffe0a6",.38)},Dw={pink:new Qe({color:new q("#ff6cab").multiplyScalar(1.25),toneMapped:!1}),violet:new Qe({color:new q("#a17bff").multiplyScalar(1.3),toneMapped:!1}),gold:new Qe({color:new q("#ffc84c").multiplyScalar(1.25),toneMapped:!1}),sky:new Qe({color:new q("#5ed7e5").multiplyScalar(1.2),toneMapped:!1})};var hS={peach:new ln({map:Oc,color:"#ffcf9f",transparent:!0,opacity:.55,blending:wt,depthWrite:!1,toneMapped:!1}),pink:new ln({map:Oc,color:"#ffa7ba",transparent:!0,opacity:.5,blending:wt,depthWrite:!1,toneMapped:!1}),gold:new ln({map:Oc,color:"#ffdf9d",transparent:!0,opacity:.56,blending:wt,depthWrite:!1,toneMapped:!1}),blue:new ln({map:Oc,color:"#a5e8ef",transparent:!0,opacity:.45,blending:wt,depthWrite:!1,toneMapped:!1})};function pt(i="gold",e=1.2,t=null){let n=hS[i].clone();t!=null&&(n.opacity=t);let s=new Dn(n);return s.scale.setScalar(e),s}function uS(){let t=document.createElement("canvas");t.width=2048,t.height=1280;let n=t.getContext("2d"),s=n.createLinearGradient(0,0,0,1280);s.addColorStop(0,"#6dc4e7"),s.addColorStop(.14,"#8ed2ef"),s.addColorStop(.31,"#c1c9ed"),s.addColorStop(.46,"#eabce4"),s.addColorStop(.6,"#ffc3d5"),s.addColorStop(.73,"#ffb39f"),s.addColorStop(.86,"#ffc8a8"),s.addColorStop(1,"#ffe2c6"),n.fillStyle=s,n.fillRect(0,0,2048,1280),n.save(),n.filter="blur(28px)";let r=ft(4201),o=["rgba(255,245,236,.20)","rgba(255,216,224,.18)","rgba(206,190,255,.16)","rgba(255,224,187,.20)","rgba(189,233,245,.12)"];for(let p=0;p<42;p++){let _=r()*2048,g=1280*(.48+r()*.42),m=130+r()*380,v=26+r()*90,E=o[Math.floor(r()*o.length)];n.save(),n.translate(_,g),n.rotate((r()-.5)*.16);let y=n.createLinearGradient(0,0,m,0);y.addColorStop(0,"rgba(255,255,255,0)"),y.addColorStop(.26,E),y.addColorStop(.7,E),y.addColorStop(1,"rgba(255,255,255,0)"),n.fillStyle=y,n.beginPath(),n.ellipse(0,0,m,v,0,0,Math.PI*2),n.fill(),n.restore()}for(let p=0;p<18;p++){let g=p%2===0?r()*2048*.22:2048-r()*2048*.22,m=1280*(.55+r()*.38),v=90+r()*210,E=n.createRadialGradient(g,m,0,g,m,v);E.addColorStop(0,"rgba(255,241,231,.16)"),E.addColorStop(.5,"rgba(255,210,216,.10)"),E.addColorStop(1,"rgba(255,210,216,0)"),n.fillStyle=E,n.fillRect(g-v,m-v,v*2,v*2)}n.restore();let a=2048*.735,l=1280*.27,c=n.createRadialGradient(a,l,0,a,l,2048*.3);c.addColorStop(0,"rgba(255,255,240,.98)"),c.addColorStop(.035,"rgba(255,251,216,.96)"),c.addColorStop(.1,"rgba(255,235,188,.60)"),c.addColorStop(.28,"rgba(255,207,169,.24)"),c.addColorStop(.62,"rgba(255,184,169,.09)"),c.addColorStop(1,"rgba(255,176,166,0)"),n.fillStyle=c,n.fillRect(0,0,2048,1280);let h=n.createRadialGradient(a,l,0,a,l,2048*.03);h.addColorStop(0,"rgba(255,255,252,1)"),h.addColorStop(.63,"rgba(255,248,215,.95)"),h.addColorStop(.85,"rgba(255,230,174,.55)"),h.addColorStop(1,"rgba(255,225,171,0)"),n.fillStyle=h,n.beginPath(),n.arc(a,l,2048*.03,0,Math.PI*2),n.fill();let u=n.createLinearGradient(0,1280*.58,0,1280);u.addColorStop(0,"rgba(255,241,225,0)"),u.addColorStop(.56,"rgba(255,206,173,.18)"),u.addColorStop(1,"rgba(255,187,153,.22)"),n.fillStyle=u,n.fillRect(0,1280*.58,2048,1280*.42),n.save(),n.filter="blur(10px)";for(let p=0;p<50;p++){let _=r()*2048,g=1280*(.18+r()*.8);n.fillStyle="rgba(255,248,238,"+(.02+r()*.05)+")",n.beginPath(),n.ellipse(_,g,4+r()*20,1+r()*3,r()*.6,0,Math.PI*2),n.fill()}n.restore();let d=n.createRadialGradient(2048*.5,1280*.46,2048*.22,2048*.5,1280*.5,2048*.72);d.addColorStop(0,"rgba(98,70,103,0)"),d.addColorStop(.75,"rgba(116,75,101,.055)"),d.addColorStop(1,"rgba(91,55,84,.15)"),n.fillStyle=d,n.fillRect(0,0,2048,1280);let f=new pi(t);return f.colorSpace=Wt,f}function dS(){return Cn(1024,512,(i,e,t)=>{let n=i.createLinearGradient(0,0,0,t);n.addColorStop(0,"#a7e2f3"),n.addColorStop(.25,"#d6dffa"),n.addColorStop(.47,"#f4cfe7"),n.addColorStop(.62,"#ffc4b5"),n.addColorStop(.78,"#ecc6dd"),n.addColorStop(1,"#9385c4"),i.fillStyle=n,i.fillRect(0,0,e,t);let s=e*.79,r=t*.34,o=i.createRadialGradient(s,r,0,s,r,e*.22);o.addColorStop(0,"rgba(255,255,235,1)"),o.addColorStop(.05,"rgba(255,246,198,.96)"),o.addColorStop(.2,"rgba(255,206,146,.5)"),o.addColorStop(.6,"rgba(255,173,140,.12)"),o.addColorStop(1,"rgba(255,170,150,0)"),i.fillStyle=o,i.fillRect(0,0,e,t);let a=ft(10);for(let l=0;l<16;l++){let c=a()*e,h=t*(.48+a()*.32),u=50+a()*170,d=i.createRadialGradient(c,h,0,c,h,u);d.addColorStop(0,"rgba(255,241,239,.15)"),d.addColorStop(.55,"rgba(240,207,234,.06)"),d.addColorStop(1,"rgba(220,160,210,0)"),i.fillStyle=d,i.fillRect(c-u,h-u,u*2,u*2)}})}function fS(){let i=new ce,e=hd(256),t=new ln({map:e,color:"#ffede6",transparent:!0,opacity:.22,depthWrite:!1,toneMapped:!0}),n=ft(73),s=[[-20,-3.2,-17,16],[-8,-5.4,-24,21],[13,-4.8,-21,18],[26,-2,-9,15],[-26,.4,6,19],[22,2.4,12,14],[4,-6.8,22,22],[-15,-7,19,20],[-24,8.8,-10,16],[29,7.4,1,22]];for(let[r,o,a,l]of s){let c=new Dn(t.clone());c.position.set(r,o,a),c.scale.set(l*(1.4+n()*.5),l*(.45+n()*.16),1),c.material.opacity=.1+n()*.12,c.material.rotation=(n()-.5)*.2,i.add(c)}return i.renderOrder=-900,i}function pS(){let e=new ke,t=new Float32Array(150*3),n=new Float32Array(150*3),s=ft(98),r=[new q("#ffe4b4"),new q("#ffc5d3"),new q("#c6eaf3"),new q("#fff5dc")];for(let l=0;l<150;l++){let c=s()*Math.PI*2,h=8+s()*24;t[l*3]=Math.cos(c)*h,t[l*3+1]=-2+s()*17,t[l*3+2]=Math.sin(c)*h;let u=r[Math.floor(s()*r.length)];n[l*3]=u.r,n[l*3+1]=u.g,n[l*3+2]=u.b}e.setAttribute("position",new bt(t,3)),e.setAttribute("color",new bt(n,3));let o=new ps({map:ud,size:.2,vertexColors:!0,transparent:!0,opacity:.7,depthWrite:!1,blending:wt,sizeAttenuation:!0,toneMapped:!1}),a=new ms(e,o);return a.frustumCulled=!1,a}function l_(i,e){let t=uS();i.background=t;let n=dS();n.mapping=Ks;let s=new zr(e),r=s.fromEquirectangular(n);i.environment=r.texture,i.environmentIntensity=.55,n.dispose(),s.dispose();let o=fS();i.add(o);let a=pS();i.add(a);let l=a.geometry.attributes.position.array.slice();function c(h){o.rotation.y=Math.sin(h*.006)*.012;let u=a.geometry.attributes.position.array;for(let d=0;d<u.length/3;d++){let f=d*3;u[f+1]=l[f+1]+Math.sin(h*.12+d*1.7)*.55,u[f]=l[f]+Math.cos(h*.07+d*2.1)*.35}a.geometry.attributes.position.needsUpdate=!0}return{background:t,dust:a,far:o,update:c}}function h_(i,e=!1){let t=i[0].index!==null,n=new Set(Object.keys(i[0].attributes)),s=new Set(Object.keys(i[0].morphAttributes)),r={},o={},a=i[0].morphTargetsRelative,l=new ke,c=0;for(let h=0;h<i.length;++h){let u=i[h],d=0;if(t!==(u.index!==null))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". All geometries must have compatible attributes; make sure index attribute exists among all geometries, or in none of them."),null;for(let f in u.attributes){if(!n.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+'. All geometries must have compatible attributes; make sure "'+f+'" attribute exists among all geometries, or in none of them.'),null;r[f]===void 0&&(r[f]=[]),r[f].push(u.attributes[f]),d++}if(d!==n.size)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". Make sure all geometries have the same number of attributes."),null;if(a!==u.morphTargetsRelative)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". .morphTargetsRelative must be consistent throughout all geometries."),null;for(let f in u.morphAttributes){if(!s.has(f))return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+".  .morphAttributes must be consistent throughout all geometries."),null;o[f]===void 0&&(o[f]=[]),o[f].push(u.morphAttributes[f])}if(e){let f;if(t)f=u.index.count;else if(u.attributes.position!==void 0)f=u.attributes.position.count;else return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed with geometry at index "+h+". The geometry must have either an index or a position attribute"),null;l.addGroup(c,f,h),c+=f}}if(t){let h=0,u=[];for(let d=0;d<i.length;++d){let f=i[d].index;for(let p=0;p<f.count;++p)u.push(f.getX(p)+h);h+=i[d].attributes.position.count}l.setIndex(u)}for(let h in r){let u=c_(r[h]);if(!u)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" attribute."),null;l.setAttribute(h,u)}for(let h in o){let u=o[h][0].length;if(u!==0){l.morphAttributes=l.morphAttributes||{},l.morphAttributes[h]=[];for(let d=0;d<u;++d){let f=[];for(let _=0;_<o[h].length;++_)f.push(o[h][_][d]);let p=c_(f);if(!p)return console.error("THREE.BufferGeometryUtils: .mergeGeometries() failed while trying to merge the "+h+" morphAttribute."),null;l.morphAttributes[h].push(p)}}}return l}function c_(i){let e,t,n,s=-1,r=0;for(let c=0;c<i.length;++c){let h=i[c];if(e===void 0&&(e=h.array.constructor),e!==h.array.constructor)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.array must be of consistent array types across matching attributes."),null;if(t===void 0&&(t=h.itemSize),t!==h.itemSize)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.itemSize must be consistent across matching attributes."),null;if(n===void 0&&(n=h.normalized),n!==h.normalized)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.normalized must be consistent across matching attributes."),null;if(s===-1&&(s=h.gpuType),s!==h.gpuType)return console.error("THREE.BufferGeometryUtils: .mergeAttributes() failed. BufferAttribute.gpuType must be consistent across matching attributes."),null;r+=h.count*t}let o=new e(r),a=new bt(o,t,n),l=0;for(let c=0;c<i.length;++c){let h=i[c];if(h.isInterleavedBufferAttribute){let u=l/t;for(let d=0,f=h.count;d<f;d++)for(let p=0;p<t;p++){let _=h.getComponent(d,p);a.setComponent(d+u,p,_)}}else o.set(h.array,l);l+=h.count*t}return s!==void 0&&(a.gpuType=s),a}var Mn={size:20.2,waterSize:16,upperSize:17.5,frameInner:16.05,waterY:.31,deckY:2.95};function Fp(i,e,t=9){let n=i/2,s=[],r=[[n-e,n-e,0],[-n+e,n-e,Math.PI/2],[-n+e,-n+e,Math.PI],[n-e,-n+e,Math.PI*1.5]];for(let[o,a,l]of r)for(let c=0;c<=t;c++){let h=l+c/t*Math.PI/2;s.push(new J(o+Math.cos(h)*e,a+Math.sin(h)*e))}return s}function mS(i,e){let t=new kt,n=Fp(i,e,10);t.moveTo(n[0].x,n[0].y);for(let s=1;s<n.length;s++)t.lineTo(n[s].x,n[s].y);return t.closePath(),t}function gS(i,e){let t=new li,n=Fp(i,e,10);t.moveTo(n[0].x,n[0].y);for(let s=1;s<n.length;s++)t.lineTo(n[s].x,n[s].y);return t.closePath(),t}function dd(i,e,t,n,s,r=160){let o=Fp(i,e,10).map(h=>ne(h.x,t,h.y));o.push(o[0].clone());let a=new je(o,!1,"centripetal"),l=new et(a,r,n,5,!1),c=new W(l,s);return c.castShadow=!1,c}var _S=`
  uniform float uTime;
  varying vec2 vUv;
  varying vec3 vWorld;
  varying vec3 vN;

  void main() {
    vec3 p = position;
    float w1 = sin(p.x * .67 + uTime * .30) * .028;
    float w2 = sin(p.y * .88 - uTime * .21 + 1.7) * .020;
    float w3 = sin((p.x + p.y) * .47 + uTime * .16) * .012;
    p.z += w1 + w2 + w3;
    vUv = uv;

    float dx = cos(p.x * .67 + uTime * .30) * .0288 + cos((p.x + p.y) * .47 + uTime * .16) * .0103;
    float dy = cos(p.y * .88 - uTime * .21 + 1.7) * .0281 + cos((p.x + p.y) * .47 + uTime * .16) * .0103;
    vec3 localN = normalize(vec3(-dx, -dy, 1.0));
    vN = normalize(normalMatrix * localN);
    vec4 wp = modelMatrix * vec4(p, 1.0);
    vWorld = wp.xyz;
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`,xS=`
  precision highp float;
  uniform float uTime;
  uniform vec3 uAqua, uLilac, uPeach, uGold, uRose;
  varying vec2 vUv;
  varying vec3 vWorld;
  varying vec3 vN;

  float hash(vec2 p){ p = fract(p * vec2(234.34, 435.345)); p += dot(p, p+34.23); return fract(p.x*p.y); }
  float noise(vec2 p){
    vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
    return mix(mix(hash(i),hash(i+vec2(1,0)),f.x), mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x), f.y);
  }

  void main() {
    vec3 N = normalize(vN);
    vec3 V = normalize(cameraPosition - vWorld);
    float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 2.0);
    vec2 uv = vUv;
    vec2 c = uv - .5;
    float r = length(c * vec2(1.0, 1.18));

    float n1 = noise(uv * 4.8 + vec2(uTime * .017, -uTime * .013));
    float n2 = noise(uv * 10.0 - vec2(uTime * .010, uTime * .018));
    vec3 col = mix(uAqua, uLilac, smoothstep(.0, .95, uv.y + c.x * .16 + n1 * .24));
    col = mix(col, uPeach, smoothstep(.48, 1.02, n1 * .72 + uv.y * .48 - .04));
    col = mix(col, uRose, smoothstep(.55, .92, n2) * .34);
    col = mix(col, uGold, smoothstep(.72, 1.0, .5 + .5 * sin((uv.x + uv.y) * 8.5 - uTime * .15)) * .15);

    // painted cloud reflections
    float band = smoothstep(.47, .82, noise(uv * vec2(3.0, 6.0) + vec2(uTime*.012, 0.0)));
    col = mix(col, vec3(1.0, .93, .94), band * .16);
    float band2 = smoothstep(.6, .9, noise(uv * vec2(6.5, 2.4) - vec2(uTime*.008, .0) + 4.0));
    col = mix(col, vec3(.95, .86, 1.0), band2 * .14);

    // a broad path of sunset on the water
    float sunStreak = exp(-pow((uv.x - .67) * 3.6 + (uv.y - .45) * 1.4, 2.0) * 6.0);
    col += uGold * sunStreak * (.20 + fres * .45);
    col += uPeach * fres * .18;

    // tiny caustic glints
    float caustic = sin(uv.x * 93.0 + uTime * .38 + sin(uv.y * 25.0) * 2.0)
                  * sin(uv.y * 80.0 - uTime * .31 + sin(uv.x * 21.0) * 2.0);
    float glint = smoothstep(.92, 1.0, caustic) * smoothstep(.03, .4, fres);
    col += vec3(1.0, .9, .68) * glint * .85;

    // thin iridescent surface film
    vec3 iri = .5 + .5 * cos(6.28318 * (fres * 1.3 + vec3(0.0, .33, .67) + vec3(uv.x * .15 + .04)));
    col = mix(col, iri, .07 + fres * .12);
    col += fres * vec3(1.0, .81, .69) * .18;

    // darken the inside corners just a touch, keeping an illuminated rim
    float edge = smoothstep(.34, .47, max(abs(c.x), abs(c.y)));
    col = mix(col, col * vec3(1.04, .98, 1.07) + vec3(.045,.03,.06), edge * .28);
    float rim = smoothstep(.44, .49, max(abs(c.x), abs(c.y)));
    col += vec3(1.0, .84, .58) * rim * .12;

    gl_FragColor = vec4(col, 1.0);
  }
`;function vS(){let i=new cn(Mn.waterSize,Mn.waterSize,96,96),e=new xt({uniforms:{uTime:{value:0},uAqua:{value:new q("#6fcbdc")},uLilac:{value:new q("#ba9ce8")},uPeach:{value:new q("#ffad92")},uGold:{value:new q("#ffd786")},uRose:{value:new q("#ff93b8")}},vertexShader:_S,fragmentShader:xS}),t=new W(i,e);return t.rotation.x=-Math.PI/2,t.position.y=Mn.waterY,t.receiveShadow=!1,t}var yS=`
  varying vec3 vN;
  varying vec3 vV;
  varying vec3 vColor;
  varying vec3 vWorld;
  void main() {
    mat4 im = mat4(1.0);
    #ifdef USE_INSTANCING
      im = instanceMatrix;
    #endif
    vec4 wp = modelMatrix * im * vec4(position, 1.0);
    vWorld = wp.xyz;
    mat3 nm = mat3(modelMatrix) * mat3(im);
    vN = normalize(nm * normal);
    vV = normalize(cameraPosition - wp.xyz);
    #ifdef USE_INSTANCING_COLOR
      vColor = instanceColor;
    #else
      vColor = vec3(1.0);
    #endif
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`,MS=`
  precision highp float;
  uniform vec3 uWarm, uCool, uRim, uShade, uLightDir;
  uniform float uTime;
  varying vec3 vN;
  varying vec3 vV;
  varying vec3 vColor;
  varying vec3 vWorld;

  void main() {
    vec3 N = normalize(vN);
    vec3 V = normalize(vV);
    vec3 L = normalize(uLightDir);
    float up = N.y * .5 + .5;
    float ndl = dot(N, L) * .5 + .5;
    float band = smoothstep(.28,.34,ndl) * .18
               + smoothstep(.50,.56,ndl) * .19
               + smoothstep(.73,.79,ndl) * .17;
    vec3 base = mix(vColor * uWarm, vColor * uCool, smoothstep(.08,.9,up));
    base *= .70 + band + .10 * up;
    base = mix(base, base * uShade, (1.0 - up) * .26);
    float rim = pow(1.0 - clamp(dot(N,V),0.0,1.0), 2.4);
    base += uRim * rim * .16;
    base += uWarm * smoothstep(.55,.0,up) * .07;
    float underGlow = smoothstep(.7, -2.8, vWorld.y);
    base += uWarm * underGlow * .075;
    float m = sin(vColor.r*10.0 + N.x*3.1 + N.y*4.7 + uTime*.04);
    base *= .985 + m * .012;
    // let the silhouette sigh into the air instead of ending on a hard edge
    float facing = clamp(dot(N,V), 0.0, 1.0);
    float alpha = .40 + .60 * pow(facing, .38);
    gl_FragColor = vec4(base, alpha);
  }
`;function bS(){return new xt({vertexShader:yS,fragmentShader:MS,transparent:!0,depthWrite:!0,uniforms:{uWarm:{value:new q("#ffdccb")},uCool:{value:new q("#edf1ff")},uRim:{value:new q("#fff0dc")},uShade:{value:new q("#a9a1c8")},uLightDir:{value:new A(8.5,18.5,12).normalize()},uTime:{value:0}}})}function ES(){let i=[{p:[0,0,0],s:[1,.86,1]},{p:[.72,.1,.24],s:[.78,.64,.78]},{p:[-.62,.08,-.15],s:[.68,.64,.62]},{p:[.18,.42,-.4],s:[.55,.56,.54]},{p:[-.22,.3,.48],s:[.6,.48,.58]},{p:[.16,-.35,.26],s:[.58,.36,.56]}],e=[];for(let a of i){let l=new Tn(1,2),c=new nt().compose(new A(a.p[0],a.p[1],a.p[2]),new $t().setFromEuler(new Gn(a.s[1]*.3,a.s[0]*1.7,a.s[2]*.2)),new A(a.s[0],a.s[1],a.s[2]));l.applyMatrix4(c),l.deleteAttribute("uv"),e.push(l)}let t=h_(e,!1),n=t.attributes.position;for(let a=0;a<n.count;a++){let l=n.getX(a),c=n.getY(a),h=n.getZ(a),u=1+.055*Math.sin(l*5.1+c*2.2+1.1)*Math.cos(h*4.3)+.03*Math.sin(c*7.2+h*4.7);n.setXYZ(a,l*u,c*u,h*u)}t.computeVertexNormals(),t.computeBoundingBox();let s=t.boundingBox,o=1/Math.max(Math.abs(s.min.x),Math.abs(s.max.x),Math.abs(s.min.z),Math.abs(s.max.z),Math.abs(s.min.y),Math.abs(s.max.y));return t.scale(o,o,o),t.computeBoundingBox(),t.computeBoundingSphere(),t}function SS(){let i=ft(20241030),e=[],t=["#fffdf9","#fff9f3","#fff4ee","#fffaf5","#fff1ed"],n=["#fff0f2","#ffe9ed","#ffeef4","#ffe7ee"],s=["#f5f0ff","#edf3ff","#f7f1fd"],r=["#fff2e6","#ffeadf","#fff4e8"],o=u=>u[Math.floor(i()*u.length)],a=(u,d,f,p,_,g,m,v)=>e.push({x:u,y:d,z:f,sx:p,sy:_,sz:g,color:m,rot:i()*xe,phase:v}),l=Mn.size/2,c=[[1,1],[1,-1],[-1,-1],[-1,1]],h=[{nx:0,nz:1,tx:1,tz:0},{nx:1,nz:0,tx:0,tz:-1},{nx:0,nz:-1,tx:-1,tz:0},{nx:-1,nz:0,tx:0,tz:1}];for(let u of h){for(let d=0;d<26;d++){let f=(-.95+d/19*1.9)*l,p=.28+i()*.32,_=.24+i()*.26,g=l-p*.9-.02;a(u.nx*g+u.tx*f,.09+i()*.12,u.nz*g+u.tz*f,u.tx?p*1.55:_,.22+i()*.22,u.tz?p*1.55:_,o(i()<.18?n:t),i()*xe)}for(let d=0;d<20;d++){let f=(-.93+d/19*1.86)*(l-.55),p=.26+i()*.32,_=l-.53+(i()-.5)*.12;a(u.nx*_+u.tx*f,.18+i()*.13,u.nz*_+u.tz*f,u.tx?p*1.5:p*1.1,.19+i()*.16,u.tz?p*1.5:p*1.1,o(i()<.2?r:t),i()*xe)}for(let d=0;d<14;d++){let f=(-.92+d/13*1.84)*(l-1),p=.22+i()*.28,_=l-1.02+(i()-.5)*.12;a(u.nx*_+u.tx*f,.24+i()*.08,u.nz*_+u.tz*f,u.tx?p*1.4:p,.16+i()*.13,u.tz?p*1.4:p,o(i()<.15?n:t),i()*xe)}for(let d=0;d<8;d++){let f=(-.82+d/7*1.64)*(l-.3),p=.55+i()*.4,_=l-p*.82;a(u.nx*_+u.tx*f,-.18-i()*.12,u.nz*_+u.tz*f,p*(u.tx?1.8:1),p*.5,p*(u.tz?1.8:1),o(i()<.2?r:t),i()*xe)}for(let d=0;d<7;d++){let f=(-.84+d/6*1.68)*(l-.15),p=.62+i()*.45,_=l-p*.55;a(u.nx*_+u.tx*f,-.88-i()*.18,u.nz*_+u.tz*f,p*(u.tx?1.55:1),p*.55,p*(u.tz?1.55:1),o(i()<.24?r:t),i()*xe)}for(let d=0;d<6;d++){let f=(-.82+d/5*1.64)*(l-.15),p=.62+i()*.46,_=l-p*.48;a(u.nx*_+u.tx*f,-1.64-i()*.2,u.nz*_+u.tz*f,p*(u.tx?1.35:1),p*.58,p*(u.tz?1.35:1),o(i()<.3?n:t),i()*xe)}for(let d=0;d<5;d++){let f=(-.78+d/4*1.56)*(l-.2),p=.45+i()*.34,_=l-p*.65;a(u.nx*_+u.tx*f,-2.34-i()*.16,u.nz*_+u.tz*f,p*(u.tx?1.35:1),p*.52,p*(u.tz?1.35:1),o(t),i()*xe)}for(let d=0;d<15;d++){let f=(-.87+d/14*1.74)*(Mn.upperSize/2),p=.18+i()*.25,_=Mn.upperSize/2-.17+(i()-.5)*.14;a(u.nx*_+u.tx*f,.4+i()*.11,u.nz*_+u.tz*f,p*(u.tx?1.55:1.1),.14+i()*.18,p*(u.tz?1.55:1.1),o(i()<.22?n:t),i()*xe)}for(let d=0;d<10;d++){let f=(-.85+d/9*1.7)*(Mn.upperSize/2),p=.14+i()*.23,_=Mn.upperSize/2-.32+(i()-.5)*.12;a(u.nx*_+u.tx*f,.52+i()*.08,u.nz*_+u.tz*f,p*(u.tx?1.35:1),.12+i()*.15,p*(u.tz?1.35:1),o(i()<.18?r:t),i()*xe)}}for(let[u,d]of c){for(let f=0;f<5;f++){let p=.45+i()*.45;a(u*(l-.5),-.1-f*.5,d*(l-.5),p*1.3,p*.5,p*1.2,o(i()<.2?n:t),i()*xe)}for(let f=0;f<2;f++)a(u*(l-.28),.18+f*.08,d*(l-.28),.3+i()*.2,.18+i()*.1,.3+i()*.2,o(t),i()*xe);a(u*(Mn.upperSize/2-.24),.48,d*(Mn.upperSize/2-.24),.24+i()*.18,.16+i()*.11,.24+i()*.18,o(n),i()*xe)}for(let u=0;u<20;u++){let d=i()*xe,f=4.6+i()*4.6,p=.4+i()*.55;a(Math.cos(d)*f,-3.1-i()*.22,Math.sin(d)*f,p*1.2,p*(.18+i()*.2),p*.9,o(i()<.5?t:r),i()*xe)}for(let u=0;u<34;u++){let d=h[Math.floor(i()*4)],f=(i()-.5)*1.8*l,p=.1+i()*.18,_=l-(i()*.45+.18);a(d.nx*_+d.tx*f,-.18-i()*2.1,d.nz*_+d.tz*f,p*1.2,p*.55,p*1.1,o(i()<.2?n:t),i()*xe)}return e}function TS(){let i=SS(),e=ES(),t=bS(),n=new En(e,t,i.length);n.instanceMatrix.setUsage($s),n.castShadow=!1,n.receiveShadow=!1,n.frustumCulled=!1;let s=new _t,r=new q;for(let u=0;u<i.length;u++)r.set(i[u].color),n.setColorAt(u,r);n.instanceColor&&(n.instanceColor.needsUpdate=!0);let o=i.map(u=>u.y),a=i.map(u=>u.x),l=i.map(u=>u.z),c=1.28;function h(u){for(let d=0;d<i.length;d++){let f=i[d];s.position.set(a[d]+Math.sin(u*.11+f.phase)*.025,o[d]+Math.sin(u*.25+f.phase)*.045,l[d]+Math.cos(u*.09+f.phase*1.3)*.02),s.rotation.set(Math.sin(u*.07+f.phase)*.04,f.rot,Math.cos(u*.06+f.phase)*.03);let p=1+Math.sin(u*.2+f.phase)*.01;s.scale.set(f.sx*c*p,f.sy*c,f.sz*c*p),s.updateMatrix(),n.setMatrixAt(d,s.matrix)}n.instanceMatrix.needsUpdate=!0,t.uniforms.uTime.value=u}return h(0),{inst:n,apply:h}}var fd;function d_(){return Cn(512,512,(i,e,t)=>{let n=i.createLinearGradient(0,0,0,t);n.addColorStop(0,"#fffcf8"),n.addColorStop(.4,"#fff7f0"),n.addColorStop(.75,"#ffefe9"),n.addColorStop(1,"#ffe9e3"),i.fillStyle=n,i.fillRect(0,0,e,t);let s=ft(771);for(let r=0;r<120;r++){let o=s()*e,a=s()*t,l=20+s()*90,c=i.createRadialGradient(o,a,0,o,a,l),h=["255,251,244","255,236,232","247,235,250","255,243,231"][r%4];c.addColorStop(0,"rgba("+h+",.25)"),c.addColorStop(1,"rgba("+h+",0)"),i.fillStyle=c,i.fillRect(o-l,a-l,l*2,l*2)}for(let r=0;r<700;r++)i.fillStyle=r%3?"rgba(255,255,255,.16)":"rgba(255,194,187,.08)",i.beginPath(),i.arc(s()*e,s()*t,.6+s()*2.2,0,7),i.fill();i.strokeStyle="rgba(255,255,255,.10)",i.lineWidth=10;for(let r=0;r<9;r++)i.beginPath(),i.arc(s()*e,t*.65+s()*t*.2,50+s()*120,Math.PI*1.1,Math.PI*1.95),i.stroke()},{repeat:[1.4,1.4]})}var wS=`
  varying vec3 vN;
  varying vec3 vV;
  varying vec3 vWorld;
  varying vec3 vLocal;
  void main(){
    vLocal = position;
    vec4 wp = modelMatrix * vec4(position,1.0);
    vWorld = wp.xyz;
    vN = normalize(mat3(modelMatrix) * normal);
    vV = normalize(cameraPosition - wp.xyz);
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`,RS=`
  precision highp float;
  uniform vec3 uTop,uMid,uBottom,uRim,uShade,uLightDir;
  uniform float uTime;
  varying vec3 vN;
  varying vec3 vV;
  varying vec3 vWorld;
  varying vec3 vLocal;
  void main(){
    vec3 N = normalize(vN);
    vec3 V = normalize(vV);
    vec3 L = normalize(uLightDir);
    float up = N.y*.5+.5;
    float ndl = dot(N,L)*.5+.5;
    vec3 base = mix(uBottom,uMid,smoothstep(.05,.6,up));
    base = mix(base,uTop,smoothstep(.45,1.0,up));
    float band = smoothstep(.30,.36,ndl)*.19 + smoothstep(.52,.58,ndl)*.18 + smoothstep(.74,.8,ndl)*.15;
    base *= .68 + band + .08*up;
    base = mix(base, base*uShade, (1.0-up)*.22);
    // quiet airy mottling
    vec3 q = vWorld * .7;
    float m = sin(q.x*1.1 + sin(q.z*.8+uTime*.02)*2.0) * sin(q.y*1.4 + q.z*.9)
            + .5*sin(q.x*2.2 - q.z*1.7 + .8);
    base *= .96 + m*.020;
    float rim = pow(1.0 - clamp(dot(N,V),0.0,1.0), 2.3);
    base += uRim*rim*.24;
    base += uMid * smoothstep(-.2,.5,vLocal.y) * .02;
    base += vec3(1.0,.72,.62) * smoothstep(.1,-3.0,vWorld.y) * .05;
    gl_FragColor = vec4(base,1.0);
  }
`;function u_(){return fd=fd||d_(),new xt({uniforms:{uTop:{value:new q("#fffaff")},uMid:{value:new q("#fff1f4")},uBottom:{value:new q("#f8e3e6")},uRim:{value:new q("#fff1d8")},uShade:{value:new q("#a29bca")},uLightDir:{value:new A(8.5,18.5,12).normalize()},uTime:{value:0}},vertexShader:wS,fragmentShader:RS})}function AS(i=20.2,e=3.3,t=20.2){let n=new kr(i,e,t,16,2.2),s=n.attributes.position,r=n.attributes.normal;for(let o=0;o<s.count;o++){let a=s.getX(o),l=s.getY(o),c=s.getZ(o),h=r.getX(o),u=r.getY(o),d=r.getZ(o),f=.085*Math.sin(a*.82+c*.63+l*1.5+1.3)+.062*Math.cos(c*1.15-a*.5+l*1.1)+.035*Math.sin(a*2.4-c*1.8+.7)+.022*Math.cos(l*4.1+c*2.5);s.setXYZ(o,a+h*f,l+u*f*.8,c+d*f)}return n.computeVertexNormals(),n}function CS(){let i=new ce;fd=fd||d_();let e=new W(AS(),u_());e.position.y=-1.6,e.castShadow=!0,e.receiveShadow=!0,i.add(e);let t=new kr(Mn.size+.06,.36,Mn.size+.06,8,1.75),n=u_(),s=new W(t,n);return s.position.y=-.08,s.castShadow=!0,s.receiveShadow=!0,i.add(s),{group:i,mass:e,shelf:s}}function PS(){let i=new ce,e=Mn.upperSize,t=Mn.frameInner,n=mS(e,1.55);n.holes.push(gS(t,1.35));let s=.48,r=new en(n,{depth:s,bevelEnabled:!0,bevelSegments:3,steps:1,bevelSize:.075,bevelThickness:.055,curveSegments:18});r.rotateX(-Math.PI/2);let o=new hn({color:"#ffe0d5",roughness:.18,metalness:.02,clearcoat:1,clearcoatRoughness:.14,iridescence:.55,iridescenceIOR:1.26,transparent:!0,opacity:.93,side:De,envMapIntensity:.85}),a=new W(r,o);a.position.y=-.08,a.castShadow=!0,a.receiveShadow=!0,i.add(a),i.add(dd(e+.02,1.57,.445,.035,k.brass)),i.add(dd(t+.01,1.35,.435,.02,new Qe({color:new q("#fff0c7").multiplyScalar(1.15),toneMapped:!1}))),i.add(dd(e+.2,1.66,-.16,.024,k.brassSoft));let l=N(ve(t-.03,.1,t-.03,1.25,5),new Ht({color:"#8ed4de",gradientMap:Zt,emissive:"#6dafcc",emissiveIntensity:.1}),{pos:[0,.06,0]});l.receiveShadow=!1,i.add(l);for(let c=0;c<6;c++){let h=pt(c%2?"pink":"gold",1.1+c*.4,.05);h.position.set((c%3-1)*5.2,.22,(c%2?1:-1)*3.8),i.add(h)}return i}function IS(){let i=new ce,e=new Qe({color:new q("#fff2d2").multiplyScalar(1.4),transparent:!0,opacity:.2,blending:wt,depthWrite:!1,side:De,toneMapped:!1}),t=[[7,3.1,.42],[7.35,3.35,.52],[7.7,3.6,.38]];for(let[s,r,o]of t){let a=new W(new vs(.955,1,128),e.clone());a.rotation.x=-Math.PI/2,a.position.y=o,a.scale.set(s,r,1),a.userData={baseScale:s,baseZ:r,phase:s*2.3},i.add(a)}return{g:i,update:s=>{for(let r of i.children){let o=1+Math.sin(s*.15+r.userData.phase)*.035;r.scale.set(r.userData.baseScale*o,r.userData.baseZ*o,1),r.material.opacity=.11+.09*(.5+.5*Math.sin(s*.15+r.userData.phase))}}}}function DS(){let i=new ce,e=hd(256),t=new ln({map:e,color:"#ffbca8",transparent:!0,opacity:.22,depthWrite:!1,blending:wt,toneMapped:!1}),n=[[0,-2.1,3.5,17],[0,-2.7,-4.5,19],[-4.5,-2.2,5,13],[4.8,-1.7,5.5,12],[-6.5,-2.4,-4,11],[6.2,-2.1,-5.1,12]];for(let[s,r,o,a]of n){let l=new Dn(t.clone());l.position.set(s,r,o),l.scale.set(a*1.35,a*.65,1),i.add(l)}return i.userData.base=i.children.map(s=>s.position.y),i}function LS(i,e,t){let n=new ce;n.position.set(i,t,e);let s=N(new xn(.006,.006,.35,4),k.brassSoft,{pos:[0,-.175,0]});n.add(s);let r=new W(new xs(.09,1),k.brass);return r.position.y=-.4,r.scale.y=1.4,n.add(r),n}function f_(){let i=document.createElement("canvas");i.width=512,i.height=512;let e=i.getContext("2d");e.clearRect(0,0,512,512),e.filter="blur(14px)";let t=[[150,290,95,.42],[230,255,125,.52],[315,280,110,.48],[390,315,80,.38],[195,330,100,.38],[280,330,130,.42],[355,345,90,.38],[110,345,70,.3],[260,200,75,.34],[335,215,70,.28],[200,380,120,.24],[310,400,130,.26]];for(let[s,r,o,a]of t){let l=e.createRadialGradient(s,r,0,s,r,o);l.addColorStop(0,"rgba(255,250,244,"+a+")"),l.addColorStop(.55,"rgba(255,238,234,"+a*.55+")"),l.addColorStop(1,"rgba(255,225,224,0)"),e.fillStyle=l,e.fillRect(s-o,r-o,o*2,o*2)}let n=new pi(i);return n.colorSpace=Wt,n}function NS(){let i=new ce,e=f_(),t=[[0,.25,9.8,9,.3],[5.2,.32,8.4,7,.26],[-5.2,.22,8.4,7.5,.27],[9.7,.22,2.5,8,.26],[9.8,.2,-1.8,7,.24],[-9.7,.18,2.5,8.2,.26],[-9.8,.16,-1.8,7,.24],[0,.14,-9.7,8.4,.22],[6,-.8,8.9,7,.2],[-6.4,-.9,8.6,7,.2],[9.6,-.9,-4.4,6.3,.18],[-9.5,-1,-4.4,6.3,.18],[2.8,-1.3,9.3,6.5,.16],[-2.8,-1.35,9.3,6.5,.16]];for(let[n,s,r,o,a]of t){let l=new ln({map:e,color:"#fff4ec",transparent:!0,opacity:a,depthWrite:!1,toneMapped:!0}),c=new Dn(l);c.position.set(n,s,r),c.scale.set(o*1.55,o*.78,1),c.renderOrder=2,i.add(c)}return i}function p_(){let i=new ce;i.name="cloud-base";let e=CS();i.add(e.group);let t=PS();i.add(t);let n=vS();i.add(n),i.add(dd(Mn.size+.04,2.1,.015,.012,new Qe({color:"#ffedc8",transparent:!0,opacity:.38,toneMapped:!1}),180));let{inst:s,apply:r}=TS();i.add(s),i.add(NS());let o=[[1,1],[1,-1],[-1,1],[-1,-1]];for(let[p,_]of o){let g=new W(new xs(.14,0),k.brass);if(g.position.set(p*(Mn.size/2-.18),-.05,_*(Mn.size/2-.18)),g.scale.set(1.2,.7,1.2),i.add(g),p*_>0){let m=LS(p*(Mn.size/2-.22),_*(Mn.size/2-.15),-1);i.add(m)}}let a=DS();i.add(a);let l=f_();for(let p=0;p<7;p++){let _=new ln({map:l,color:p%2?"#ffe4db":"#fff1e6",transparent:!0,opacity:.16,depthWrite:!1}),g=new Dn(_),m=p/7*xe;g.position.set(Math.cos(m)*5.1,-3.1+Math.sin(p)*.1,Math.sin(m)*5.1),g.scale.set(10+p,3.2+p*.3,1),i.add(g)}let c=IS();i.add(c.g);let h=ft(451);for(let p=0;p<12;p++){let _=h()*xe,g=5.6+h()*2.4,m=N(ze(.11,1),new Ht({color:"#ffd7df",gradientMap:Zt}),{pos:[Math.cos(_)*g,Mn.waterY+.075,Math.sin(_)*g],scale:[1.6+h()*.7,.28,.75+h()*.4],rot:[0,h()*xe,0]});m.castShadow=!1,m.receiveShadow=!1,i.add(m)}let u=[[-2.5,-1.4,0,"#ffae98",5.2,12],[4.5,-1.5,3.5,"#ffd0a9",3.5,11],[-5,-1.8,4.2,"#ffb8be",2.5,9]];for(let[p,_,g,m,v,E]of u){let y=new Yt(m,v,E,2);y.position.set(p,_,g),i.add(y)}let d=a.userData.base;function f(p){r(p),n.material.uniforms.uTime.value=p,c.update(p),s.material.uniforms.uTime.value=p,e.mass.material.uniforms?.uTime&&(e.mass.material.uniforms.uTime.value=p),e.shelf.material.uniforms?.uTime&&(e.shelf.material.uniforms.uTime.value=p),a.children.forEach((_,g)=>{_.position.y=d[g]+Math.sin(p*.08+g)*.08})}return{group:i,update:f,inst:s,water:n}}var Vr=2.8,pa=2.72,__=14.8,x_=-7.4,Bp=92,Gr=48,pd=[{t:0,w:.035,h:.045,cy:1.5},{t:.025,w:.63,h:.4,cy:1.39},{t:.075,w:1.52,h:.8,cy:1.29},{t:.145,w:2.37,h:1.1,cy:1.23},{t:.24,w:2.83,h:1.31,cy:1.23},{t:.38,w:3,h:1.42,cy:1.26},{t:.52,w:2.96,h:1.42,cy:1.3},{t:.64,w:2.66,h:1.31,cy:1.37},{t:.76,w:2.08,h:1.08,cy:1.47},{t:.85,w:1.49,h:.8,cy:1.58},{t:.93,w:.82,h:.45,cy:1.68},{t:.98,w:.27,h:.16,cy:1.76},{t:1,w:.055,h:.06,cy:1.8}];function v_(i){i=Fc(i,0,1);let e=0;for(;e<pd.length-2&&i>pd[e+1].t;)e++;let t=pd[e],n=pd[e+1],s=Fc((i-t.t)/(n.t-t.t),0,1),r=s*s*(3-2*s);return{t:i,w:t.w+(n.w-t.w)*r,h:t.h+(n.h-t.h)*r,cy:t.cy+(n.cy-t.cy)*r}}function Qs(i,e){let t=v_(i),n=x_+__*i,s=Math.sin(i*Math.PI)*.19-i*.06,r=t.w*Math.sign(Math.cos(e))*Math.pow(Math.abs(Math.cos(e)),.9),o=t.h*Math.sign(Math.sin(e))*Math.pow(Math.abs(Math.sin(e)),.82);return{x:n,y:t.cy+o,z:s+r,top:t.cy+t.h,width:t.w,height:t.h,centerY:t.cy,centerZ:s}}var US=`
  varying vec3 vN;
  varying vec3 vV;
  varying vec3 vLocal;
  void main() {
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vN = normalize(mat3(modelMatrix) * normal);
    vLocal = position;
    vV = normalize(cameraPosition - wp.xyz);
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`,FS=`
  precision highp float;
  uniform vec3 uTop, uSide, uBelly, uRim, uAurora, uShadow;
  uniform vec3 uLight;
  uniform float uTime;
  uniform float uOpacity;
  varying vec3 vN;
  varying vec3 vV;
  varying vec3 vLocal;

  void main() {
    vec3 n = normalize(vN);
    if (!gl_FrontFacing) n = -n;
    vec3 v = normalize(vV);
    vec3 l = normalize(uLight);

    float top = smoothstep(-.15, 2.66, vLocal.y);
    float bandTop = smoothstep(1.10, 2.45, vLocal.y);
    vec3 base = mix(uBelly, uSide, smoothstep(-.25, .85, vLocal.y));
    base = mix(base, uTop, smoothstep(.28, 1.0, bandTop));

    float ndl = dot(n, l) * .5 + .5;
    float lightBand = smoothstep(.30,.36,ndl) * .19
                    + smoothstep(.50,.56,ndl) * .18
                    + smoothstep(.72,.78,ndl) * .15
                    + smoothstep(.86,.91,ndl) * .10;
    base *= .64 + lightBand;

    // cool shadow pooled along the flank
    float under = smoothstep(.55, .95, 1.0 - top);
    base = mix(base, uShadow, under * .12);

    // warm light glowing through the rim
    float rim = pow(1.0 - clamp(dot(n, v), 0.0, 1.0), 2.05);
    base += uRim * rim * .58;
    float through = pow(max(dot(-n, l), 0.0), 2.2);
    base += uRim * through * .12;
    base = mix(base, uBelly, smoothstep(.35, 0.0, top) * .24);

    // opaline aurora along the back
    float aurora = smoothstep(.55, 1.0, bandTop) * smoothstep(2.0, .8, abs(vLocal.z));
    float ribbon = .5 + .5 * sin(vLocal.x * .95 + uTime * .30 + vLocal.z * 1.7);
    base = mix(base, uAurora, aurora * (.18 + ribbon * .18));
    base += uAurora * aurora * .05;

    // pearly sheen
    vec3 h = normalize(l + v);
    base += vec3(1.0, .96, .88) * pow(max(dot(n, h), 0.0), 11.0) * .12;

    // translucent marble veins
    float vein = smoothstep(.94, 1.0, .5 + .5 * sin(vLocal.x * 3.9 + sin(vLocal.y * 5.2) * 2.0 + vLocal.z * 1.5));
    base = mix(base, uRim, vein * .08);

    gl_FragColor = vec4(base, uOpacity);
  }
`;function m_(i=!1,e=.955){return new xt({uniforms:{uTop:{value:new q("#d4ebe3")},uSide:{value:new q("#a7d2ce")},uBelly:{value:new q("#f5c5c0")},uRim:{value:new q("#ffedc7")},uAurora:{value:new q("#a8e3d2")},uShadow:{value:new q("#7baeb5")},uLight:{value:new A(-.4,.82,.55).normalize()},uTime:{value:0},uOpacity:{value:e}},vertexShader:US,fragmentShader:FS,transparent:!0,depthWrite:!0,side:i?De:zi})}function BS(){let i=[],e=[];for(let n=0;n<=Bp;n++){let s=n/Bp;for(let r=0;r<=Gr;r++){let o=r/Gr*xe,a=Qs(s,o);i.push(a.x,a.y,a.z)}}for(let n=0;n<Bp;n++)for(let s=0;s<Gr;s++){let r=n*(Gr+1)+s,o=(n+1)*(Gr+1)+s,a=(n+1)*(Gr+1)+s+1,l=n*(Gr+1)+s+1;e.push(r,o,l,o,a,l)}let t=new ke;return t.setAttribute("position",new _e(i,3)),t.setIndex(e),t.computeVertexNormals(),t}function OS(){let i=new kt;i.moveTo(0,0),i.bezierCurveTo(.28,.35,.63,.99,1.15,1.58),i.bezierCurveTo(1.75,2.25,2.65,2.86,3.42,2.62),i.bezierCurveTo(3.84,2.48,3.52,2.03,3.2,1.74),i.bezierCurveTo(2.88,1.42,2.62,1.31,2.33,.99),i.bezierCurveTo(2.07,.69,1.83,.64,1.55,.4),i.bezierCurveTo(1.16,.12,.65,.02,0,0);let e=new en(i,{depth:.105,bevelEnabled:!0,bevelSegments:3,steps:1,bevelSize:.045,bevelThickness:.04,curveSegments:28});e.rotateX(Math.PI/2);let t=e.attributes.position;for(let n=0;n<t.count;n++){let s=t.getZ(n),r=.42*Math.pow(Math.max(0,s)/3.35,2.1);t.setY(n,t.getY(n)+r)}return e.computeVertexNormals(),e}function HS(){return[[0,0],[.28,.35],[.63,.99],[1.15,1.58],[1.75,2.25],[2.65,2.86],[3.42,2.62],[3.84,2.48],[3.52,2.03],[3.2,1.74],[2.88,1.42],[2.62,1.31],[2.33,.99],[2.07,.69],[1.83,.64],[1.55,.4],[1.16,.12],[.65,.02],[0,0]].map(([e,t])=>ne(e,.075+.42*Math.pow(Math.max(0,t)/3.35,2.1),t))}function g_(i,e){let t=new ce,s=Qs(.235,i>0?.06:Math.PI-.06);t.position.set(s.x,1.58,i*(Math.abs(s.z)-.02));let r=.44;t.rotation.x=i>0?r:Math.PI-r,t.rotation.z=i>0?-.1:.1,t.rotation.y=i>0?.07:-.07,t.userData.baseX=t.rotation.x,t.userData.baseZ=t.rotation.z,t.userData.side=i;let o=new W(OS(),e);o.castShadow=!0,o.receiveShadow=!0,t.add(o);let a=HS(),l=nn("#efc77f");l.side=De;let c=new W(new et(new je(a,!1,"centripetal"),84,.027,5,!1),l);c.castShadow=!1,t.add(c);for(let d=0;d<4;d++){let f=.35+d*.38,p=1.8+d%2*.35,_=new je([ne(.12,.06,-.02),ne(.4+Math.cos(f)*.1,.07,.4+d*.13),ne(.9+Math.sin(f)*.3,.075,.9+d*.18),ne(1.6+Math.sin(f)*.2,.08,1.35+d*.15)]),g=new W(new et(_,20,.011,3),k.brassSoft);g.castShadow=!1,t.add(g)}let h=N(ze(.075,2),Yn("#ffe3a8",.9),{pos:[3.35,.38,2.48]});h.castShadow=!1;let u=new W(new dt(.2,.026,5,18,Math.PI*1.5),k.brassSoft);return u.rotation.z=.2,t.add(u),t.add(h),t}function zS(){let i=new kt;i.moveTo(0,0),i.bezierCurveTo(.28,.45,.38,1.18,.92,1.86),i.bezierCurveTo(1.3,2.32,2.1,2.78,2.58,2.48),i.bezierCurveTo(2.96,2.23,2.7,1.76,2.33,1.3),i.bezierCurveTo(1.96,.86,1.64,.44,1.3,.15),i.quadraticCurveTo(1.02,-.05,.68,0),i.quadraticCurveTo(.25,.01,0,0);let e=new en(i,{depth:.17,bevelEnabled:!0,bevelSegments:3,steps:1,bevelSize:.07,bevelThickness:.06,curveSegments:24});return e.rotateX(-Math.PI/2),e.computeVertexNormals(),e}function kS(i){let e=new ce;e.position.set(6.98,1.8,0),e.rotation.z=.12;let t=zS(),n=nn("#efc57e");n.side=De,e.scale.setScalar(1.1);let s=new ce;s.rotation.x=.44,s.position.z=-.015;let r=new W(t,i);r.castShadow=!0,r.receiveShadow=!0,s.add(r);for(let f=0;f<3;f++){let p=[ne(.18+f*.05,.11,-.06),ne(1+f*.08,.1,-.35-f*.1),ne(1.65+f*.02,.1,-.8-f*.15),ne(2.1-f*.1,.08,-1.4-f*.08)],_=new W(new et(new je(p),24,.011,3),n);_.castShadow=!1,s.add(_)}let o=[ne(0,.025,0),ne(.55,.03,-.9),ne(1.1,.03,-1.8),ne(2.18,.01,-2.23)],a=new W(new et(new je(o),26,.025,5),n);s.add(a),e.add(s);let l=new ce;l.rotation.x=-.44,l.position.z=.015,l.scale.z=-1;let c=new W(t,i);c.castShadow=!0,c.receiveShadow=!0,l.add(c);for(let f=0;f<3;f++){let p=[ne(.18+f*.05,.11,-.06),ne(1+f*.08,.1,-.35-f*.1),ne(1.65+f*.02,.1,-.8-f*.15),ne(2.1-f*.1,.08,-1.4-f*.08)],_=new W(new et(new je(p),24,.011,3),n);_.castShadow=!1,l.add(_)}let h=new W(new et(new je(o.map(f=>f.clone())),26,.025,5),n);l.add(h),e.add(l);let u=N(ze(.075,2),Yn("#ffe2a8",1.15),{pos:[.45,.12,0]});u.castShadow=!1,e.add(u);let d=new W(new dt(.22,.025,5,18,Math.PI*1.4),k.brass);return d.rotation.x=Math.PI/2,d.position.set(.02,.02,0),e.add(d),e}function GS(i){let e=new ce,t=new kt;t.moveTo(0,0),t.bezierCurveTo(.15,.35,.48,.74,.92,.88),t.bezierCurveTo(1.24,.98,1.36,.68,1.08,.33),t.bezierCurveTo(.78,.06,.35,-.03,0,0);let n=new en(t,{depth:.12,bevelEnabled:!0,bevelSegments:2,steps:1,bevelSize:.04,bevelThickness:.035,curveSegments:16}),s=new W(n,i);s.castShadow=!0,s.receiveShadow=!0,s.position.set(4.05,2.46,-.06),s.scale.set(1.45,1.25,1.15),s.rotation.y=-.04,e.add(s);let r=[ne(4.08,2.48,.07),ne(4.85,2.93,.04),ne(5.35,3.3,-.02)],o=new W(new et(new je(r),18,.018,4),nn("#efc77f"));return o.material.side=De,e.add(o),e.position.set(0,0,0),e}function VS(i,e,t){let n=v_(i),s=x_+__*i,r=Math.sin(i*Math.PI)*.19-i*.06,o=Math.pow(Fc(e/Math.max(.001,n.h),0,1),1/.82),a=Math.sqrt(Math.max(0,1-o*o)),l=r+t*n.w*Math.pow(a,.9);return{x:s,y:n.cy+e,z:l,cz:r,p:n}}function WS(){let i=new ce;for(let e of[-1,1]){let n=VS(.155,.23,e),s=e,r=new ce;r.position.set(n.x,n.y,n.z+s*.1),r.renderOrder=20;let o=new W(new Rt(1,20,12),new Qe({color:"#fff8e7",toneMapped:!1}));o.scale.set(.27,.34,.085),r.add(o);let a=new W(new Rt(1,20,12),new Qe({color:"#403a56",toneMapped:!1}));a.scale.set(.145,.235,.055),a.position.z=s*.06,r.add(a);let l=new W(new Rt(.04,10,8),new Qe({color:"#fff9df",toneMapped:!1}));l.position.set(-.05,.1,s*.12),r.add(l);let c=new W(new Rt(.018,8,6),new Qe({color:"#ffdca8",toneMapped:!1}));c.position.set(.055,-.06,s*.115),r.add(c);let h=[];for(let g=0;g<=10;g++){let m=-1.05+g/10*2.1;h.push(new A(Math.sin(m)*.29,.27+Math.cos(m)*.11,s*.13))}let u=new W(new et(new je(h),18,.018,4,!1),k.ink);u.castShadow=!1,r.add(u);for(let g=0;g<3;g++){let m=new W(new et(new je([new A(-.14+g*.14,.32,s*.13),new A(-.12+g*.14,.5,s*.135)]),5,.011,3),k.inkSoft);r.add(m)}let d=new W(new Rt(.24,16,8),new Qe({color:"#ff9db4",transparent:!0,opacity:.18,depthWrite:!1,toneMapped:!1,side:De}));d.scale.set(1.3,.5,.045),d.position.set(0,-.28,s*.11),r.add(d);let f=N(ze(.04,2),k.brassSoft,{pos:[.22,.12,s*.15]});r.add(f),i.add(r);let p=[];for(let g=0;g<=14;g++){let m=g/14,v=.035+m*.14,E=Qs(v,e>0?-.52:Math.PI+.52),y=Math.sin(m*Math.PI)*.06;p.push(new A(E.x,E.y+.05+y,E.z+s*.1))}let _=new W(new et(new je(p),30,.017,4,!1),k.inkSoft);_.castShadow=!1,i.add(_)}return i}function XS(){let i=new ce,e=ft(883),t=[[.09,.78,.022],[.12,.62,.018],[.18,.85,.02],[.24,.68,.016],[.32,.84,.018],[.51,.6,.014],[.58,.78,.016]];for(let[n,s,r]of t)for(let o of[-1,1]){let a=Qs(n,o>0?s:Math.PI-s),l=N(ze(r,2),Yn("#ffe5b4",1),{pos:[a.x,a.y,a.z+o*.015]});l.castShadow=!1,i.add(l);let c=pt("gold",r*7,.22);c.position.set(a.x,a.y,a.z+o*.03),i.add(c)}for(let n of[-1,1]){let s=[];for(let o=0;o<=34;o++){let a=.17+o/34*.66,l=Qs(a,n>0?.44:Math.PI-.44);s.push(ne(l.x,l.y+.28,l.z+n*.014))}let r=new W(new et(new je(s),54,.011,3),new Qe({color:new q("#ffdaa3"),transparent:!0,opacity:.34,blending:wt,depthWrite:!1,toneMapped:!1}));r.castShadow=!1,i.add(r)}for(let n of[-1,1])for(let s=0;s<3;s++){let r=[];for(let a=0;a<=18;a++){let l=.05+a/18*.22,c=Qs(l,n>0?-1.15+s*.16:Math.PI+1.15-s*.16);r.push(ne(c.x,c.y,c.z+n*.01))}let o=new W(new et(new je(r),30,.007,3),new Qe({color:new q("#e9aaa9"),transparent:!0,opacity:.3,depthWrite:!1,toneMapped:!1}));i.add(o)}for(let n=0;n<4;n++){let s=Qs(.07+n*.025,Math.PI*.5),r=N(ze(.035,1),Yn(n%2?"#ffdf9e":"#e6fcff",1.1),{pos:[s.x,s.top+.02,s.z+.2]});r.castShadow=!1,i.add(r)}return i}function Op(i,e,t=2.7,n=.035,s=0){let r=new kt,o=128;for(let a=0;a<=o;a++){let l=a/o*xe,c=1+Math.sin(l*5+1.7)*n+Math.sin(l*8.2+.3)*n*.55,h=Math.cos(l),u=Math.sin(l),d=Math.sign(h)*Math.pow(Math.abs(h),2/t)*i*c,f=Math.sign(u)*Math.pow(Math.abs(u),2/t)*e*c+s;a===0?r.moveTo(d,f):r.lineTo(d,f)}return r.closePath(),r}function YS(){return Cn(512,512,(i,e,t)=>{let n=i.createLinearGradient(0,0,e,t);n.addColorStop(0,"#c4e4cb"),n.addColorStop(.35,"#aad4bc"),n.addColorStop(.68,"#d1e3c0"),n.addColorStop(1,"#b4d6ca"),i.fillStyle=n,i.fillRect(0,0,e,t);let s=ft(151);for(let r=0;r<220;r++)i.fillStyle=["rgba(255,246,216,.4)","rgba(174,219,185,.5)","rgba(255,190,208,.24)","rgba(170,188,238,.18)"][r%4],i.beginPath(),i.ellipse(s()*e,s()*t,3+s()*18,1+s()*7,s()*3,0,7),i.fill();for(let r=0;r<70;r++)i.fillStyle=["#fff6e0","#ffc8d8","#e5d4ff","#ffe2a2"][r%4],i.beginPath(),i.arc(s()*e,s()*t,.7+s()*1.7,0,7),i.fill();i.strokeStyle="rgba(241,224,198,.45)",i.lineWidth=18,i.lineCap="round",i.beginPath(),i.moveTo(e*.18,t*.85),i.bezierCurveTo(e*.35,t*.68,e*.32,t*.44,e*.48,t*.3),i.stroke()})}var Hp;function qS(){let i=new ce,e=Op(3.3,2.6,3.1,.028,.08),t=new en(e,{depth:.26,bevelEnabled:!0,bevelSegments:4,steps:1,bevelSize:.1,bevelThickness:.09,curveSegments:26});t.rotateX(-Math.PI/2);let n=new Ht({color:"#d8e4ca",gradientMap:Zt,emissive:"#a9caa7",emissiveIntensity:.055}),s=new W(t,n);s.position.y=pa-.32,s.castShadow=!0,s.receiveShadow=!0,i.add(s),ns(s,"#7e6371",.018,.36);let r=new Sr(e,32);r.rotateX(-Math.PI/2);let o=r.attributes.position,a=r.attributes.uv,l=-3.5,c=3.5,h=-2.7,u=2.9;for(let F=0;F<a.count;F++)a.setXY(F,(o.getX(F)-l)/(c-l),(o.getZ(F)-h)/(u-h));Hp=Hp||YS();let d=new Ht({map:Hp,gradientMap:Zt,color:"#effae7",side:De,emissive:"#90c8a9",emissiveIntensity:.045}),f=new W(r,d);f.position.y=pa-.005,f.receiveShadow=!0,i.add(f);let p=[];for(let F=0;F<=90;F++){let I=F/90*xe,P=1+Math.sin(I*5+1.7)*.028+Math.sin(I*8.2+.3)*.015,U=Math.cos(I),z=Math.sin(I),V=Math.sign(U)*Math.pow(Math.abs(U),2/3.1)*3.3*P,ie=Math.sign(z)*Math.pow(Math.abs(z),2/3.1)*2.6*P+.08;p.push(ne(V,pa+.015,ie))}p.push(p[0].clone());let _=new W(new et(new je(p,!1,"centripetal"),160,.014,4),k.brassSoft);_.castShadow=!1,i.add(_);let g=Op(2.86,2.15,6.5,.008,0),m=new en(g,{depth:.09,bevelEnabled:!0,bevelSegments:2,steps:1,bevelSize:.045,bevelThickness:.035,curveSegments:20});m.rotateX(-Math.PI/2);let v=new Ht({color:"#dab08d",map:Pt.deck,gradientMap:Zt,emissive:"#643e30",emissiveIntensity:.03}),E=new W(m,v);E.position.set(-.05,Vr-.09,.18),E.castShadow=!0,E.receiveShadow=!0,i.add(E),ns(E,"#73515b",.013,.4);let y=[];Op(2.72,2.02,7.5,.004,0).getPoints(72).forEach(F=>y.push(ne(F.x-.05,Vr+.015,F.y+.18))),y.push(y[0].clone());let T=new W(new et(new je(y,!1,"centripetal"),160,.018,5),k.brassSoft);T.castShadow=!1,i.add(T);let x=o_(6,4.9,.46);x.position.set(-.05,Vr+.005,.15),i.add(x);let S=ft(444),C=new Tn(1,2),L=["#eef3d8","#f7e8d2","#d8e4ca","#e9def5"];for(let F=0;F<11;F++){let I=F/11*xe+(S()-.5)*.08,P=Math.cos(I),U=Math.sin(I),z=Math.sign(P)*Math.pow(Math.abs(P),2/2.8)*3.36,V=Math.sign(U)*Math.pow(Math.abs(U),2/2.8)*2.66+.08,ie=N(C,me(L[F%L.length],{emissive:"#c1d8b6",emissiveIntensity:.035}),{pos:[z,pa-.12+(S()-.5)*.06,V],scale:[.18+S()*.22,.1+S()*.12,.18+S()*.22],rot:[0,S()*xe,0]});ie.castShadow=!0,ie.receiveShadow=!0,i.add(ie)}for(let F=0;F<7;F++){let I=.4+F*1.3,P=Math.cos(I)*(2.3+F%2*.4),U=Math.sin(I)*(1.7+F%3*.2);if(Math.abs(P)<2.4&&Math.abs(U)<1.9)continue;let z=N(ze(.12+S()*.08,1),me("#e6d2c7"),{pos:[P,pa+.02,U],scale:[1.2,.4,1]});i.add(z)}return{group:i,deck:E,terrace:s}}var ZS=`
  varying vec2 vUv;
  varying vec3 vN;
  varying vec3 vV;
  void main(){
    vUv=uv;
    vec4 wp=modelMatrix*vec4(position,1.);
    vN=normalize(mat3(modelMatrix)*normal);
    vV=normalize(cameraPosition-wp.xyz);
    gl_Position=projectionMatrix*viewMatrix*wp;
  }
`,JS=`
  uniform float uTime;
  uniform vec3 uA,uB,uC;
  varying vec2 vUv;
  varying vec3 vN;
  varying vec3 vV;
  void main(){
    float along = vUv.y;
    float stream = smoothstep(0.,.08,along) * (1.0 - smoothstep(.72,1.,along));
    float running = .5+.5*sin(vUv.x*18. + along*36. - uTime*2.1 + sin(vUv.x*5.)*2.);
    float rim = pow(1.-abs(dot(normalize(vN),normalize(vV))),1.4);
    vec3 col = mix(uB,uA,smoothstep(.05,.8,along));
    col = mix(col,uC,smoothstep(.55,1.,running*.45+along*.25));
    col += uA*rim*.26;
    gl_FragColor=vec4(col, (stream*.65 + rim*.2)*(0.66+running*.34));
  }
`;function KS(){let i=new ce;i.name="whale-fountain";let e=Qs(.145,Math.PI/2);i.position.set(e.x,e.top+.02,e.z);let t=new ce;t.scale.setScalar(1.35);let n=new W(new oi(.31,32),new Qe({color:new q("#a8f3f5").multiplyScalar(1.1),transparent:!0,opacity:.85,toneMapped:!1,side:De}));n.rotation.x=-Math.PI/2,n.position.y=.015,t.add(n);let s=new W(new dt(.32,.045,8,28),k.brass);s.rotation.x=-Math.PI/2,t.add(s);let r=new W(new dt(.37,.012,4,32),new Qe({color:"#c9f8f1",transparent:!0,opacity:.35,blending:wt,depthWrite:!1,toneMapped:!1}));r.rotation.x=-Math.PI/2,r.position.y=.04,t.add(r),i.add(t);let o=pt("blue",2,.34);o.position.y=.1,i.add(o);let a=new xt({uniforms:{uTime:{value:0},uA:{value:new q("#f2feff")},uB:{value:new q("#92e7ec")},uC:{value:new q("#ffc8da")}},vertexShader:ZS,fragmentShader:JS,transparent:!0,depthWrite:!1,blending:wt,side:De});[[[0,.05,0],[-.1,1,.04],[-.34,2,.1],[-.18,2.9,-.05],[-.38,3.5,.18]],[[.03,.05,.02],[.45,.9,-.15],[.95,1.85,-.3],[1.15,2.8,-.1],[1.55,3.25,.2]],[[-.02,.05,-.02],[-.5,.8,.2],[-1,1.55,.25],[-1.5,2.3,.05],[-1.8,2.6,-.15]],[[.02,.05,.05],[.1,1.2,.4],[.35,2.1,.65],[.1,2.9,.5],[.4,3.2,.2]]].forEach((M,T)=>{let x=new je(M.map(C=>ne(...C))),S=new W(new et(x,50,T===0?.075:.038,7,!1),a);S.renderOrder=5,i.add(S)});let c=new ce;c.position.set(.05,3.4,0);for(let M=0;M<9;M++){let T=M/9*xe,x=N(ze(.04+Math.random()*.025,1),fn.blue,{pos:[Math.cos(T)*.3,Math.random()*.18,Math.sin(T)*.25],scale:[1,.7,1]});x.castShadow=!1,c.add(x)}i.add(c);let h=200,u=new ke,d=new Float32Array(h*3),f=new Float32Array(h),p=new Float32Array(h),_=new Float32Array(h*4),g=ft(534);for(let M=0;M<h;M++)_[M*4]=g(),_[M*4+1]=.25+g()*.9,_[M*4+2]=.18+g()*.9,_[M*4+3]=g(),f[M]=.06+g()*.18,p[M]=0;u.setAttribute("position",new bt(d,3)),u.setAttribute("aSize",new bt(f,1)),u.setAttribute("aAlpha",new bt(p,1));let m=new xt({uniforms:{uMap:{value:ud},uColor:{value:new q("#fff0bc")}},vertexShader:`
      attribute float aSize; attribute float aAlpha; varying float vAlpha;
      void main(){ vAlpha=aAlpha; vec4 mv=modelViewMatrix*vec4(position,1.); gl_PointSize=aSize*1000.0/max(1.0,-mv.z); gl_Position=projectionMatrix*mv; }
    `,fragmentShader:`
      uniform sampler2D uMap; uniform vec3 uColor; varying float vAlpha;
      void main(){ vec4 t=texture2D(uMap,gl_PointCoord); gl_FragColor=vec4(uColor,t.a*vAlpha); }
    `,transparent:!0,depthWrite:!1,blending:wt,toneMapped:!1}),v=new ms(u,m);v.frustumCulled=!1,i.add(v);let E=new Yt("#bceff0",2.2,7,2);E.position.set(0,1.5,0),i.add(E);let y=new ce;for(let M=0;M<7;M++){let T=pt(M%2?"pink":"gold",.22+.1*(M%3),.22);T.userData={phase:M*1.4,rad:.35+M%3*.25,y:.8+M*.32},y.add(T)}i.add(y);function w(M){a.uniforms.uTime.value=M,c.rotation.y=M*.25,c.position.y=3.4+Math.sin(M*.7)*.08;let T=u.attributes.position.array,x=u.attributes.aAlpha.array;for(let S=0;S<h;S++){let C=_[S*4],L=_[S*4+1],F=_[S*4+2],I=_[S*4+3],P=(M*.09*L+C)%1,U=Dp(0,.6,P),z=Math.sin(I*xe+P*7.2+M*.22)*F*U*.6,V=Math.cos(I*xe+P*7.2+M*.22)*F*U*.45,ie=.08+P*3.55+Math.sin(P*10+M)*.04;T[S*3]=z,T[S*3+1]=ie,T[S*3+2]=V,x[S]=Math.sin(Math.min(1,P*2.2)*Math.PI*.5)*(1-Dp(.6,1,P))*.95}u.attributes.position.needsUpdate=!0,u.attributes.aAlpha.needsUpdate=!0,y.children.forEach((S,C)=>{let L=(M*.07+C*.17)%1;S.position.set(Math.cos(M*.3+C*2.2)*(.4+C*.08),.1+L*2.6,Math.sin(M*.25+C)*.35),S.material.opacity=.12*(1-L)})}return{group:i,update:w}}function y_(){let i=new ce;i.name="jade-whale";let e=m_(!1,.96),t=m_(!0,.84);t.uniforms.uTop.value.set("#d6f4ec"),t.uniforms.uSide.value.set("#9bd7d2"),t.uniforms.uBelly.value.set("#8bcfca"),t.uniforms.uRim.value.set("#ffe6b8"),t.uniforms.uAurora.value.set("#71dfcc");let n=new W(BS(),e);n.name="whale-body",n.castShadow=!0,n.receiveShadow=!0,i.add(n),ns(n,"#5f4c5d",.043,1),i.add(XS()),i.add(WS());let s=g_(1,t),r=g_(-1,t);i.add(s,r);let o=kS(t);i.add(o);let a=GS(t);i.add(a);let l=qS();i.add(l.group);let c=KS();i.add(c.group);let h=new W(new oi(1,64),new Qe({color:"#937bb2",transparent:!0,opacity:.12,depthWrite:!1}));h.rotation.x=-Math.PI/2,h.scale.set(7.3,3.1,1),h.position.y=.335,i.add(h);let u=s.rotation.x,d=s.rotation.z,f=r.rotation.x,p=o.rotation.z,_=i.position.y,g=0;function m(v){g=v,e.uniforms.uTime.value=v,t.uniforms.uTime.value=v;let E=Math.sin(v*.32);i.position.y=Math.sin(v*.3+1)*.035,s.rotation.x=u+Math.sin(v*.42+1.2)*.03,s.rotation.z=d+Math.cos(v*.31)*.014,r.rotation.x=f-Math.sin(v*.42+1.45)*.03,r.rotation.z=-.1-Math.cos(v*.31+.2)*.014,o.rotation.y=Math.sin(v*.28+.3)*.045,o.rotation.z=p+Math.sin(v*.21+1.2)*.022,c.update(v)}return{group:i,update:m,body:n,deckY:Vr,platformY:pa,terrace:l}}var he={W:4.6,D:3.7,wallT:.105,groundBase:.14,groundH:1.68,slabY:1.78,slabT:.15,upperFloorY:1.93,upperH:1.37,upperWallBase:1.93,wallTop:3.3,roofBaseY:3.3,ridgeY:4.66,eaveY:3.58,eaveZ:2.36,roofHalfW:2.88,tower:{x:1.92,z:-1.24,r:.64,bodyTop:4.15,lanternTop:5.25,coneTop:6.22,vaneTop:6.98}};var Rs=.175;function M_(i,e,t=28){let n=i.map(([r,o])=>new J(r,o)),s=new Oi(n,t);return s.computeVertexNormals(),new W(s,e)}function $S(i,e,t=.5){let n=[];for(let[o,a]of i)n.push(o.x,o.y,o.z,a.x,a.y,a.z);let s=new ke;s.setAttribute("position",new _e(n,3));let r=new tn({color:e,transparent:!0,opacity:t,blending:wt,depthWrite:!1,toneMapped:!1});return new Sn(s,r)}var is={blush:me("#ffd1d8",{side:De}),peach:me("#ffd4b8",{side:De}),lilac:me("#d9c9ff",{side:De}),cream:me("#fff2dd",{side:De}),sky:me("#cbe9f5",{side:De}),mint:me("#c8e8da",{side:De}),gold:me("#f4d28d",{side:De})};function jS(i,e,t,n={}){let s=fa(i,e,n.ws||12,n.hs||12),r=s.attributes.position,o=ft(n.seed||8);for(let l=0;l<r.count;l++){let c=r.getX(l),h=r.getY(l);r.setZ(l,Math.sin(c*7+h*2)*.014+Math.sin(h*9)*.01+(n.wave?Math.sin(c*4+n.wave)*.02:0))}s.computeVertexNormals();let a=new W(s,t);return a.castShadow=!1,a.receiveShadow=!0,a}function QS(i,e,t=1){let n=new ce,s=new hn({color:i,transparent:!0,opacity:.23,roughness:.06,metalness:0,clearcoat:1,clearcoatRoughness:.05,iridescence:.7,iridescenceIOR:1.3,envMapIntensity:1.8,side:De,depthWrite:!1}),o=M_([[.1,0],[.22,.035],[.28,.13],[.285,.29],[.25,.43],[.2,.505],[.18,.545],[.17,.56]],s);o.scale.setScalar(t),o.castShadow=!1,n.add(o);let a=[[.005,.035],[.19,.045],[.245,.13],[.25,.28],[.225,.39],[.19,.44],[.005,.44]],l=new Qe({color:new q(e).multiplyScalar(1.12),transparent:!0,opacity:.82,depthWrite:!1,toneMapped:!1}),c=M_(a,l);c.scale.setScalar(t),c.renderOrder=1,n.add(c);let h=N(Oe(.22*t,.27*t,.06*t,20),k.woodDark,{pos:[0,.03*t,0]});h.castShadow=!0,n.add(h);let u=new W(new dt(.18*t,.015*t,5,22),k.brass);u.rotation.x=Math.PI/2,u.position.y=.56*t,n.add(u);let d=N(new Rt(.18*t,18,8,0,xe,0,Math.PI*.32),k.brassSoft,{pos:[0,.56*t,0]});d.scale.y=.45,n.add(d);let f=[];for(let g=0;g<=32;g++){let m=g/32,v=m*Math.PI*5,E=.18*t*(1-m*.5);f.push(ne(Math.cos(v)*E,(.06+m*.35)*t,Math.sin(v)*E))}let p=new W(new et(new je(f),40,.008*t,3,!1),Yn("#fff5d8",1.1,.6));p.renderOrder=2,n.add(p);for(let g=0;g<7;g++){let m=g*2.1+.8,v=pt("gold",.06*t+.015,.22);v.position.set(Math.cos(m)*.14*t,(.15+g*.035)*t,Math.sin(m)*.14*t),n.add(v)}let _=pt(i==="#ffb4d1"?"pink":"gold",.7*t,.14);return _.position.y=.3*t,n.add(_),n}function eT(){let i=new ce;i.position.set(.56,Rs+.03,-.5);let e=k.woodWarm,t=k.woodDark,n=1.35,s=.74,r=1.43,o=ve(.075,r,.075,.022);for(let I of[-1,1])for(let P of[-1,1]){let U=N(o,t,{pos:[I*n/2,r/2,P*s/2]});U.castShadow=!0,i.add(U)}let a=N(ve(n+.2,.11,s+.16,.035),e,{pos:[0,.07,0]});i.add(a);let l=N(ve(n+.1,.1,.1,.03),e,{pos:[0,r-.02,0]});i.add(l);let c=N(ve(n+.08,.055,.055,.02),t,{pos:[0,1.19,-.22]});i.add(c);let h=N(Oe(.065,.065,n,12),e,{pos:[0,.7,.32],rot:[0,0,Math.PI/2]});i.add(h);let u=new W(fa(1.06,.66,10,14),k.starCloth),d=u.geometry.attributes.position;for(let I=0;I<d.count;I++){let P=d.getX(I),U=d.getY(I);d.setZ(I,Math.sin((P+.5)*8+U*2)*.025+Math.sin(U*7)*.012)}u.geometry.computeVertexNormals(),u.position.set(0,.76,.345),u.castShadow=!1,i.add(u);let f=[];for(let I=0;I<11;I++){let P=-.48+I*.096;f.push(ne(P,.41,.35),ne(P+Math.sin(I)*.01,.34,.35))}let p=new ke,_=[];f.forEach(I=>_.push(I.x,I.y,I.z)),p.setAttribute("position",new _e(_,3));let g=new Sn(p,new tn({color:"#ffe5ad",transparent:!0,opacity:.7,toneMapped:!1}));i.add(g);for(let I=0;I<6;I++){let P=pt("gold",.08+I%2*.03,.4);P.position.set(-.44+I*.18,.55+I%3*.15,.42),P.userData={base:P.position.clone(),ph:I*1.5},P.name="loomStar",i.add(P)}let m=[];for(let I=0;I<17;I++){let P=-n/2+.08+I/16*(n-.16);m.push([ne(P,.74,.23),ne(P,1.36,.03)])}i.add($S(m,"#ffe7b8",.32));let v=new ce,E=N(ve(.2,.065,.095,.026),me("#ffdba9"),{pos:[0,0,0]});v.add(E);let y=N(ze(.033,1),k.brass,{pos:[-.11,0,0],scale:[1.2,.7,.9]}),w=N(ze(.033,1),k.brass,{pos:[.11,0,0],scale:[1.2,.7,.9]});v.add(y,w),v.position.set(0,.95,.42),i.add(v);let M=N(ve(n-.1,.035,.035,.012),k.brassDeep,{pos:[0,1.04,.1]});i.add(M);let T=new ce,x=N(Oe(.25,.25,.1,20),is.blush,{pos:[0,.33,.83]});T.add(x);let S=N(ze(.23,1),is.peach,{pos:[0,.43,.83],scale:[1,.35,1]});T.add(S);for(let I=0;I<3;I++){let P=I/3*xe,U=N(Oe(.035,.045,.32,8),k.woodDark,{pos:[Math.cos(P)*.16,.16,.83+Math.sin(P)*.16]});T.add(U)}i.add(T);let C=[],L=M.position.y;function F(I){v.position.x=Math.sin(I*1.7)*.49,v.rotation.z=Math.sin(I*1.7)*.04,M.position.y=L+Math.sin(I*3.4)*.018,u.rotation.z=Math.sin(I*.5)*.004,i.children.forEach(P=>{P.name==="loomStar"&&(P.position.y=P.userData.base.y+Math.sin(I*.7+P.userData.ph)*.035,P.material.opacity=.18+.18*(.5+.5*Math.sin(I*1.2+P.userData.ph)))})}return{group:i,update:F}}function tT(){let i=new ce;i.position.set(-.15,Rs,-1.6);let e=1.75,t=1.52,n=.32,s=k.woodWarm,r=[[-e/2,-n/2],[e/2,-n/2],[-e/2,n/2],[e/2,n/2]];for(let[h,u]of r){let d=N(ve(.065,t,.065,.018),k.woodDark,{pos:[h,t/2,u]});i.add(d)}for(let h=0;h<3;h++){let u=.35+h*.47,d=N(ve(e,.055,n+.07,.018),s,{pos:[0,u,0]});i.add(d);let f=N(ve(e,.006,.04,.002),k.woodPale,{pos:[0,u+.05,-n/2]});f.castShadow=!1,i.add(f)}let o=ft(203),a=["#ffb1c5","#ffd092","#b5a5f4","#9eddd5","#ffd9bd","#afc8f3","#f4b4a9","#caedc9"];for(let h=0;h<3;h++){let u=.39+h*.47;for(let d=0;d<5;d++){let f=-e/2+.18+d*(e-.36)/4+(o()-.5)*.05,p=o(),_=a[Math.floor(o()*a.length)];if(p<.58){let g=new ce,m=N(Oe(.052,.052,.16,10),me(_),{pos:[0,.11,0]}),v=N(Oe(.085,.085,.018,12),k.woodPale,{pos:[0,.197,0]}),E=N(Oe(.085,.085,.018,12),k.woodPale,{pos:[0,.018,0]});g.add(m,v,E),g.position.set(f,u,.02),g.rotation.z=(o()-.5)*.12,i.add(g)}else{let g=Math.floor(o()*3)+1;for(let m=0;m<g;m++){let v=N(ve(.24+o()*.12,.06,.19+o()*.04,.028),me(_),{pos:[f,u+.04+m*.063,.02],rot:[0,(o()-.5)*.2,0]});i.add(v)}}}}let l=N(Oe(.018,.018,e-.18,7),k.brassDeep,{pos:[0,.45,.28],rot:[0,0,Math.PI/2]});i.add(l);for(let h=0;h<4;h++){let u=.48-h*.05,d=N(new vn(.035,.15,8),me(a[h]),{pos:[-.55+h*.37,.34-h*.06,.3]});i.add(d);let f=N(Oe(.004,.004,.12,4),k.brassDeep,{pos:[-.55+h*.37,.44-h*.06,.3]});i.add(f)}let c=N(Oe(.09,.07,.13,12),me("#e7b7a4"),{pos:[.65,t+.01,0]});i.add(c);for(let h=0;h<5;h++){let u=N(ze(.06,1),me("#a8d6b9"),{pos:[.65+(o()-.5)*.15,t+.11+o()*.12,(o()-.5)*.12],scale:[.8,.35,.8]});i.add(u)}return i}function nT(){let i=new ce;i.position.set(1.4,Rs,.68);let e=.59,t=N(ve(1.05,.085,.58,.03),k.wood,{pos:[0,e,0]});i.add(t);for(let f of[-1,1])for(let p of[-1,1]){let _=N(Oe(.04,.05,.6,8),k.woodDark,{pos:[f*.42,.3,p*.23]});i.add(_)}let n=N(ve(.55,.11,.37,.055),is.cream,{pos:[-.19,e+.09,0],rot:[0,.12,0]});i.add(n);let s=N(ve(.4,.08,.29,.045),is.lilac,{pos:[-.16,e+.17,0],rot:[0,-.06,.03]});i.add(s);let r=new ce;r.position.set(.27,e+.105,.02);let o=N(ve(.4,.12,.24,.055),nn("#e5af6c"),{pos:[0,.01,0]});o.scale.z=1,r.add(o);let a=N(ze(.09,1),nn("#edc58f"),{pos:[-.19,.03,0],scale:[1.25,.65,1.1]});r.add(a);let l=new W(new dt(.12,.022,6,18,Math.PI),k.woodDark);l.rotation.y=Math.PI/2,l.rotation.z=Math.PI/2,l.position.y=.16,r.add(l);let c=N(Oe(.028,.028,.02,12),k.brass,{pos:[.1,.1,.02],rot:[Math.PI/2,0,0]});r.add(c),i.add(r);let h=[];for(let f=0;f<7;f++){let p=pt("peach",.18,0);p.position.set(.32+f%3*.08,e+.22,.02+f%2*.08),p.userData={phase:f*.8,baseY:e+.2,baseX:.32+f%3*.08},i.add(p),h.push(p)}let u=N(new Rt(.075,12,8),is.blush,{pos:[-.38,e+.17,.15]});u.scale.y=.65,i.add(u);for(let f=0;f<5;f++){let p=N(Oe(.003,.003,.11,4),k.brass,{pos:[-.44+f*.028,e+.26,.15],rot:[f%2?.1:-.1,0,.2]});i.add(p)}return{group:i,update:f=>{h.forEach((p,_)=>{let g=(f*.13+_/7*.8)%1;p.position.y=p.userData.baseY+g*.65,p.position.x=p.userData.baseX+Math.sin(f*.7+_)*.06+g*.08,p.material.opacity=.16*Math.sin(Math.min(1,g)*Math.PI),p.scale.setScalar(.13+g*.28)})}}}function iT(){let i=new ce;i.position.set(-1.1,he.upperFloorY,-.95);let e=N(ve(1.35,.16,1.65,.06),k.woodWarm,{pos:[0,.2,0]});i.add(e);let t=N(ve(1.35,.34,.08,.05),k.wood,{pos:[0,.35,.8]});i.add(t);let n=N(ve(1.32,.82,.07,.09),k.wood,{pos:[0,.52,-.81]}),s=N(ve(1.24,.16,.09,.04),k.woodPale,{pos:[0,.94,-.81]});i.add(n,s);let r=N(ve(1.18,.18,1.46,.08),k.cream,{pos:[0,.34,0]});i.add(r);let o=N(ve(1.22,.13,1,.08),is.blush,{pos:[0,.47,.26]});i.add(o);let a=N(ve(1.15,.06,.7,.07),is.lilac,{pos:[0,.55,.12],rot:[0,.02,0]});i.add(a);let l=[[-.3,.58,-.56,.36,.2,"#fff0dd"],[.22,.6,-.6,.42,.22,"#ffd4dd"],[-.02,.7,-.48,.32,.18,"#e7d8ff"],[.38,.67,-.38,.24,.16,"#ffe3c5"],[-.36,.67,-.35,.25,.16,"#ffe7ee"]];for(let h=0;h<l.length;h++){let[u,d,f,p,_,g]=l[h],m=N(ze(1,2),me(g),{pos:[u,d,f],scale:[p,_,p*.72],rot:[h%2?-.15:.12,h*.9,.1]});m.castShadow=!0,i.add(m);let v=N(ze(.025,1),k.brass,{pos:[u,d+.02,f+p*.55]});i.add(v)}for(let h=0;h<12;h++){let u=N(Oe(.008,.008,.14,4),is.cream,{pos:[-.55+h*.1,.3,.79],rot:[.35,0,0]});i.add(u)}let c=sT(.28,1);return c.position.set(0,.95,-.77),c.rotation.x=.06,i.add(c),i}function sT(i=.3,e=.8){let t=new ce,n=new W(new dt(i,.022,6,40),nn("#f4c977"));t.add(n);let s=12,r=[];for(let c=0;c<s;c++){let h=c/s*xe,u=(c+1)/s*xe,d=i*.82,f=i*.58,p=ne(Math.cos(h)*d,Math.sin(h)*d,-.006),_=ne(Math.cos(u)*d,Math.sin(u)*d,-.006),g=ne(Math.cos((h+u)/2)*d*.7,Math.sin((h+u)/2)*d*.7,-.006);r.push(p,g,g,_)}let o=new ke().setFromPoints(r),a=new Sn(o,new tn({color:"#ffe4a3",transparent:!0,opacity:.72,blending:wt,depthWrite:!1,toneMapped:!1}));t.add(a);for(let c=0;c<3;c++){let h=-.6+c*.6,u=Math.sin(h)*i*.55,d=N(Oe(.004,.004,.18,3),k.brassDeep,{pos:[u,-i-.09,0]});t.add(d);let f=N(new vn(.035,.13,5),fn[c===1?"gold":"pink"],{pos:[u,-i-.24,0]});f.castShadow=!1,t.add(f)}let l=pt("gold",i*1.1,.24*e);return t.add(l),t}function rT(){let i=new ce;i.position.set(.38,he.upperFloorY,-1.3);let e=N(ve(.64,.52,.45,.04),k.woodDark,{pos:[0,.26,0]});i.add(e);let t=N(ve(.7,.06,.52,.02),k.wood,{pos:[0,.55,0]});i.add(t);let n=N(ve(.3,.16,.24,.03),k.woodPale,{pos:[0,.66,0]});i.add(n);let s=N(Oe(.17,.19,.04,24),k.brass,{pos:[0,.76,0]});i.add(s);let r=new W(new Rt(.19,24,14,0,xe,0,Math.PI/2),new hn({color:"#f6f0ff",transparent:!0,opacity:.25,roughness:.08,clearcoat:1,side:De,depthWrite:!1}));r.position.y=.76,i.add(r);let o=new ce;o.position.y=.79;let a=S_(.11,.025,"#ffd578");a.position.set(.08,.1,0),o.add(a);let l=new W(new dt(.075,.013,5,20,Math.PI*1.35),nn("#ffe1a3"));l.rotation.z=1.4,l.position.set(-.07,.06,0),o.add(l);for(let d=0;d<3;d++){let f=pt("gold",.045,.4),p=d/3*xe;f.position.set(Math.cos(p)*.12,.1+Math.sin(p)*.05,Math.sin(p)*.09),o.add(f)}i.add(o);let c=N(Oe(.006,.006,.25,4),k.brassDeep,{pos:[0,.91,0]});i.add(c);let h=[];for(let d=0;d<5;d++){let f=oT();f.position.set(0,.85,0),f.scale.setScalar(.11),f.userData={phase:d*.6,baseX:-.04+d%2*.09,baseZ:d%3*.03},i.add(f),h.push(f)}return{group:i,update:d=>{o.rotation.y=d*.55,o.position.y=.79+Math.sin(d*.8)*.006,h.forEach((f,p)=>{let _=(d*.16+p*.23)%1;f.position.set(f.userData.baseX+Math.sin(_*7+p)*.09,.74+_*.55,f.userData.baseZ+Math.cos(_*4+p)*.05),f.material.opacity=Math.sin(_*Math.PI)*.55})}}}function oT(){let i=Cn(64,64,(e,t,n)=>{e.clearRect(0,0,t,n),e.fillStyle="#ffe6a8",e.strokeStyle="#ffe6a8",e.lineWidth=4,e.beginPath(),e.ellipse(24,45,9,6,-.2,0,Math.PI*2),e.fill(),e.beginPath(),e.moveTo(32,43),e.lineTo(32,14),e.quadraticCurveTo(48,20,48,30),e.stroke(),e.beginPath(),e.ellipse(46,42,7,5,-.2,0,Math.PI*2),e.fill()});return new Dn(new ln({map:i,transparent:!0,opacity:0,depthWrite:!1,blending:wt,toneMapped:!1}))}function aT(){let i=new ce;i.position.set(1.43,he.upperFloorY,-1.35);let e=.92,t=1.02,n=.35,s=N(ve(e,t,n,.035),k.woodDark,{pos:[0,t/2,0]});i.add(s);let r=me("#5a4157");for(let l=0;l<2;l++){let c=.25+l*.42,h=N(ve(e-.14,.36,.035,.02),r,{pos:[0,c,-n/2-.012]});i.add(h);let u=N(ve(e-.08,.04,n-.04,.015),k.woodWarm,{pos:[0,c-.19,0]});i.add(u);for(let d=0;d<3;d++){let f=["#ff87b6","#ad8aff","#ffd25d","#84dce4","#ffbfd4","#d1b1ff"],p=f[(l*3+d)%f.length],_=new ce;_.position.set(-.28+d*.28,c-.08,0);let g=N(new Rt(.085,16,12),Yn(p,1.05,.95));g.castShadow=!1,_.add(g);let m=N(new Rt(.115,16,12),fn[d%2?"pink":"lilac"],{pos:[0,0,0]});m.castShadow=!1,_.add(m);let v=pt("gold",.33,.18);_.add(v),_.name="dreamOrb",_.userData={baseY:_.position.y,phase:d*1.4+l*2.2},i.add(_)}}for(let l of[-1,1])for(let c of[-1,1]){let h=N(Oe(.035,.045,.1,6),k.woodWarm,{pos:[l*.36,.02,c*.1]});i.add(h)}let o=S_(.075,.02,"#ffd27d");return o.position.set(0,t+.06,0),i.add(o),{group:i,update:l=>{i.children.forEach(c=>{c.name==="dreamOrb"&&(c.position.y=c.userData.baseY+Math.sin(l*.8+c.userData.phase)*.009,c.rotation.y=l*.2+c.userData.phase)})}}}function S_(i=.12,e=.04,t="#ffd27d"){let n=new kt,s=5,r=i,o=i*.44;for(let c=0;c<s*2;c++){let h=c*Math.PI/s-Math.PI/2,u=c%2?o:r,d=Math.cos(h)*u,f=Math.sin(h)*u;c===0?n.moveTo(d,f):n.lineTo(d,f)}n.closePath();let a=new en(n,{depth:e,bevelEnabled:!0,bevelSegments:1,steps:1,bevelSize:.008,bevelThickness:.008,curveSegments:2}),l=new W(a,nn(t));return l.castShadow=!0,l}function lT(i=.38,e=.1){let t=new kt;return t.moveTo(0,0),t.bezierCurveTo(-e*.5,.15,-e*.45,i*.8,0,i),t.bezierCurveTo(e*.45,i*.8,e*.5,.15,0,0),new en(t,{depth:.018,bevelEnabled:!0,bevelSegments:2,steps:1,bevelSize:.012,bevelThickness:.008,curveSegments:14})}function cT(){let i=new ce;i.position.set(1.52,he.upperFloorY,.72);let e=N(Oe(.2,.25,.07,20),k.brassDeep,{pos:[0,.04,0]});i.add(e);let t=N(Oe(.018,.024,1.1,8),k.brass,{pos:[0,.58,0]});i.add(t);let n=new ce;n.position.y=1.13;let s=N(ze(.14,2),Yn("#ffd6a1",1.3));s.castShadow=!1,n.add(s);let r=ft(91);for(let c=0;c<16;c++){let h=c/16*xe,u=N(lT(.26+r()*.16,.08+r()*.05),me(c%3?"#fff2de":"#ffd8df",{side:De}),{pos:[Math.cos(h)*.06,-.02,Math.sin(h)*.06],rot:[.5+(r()-.5)*.5,h,-.45+(r()-.5)*.3],scale:[1,1,1]});u.castShadow=!1,n.add(u)}let o=pt("gold",1.1,.2);n.add(o),i.add(n);let a=n.children.slice(1);return{group:i,update:c=>{a.forEach((h,u)=>{h.rotation.z=-.45+(u%2?1:-1)*(.32+Math.sin(c*.5+u)*.025)}),n.rotation.y=Math.sin(c*.14)*.08}}}function b_(i,e,t,n="#ffcf9c"){let s=new ce;s.position.set(i,t,e);let r=N(Oe(.006,.006,.36,4),k.brassDeep,{pos:[0,-.18,0]});s.add(r);let o=new W(new Rt(.16,20,10,0,xe,0,Math.PI*.62),new hn({color:"#ffd9bb",transparent:!0,opacity:.5,roughness:.15,clearcoat:1,side:De,depthWrite:!1}));o.scale.y=.85,o.position.y=-.42,s.add(o);let a=N(ze(.07,2),Yn(n,1.5),{pos:[0,-.4,0]});a.castShadow=!1,s.add(a);let l=pt("gold",.8,.2);return l.position.y=-.4,s.add(l),s}function E_(i,e,t,n,s,r=1){let o=new cn(i,e,24,18),a=o.attributes.position,l=ft(r);for(let u=0;u<a.count;u++)a.setZ(u,Math.sin(a.getX(u)*7+r)*.008+Math.cos(a.getY(u)*8)*.006);o.computeVertexNormals();let c=new Ht({map:Pt.rug,gradientMap:Zt,side:De}),h=new W(o,c);return h.rotation.x=-Math.PI/2,h.position.set(t,s+.006,n),h.receiveShadow=!0,h}function hT(){let i=new ce;i.position.set(-.15,1.18,-1.71);let e=jS(1,.75,k.starCloth,{ws:10,hs:10,seed:5});e.position.y=0,i.add(e);let t=N(Oe(.035,.035,1.2,8),k.brassDeep,{pos:[0,.42,0],rot:[0,0,Math.PI/2]});i.add(t);for(let n=0;n<6;n++){let s=N(Oe(.006,.006,.15,3),is.cream,{pos:[-.45+n*.18,-.42,0]});i.add(s)}return i}function uT(){let i=new ce;i.position.set(1.83,Rs,-1.05),i.rotation.z=-.11;for(let e of[-.22,.22]){let t=N(ve(.06,2.12,.06,.015),k.woodDark,{pos:[e,1.04,-.02]});i.add(t)}for(let e=0;e<7;e++){let t=N(Oe(.028,.028,.5,8),k.woodWarm,{pos:[0,.35+e*.28,0],rot:[0,0,Math.PI/2]});i.add(t)}return i}function T_(){let i=new ce;i.name="atelier-interior";let e=N(ve(4.3,.12,3.38,.04),k.woodWarm,{pos:[0,.09,0]});e.receiveShadow=!0,i.add(e);let t=N(ve(4.22,.12,3.24,.04),k.wood,{pos:[0,he.upperFloorY-.06,0]});t.receiveShadow=!0,i.add(t),i.add(E_(2.3,1.75,-.02,.23,Rs,3)),i.add(E_(1.65,1.1,.45,.32,he.upperFloorY,7));for(let T=0;T<5;T++){let x=N(ve(4.28,.07,.08,.02),k.woodDark,{pos:[0,he.slabY-.01,-1.35+T*.64]});i.add(x)}let n=[["#ffacc8","#ff75ad"],["#c4b8ff","#9b78ff"],["#ffe0a2","#ffc94f"]];[[-1.62,-.88],[-1.54,-.15],[-1.43,.6]].forEach(([T,x],S)=>{let C=QS(n[S][0],n[S][1],.92+S*.05);C.position.set(T,Rs,x),i.add(C);let L=N(Oe(.27,.3,.03,18),k.brassSoft,{pos:[T,Rs+.015,x]});i.add(L)});let r=eT();i.add(r.group),i.add(tT());let o=nT();i.add(o.group),i.add(hT()),i.add(uT());let a=N(Oe(.17,.22,.22,18),k.basket,{pos:[1.78,Rs+.11,.12]});i.add(a);for(let T=0;T<5;T++){let x=N(ze(.07,1),me(["#ffafc5","#b7a3f2","#ffd085","#9edfd7","#ffd8bd"][T]),{pos:[1.78+(T%2-.5)*.16,Rs+.2+Math.floor(T/2)*.055,.12+(T%3-1)*.12]});i.add(x)}i.add(iT());let l=aT();i.add(l.group);let c=rT();i.add(c.group);let h=cT();i.add(h.group);let u=N(ve(.74,.34,.45,.04),k.woodDark,{pos:[.52,he.upperFloorY+.17,.96]});i.add(u);let d=N(ve(.79,.07,.49,.02),k.wood,{pos:[.52,he.upperFloorY+.37,.96]});i.add(d);let f=N(ze(.24,2),is.lilac,{pos:[.52,he.upperFloorY+.46,.96],scale:[1.35,.44,.85]});i.add(f);for(let T=0;T<3;T++){let x=N(ve(.3,.05,.22,.01),me(["#ffc9d7","#b6dff0","#ffdfad"][T]),{pos:[.94,he.upperFloorY+.03+T*.045,-.25],rot:[0,.2+T*.1,0]});i.add(x)}i.add(b_(-.25,.15,he.slabY-.02,"#ffca94")),i.add(b_(.38,-.62,he.upperFloorY+1.12,"#ffd2ad"));let p=new Yt("#ffc08a",5.2,4.3,2);p.position.set(-.2,.95,.1),i.add(p);let _=new Yt("#ffd0a4",3.6,3.3,2);_.position.set(.2,he.upperFloorY+.9,-.15),i.add(_);let g=new Yt("#ff8ebf",1.3,2.2,2);g.position.set(-1.5,.45,-.3),i.add(g);let m=new Yt("#c9b5ff",1,1.8,2);m.position.set(1.35,he.upperFloorY+.7,-.9),i.add(m);let v=i.children.filter(T=>T.isGroup&&T.children[0]?.geometry?.type==="CylinderGeometry"),E=u.position.clone();function y(T){r.update(T),o.update(T),c.update(T),h.update(T),l.update(T),i.children.forEach(x=>{x.isGroup&&x.userData&&x.userData.update&&x.userData.update(T)}),i.children.forEach(x=>{x.isGroup&&x.children.length&&x.children[0].geometry?.type==="CylinderGeometry"&&x.children.some(S=>S.material?.type==="MeshPhysicalMaterial")&&(x.rotation.z=Math.sin(T*.42+x.position.x)*.026,x.rotation.x=Math.cos(T*.36+x.position.z)*.018)}),i.traverse(x=>{x.name==="dreamOrb"&&(x.position.y=x.userData.baseY+Math.sin(T*.8+x.userData.phase)*.009,x.rotation.y=T*.2+x.userData.phase)})}let w=i.children.find(T=>T.type==="Group"&&T.children.some(x=>x.name==="dreamOrb")),M=null;return{group:i,update:y}}var Et=he.D,Jt=he.W,vi=he.wallT;function dT(i=.12,e=.45){let t=new kt,n=5,s=i,r=i*e;for(let o=0;o<n*2;o++){let a=o*Math.PI/n-Math.PI/2,l=o%2?r:s,c=Math.cos(a)*l,h=Math.sin(a)*l;o===0?t.moveTo(c,h):t.lineTo(c,h)}return t.closePath(),t}function ma(i=.1,e=.028,t="#ffd17c"){let n=new en(dT(i),{depth:e,bevelEnabled:!0,bevelSegments:1,steps:1,bevelSize:.007,bevelThickness:.006,curveSegments:2}),s=new W(n,nn(t));return s.castShadow=!0,s}function zp(i=.18,e=.028,t=Math.PI*1.3){let n=new dt(i,e,6,24,t),s=new W(n,nn("#ffd985"));return s.castShadow=!0,s}function fT(i,e){let t=Lp(i.x,i.bottom,i.w,i.h,e),n=new je(t,!1,"catmullrom",.02);return new et(n,60,.032,5,!1)}function pT(i,e,t={}){let n=new ce,s=k.woodDark,r=N(ve(.034,i.h*(t.vScale??.8),.035,.01),s,{pos:[i.x,i.bottom+i.h*.36,e]});n.add(r);let o=N(ve(i.w*.76,.032,.035,.01),s,{pos:[i.x,i.bottom+i.h*.56,e]});if(n.add(o),t.ring){let a=new W(new dt(Math.min(i.w,i.h)*.16,.018,5,18),s);a.position.set(i.x,i.bottom+i.h*.72,e),n.add(a);for(let l=0;l<4;l++){let c=l/4*Math.PI*2+Math.PI/4,h=N(Oe(.009,.009,Math.min(i.w,i.h)*.16,4),s,{pos:[i.x+Math.cos(c)*Math.min(i.w,i.h)*.08,i.bottom+i.h*.72+Math.sin(c)*Math.min(i.w,i.h)*.08,e],rot:[Math.PI/2,0,c]});n.add(h)}}return n}function mT(i,e,t,n=.52){let s=new ce,r=N(ve(n,.15,.2,.035),k.woodDark,{pos:[i,e,t]});s.add(r);let o=N(ve(n-.06,.035,.15,.012),me("#6d4b48"),{pos:[i,e+.08,t]});s.add(o);let a=ft(400+Math.floor(i*11));for(let l=0;l<8;l++){let c=i+(a()-.5)*n*.8,h=t+(a()-.5)*.12,u=N(ze(.07,1),me(l%3?"#9ed9b9":"#c3e8c8"),{pos:[c,e+.12+a()*.06,h],scale:[.7,.35,.7],rot:[0,a()*xe,0]});if(u.castShadow=!1,s.add(u),l<5){let d=N(ze(.035,1),me(["#ffb4c8","#ffe3b2","#ffd0de","#d8c2ff"][l%4]),{pos:[c+(a()-.5)*.08,e+.19+a()*.06,h],scale:[1,.8,1]});s.add(d)}}for(let l=0;l<3;l++){let c=N(Oe(.008,.008,.22,4),me("#9bcbb3"),{pos:[i-n*.28+l*.24,e-.08,t+.12],rot:[.2,0,.4]});s.add(c)}return s}function Wr(i){let{width:e,height:t,holes:n,flowers:s=[],mullions:r=[],trim:o=!0,outline:a=!0}=i,l=new ce,c=new kt;c.moveTo(-e/2,0),c.lineTo(e/2,0),c.lineTo(e/2,t),c.lineTo(-e/2,t),c.closePath();for(let _ of n){let g=r_(_.x,_.bottom,_.w,_.h,0);c.holes.push(g)}let h=new en(c,{depth:vi,bevelEnabled:!0,bevelSegments:2,steps:1,bevelSize:.026,bevelThickness:.022,curveSegments:16});h.translate(0,0,-vi/2);let u=new W(h,k.plaster);u.castShadow=!0,u.receiveShadow=!0,l.add(u),a&&ns(u,"#816270",.012,.48);let d=k.woodDark,f=N(ve(e+.06,.12,vi+.12,.025),d,{pos:[0,t-.055,0]}),p=N(ve(e+.08,.11,vi+.14,.025),d,{pos:[0,.055,0]});l.add(f,p);for(let _ of[-1,1])l.add(N(ve(.12,t,vi+.13,.03),d,{pos:[_*(e/2-.012),t/2,0]}));for(let _ of n){if(_.w>.8){let g=_.bottom+_.h-_.w*.5;for(let m of[-1,1]){let v=_.x+m*_.w/2;l.add(N(ve(.07,g,vi+.125,.018),d,{pos:[v,g/2,0]}))}}if(o)for(let g of[-1,1]){let m=g*(vi/2+.023),v=new W(fT(_,m),d);v.castShadow=!1,l.add(v);let E=Lp(_.x,_.bottom+.04,_.w-.09,_.h-.08,m+g*.008),y=new je(E,!1,"catmullrom",.02),w=new W(new et(y,50,.008,4,!1),k.brassSoft);l.add(w)}}for(let _ of r){let g=n.findIndex(m=>m.x===_);g>=0&&l.add(pT(n[g],vi/2+.03,{ring:!0}))}for(let[_,g]of[[-1,1],[1,1],[-1,-1],[1,-1]]){if(g<0&&i.noBackBraces)continue;let m=N(ve(.055,.48,.045,.012),d,{pos:[_*(e/2-.3),t-.36,g*(vi/2+.005)],rot:[0,0,_*.65]});m.castShadow=!1,l.add(m)}for(let _ of s)l.add(mT(_.x,_.y,vi/2+.13,_.width||.52));return{group:l,wall:u}}function w_(i){let n=he.roofHalfW,s=he.eaveZ,r=he.ridgeY,o=he.eaveY,a=[],l=[],c=[];for(let f=0;f<=16;f++){let p=f/16;for(let _=0;_<=34;_++){let g=_/34,m=-n+g*n*2,v=i*s*p,E=.16*Math.pow(p,2.2),y=.22*Math.pow(Math.abs(m)/n,5.5)*Math.pow(p,2),w=r-(r-o)*Math.pow(p,1.14)+y;a.push(m,w,v),l.push(g*2.4+.03,p*2.1)}}for(let f=0;f<16;f++)for(let p=0;p<34;p++){let _=f*35+p,g=(f+1)*35+p,m=(f+1)*35+p+1,v=f*35+p+1;c.push(_,g,v,g,m,v)}let h=new ke;h.setAttribute("position",new _e(a,3)),h.setAttribute("uv",new _e(l,2)),h.setIndex(c),h.computeVertexNormals();let u=new Ht({color:"#ffffff",map:Pt.roof,gradientMap:Zt,side:De,emissive:new q("#8e4e60"),emissiveIntensity:.035}),d=new W(h,u);return d.castShadow=!0,d.receiveShadow=!0,{roof:d,halfW:n,eaveZ:s,apex:r,eaveY:o}}function gT(){let i=new ce,e=w_(1),t=w_(-1);i.add(e.roof,t.roof);let n=N(Oe(.085,.085,he.roofHalfW*2+.24,10),k.woodDark,{pos:[0,he.ridgeY+.015,0],rot:[0,0,Math.PI/2]});i.add(n);let s=N(Oe(.026,.026,he.roofHalfW*2+.32,6),k.brass,{pos:[0,he.ridgeY+.102,0],rot:[0,0,Math.PI/2]});i.add(s);for(let a of[-1,1]){let l=N(new Rt(.1,12,8),k.brass,{pos:[a*(he.roofHalfW+.06),he.ridgeY+.08,0],scale:[1,.8,1]});i.add(l);let c=N(new vn(.025,.22,5),k.brass,{pos:[a*(he.roofHalfW+.06),he.ridgeY+.22,0],rot:[0,0,a*.06]});i.add(c)}for(let a of[-1,1]){let l=[];for(let d=0;d<=30;d++){let f=-he.roofHalfW+d/30*he.roofHalfW*2,p=.22*Math.pow(Math.abs(f)/he.roofHalfW,5.5);l.push(ne(f,he.eaveY+p,a*(he.eaveZ+.004)))}let c=new je(l),h=new W(new et(c,90,.055,6),k.woodDark);h.castShadow=!0,i.add(h);let u=new W(new et(c,90,.018,4),k.brass);u.position.y=-.09,i.add(u)}for(let a of[-1,1]){for(let l=0;l<=8;l++){let c=-he.roofHalfW+l/8*he.roofHalfW*2,h=[];for(let d=0;d<=8;d++){let f=d/8,p=.22*Math.pow(Math.abs(c)/he.roofHalfW,5.5)*Math.pow(f,2);h.push(ne(c,he.ridgeY-(he.ridgeY-he.eaveY)*Math.pow(f,1.14)+p+.012,a*he.eaveZ*f))}let u=new W(new et(new je(h),34,.008,3),new Qe({color:"#b56d76",transparent:!0,opacity:.23,toneMapped:!1}));u.castShadow=!1,i.add(u)}if(a===1)for(let l=0;l<9;l++){let c=-2.2+l*.55,h=N(ze(.055,1),k.brassSoft,{pos:[c,he.eaveY-.08,he.eaveZ+.05],scale:[1.2,.6,.8]});h.castShadow=!1,i.add(h);let u=N(new vn(.025,.1,5),k.brass,{pos:[c,he.eaveY-.19,he.eaveZ+.05],rot:[Math.PI,0,0]});u.castShadow=!1,i.add(u)}}let r=k.woodDark;for(let a of[-1,1])for(let l=0;l<7;l++){let c=-2.25+l*.75,h=ne(c,he.ridgeY-.1,a*.16),u=ne(c,he.eaveY-.14,a*(he.eaveZ-.08)),d=new W(new xn(.043,.034,h.distanceTo(u),6),r);d.position.copy(h).add(u).multiplyScalar(.5),d.quaternion.setFromUnitVectors(new A(0,1,0),new A().subVectors(u,h).normalize()),d.castShadow=!1,i.add(d)}let o=ma(.13,.025,"#ffd27d");return o.position.set(0,he.ridgeY+.36,0),i.add(o),i}function R_(i,e,t){let n=new ce;n.position.set(i,t,Et/2+vi/2+.13);let s=e;n.rotation.y=s*1.05;let r=new ce,o=1,a=1.28;r.position.x=-s*.5;let l=k.woodDark,c=[[0,a-.04,o,.08,0],[0,.06,o,.08,0]],h=N(ve(o,.075,.06,.015),l,{pos:[0,a-.03,.02]}),u=N(ve(o,.075,.06,.015),l,{pos:[0,.03,.02]}),d=N(ve(.06,a,.06,.015),l,{pos:[-o/2+.03,a/2,.02]}),f=N(ve(.06,a,.06,.015),l,{pos:[o/2-.03,a/2,.02]});r.add(h,u,d,f);for(let _=1;_<4;_++)r.add(N(ve(.026,a-.12,.035,.006),l,{pos:[-o/2+_*o/4,a/2,.03]}));for(let _=1;_<5;_++)r.add(N(ve(o-.12,.026,.035,.006),l,{pos:[0,.06+_*a/6,.03]}));for(let _=0;_<3;_++){let g=ma(.035,.012,"#efc075");g.position.set(-.22+_*.22,a-.23,.07),r.add(g)}let p=N(new dt(.045,.009,5,12,Math.PI),k.brass,{pos:[-s*.35,.62,.07],rot:[0,0,s>0?0:Math.PI]});return r.add(p),n.add(r),n}function _T(){let i=new ce,e=Et/2+.13,t=he.upperFloorY+.52,n=he.upperFloorY+.01,s=k.wood,r=N(ve(Jt+.16,.075,.085,.025),s,{pos:[0,t,e]});i.add(r);let o=N(ve(Jt+.16,.045,.065,.018),s,{pos:[0,n+.11,e]});i.add(o);for(let l=0;l<13;l++){let c=-Jt/2+.1+l*(Jt-.2)/12,h=N(Oe(.022,.026,t-n-.1,7),k.wood,{pos:[c,n+.12+(t-n-.1)/2,e]});i.add(h)}for(let l of[-1,1]){let c=N(ve(.1,.66,.1,.02),k.woodDark,{pos:[l*(Jt/2+.06),n+.32,e]});i.add(c);let h=N(ze(.075,1),k.brassSoft,{pos:[l*(Jt/2+.06),n+.69,e]});i.add(h)}let a=ft(510);for(let l=0;l<9;l++){let c=-2.05+l*.51,h=N(ze(.09,1),me(l%2?"#9fcfb5":"#bfe2bd"),{pos:[c,t-.05+(a()-.5)*.06,e+.05],scale:[1.2,.4,.8]});if(i.add(h),l%2===0){let d=N(ze(.045,1),me(l%4?"#ffc1d4":"#ffe7b6"),{pos:[c+.08,t+.01,e+.08]});i.add(d)}let u=pt("gold",.055,.18);u.position.set(c-.1,t-.1,e+.07),i.add(u)}return i}function A_(i){let e=new ce,t=new W(new dt(i,.022,6,40),nn("#f3c674"));e.add(t);let n=[],s=14;for(let a=0;a<s;a++){let l=a/s*xe,c=(a+1)/s*xe,h=ne(Math.cos(l)*i*.82,Math.sin(l)*i*.82,.01),u=ne(Math.cos(c)*i*.82,Math.sin(c)*i*.82,.01),d=ne(Math.cos((l+c)/2)*i*.55,Math.sin((l+c)/2)*i*.55,.01);n.push(h,d,d,u)}let r=new ke().setFromPoints(n),o=new Sn(r,new tn({color:"#ffdda0",transparent:!0,opacity:.6,blending:wt,depthWrite:!1,toneMapped:!1}));e.add(o);for(let a=0;a<3;a++){let l=-.22+a*.22,c=N(Oe(.004,.004,.23,3),k.brassDeep,{pos:[l,-i-.12,.01]});e.add(c);let h=N(new vn(.035,.15,5),me(a===1?"#ffd4a2":"#d9c5ff",{side:De}),{pos:[l,-i-.3,.01]});h.castShadow=!1,e.add(h)}return e}function xT(){let i=new ce,{x:e,z:t,r:n}=he.tower;i.position.set(e,0,t);let s=he.tower.bodyTop,r=N(Oe(n*1.01,n*1.05,s,16),k.plaster,{pos:[0,s/2,0]});r.castShadow=!0,r.receiveShadow=!0,i.add(r),ns(r,"#826371",.014,.48);let o=N(Oe(n*1.08,n*1.13,.42,16),k.woodDark,{pos:[0,.21,0]});i.add(o);let a=new W(new dt(n*1.02,.03,5,36),k.brass);a.rotation.x=Math.PI/2,a.position.y=.45,i.add(a);for(let Ge of[1.25,2.2,3.12,3.88]){let He=new W(new dt(n*1.013,.014,4,36),k.brassSoft);He.rotation.x=Math.PI/2,He.position.y=Ge,i.add(He)}for(let Ge=0;Ge<4;Ge++){let He=Ge*Math.PI/2+Math.PI/4,rt=new ce;rt.position.set(Math.cos(He)*n*.97,2.64,Math.sin(He)*n*.97),rt.rotation.y=Math.PI/2-He;let j=N(ve(.24,.46,.04,.06),k.washi,{pos:[0,0,0]});j.castShadow=!1,rt.add(j);let oe=N(ve(.34,.1,.07,.018),k.woodDark,{pos:[0,-.26,.01]});rt.add(oe);let Ee=pt("gold",.28,.2);Ee.position.z=.06,rt.add(Ee),i.add(rt)}let l=A_(.4);l.position.set(0,3.28,n+.04),i.add(l);let c=pt("pink",.7,.16);c.position.set(0,3.28,n+.1),i.add(c);let h=s,u=N(Oe(n*1.34,n*1.28,.12,20),k.deck,{pos:[0,h,0]});i.add(u);let d=new W(new dt(n*1.3,.028,5,30),k.brass);d.rotation.x=Math.PI/2,d.position.y=h+.075,i.add(d);for(let Ge=0;Ge<10;Ge++){let He=Ge/10*xe,rt=N(Oe(.018,.022,.34,5),k.wood,{pos:[Math.cos(He)*n*1.24,h+.26,Math.sin(He)*n*1.24]});i.add(rt)}let f=new W(new dt(n*1.24,.028,5,36),k.wood);f.rotation.x=Math.PI/2,f.position.y=h+.43,i.add(f);let p=he.tower.lanternTop-he.tower.bodyTop-.1,_=h+.07,g=new hn({color:"#fff2dc",transparent:!0,opacity:.17,roughness:.04,metalness:0,clearcoat:1,clearcoatRoughness:.05,side:De,depthWrite:!1,envMapIntensity:1.5}),m=N(Oe(n*.87,n*.9,p,12,1,!0),g,{pos:[0,_+p/2,0]});m.castShadow=!1,i.add(m);for(let Ge=0;Ge<8;Ge++){let He=Ge/8*xe,rt=N(Oe(.022,.025,p,6),k.brassDeep,{pos:[Math.cos(He)*n*.91,_+p/2,Math.sin(He)*n*.91]});i.add(rt)}for(let Ge of[_,_+p]){let He=new W(new dt(n*.92,.026,5,30),k.brass);He.rotation.x=Math.PI/2,He.position.y=Ge,i.add(He)}let v=A_(.36);v.position.set(.02,_+p*.72,n*.91),v.scale.setScalar(.92),i.add(v);let E=pt("gold",1.4,.16);E.position.set(.02,_+p*.72,n*.95),i.add(E);let y=N(new Rt(.19,24,16),Yn("#ffdca8",1.2));y.position.y=_+p*.52,y.castShadow=!1,i.add(y);let w=zp(.13,.023);w.position.set(0,_+p*.52,.24),w.castShadow=!1,i.add(w);let M=pt("gold",2.8,.38);M.position.y=_+p*.52,i.add(M);let T=new Yt("#ffc58b",3.2,4.2,2);T.position.y=_+p*.5,i.add(T);let x=he.tower.lanternTop-.02,S=he.tower.coneTop-x,C=N(new vn(n*1.42,S,18,1,!1),k.roof,{pos:[0,x+S/2,0]});C.castShadow=!0,C.receiveShadow=!0,i.add(C);for(let Ge=0;Ge<5;Ge++){let He=Ge/5*xe,rt=N(ze(.07,1),k.cloudPink,{pos:[Math.cos(He)*n*1.4,x+.01,Math.sin(He)*n*1.4],scale:[1.2,.45,.8]});i.add(rt)}let L=new W(new dt(n*1.42,.028,5,36),k.brass);L.rotation.x=Math.PI/2,L.position.y=x+.015,i.add(L);let F=[];for(let Ge=0;Ge<=30;Ge++){let He=Ge/30,rt=He*Math.PI*3.2,j=n*1.38*(1-He*.96);F.push(ne(Math.cos(rt)*j,x+He*S+.02,Math.sin(rt)*j))}let I=new W(new et(new je(F),80,.012,4,!1),k.brassSoft);i.add(I);let P=N(Oe(.018,.018,.25,6),k.brass,{pos:[0,he.tower.coneTop+.12,0]});i.add(P);let U=N(ze(.055,1),k.brass,{pos:[0,he.tower.coneTop+.26,0]});i.add(U);let z=new ce;z.position.y=he.tower.coneTop+.27;let V=N(Oe(.016,.022,.68,6),k.brass,{pos:[0,.34,0]});z.add(V);let ie=N(ve(.82,.025,.025,.008),k.brassDeep,{pos:[0,.5,0]});z.add(ie);let $=N(new vn(.045,.16,4),k.brass,{pos:[.47,.5,0],rot:[0,0,-Math.PI/2]});z.add($);let se=N(ve(.13,.1,.016,.01),k.brassSoft,{pos:[-.42,.5,0],rot:[0,0,-.45]});z.add(se);let te=zp(.17,.022,Math.PI*1.3);te.rotation.z=.7,te.position.set(0,.68,0),z.add(te);for(let Ge=0;Ge<3;Ge++){let He=ma(.045+Ge*.012,.012,"#ffe6a6");He.position.set(Math.cos(Ge*2.1)*.34,.56+Math.sin(Ge)*.1,Math.sin(Ge*2.1)*.06),z.add(He)}let Xe=N(Oe(.004,.004,.2,3),k.brassDeep,{pos:[-.22,.38,0]});z.add(Xe);let Ue=N(ze(.045,1),fn.lilac,{pos:[-.22,.26,0]});return Ue.castShadow=!1,z.add(Ue),i.add(z),i.userData.vane=z,i.userData.halo=M,i}function C_(i,e,t){let n=new ce;n.position.set(i,e,t);let s=N(Oe(.008,.008,.34,4),k.brassDeep,{pos:[0,.17,0]});n.add(s);let r=N(new vn(.17,.12,8),k.brassDeep,{pos:[0,-.01,0]});n.add(r);let o=new W(new xn(.12,.1,.24,8,1,!0),new hn({color:"#ffe9c8",transparent:!0,opacity:.33,roughness:.08,clearcoat:1,side:De,depthWrite:!1}));o.position.y=-.14,n.add(o);let a=N(ve(.03,.25,.03,.006),k.brass,{pos:[.11,-.14,0]});n.add(a);let l=N(ze(.06,2),Yn("#ffd59b",1.8),{pos:[0,-.14,0]});l.castShadow=!1,n.add(l);let c=pt("gold",1.15,.32);return c.position.y=-.14,n.add(c),n.userData={phase:i*2.3,baseRot:.04},n}function vT(){let i=new ce,e=[];for(let s=0;s<=32;s++){let r=s/32,o=-2.2+r*4.4,a=3.26-Math.sin(r*Math.PI*2)*.08-Math.sin(r*Math.PI)*.05;e.push(ne(o,a,Et/2+.3))}let t=new W(new et(new je(e),80,.006,3,!1),new Qe({color:"#795e62",transparent:!0,opacity:.5}));i.add(t);let n=[];for(let s=2;s<32;s+=3){let r=e[s],o=N(ze(.038,1),Yn(s%2?"#ffe0a0":"#ffd1dd",1.6),{pos:[r.x,r.y-.06,r.z]});o.castShadow=!1,i.add(o),n.push(o);let a=pt(s%2?"gold":"pink",.26,.12);a.position.copy(o.position),i.add(a)}return i}function yT(){let i=new ce,e=Et/2+.75,t=3.2,n=N(Oe(.045,.052,2.9,8),me("#e8bd84"),{pos:[1.85,t,e],rot:[0,0,Math.PI/2]});i.add(n);for(let l of[.5,3.2]){let c=N(Oe(.008,.008,.82,3),k.brassDeep,{pos:[l,t+.38,e-.2],rot:[.35,0,0]});i.add(c)}for(let l of[.48,3.18]){let c=new W(new dt(.1,.012,4,16),k.brassSoft);c.position.set(l,t,e),i.add(c);let h=ma(.04,.012,"#ffd98e");h.position.set(l,t,e-.03),i.add(h)}let s=[],r=[1.02,1.5,2,2.47,2.93],o=[["#ffcf9a","#ff81a7","#a787ff"],["#82e5da","#8db5ff","#d0a6ff"],["#ffd28e","#ff9fcf","#ffc09b"],["#b798ff","#74d6ef","#ffbc96"],["#ffd77e","#7de0bd","#b393ff"]],a=[5.9,6.6,7.1,6.8,6.05];return r.forEach((l,c)=>{let h=new W(new dt(.036,.008,4,12),k.brass);h.position.set(l,t-.045,e),h.rotation.x=Math.PI/2,i.add(h),s.push({x:l,y:t-.06,z:e,width:.36+c%3*.035,length:a[c],palette:o[c],seed:c*1.7+.4})}),{group:i,anchors:s}}function MT(){let i=new ce,e=fn.gold;for(let t=0;t<5;t++){let n=-1.4+t*.7,s=N(Oe(.004,.004,.35,3),k.brassDeep,{pos:[n,3.15,Et/2+.35]});i.add(s);let r=N(Oe(.022,.022,.15,6,1,!0),e,{pos:[n,2.94,Et/2+.35]});r.castShadow=!1,i.add(r);let o=N(ze(.025,1),k.brassSoft,{pos:[n,3.04,Et/2+.35]});i.add(o)}return i}function bT(){let i=new ce;i.position.set(0,1.36,Et/2+.22);let e=new W(new dt(.28,.055,7,24),me("#b9d9b4"));i.add(e);let t=ft(166);for(let r=0;r<12;r++){let o=r/12*xe,a=N(ze(.1,1),me(r%3?"#9fceb0":"#cbe4bc"),{pos:[Math.cos(o)*.3,Math.sin(o)*.3,0],scale:[.9,.35,.75]});i.add(a),r%2===0&&i.add(N(ze(.045,1),me(r%4?"#ffc4d6":"#ffe5b2"),{pos:[Math.cos(o)*.32,Math.sin(o)*.32,.06]}))}let n=zp(.09,.016,Math.PI*1.2);n.position.z=.1,n.rotation.z=.9,i.add(n);let s=N(Oe(.008,.008,.35,3),k.brassDeep,{pos:[0,.45,0]});return i.add(s),i}function P_(){let i=new ce;i.name="atelier";let e=N(ve(Jt+.46,.17,Et+.42,.05),k.woodDark,{pos:[0,-.075,0]});e.receiveShadow=!0,e.castShadow=!0,i.add(e);let t=N(ve(2.1,.13,.55,.04),k.wood,{pos:[0,.06,Et/2+.28]});i.add(t);for(let x=0;x<2;x++){let S=N(ve(1.8+x*.22,.08,.34,.025),k.woodWarm,{pos:[0,-.02-x*.07,Et/2+.52+x*.2]});i.add(S)}let n=N(fa(1.2,.5),new Ht({map:Pt.rug,gradientMap:Zt,side:De}),{pos:[0,.145,Et/2+.55],rot:[-Math.PI/2,0,0]});n.receiveShadow=!0,i.add(n);let s=Wr({width:Jt,height:he.groundH,holes:[{x:0,bottom:.1,w:2.05,h:1.43},{x:-1.82,bottom:.68,w:.48,h:.63},{x:1.82,bottom:.68,w:.48,h:.63}],flowers:[{x:-1.82,y:.63,width:.52},{x:1.82,y:.63,width:.46}],mullions:[-1.82,1.82]});s.group.position.set(0,he.groundBase,Et/2),i.add(s.group);let r=Wr({width:Jt,height:he.groundH,holes:[{x:0,bottom:.48,w:1.35,h:.96},{x:-1.55,bottom:.68,w:.48,h:.63},{x:1.55,bottom:.68,w:.48,h:.63}],flowers:[{x:-1.55,y:.63,width:.45},{x:1.55,y:.63,width:.45}],mullions:[0,-1.55,1.55]});r.group.position.set(0,he.groundBase,-Et/2),r.group.rotation.y=Math.PI,i.add(r.group);let o=Wr({width:Et,height:he.groundH,holes:[{x:0,bottom:.16,w:1.52,h:1.2},{x:-1.35,bottom:.7,w:.44,h:.6},{x:1.35,bottom:.7,w:.44,h:.6}],flowers:[{x:-1.35,y:.65,width:.4},{x:1.35,y:.65,width:.4}],mullions:[0,-1.35,1.35]});o.group.position.set(Jt/2,he.groundBase,0),o.group.rotation.y=Math.PI/2,i.add(o.group);let a=Wr({width:Et,height:he.groundH,holes:[{x:0,bottom:.16,w:1.52,h:1.2},{x:-1.35,bottom:.7,w:.44,h:.6},{x:1.35,bottom:.7,w:.44,h:.6}],flowers:[{x:-1.35,y:.65,width:.4},{x:1.35,y:.65,width:.4}],mullions:[0,-1.35,1.35]});a.group.position.set(-Jt/2,he.groundBase,0),a.group.rotation.y=-Math.PI/2,i.add(a.group);let l=Wr({width:Jt,height:he.upperH,holes:[{x:0,bottom:.12,w:1.4,h:1.01},{x:-1.58,bottom:.4,w:.53,h:.68},{x:1.58,bottom:.4,w:.53,h:.68}],flowers:[{x:-1.58,y:.36,width:.48},{x:1.58,y:.36,width:.48}],mullions:[0,-1.58,1.58],noBackBraces:!0});l.group.position.set(0,he.upperWallBase,-Et/2),l.group.rotation.y=Math.PI,i.add(l.group);let c=Wr({width:Et,height:he.upperH,holes:[{x:0,bottom:.08,w:1.42,h:1.08},{x:-1.34,bottom:.38,w:.45,h:.63},{x:1.34,bottom:.38,w:.45,h:.63}],flowers:[{x:-1.34,y:.33,width:.42},{x:1.34,y:.33,width:.42}],mullions:[0,-1.34,1.34]});c.group.position.set(Jt/2,he.upperWallBase,0),c.group.rotation.y=Math.PI/2,i.add(c.group);let h=Wr({width:Et,height:he.upperH,holes:[{x:0,bottom:.08,w:1.42,h:1.08},{x:-1.34,bottom:.38,w:.45,h:.63},{x:1.34,bottom:.38,w:.45,h:.63}],flowers:[{x:-1.34,y:.33,width:.42},{x:1.34,y:.33,width:.42}],mullions:[0,-1.34,1.34]});h.group.position.set(-Jt/2,he.upperWallBase,0),h.group.rotation.y=-Math.PI/2,i.add(h.group);let u=N(ve(Jt+.16,.095,.62,.03),k.deck,{pos:[0,he.upperFloorY-.055,Et/2+.16]});u.receiveShadow=!0,i.add(u);let d=N(ve(Jt+.24,.09,.11,.025),k.woodDark,{pos:[0,he.upperFloorY-.055,Et/2+.47]});i.add(d),i.add(_T());for(let x of[-1,1]){let S=he.ridgeY-he.wallTop+.06,C=new kt;C.moveTo(-Et/2,0),C.quadraticCurveTo(0,-.08,Et/2,0),C.lineTo(0,S),C.lineTo(-Et/2,0),C.closePath();let L=new li;L.absarc(0,S*.38,.22,0,Math.PI*2,!0),C.holes.push(L);let F=new en(C,{depth:.09,bevelEnabled:!0,bevelSegments:2,steps:1,bevelSize:.025,bevelThickness:.02,curveSegments:18});F.translate(0,0,-.045);let I=new W(F,k.plaster);I.rotation.y=x*Math.PI/2,I.position.set(x*(Jt/2-.045),he.wallTop,0),I.castShadow=!0,I.receiveShadow=!0,i.add(I);let P=[ne(x*(Jt/2+.015),he.wallTop,-Et/2),ne(x*(Jt/2+.015),he.wallTop+S-.03,0),ne(x*(Jt/2+.015),he.wallTop,Et/2)],U=new W(new et(new je(P,!1,"catmullrom",.01),30,.04,5,!1),k.woodDark);i.add(U);let z=new W(new dt(.24,.022,5,30),k.brassSoft);z.rotation.y=x*Math.PI/2,z.position.set(x*(Jt/2+.006),he.wallTop+S*.38,0),i.add(z);let V=ma(.075,.018,"#ffd798");V.rotation.y=x*Math.PI/2,V.position.set(x*(Jt/2+.02),he.wallTop+S*.38,0),i.add(V)}for(let x of[-1,1])for(let S of[-1,1]){let C=N(ve(.15,he.wallTop,.15,.03),k.woodDark,{pos:[x*(Jt/2+.01),he.wallTop/2-.02,S*(Et/2+.01)]});i.add(C),ns(C,"#76505e",.012,.5);let L=N(ve(.075,.55,.06,.02),k.woodDark,{pos:[x*(Jt/2-.34),he.slabY+.18,S*(Et/2+.02)],rot:[0,0,S*x*.65]});i.add(L)}let f=N(ve(Jt+.24,.17,Et+.24,.035),k.woodDark,{pos:[0,he.slabY+.01,0]});i.add(f);let p=N(ve(Jt+.15,.11,Et+.15,.025),k.woodDark,{pos:[0,he.wallTop-.04,0]});i.add(p);for(let x=0;x<9;x++){let S=-2+x*.5,C=N(ve(.07,.24,.07,.015),k.woodDark,{pos:[S,he.slabY-.16,Et/2+.13],rot:[.5,0,0]});i.add(C)}i.add(R_(-1.02,-1,he.groundBase+.1)),i.add(R_(1.02,1,he.groundBase+.1));{let x=he.groundBase+.1+1.43,S=he.groundBase+.1+1.43-2.05/2;for(let L=0;L<3;L++){let F=-1.1+L*1.1,I=N(ve(.026,.47,.03,.006),k.woodDark,{pos:[0,he.groundBase+1.31,Et/2+vi/2+.04],rot:[0,0,F]});i.add(I)}let C=ma(.09,.02,"#ffda8f");C.position.set(0,he.groundBase+1.49,Et/2+vi/2+.06),i.add(C)}i.add(bT()),i.add(C_(-1.95,he.groundBase+.92,Et/2+.25)),i.add(C_(1.95,he.groundBase+.92,Et/2+.25)),i.add(vT()),i.add(MT());for(let x of[-1,1]){let S=N(Oe(.17,.13,.28,14),me("#e9b59e"),{pos:[x*1.65,he.groundBase+.14,Et/2+.38]});S.castShadow=!0,i.add(S);for(let C=0;C<4;C++){let L=N(ze(.11,1),me(C%2?"#a5d7b6":"#c5e5bd"),{pos:[x*1.65+(C-1.5)*.09,he.groundBase+.34+C%2*.12,Et/2+.38],scale:[.7,.8,.4],rot:[.3,C,.2]});i.add(L)}}let _=T_();i.add(_.group);for(let x=0;x<2;x++){let S=new W(fa(.65,.8,8,10),new hn({color:["#ffd3dd","#d6c9ff"][x],transparent:!0,opacity:.48,roughness:.4,side:De,depthWrite:!1})),C=S.geometry.attributes.position;for(let L=0;L<C.count;L++){let F=C.getX(L),I=C.getY(L);C.setZ(L,Math.sin((F+.4)*7+I*2)*.02)}S.geometry.computeVertexNormals(),S.position.set(-1.68+x*3.35,he.upperFloorY+.02,Et/2+.24),S.rotation.z=0,i.add(S)}i.add(gT());let g=xT();i.add(g);let m=yT();i.add(m.group);let v=[];for(let x=0;x<10;x++){let S=pt(x%3?"pink":"gold",.18+x%2*.08,.2);S.position.set(-2.2+x%5*.9,he.wallTop+.7+x%3*.6,-1.2+x%2*.8),S.userData={base:S.position.clone(),ph:x*1.1},i.add(S),v.push(S)}let E=i.children.filter(x=>x.isGroup&&x.userData?.phase!==void 0&&x.userData?.baseRot!==void 0),y=g.userData.vane,w=g.userData.halo,M=[];function T(x){_.update(x);for(let S of E)S.rotation.z=Math.sin(x*.6+S.userData.phase)*.025,S.rotation.x=Math.cos(x*.45+S.userData.phase)*.018;if(y&&(y.rotation.y=Math.sin(x*.18)*.4+Math.sin(x*.53+2)*.08,y.rotation.z=Math.sin(x*.4)*.02),w){let S=2.8+Math.sin(x*.7)*.18;w.scale.setScalar(S)}v.forEach((S,C)=>{S.position.x=S.userData.base.x+Math.sin(x*.12+C)*.2,S.position.y=S.userData.base.y+Math.cos(x*.16+C)*.15,S.material.opacity=.1+.1*(.5+.5*Math.sin(x*.8+C))}),i.children.forEach(S=>{S.isMesh&&S.material?.type==="MeshPhysicalMaterial"&&S.position.z>Et/2+.2&&S.position.y<he.upperFloorY+.2&&(S.rotation.x=-.18+Math.sin(x*.45+S.position.x)*.02)})}return{group:i,update:T,silkAnchors:m.anchors,interior:_,tower:g}}var I_=`
  uniform float uTime;
  uniform float uSeed;
  uniform float uLength;
  varying vec2 vUv;
  varying vec3 vWorld;
  varying vec3 vLocal;

  void main() {
    vUv = uv;
    vLocal = position;
    vec3 p = position;
    float hang = clamp(-p.y / uLength, 0.0, 1.0);
    float h2 = hang * hang;
    float wave = sin(hang * 7.6 - uTime * 1.02 + uSeed) * .22 * h2
               + sin(hang * 3.4 + uTime * .63 + uSeed * 1.7) * .10 * hang;
    p.z += wave;
    p.x += sin(hang * 5.2 + uTime * .72 + uSeed * .8) * .075 * h2;
    p.z += sin(uv.x * 6.283 + uTime * .4 + hang * 2.0) * .025 * h2;

    vec4 wp = modelMatrix * vec4(p, 1.0);
    vWorld = wp.xyz;
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`,D_=`
  precision highp float;
  uniform float uTime;
  uniform float uSeed;
  uniform vec3 uA;
  uniform vec3 uB;
  uniform vec3 uC;
  uniform float uOpacity;
  varying vec2 vUv;
  varying vec3 vWorld;

  float hash21(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }

  void main() {
    vec3 N = normalize(cross(dFdx(vWorld), dFdy(vWorld)));
    vec3 V = normalize(cameraPosition - vWorld);
    if (dot(N, V) < 0.0) N = -N;
    vec3 L = normalize(vec3(-.35, .8, .52));
    float lam = clamp(dot(N, L) * .5 + .5, 0.0, 1.0);
    float soft = smoothstep(.25, .8, lam);

    float t = vUv.y;
    vec3 col = mix(uA, uB, smoothstep(.0, .72, t)); // saturated silk
    col *= 1.05;
    col = mix(col, uC, smoothstep(.58, 1.0, t) * .86);
    col = mix(col, vec3(1.0, .94, .88), .045);

    // moving iridescent bands, like sunlight through the weave
    float band = .5 + .5 * sin(t * 26.0 + vUv.x * 7.0 - uTime * .95 + uSeed);
    col = mix(col, col * vec3(1.05, .98, 1.08) + vec3(.035,.012,.055), band * .28);
    float gold = smoothstep(.72, 1.0, .5 + .5 * sin(t * 45.0 + uTime * .4 + uSeed * 2.1));
    col += vec3(1.0, .78, .45) * gold * .07;

    // raised edging and a feather-light sheen
    float edge = smoothstep(.42, .5, abs(vUv.x - .5));
    col = mix(col, col * vec3(1.10, 1.02, .92) + vec3(.05,.03,.015), edge * .35);
    float sheen = pow(1.0 - clamp(abs(dot(N, V)), 0.0, 1.0), 2.2);
    col += vec3(1.0, .90, .78) * sheen * .17;

    // tiny stars caught in the silk
    float sparkle = step(.995, hash21(floor(vUv * vec2(52.0, 190.0)) + floor(uTime*.25)));
    col += vec3(1.0,.9,.7) * sparkle * .35;

    // darker silk fold lines + gold fringe at the bottom
    col *= .90 + .10 * smoothstep(0.0, .9, soft);
    float hem = 1.0 - smoothstep(.0, .025, vUv.y);
    col = mix(col, vec3(1.0, .82, .48), hem * .45);

    float alpha = uOpacity * (0.83 + edge*.1);
    alpha *= smoothstep(0.0, .018, vUv.x) * smoothstep(1.0, .982, vUv.x);
    gl_FragColor = vec4(col, alpha);
  }
`;function L_(i){let e=new ce;e.name="silk-waterfall";let t=[];i.forEach((s,r)=>{let o=new xt({uniforms:{uTime:{value:0},uSeed:{value:s.seed},uLength:{value:s.length},uA:{value:new q(s.palette[0])},uB:{value:new q(s.palette[1])},uC:{value:new q(s.palette[2])},uOpacity:{value:.92}},vertexShader:I_,fragmentShader:D_,transparent:!0,depthWrite:!1,side:De,blending:Vn});t.push(o);let a=new cn(s.width,s.length,10,64);a.translate(0,-s.length/2,0);let l=new W(a,o);l.position.set(s.x,s.y,s.z),l.rotation.y=-.035+r*.01,l.renderOrder=6+r,l.castShadow=!1,l.receiveShadow=!1,e.add(l);let c=new W(new dt(.04,.009,4,12),k.brass);if(c.position.set(s.x,s.y+.02,s.z),c.rotation.x=Math.PI/2,e.add(c),r===0||r===2||r===4){let h=o.clone();h.uniforms=wi.clone(o.uniforms),h.uniforms.uOpacity.value=.24,h.uniforms.uSeed.value=s.seed+2.4;let u=new cn(s.width*1.55,s.length*1.02,8,48);u.translate(0,-s.length*.51,0);let d=new W(u,h);d.position.set(s.x+.03,s.y+.01,s.z-.06),d.renderOrder=4,e.add(d),t.push(h)}});{let s=new xt({uniforms:{uTime:{value:0},uSeed:{value:4.2},uLength:{value:7.4},uA:{value:new q("#ffd3b6")},uB:{value:new q("#e8a8df")},uC:{value:new q("#b5d8f3")},uOpacity:{value:.13}},vertexShader:I_,fragmentShader:D_,transparent:!0,depthWrite:!1,side:De}),r=new cn(2,7.4,14,52);r.translate(0,-3.7,0);let o=new W(r,s);o.position.set(2.16,3.09,2.58),o.rotation.y=-.03,o.renderOrder=3,e.add(o),t.push(s)}function n(s){for(let r of t)r.uniforms.uTime.value=s}return{group:e,update:n}}function N_(i,e=44){let t=new ce;t.name="rainbow-bubbles";let n=new Rt(1,12,9),s=new xt({uniforms:{uTime:{value:0}},vertexShader:`
      varying vec3 vN; varying vec3 vV; varying vec3 vWorld;
      void main(){
        mat4 im = mat4(1.0);
        #ifdef USE_INSTANCING
          im = instanceMatrix;
        #endif
        vec4 wp = modelMatrix * im * vec4(position,1.0);
        vWorld = wp.xyz;
        vN = normalize(mat3(modelMatrix) * mat3(im) * normal);
        vV = normalize(cameraPosition - wp.xyz);
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,fragmentShader:`
      precision highp float;
      uniform float uTime;
      varying vec3 vN; varying vec3 vV; varying vec3 vWorld;
      void main(){
        vec3 N = normalize(vN);
        vec3 V = normalize(vV);
        float fres = pow(1.0 - abs(dot(N,V)), 1.7);
        vec3 iri = .5 + .5 * cos(6.28318 * (fres * 1.35 + vec3(0.0,.33,.67) + vWorld.y * .035 + uTime * .018));
        vec3 col = mix(vec3(.92,.99,1.0), iri, .72);
        float spec = pow(max(dot(N, normalize(vec3(.38,.82,.42))), 0.0), 22.0);
        col += vec3(1.0,.98,.9) * spec * 1.2;
        float alpha = .06 + fres * .48 + spec * .45;
        gl_FragColor = vec4(col, alpha);
      }
    `,transparent:!0,depthWrite:!1,side:De,blending:Vn}),r=new En(n,s,e);r.instanceMatrix.setUsage($s),r.castShadow=!1,r.receiveShadow=!1,r.renderOrder=12,r.frustumCulled=!1;let o=new _t,a=ft(921),l=[],c=[new q("#ffd9ea"),new q("#d8f6ff"),new q("#fff0c8"),new q("#e4d5ff")];for(let u=0;u<e;u++){let d=i[u%i.length];l.push({src:d,phase:a(),speed:.16+a()*.22,size:.065+a()*.14,angle:a()*xe,radius:.06+a()*.22,drift:.5+a()*1.4,maxH:1.4+a()*2.4}),r.setColorAt(u,c[u%c.length])}for(let u=0;u<Math.min(8,e);u++)l[u].size*=1.9,l[u].speed*=.72;t.add(r);function h(u){for(let d=0;d<e;d++){let f=l[d],p=(u*f.speed*.55+f.phase)%1,_=Math.sin(Math.min(1,p)*Math.PI*.5),g=Math.sin(Math.min(1,p)*Math.PI),m=Math.sin(u*(.6+f.speed*4)+f.phase*9),v=f.radius+_*.14,E=f.src.x+Math.cos(f.angle+_*2.2+u*.13)*v*.7+Math.sin(u*.3+f.phase*4)*.03,y=f.src.z+Math.sin(f.angle+_*1.9-u*.1)*v*.6,w=f.src.y+p*f.maxH+m*.035,M=f.size*(.35+.9*g);o.position.set(E,w,y),o.scale.setScalar(M),o.rotation.set(u*.3+f.phase,u*.5+f.angle,0),o.updateMatrix(),r.setMatrixAt(d,o.matrix)}r.instanceMatrix.needsUpdate=!0,s.uniforms.uTime.value=u}return h(0),{group:t,update:h,inst:r}}var ET=`
  varying vec3 vN;
  varying vec3 vV;
  varying vec3 vPos;
  varying vec2 vUv;
  uniform float uTime;
  uniform float uPulse;
  void main() {
    vUv = uv;
    vec3 p = position;
    // a little breathing scallop around the hem
    float wob = sin(atan(p.z, p.x) * 7.0 + uTime * 1.4) * .025 * smoothstep(.0, .5, .5 - p.y);
    p.xz *= 1.0 + wob;
    p.y *= 1.0 + sin(uTime * .9) * .02 + uPulse * .02;
    vPos = p;
    vec4 wp = modelMatrix * vec4(p, 1.0);
    vN = normalize(mat3(modelMatrix) * normal);
    vV = normalize(cameraPosition - wp.xyz);
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`,ST=`
  uniform vec3 uA;
  uniform vec3 uB;
  uniform vec3 uRim;
  uniform float uTime;
  uniform float uOpacity;
  varying vec3 vN;
  varying vec3 vV;
  varying vec3 vPos;
  varying vec2 vUv;

  void main() {
    vec3 N = normalize(vN);
    if (!gl_FrontFacing) N = -N;
    vec3 V = normalize(vV);
    float fres = pow(1.0 - clamp(dot(N, V), 0.0, 1.0), 1.55);
    float vertexGlow = smoothstep(-.4, .55, vPos.y);
    vec3 col = mix(uB, uA, vertexGlow * .8 + fres * .3);
    col *= 1.08;
    float veins = .5 + .5 * sin(vPos.x * 18.0 + vPos.z * 13.0 + uTime * .9)
                  * sin(vPos.y * 21.0 - uTime * .7);
    col = mix(col, uRim, veins * .14 + fres * .38);
    vec3 iri = .5 + .5 * cos(6.283 * (fres + vec3(0.0, .28, .62) + vUv.x * .18 + uTime * .025));
    col = mix(col, iri, .10 + fres * .18);
    float alpha = uOpacity * (.38 + fres * .54 + veins * .06);
    gl_FragColor = vec4(col, alpha);
  }
`;function U_(i,e,t){let n=new Rt(i,30,16,0,xe,0,Math.PI/2),s=new xt({uniforms:{uTime:{value:0},uPulse:{value:t},uA:{value:new q(e)},uB:{value:new q("#fff4f6")},uRim:{value:new q("#ffdcef")},uOpacity:{value:1}},vertexShader:ET,fragmentShader:ST,transparent:!0,depthWrite:!1,side:De,blending:Vn}),r=new W(n,s);return r.scale.set(1,.66,1),r.castShadow=!1,r}function F_(i,e,t=7,n=1){let s=new ce,r=ft(n),o=fn[e]||fn.pink,a=[];for(let l=0;l<t;l++){let c=l/t*xe+.2,h=new ce;h.rotation.y=c;let u=.7+r()*1.05,d=.15+r()*.22,f=[];for(let g=0;g<=6;g++){let m=g/6;f.push(ne(Math.sin(m*(1.2+r()*.4)+l)*.045+m*.02,-m*u,d*m+Math.sin(m*Math.PI*2+l*2)*.05))}let p=new W(new et(new je(f),14,.01+r()*.008,4,!1),o);p.castShadow=!1,h.add(p);let _=new W(new Tn(.018+r()*.012,1),fn.lilac);_.position.copy(f[f.length-1]),_.castShadow=!1,h.add(_),h.userData={phase:r()*xe,baseX:h.rotation.x},s.add(h),a.push(h)}return{group:s,tentacles:a}}function B_(){let i=new ce;i.name="jelly-lamps";let e=[{x:-5.1,y:5.4,z:3.7,r:.44,color:"pink",c:"#ff88b7",seed:1,bob:1.15,phase:.4},{x:4.95,y:6.7,z:3.4,r:.48,color:"lilac",c:"#ab88ff",seed:2,bob:.95,phase:2},{x:6.8,y:4.6,z:-.7,r:.34,color:"blue",c:"#8bdde9",seed:3,bob:1.35,phase:4.1},{x:-5.7,y:4.45,z:1.2,r:.28,color:"peach",c:"#ffb68e",seed:4,bob:1,phase:5.2},{x:-.5,y:9,z:-3.8,r:.38,color:"blue",c:"#a9e1ee",seed:5,bob:1.2,phase:1.3},{x:2,y:9.1,z:3.8,r:.3,color:"pink",c:"#ffa3c3",seed:6,bob:.8,phase:3.6},{x:-7.4,y:7.6,z:-2,r:.32,color:"gold",c:"#ffd18c",seed:7,bob:1.45,phase:2.7},{x:6.8,y:7.2,z:1.2,r:.24,color:"lilac",c:"#cbb5ff",seed:8,bob:1.1,phase:5.9}],t=[];for(let s of e){let r=new ce;r.position.set(s.x,s.y,s.z),r.scale.setScalar(1.58),r.userData={...s,baseY:s.y};let o=U_(s.r,s.c,0);r.add(o);let a=new ce;for(let f=0;f<9;f++){let p=f/9*xe,_=N(ze(.085+s.r*.14,1),fn[s.color]||fn.pink,{pos:[Math.cos(p)*s.r*.95,-.02,Math.sin(p)*s.r*.95],scale:[1.5,.42,1],rot:[0,-p,.4]});_.castShadow=!1,a.add(_)}r.add(a);let l=N(ze(s.r*.22,2),new Qe({color:new q(s.c).multiplyScalar(1.3),transparent:!0,opacity:.9,blending:wt,depthWrite:!1,toneMapped:!1}),{pos:[0,s.r*.3,0]});l.castShadow=!1,r.add(l);let c=pt(s.color==="gold"?"gold":s.color==="blue"?"blue":"pink",s.r*7.5,.26);c.position.y=s.r*.22,r.add(c);let h=F_(s.r,s.color,7,s.seed*13);r.add(h.group);let u=new W(new dt(s.r*.94,.014,5,30),new Qe({color:new q(s.c).multiplyScalar(1.35),transparent:!0,opacity:.8,blending:wt,depthWrite:!1,toneMapped:!1}));u.rotation.x=Math.PI/2,r.add(u);let d=pt("gold",s.r*1.2,.18);if(d.position.y=-.08,r.add(d),s.r>.4){let f=new Yt(s.c,1.8,4.4,2);f.position.set(0,s.r*.5,0),r.add(f)}i.add(r),t.push({group:r,bell:o,skirt:a,tentacles:h.tentacles,halo:c,core:l,spec:s})}for(let s=0;s<2;s++){let r={x:s?7.2:-7.6,y:.65,z:s?2.1:3,r:.1,color:"pink",c:"#ffc4d8",seed:14+s,bob:.7,phase:s*2.4},o=new ce;o.position.set(r.x,r.y,r.z),o.userData={...r,baseY:r.y};let a=U_(r.r,r.c,.4);o.add(a);let l=pt("pink",.6,.2);o.add(l);let c=F_(r.r,"pink",4,17+s);o.add(c.group),i.add(o),t.push({group:o,bell:a,skirt:null,tentacles:c.tentacles,halo:l,core:null,spec:r})}function n(s){for(let r=0;r<t.length;r++){let o=t[r],a=o.spec,l=a.phase,c=a.baseY!==void 0?a.baseY:a.y;o.group.position.y=c+Math.sin(s*.33+l)*a.bob*.22,o.group.position.x=a.x+Math.sin(s*.16+l*1.7)*.12,o.group.position.z=a.z+Math.cos(s*.14+l)*.09,o.group.rotation.y=Math.sin(s*.1+l)*.08;let h=1+Math.sin(s*.56+l)*.045;o.bell.scale.set(h,.66*(.92+Math.sin(s*.52+l)*.06),h),o.bell.material.uniforms.uTime.value=s,o.bell.material.uniforms.uPulse.value=Math.sin(s*.56+l),o.tentacles.forEach((u,d)=>{u.rotation.x=u.userData.baseX+Math.sin(s*.45+l+d*1.2)*.16,u.rotation.z=Math.cos(s*.36+l+d*.9)*.12}),o.halo&&(o.halo.material.opacity=.12+.05*(.5+.5*Math.sin(s*.8+l))),o.core&&o.core.scale.setScalar(1+Math.sin(s*.8+l)*.08)}}return{group:i,update:n}}function TT(i=.08,e=.02){let t=new kt;for(let n=0;n<10;n++){let s=n*Math.PI/5-Math.PI/2,r=n%2?i*.42:i,o=Math.cos(s)*r,a=Math.sin(s)*r;n===0?t.moveTo(o,a):t.lineTo(o,a)}return t.closePath(),new en(t,{depth:e,bevelEnabled:!0,bevelSegments:1,steps:1,bevelSize:.008,bevelThickness:.006,curveSegments:2})}function O_(){let i=new ce;i.name="wishing-tree",i.position.set(-7.35,.2,2.15),i.scale.setScalar(1.22),i.rotation.y=-.2;let e=ft(818),t=new ce;for(let I=0;I<12;I++){let P=I/12*xe,U=.5+e()*1.3,z=N(ze(1,2),me([qt.cloudCream,qt.cloudPink,qt.cloudPeach,qt.cloudLilac][I%4]),{pos:[Math.cos(P)*U*.8,.18+e()*.36,Math.sin(P)*U*.6],scale:[.55+e()*.6,.25+e()*.22,.5+e()*.5],rot:[0,e()*xe,0]});t.add(z)}let n=N(new Rt(1,24,12),me("#b7ddc7",{emissive:"#a4d5b7",emissiveIntensity:.08}),{pos:[0,.56,0],scale:[1.45,.24,1.08]});n.receiveShadow=!0,t.add(n);for(let I=0;I<5;I++){let P=e()*xe,U=.55+e()*.65,z=N(ze(.08+e()*.06,1),me("#e3d2c8"),{pos:[Math.cos(P)*U,.64+e()*.02,Math.sin(P)*U*.7],scale:[1.3,.45,1]});t.add(z)}for(let I=0;I<4;I++){let P=1+I*1.5,U=N(Oe(.015,.02,.11,5),me("#fff1dc"),{pos:[Math.cos(P)*.9,.68,Math.sin(P)*.55]});t.add(U);let z=N(new Rt(.07,10,6,0,xe,0,Math.PI/2),me(I%2?"#ffc0d1":"#d9c4ff"),{pos:[Math.cos(P)*.9,.79,Math.sin(P)*.55],scale:[1,.7,1]});t.add(z)}i.add(t);let s=me("#8d5b52",{emissive:"#4a2c30",emissiveIntensity:.06}),r=[ne(0,.64,0),ne(-.12,1.15,.08),ne(.06,1.76,-.04),ne(-.16,2.4,.08),ne(-.07,3.1,-.06),ne(.16,3.7,.02),ne(.2,4.38,-.02)],o=new W(new et(new je(r),32,.16,8,!1),s);o.castShadow=!0,o.receiveShadow=!0,i.add(o);let a=new W(new et(new je([ne(.12,3.25,-.03),ne(.22,3.85,.05),ne(.18,4.48,-.03)]),16,.085,6,!1),wT());i.add(a),ns(o,"#5d3e43",.012,.4);for(let I=0;I<5;I++){let P=I/5*xe+.2,U=ne(Math.cos(P)*.8,.6,Math.sin(P)*.55),z=new W(new et(new je([ne(0,.72,0),ne(Math.cos(P)*.35,.68,Math.sin(P)*.2),U]),12,.055,5,!1),s);i.add(z)}let l=[{pts:[ne(-.1,3.15,0),ne(-.7,3.55,-.2),ne(-1.4,3.95,-.45),ne(-2,4.15,-.2)],r:.07},{pts:[ne(.12,3.5,0),ne(.8,3.65,.2),ne(1.55,4.08,.1),ne(1.9,4.45,.5)],r:.065},{pts:[ne(-.03,3.85,0),ne(-.2,4.25,-.6),ne(-.7,4.55,-.95),ne(-1.1,4.65,-.9)],r:.055},{pts:[ne(.18,4.03,0),ne(.4,4.4,.55),ne(.1,4.8,.95),ne(-.4,5.12,.8)],r:.05},{pts:[ne(-.1,4.2,0),ne(-.5,4.55,.35),ne(-.9,4.9,.25),ne(-1.15,5.1,-.2)],r:.04}];for(let I of l){let P=new W(new et(new je(I.pts),20,I.r,6,!1),s);P.castShadow=!0,i.add(P);let U=I.pts[I.pts.length-1],z=new W(new et(new je([U,U.clone().add(ne(.18,.32,.22)),U.clone().add(ne(.05,.55,.34))]),10,I.r*.35,4,!1),s);i.add(z)}for(let I=0;I<3;I++){let P=[];for(let z=0;z<=18;z++){let V=z/18,ie=new je(r).getPointAt(V*.8);P.push(ie.add(ne(Math.cos(I*2.1+V*4)*.16,0,Math.sin(I*2.1+V*4)*.16)))}let U=new W(new et(new je(P),20,.009,3),new Qe({color:"#e6b999",transparent:!0,opacity:.35,toneMapped:!1,depthWrite:!1}));i.add(U)}let c=new ce,h=[[-1.5,4.35,-.4,1.05],[-.8,4.65,-.75,.9],[.25,4.7,-.45,.92],[1.3,4.45,.2,1],[1.75,4.7,.5,.65],[-1.8,4.8,.2,.72],[-.9,5,.2,.8],[.35,5.15,.35,.82],[-.3,5.05,-.95,.68],[1.05,4.95,-.7,.6],[-1.2,4.3,.6,.8],[.9,4.1,.6,.66],[-2.1,4.25,.1,.55]];for(let I=0;I<h.length;I++){let[P,U,z,V]=h[I],ie=me([qt.cloudLilac,qt.cloudPink,qt.cloudPeach,qt.cloudCream,qt.cloudMint][I%5],{emissive:I%2?"#ffc9e1":"#d9c8ff",emissiveIntensity:.08}),$=3+Math.floor(e()*3);for(let se=0;se<$;se++){let te=N(ze(1,2),ie,{pos:[P+(e()-.5)*V*1.4,U+(e()-.5)*V*.55,z+(e()-.5)*V*.9],scale:[V*(.55+e()*.6),V*(.38+e()*.35),V*(.55+e()*.5)],rot:[e()*.2,e()*xe,e()*.2]});te.castShadow=!0,te.receiveShadow=!0,c.add(te)}}for(let I=0;I<18;I++){let P=e()*xe,U=.5+e()*1.6,z=N(ze(.04+e()*.05,1),me(I%4===0?"#ffe4a5":I%3===0?"#ffc6da":"#fff2e4"),{pos:[Math.cos(P)*U,4.1+e()*1.15,Math.sin(P)*U*.65]});z.castShadow=!1,c.add(z)}i.add(c);let u=[];for(let I=0;I<7;I++){let P=pt(I%2?"gold":"pink",.22+e()*.18,.22);P.position.set((e()-.5)*2.8,3.9+e()*.95,(e()-.5)*1.4),c.add(P),u.push({sprite:P,base:P.position.clone(),phase:e()*xe})}let d=new Yt("#ffca9a",2.6,4.5,2);d.position.set(-.1,3.9,.1),i.add(d);for(let I=0;I<4;I++){let P=ne(-1.2+I*.8,4.15-I%2*.25,.75+I%2*.25),U=N(Oe(.004,.004,.32,3),k.brassDeep,{pos:[P.x,P.y-.16,P.z]});i.add(U);let z=new W(TT(.075,.015),nn("#ffd68c"));z.position.set(P.x,P.y-.35,P.z),z.rotation.y=I*.6,i.add(z)}let f=[],p=38;for(let I=0;I<p;I++){let P=e()*xe,U=.45+e()*2.05,z=ne(Math.cos(P)*U,3+e()*1.55,Math.sin(P)*U*.68),V=.26+e()*.58,ie=.14+e()*.22;f.push({top:z,len:V,glen:ie,phase:e()*xe,amp:.09+e()*.08,color:[qt.dyeRose,qt.dyeLilac,qt.dyeGold,qt.dyeSky,"#fff0d0"][I%5],spin:(e()-.5)*.4})}let _=new xn(.0028,.0028,1,3),g=new Qe({color:"#f8dcae",transparent:!0,opacity:.55,toneMapped:!1,depthWrite:!1}),m=new En(_,g,p);m.frustumCulled=!1,m.castShadow=!1;let v=new xn(.015,.032,1,6,1,!0),E=new hn({color:"#ffffff",transparent:!0,opacity:.62,roughness:.06,metalness:0,clearcoat:1,clearcoatRoughness:.06,iridescence:1,iridescenceIOR:1.35,iridescenceThicknessRange:[100,700],side:De,depthWrite:!1,envMapIntensity:1.7}),y=new En(v,E,p);y.frustumCulled=!1,y.castShadow=!1,y.renderOrder=8;let w=new Tn(.014,1),M=new En(w,k.brass,p);M.frustumCulled=!1,M.castShadow=!1;let T=new _t,x=new $t,S=new Gn;for(let I=0;I<p;I++)y.setColorAt(I,new q(f[I].color)),M.setColorAt(I,new q("#ffd889"));i.add(m,y,M);let C=pt("gold",1.5,.12);C.position.set(0,.9,0),i.add(C);let L=[];for(let I=0;I<6;I++){let P=e()*xe,U=.6+e()*.8,z=N(ze(.16,1),me(["#ffc1d5","#fff0dc","#d6c4ff"][I%3]),{pos:[Math.cos(P)*U*.8,.72+e()*.18,Math.sin(P)*U*.5],scale:[1.2,.5,1]});t.add(z)}function F(I){c.position.y=Math.sin(I*.23)*.025,c.rotation.z=Math.sin(I*.17)*.006;for(let P of u)P.sprite.position.y=P.base.y+Math.sin(I*.6+P.phase)*.06,P.sprite.material.opacity=.12+.13*(.5+.5*Math.sin(I*.9+P.phase));for(let P=0;P<p;P++){let U=f[P],z=Math.sin(I*.78+U.phase)*U.amp,V=Math.cos(I*.61+U.phase*1.3)*U.amp;S.set(z,0,V),x.setFromEuler(S),T.position.copy(U.top).add(new A(0,-U.len/2,0).applyQuaternion(x)),T.quaternion.copy(x),T.scale.set(1,U.len,1),T.updateMatrix(),m.setMatrixAt(P,T.matrix);let ie=new A(0,-U.len-U.glen*.5,0).applyQuaternion(x).add(U.top);T.position.copy(ie),T.quaternion.copy(x),T.rotateY(I*.18+U.phase+U.spin),T.scale.set(1,U.glen,1),T.updateMatrix(),y.setMatrixAt(P,T.matrix),T.position.copy(U.top).add(new A(0,-U.len-.035,0).applyQuaternion(x)),T.quaternion.copy(x),T.scale.setScalar(1),T.updateMatrix(),M.setMatrixAt(P,T.matrix)}m.instanceMatrix.needsUpdate=!0,y.instanceMatrix.needsUpdate=!0,M.instanceMatrix.needsUpdate=!0}return F(0),{group:i,update:F,chimes:f}}function wT(){return me("#a06d5d",{emissive:"#44232a",emissiveIntensity:.05})}function RT(i=1,e=.16){let t=new kt;return t.moveTo(0,0),t.bezierCurveTo(-e*.7,.22,-e*.95,i*.68,0,i),t.bezierCurveTo(e*.95,i*.68,e*.7,.22,0,0),new en(t,{depth:.014,bevelEnabled:!1,steps:1,curveSegments:14})}function H_(i){let e=new ce;e.position.set(-.05,.32,i*.34),e.rotation.x=i*.33,e.rotation.z=i*-.16,e.rotation.y=i*.06;let t=RT(),n=me("#fff4e5",{side:De,emissive:"#ffdcc9",emissiveIntensity:.08}),s=me("#ffd4dc",{side:De,emissive:"#ffc2cf",emissiveIntensity:.08}),r=nn("#efc57c");for(let o=0;o<8;o++){let a=o/7,l=-.72+a*1.34,c=.62+Math.sin(a*Math.PI)*.52,h=new W(t,o%3===1?s:n);h.rotation.z=l,h.scale.set(1,c,1),h.position.z=o*.006,h.castShadow=!0,e.add(h);let u=new A(Math.sin(l)*c,Math.cos(l)*c,.03),d=new W(new et(new je([ne(0,0,.025),ne(u.x*.5,u.y*.55,.03),u]),10,.006,3,!1),r);e.add(d)}for(let o=0;o<3;o++){let a=new W(t,n);a.rotation.z=-.2+o*.22,a.scale.set(.7,.34,.7),a.position.z=-.015,e.add(a)}return e}function AT(){let t=[],n=[];for(let r=0;r<=26;r++){let o=r/26,a=-1.25+2.5*o,l=.44*Math.pow(Math.sin(Math.PI*CT(o*.94+.03,0,1)),.62),c=.2+.11*Math.sin(Math.PI*o),h=-.31-.16*Math.sin(Math.PI*o);for(let u=0;u<=10;u++){let d=Math.PI*u/10,f=l*Math.cos(d),p=c-(c-h)*Math.pow(Math.sin(d),.8);t.push(a,p,f)}}for(let r=0;r<26;r++)for(let o=0;o<10;o++){let a=r*11+o,l=(r+1)*11+o,c=(r+1)*11+o+1,h=r*11+o+1;n.push(a,l,h,l,c,h)}let s=new ke;return s.setAttribute("position",new _e(t,3)),s.setAttribute("uv",new _e(t.map((r,o)=>o),1)),s.setIndex(n),s.computeVertexNormals(),s}function CT(i,e,t){return Math.max(e,Math.min(t,i))}function PT(){let i=new ce;i.position.set(7.35,.69,5.55),i.rotation.y=1.08,i.rotation.z=-.035;let e=new Ht({color:"#fff0dc",map:Pt.wood,gradientMap:Zt,side:De}),t=new W(AT(),e);t.castShadow=!0,t.receiveShadow=!0,i.add(t);let n=N(ve(1.35,.045,.45,.15),k.woodDark,{pos:[0,-.04,0]});n.castShadow=!1,i.add(n);let s=N(ve(.65,.16,.42,.08),me("#ffd1dc"),{pos:[-.48,.08,0]});i.add(s);let r=N(ve(.55,.11,.4,.06),me("#d8c8ff"),{pos:[-.55,.2,0]});i.add(r);let o=N(ze(.2,2),me("#fff8eb"),{pos:[.46,.11,0],scale:[1.1,.4,.85]});i.add(o);for(let m of[-1,1]){let v=[];for(let y=0;y<=20;y++){let w=y/20,M=-1.25+2.5*w,T=.44*Math.pow(Math.sin(Math.PI*(w*.94+.03)),.62)+.015,x=.2+.11*Math.sin(Math.PI*w);v.push(ne(M,x,m*T))}let E=new W(new et(new je(v),40,.028,5),nn("#d9aa6e"));E.castShadow=!0,i.add(E)}for(let m of[-.35,.38]){let v=N(ve(.28,.06,.72,.02),k.wood,{pos:[m,.19,0]});i.add(v)}for(let m=0;m<2;m++){let v=N(Oe(.018,.024,1.45,7),k.wood,{pos:[.02,.24+m*.04,.13-m*.24],rot:[0,Math.PI/2,Math.PI/2],scale:[1,1,1]});v.castShadow=!0,i.add(v);let E=N(ze(.11,1),k.woodPale,{pos:[.72,.24+m*.04,.13-m*.24],scale:[1.8,.35,.8]});i.add(E)}let a=H_(1),l=H_(-1);i.add(a,l);let c=new ce;c.position.set(1.02,.25,0);let h=new W(new et(new je([ne(0,0,0),ne(-.04,.26,.02),ne(.06,.44,.02),ne(.12,.52,0)]),12,.018,5,!1),nn("#efc078"));c.add(h);let u=new ce;u.position.set(.12,.54,0);for(let m=0;m<4;m++){let v=m/4*xe,E=N(Oe(.006,.006,.2,4),k.brass,{pos:[Math.cos(v)*.06,-.1,Math.sin(v)*.06]});u.add(E)}let d=N(new vn(.09,.08,8),k.brassDeep,{pos:[0,0,0]});u.add(d);let f=N(ze(.055,2),new Qe({color:new q("#ffd8a0").multiplyScalar(1.4),toneMapped:!1}),{pos:[0,-.06,0]});u.add(f);let p=pt("gold",1,.28);p.position.y=-.06,u.add(p),c.add(u),i.add(c);let _=new W(new et(new je([ne(-1.2,.19,0),ne(-1.38,.36,.02),ne(-1.32,.58,-.04),ne(-1.16,.68,.03)]),12,.023,4,!1),nn("#efc078"));i.add(_);let g=IT(.075,.014,"#ffdd92");g.position.set(-1.15,.71,.03),g.rotation.y=.3,i.add(g);for(let m=0;m<4;m++){let v=N(ze(.24+m*.05,2),me(m%2?"#ffd7dd":"#fff4e7"),{pos:[-.5+m*.35,-.38,0],scale:[1.3,.6,1]});v.castShadow=!1,i.add(v)}for(let m=0;m<8;m++){let v=pt(m%2?"pink":"gold",.1+.05*(m%2),.25);v.position.set(-.3+m/8*1,.8+Math.sin(m)*.2,.35+m%3*.1),i.add(v)}return{boat:i,wingL:l,wingR:a,glow:p}}function IT(i=.08,e=.018,t="#ffd785"){let n=new kt;for(let r=0;r<10;r++){let o=r*Math.PI/5-Math.PI/2,a=r%2?i*.43:i,l=Math.cos(o)*a,c=Math.sin(o)*a;r===0?n.moveTo(l,c):n.lineTo(l,c)}n.closePath();let s=new en(n,{depth:e,bevelEnabled:!0,bevelSegments:1,steps:1,bevelSize:.006,bevelThickness:.005,curveSegments:2});return new W(s,nn(t))}function DT(){let i=new ce,e=ne(6.25,.33,4.9),t=N(new xn(1,1.12,.13,24),k.deck,{pos:[e.x,e.y,e.z]});t.castShadow=!0,t.receiveShadow=!0,i.add(t);let n=new W(new dt(1,.035,5,32),k.woodDark);n.rotation.x=Math.PI/2,n.position.set(e.x,e.y+.07,e.z),i.add(n);for(let p=0;p<4;p++){let _=p/4*xe+.5,g=N(Oe(.055,.07,.8,7),k.woodDark,{pos:[e.x+Math.cos(_)*.7,e.y-.4,e.z+Math.sin(_)*.7]});i.add(g)}for(let p=0;p<4;p++){let _=.7+p*.42,g=N(Oe(.022,.027,.5,5),k.wood,{pos:[e.x+Math.cos(_)*.94,e.y+.24,e.z+Math.sin(_)*.94]});i.add(g)}let s=[];for(let p=0;p<=8;p++){let _=.7+p/8*1.26;s.push(ne(e.x+Math.cos(_)*.94,e.y+.49,e.z+Math.sin(_)*.94))}let r=new W(new et(new je(s),30,.025,4),k.woodDark);i.add(r);let o=N(Oe(.065,.085,.92,8),k.woodDark,{pos:[e.x+.69,e.y+.38,e.z-.1]});i.add(o);let a=N(new Rt(.095,10,8),k.brass,{pos:[e.x+.69,e.y+.86,e.z-.1],scale:[1,.65,1]});i.add(a);let l=N(Oe(.02,.026,1,6),k.brassDeep,{pos:[e.x-.48,e.y+.46,e.z+.48]});i.add(l);let c=N(ze(.12,2),fn.gold,{pos:[e.x-.48,e.y+.93,e.z+.48]});i.add(c);let h=N(ze(.06,2),new Qe({color:new q("#ffcf8b").multiplyScalar(1.5),toneMapped:!1}),{pos:[e.x-.48,e.y+.93,e.z+.48]});i.add(h);let u=pt("gold",1.4,.22);u.position.set(e.x-.48,e.y+.93,e.z+.48),i.add(u);let d=N(ve(.35,.24,.3,.03),k.wood,{pos:[e.x-.38,e.y+.17,e.z-.25],rot:[0,.4,0]});i.add(d);let f=new W(new dt(.12,.03,5,18),me("#d5ae7f"),{pos:[e.x-.1,e.y+.12,e.z+.33],rot:[Math.PI/2,0,0]});i.add(f);for(let p=0;p<5;p++){let _=N(ze(.35+p*.04,2),me(p%2?"#ffe3e0":"#fff4e8"),{pos:[e.x+(p%3-.5)*.7,-.07-p*.05,e.z+(p%2-.5)*.55],scale:[1.5,.55,1.2]});i.add(_)}return i.position.set(0,0,0),i.userData.center=e,i.userData.moorPos=ne(e.x+.69,e.y+.88,e.z-.1),i}function LT(){let i=new ce;i.name="sky-boardwalk";let e=new je([ne(2.55,2.74,1.02),ne(3.22,2.61,1.62),ne(3.92,2.33,2.4),ne(4.67,1.86,3.18),ne(5.38,1.25,3.86),ne(5.96,.62,4.46)]),t=24,s=e.getLength()/t,r=new En(new mi(1.06,.075,s*.92),k.deck,t);r.castShadow=!0,r.receiveShadow=!0,r.instanceMatrix.setUsage($s);let o=new _t,a=new A(0,1,0),l=new A,c=new A,h=new A,u=[];for(let m=0;m<t;m++){let v=(m+.5)/t,E=e.getPointAt(v);e.getTangentAt(v,c),l.crossVectors(c,a).normalize(),h.crossVectors(l,c).normalize();let y=new nt;y.makeBasis(l,h,c.clone().normalize()),o.position.copy(E).addScaledVector(h,.035),o.quaternion.setFromRotationMatrix(y),o.scale.set(1,1,1),o.updateMatrix(),r.setMatrixAt(m,o.matrix),u.push({p:E.clone(),side:l.clone(),normal:h.clone(),t:v})}r.instanceMatrix.needsUpdate=!0,i.add(r);for(let m of[-.34,.34]){let v=[];for(let y=0;y<=20;y++){let w=y/20,M=e.getPointAt(w),T=e.getTangentAt(w),x=new A().crossVectors(T,a).normalize();v.push(M.clone().addScaledVector(x,m).addScaledVector(a,-.075))}let E=new W(new et(new je(v),40,.045,5),k.woodDark);E.castShadow=!0,i.add(E)}let d=.58,f=[];for(let m=1;m<t;m+=3){let v=m/t,E=e.getPointAt(v),y=e.getTangentAt(v),w=new A().crossVectors(y,a).normalize(),M=E.clone().addScaledVector(w,d),T=.58,x=N(ve(.055,T,.055,.014),k.woodDark,{pos:[M.x,M.y+T/2,M.z],rot:[0,Math.atan2(y.x,y.z),0]});if(i.add(x),f.push(M),m===10||m===19){let S=N(ze(.095,2),fn.gold,{pos:[M.x,M.y+T+.08,M.z]});i.add(S);let C=pt("gold",1.1,.18);C.position.set(M.x,M.y+T+.08,M.z),i.add(C)}}for(let m of[.58,.3]){let v=[];for(let y=0;y<=22;y++){let w=y/22,M=e.getPointAt(w),T=e.getTangentAt(w),x=new A().crossVectors(T,a).normalize(),S=M.clone().addScaledVector(x,d).addScaledVector(a,m);v.push(S)}let E=new W(new et(new je(v),50,m>.5?.025:.014,4),k.wood);i.add(E)}for(let m=0;m<6;m++){let v=(m+1)/7,E=e.getPointAt(v);for(let y=0;y<2;y++){let w=N(ze(.28+m%3*.1,2),me(m%2?"#ffe0dc":"#fff3e9"),{pos:[E.x+(y?.25:-.25),E.y-.28-.07*y,E.z+(y?.1:-.2)],scale:[1.3,.48,1.1]});w.castShadow=!1,i.add(w)}}let p=e.getPointAt(.03),_=N(Oe(.035,.045,.5,6),k.woodDark,{pos:[p.x-.5,p.y+.25,p.z+.15]});i.add(_);let g=new W(new cn(.28,.16),new Qe({color:"#ffd0dc",side:De,transparent:!0,opacity:.85,toneMapped:!1}));return g.position.set(p.x-.34,p.y+.43,p.z+.15),i.add(g),{group:i,curve:e,positions:u}}function z_(){let i=new ce;i.name="cloud-boat-and-boardwalk";let e=LT();i.add(e.group);let t=DT();i.add(t);let{boat:n,wingL:s,wingR:r,glow:o}=PT();i.add(n),n.updateMatrixWorld(!0);let a=n.localToWorld(ne(1.14,.24,0)),l=t.userData.moorPos,c=a.clone().add(l).multiplyScalar(.5);c.y=Math.min(a.y,l.y)-.22;let h=new W(new et(new je([a,c,l]),24,.012,4,!1),me("#bf956b"));i.add(h);let u=[];for(let m=0;m<3;m++){let v=new W(new vs(.95,1,64),new Qe({color:"#fff2da",transparent:!0,opacity:.14,side:De,depthWrite:!1,blending:wt,toneMapped:!1}));v.rotation.x=-Math.PI/2,v.position.set(7.35,.225,5.55),v.scale.set(1.3+m*.26,.65+m*.16,1),v.userData.phase=m*1.3,i.add(v),u.push(v)}let d=n.position.y,f=n.rotation.z,p=s.rotation.x,_=r.rotation.x;function g(m){n.position.y=d+Math.sin(m*.55)*.025,n.rotation.z=f+Math.sin(m*.42)*.009,n.rotation.x=Math.sin(m*.36+1)*.008,s.rotation.x=p+Math.sin(m*.32)*.018,r.rotation.x=_-Math.sin(m*.32+.4)*.018,u.forEach((v,E)=>{let y=(m*.09+E*.33)%1;v.scale.set(1.15+y*.9,.58+y*.45,1),v.material.opacity=.12*(1-y)})}return{group:i,update:g,boat:n,dock:t,walk:e}}var NT=`
  varying vec2 vUv;
  varying vec3 vWorld;
  void main(){
    vUv = uv;
    vec4 wp = modelMatrix * vec4(position,1.0);
    vWorld = wp.xyz;
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`,UT=`
  uniform float uTime;
  uniform vec3 uA,uB,uC;
  varying vec2 vUv;
  varying vec3 vWorld;

  void main(){
    vec2 p = vUv - .5;
    float r = length(p);
    float ang = atan(p.y,p.x);
    float swirl = sin(ang*3.0 + r*22.0 - uTime*.7) * .5 + .5;
    float swirl2 = sin(ang*5.0 - r*16.0 + uTime*.42) * .5 + .5;
    vec3 col = mix(uA,uB, swirl*.7 + .05);
    col = mix(col,uC, smoothstep(.65,1.0,swirl2)*.65);
    col += uC * .07;
    // broad creamy reflections
    float shine = smoothstep(.55,.9, swirl2) * smoothstep(.0,.35,.42-r);
    col += vec3(1.0,.94,.82) * shine * .25;
    // golden bubble flowers
    float fleck = smoothstep(.92,1.0, sin(ang*12.0 + r*70.0 - uTime*1.8)*.5+.5)
               * smoothstep(.0,.28,.44-r);
    col += vec3(1.0,.92,.72)*fleck*.7;
    // darkened rim so the liquid sits inside the barrel
    col *= .83 + .17*smoothstep(.5,.42,r);
    gl_FragColor = vec4(col,1.0);
  }
`;function FT(i,e){let t=new xt({uniforms:{uTime:{value:0},uA:{value:new q(i[0])},uB:{value:new q(i[1])},uC:{value:new q(i[2])}},vertexShader:NT,fragmentShader:UT}),n=new W(new oi(e,48),t);return n.rotation.x=-Math.PI/2,n.position.y=.54,n}function k_({x:i,y:e,z:t,scale:n=1,colors:s,seed:r=1}){let o=new ce;o.position.set(i,e,t),o.scale.setScalar(n),o.userData={seed:r};let a=ft(r);for(let M=0;M<5;M++){let T=N(ze(.3,2),me(M%2?"#ffe2dd":"#fff4e9"),{pos:[(M%3-.5)*.45,-.08,(M%2-.5)*.35],scale:[1.4,.35,1.05]});T.castShadow=!1,o.add(T)}let l=new W(new Oi([new J(.31,0),new J(.38,.04),new J(.47,.2),new J(.49,.42),new J(.46,.55),new J(.42,.6)],24),new Ht({color:"#fff2dd",map:Pt.wood,gradientMap:Zt}));l.castShadow=!0,l.receiveShadow=!0,o.add(l);for(let M=0;M<14;M++){let T=M/14*xe,x=N(ve(.032,.52,.055,.012),k.woodWarm,{pos:[Math.cos(T)*.473,.3,Math.sin(T)*.473],rot:[0,-T,.015]});x.castShadow=!1,o.add(x)}for(let M of[.14,.47]){let T=new W(new dt(.473,.022,5,36),k.brass);T.rotation.x=Math.PI/2,T.position.y=M,o.add(T)}let c=new W(new dt(.425,.038,6,36),k.brassDeep);c.rotation.x=Math.PI/2,c.position.y=.595,o.add(c);let h=new W(new xn(.4,.37,.06,24,1,!0),k.woodDark);h.position.y=.56,o.add(h);let u=FT(s,.42);u.position.y=.615,o.add(u);let d=pt(s[2]==="#ffd15b"?"gold":"pink",2.7,.4);d.position.y=.62,o.add(d);for(let M=0;M<5;M++){let T=pt(M%2?"pink":"gold",1+M*.25,.16);T.position.set(Math.cos(M*1.6)*.3,.82+M*.08,Math.sin(M*1.6)*.3),o.add(T)}let f=new Yt(s[1],1.6,3,2);f.position.set(0,.9,0),o.add(f);for(let M=0;M<9;M++){let T=a()*xe,x=a()*.3,S=N(new Rt(.026+a()*.055,10,8),new hn({color:"#ffffff",transparent:!0,opacity:.36,roughness:.02,metalness:0,clearcoat:1,iridescence:1,iridescenceIOR:1.35,envMapIntensity:1.8,depthWrite:!1,side:De}),{pos:[Math.cos(T)*x,.6+a()*.03,Math.sin(T)*x],scale:[1,.7,1]});S.castShadow=!1,o.add(S)}for(let M=0;M<2;M++){let T=.4+M*2.4,x=new W(new et(new je([ne(Math.cos(T)*.44,.55,Math.sin(T)*.44),ne(Math.cos(T)*.47,.38,Math.sin(T)*.47),ne(Math.cos(T)*.46,.22,Math.sin(T)*.46)]),8,.017,4,!1),Yn(s[1],.8,.8));x.castShadow=!1,o.add(x)}let p=new ce;p.rotation.z=.36,p.rotation.y=-.4;let _=N(Oe(.023,.028,1.15,7),k.wood,{pos:[0,.55,0]});p.add(_);let g=N(ve(.17,.26,.035,.02),k.woodWarm,{pos:[0,-.05,0]});p.add(g),p.position.set(.18,.05,.08),o.add(p);let m=N(Oe(.035,.045,.12,8),k.brass,{pos:[.38,.14,.27],rot:[0,0,Math.PI/2]});o.add(m);let v=N(new dt(.055,.012,4,12,Math.PI),k.brass,{pos:[.46,.18,.27],rot:[0,0,Math.PI/2]});o.add(v);let E=[];for(let M=0;M<7;M++){let T=pt(M%2?"pink":"gold",.18,0);T.position.set((a()-.5)*.4,.7,(a()-.5)*.4),T.userData={phase:a()*xe,base:T.position.clone()},o.add(T),E.push(T)}for(let M=0;M<3;M++){let T=M/3*xe,x=N(ze(.035,1),fn.gold,{pos:[Math.cos(T)*.23,.62,Math.sin(T)*.23]});x.castShadow=!1,o.add(x)}let y=new A(i,e+.62*n,t);return{group:o,update:M=>{u.material.uniforms.uTime.value=M,E.forEach((T,x)=>{let S=(M*.11+x/7*.7)%1;T.position.x=T.userData.base.x+Math.sin(M*.5+x)*.08+S*.1,T.position.y=.68+S*.65,T.position.z=T.userData.base.z+Math.cos(M*.4+x)*.06,T.material.opacity=.12*Math.sin(Math.min(1,S)*Math.PI),T.scale.setScalar(.15+S*.25)})},source:y}}function G_(i,e,t,n=1,s=3,r=null){let o=new ce;o.position.set(i,e,t),o.scale.setScalar(n);let a=new W(new Oi([new J(.22,0),new J(.25,.01),new J(.33,.12),new J(.4,.3),new J(.42,.36)],24),new Ht({color:"#ffffff",map:Pt.basket,gradientMap:Zt}));a.material.side=De,a.castShadow=!0,a.receiveShadow=!0,o.add(a);let l=new W(new dt(.42,.035,5,28),k.woodWarm);l.rotation.x=Math.PI/2,l.position.y=.35,o.add(l);for(let f of[-1,1]){let p=new W(new dt(.37,.023,5,28,Math.PI),k.woodWarm);p.position.set(0,.34,0),p.rotation.x=-.12,p.rotation.z=f>0?0:Math.PI,p.rotation.y=0,o.add(p);break}let c=ft(s),h=r||["#ffc6d7","#ffe0a3","#c9b8ff","#b8ebdf","#fff0dc","#ffd2b5"];for(let f=0;f<11;f++){let p=c()*xe,_=c()*.26,g=N(ze(.11+c()*.1,2),me(h[f%h.length]),{pos:[Math.cos(p)*_,.42+c()*.2,Math.sin(p)*_],scale:[1.15,.8,1],rot:[0,c()*xe,c()*.2]});g.castShadow=!0,o.add(g)}let u=N(Oe(.006,.006,.4,4),k.brass,{pos:[.18,.55,.18],rot:[0,0,-.75]});o.add(u);let d=N(new dt(.18,.018,4,12,Math.PI*1.3),me("#ffc9d7"),{pos:[.32,.42,-.08],rot:[.4,.2,.2]});return o.add(d),o}function V_(){let i=new ce;i.name="cloud-dye-vats";let e=[],t=[],n=k_({x:-2.82,y:2.79,z:2.56,scale:1.15,seed:12,colors:["#ff78ad","#b18cff","#ffd164"]});i.add(n.group),e.push(n.update),t.push(n.source);let s=k_({x:2.56,y:2.78,z:2.52,scale:.92,seed:22,colors:["#72d9df","#b995ff","#ffc8db"]});i.add(s.group),e.push(s.update),t.push(s.source);let r=G_(-1.48,2.8,2.4,1.04,3);i.add(r);let o=G_(-4.6,.44,8.7,1.12,8,["#ffb7d0","#d2c0ff","#9fe6db","#ffe09a"]);i.add(o);for(let d=0;d<3;d++){let f=N(ze(.22+d*.05,2),me(d%2?"#fff2e7":"#ffd9dc",{emissive:"#ffc5b8",emissiveIntensity:.05}),{pos:[-4.6+(d%2-.5)*.4,.34+d*.02,8.7+(d%3-1)*.25],scale:[1.5,.4,1.2]});i.add(f)}let a=new ce;a.position.set(2.35,2.79,-1.15);let l=N(ve(.62,.32,.46,.04),k.woodDark,{pos:[0,.16,0]});a.add(l);for(let d=0;d<5;d++){let f=N(Oe(.07,.07,.52,10),me(["#ffbfd2","#cbb7ff","#ffd48b","#a8e6dc","#ffc9b0"][d]),{pos:[-.24+d*.12,.36,.04],rot:[Math.PI/2,0,0]});a.add(f)}let c=N(new cn(.7,.4,8,6),new Ht({color:"#ffd8c7",map:Pt.rug,gradientMap:Zt,side:De}),{pos:[0,.33,-.23],rot:[.2,0,.1]});a.add(c),i.add(a);let h=new Qe({color:"#634956",transparent:!0,opacity:.18,depthWrite:!1});for(let[d,f,p,_]of[[-2.82,2.56,.9,.8],[2.56,2.52,.75,.65],[-1.48,2.4,.7,.55]]){let g=new W(new oi(1,32),h);g.rotation.x=-Math.PI/2,g.scale.set(p,_,1),g.position.set(d,2.805,f),i.add(g)}function u(d){e.forEach(f=>f(d))}return{group:i,update:u,sources:t}}function BT(){let i=new ce;i.name="wildflower-meadow";let e=ft(992),t=new vn(.014,.16,3);t.translate(0,.08,0);let n=new En(t,me("#a8d8b8"),90),s=new Tn(.035,1),r=new En(s,new Ht({color:"#ffffff",gradientMap:Zt}),70),o=new En(new Tn(.012,1),k.brass,70),a=new _t,l=["#ffc3d8","#fff1d0","#d9c5ff","#ffd7a6","#d5f1e4"],c=new q,h=0,u=0;function d(p,_,g,m=1,v=0){h>=90||(a.position.set(p,_,g),a.rotation.set((e()-.5)*.2,v,(e()-.5)*.25),a.scale.set(.8+e()*.7,m,1),a.updateMatrix(),n.setMatrixAt(h++,a.matrix))}function f(p,_,g,m=1){u>=70||(a.position.set(p,_,g),a.rotation.set(0,e()*xe,0),a.scale.setScalar(m),a.updateMatrix(),r.setMatrixAt(u,a.matrix),c.set(l[u%l.length]),r.setColorAt(u,c),a.position.set(p,_+.005,g),a.scale.setScalar(.7),a.updateMatrix(),o.setMatrixAt(u,a.matrix),u++)}for(let p=0;p<85;p++){let _=e()*xe,g=.88+e()*.1,m=Math.cos(_)*3.28*g,v=Math.sin(_)*2.58*g+.08;Math.abs(m)<2.93&&v>-1.98&&v<2.36||(d(m,2.715,v,.6+e()*.65,_),e()<.64&&f(m,2.84,v,.48+e()*.5))}for(let p=0;p<60;p++){let _=e()*xe,g=8.95+e()*.75,m=Math.cos(_)*g,v=Math.sin(_)*g;Math.abs(m)>9.85||Math.abs(v)>9.85||(d(m,.31+e()*.12,v,.45+e()*.4,_),e()<.5&&f(m,.43+e()*.1,v,.32+e()*.4))}return d(-1.26,2.73,2.42,.55,.3),d(1.46,2.73,2.36,.6,-.4),f(1.1,2.87,2.44,.6),f(-.92,2.86,2.47,.5),n.instanceMatrix.needsUpdate=!0,r.instanceMatrix.needsUpdate=!0,o.instanceMatrix.needsUpdate=!0,n.castShadow=!0,r.castShadow=!0,o.castShadow=!1,n.frustumCulled=!1,r.frustumCulled=!1,o.frustumCulled=!1,i.add(n,r,o),i}function OT(i,e,t=.27,n=1,s=1){let r=new ce;r.position.set(i,t,e),r.scale.setScalar(n);let o=ft(s),a=me(o()<.5?"#a9dfc9":"#c7e8ce",{side:De});for(let u=0;u<3;u++){let d=N(new oi(.24,16,.22,Math.PI*1.72),a,{pos:[u*.17-.17,.006*u,u*.08],rot:[-Math.PI/2,0,o()*xe]});d.castShadow=!1,r.add(d)}let l=new ce;l.position.y=.035;let c=N(ze(.05,2),fn.gold,{pos:[0,.03,0]});l.add(c);for(let u=0;u<6;u++){let d=u/6*xe,f=N(new Rt(.075,10,6,0,Math.PI*2,0,Math.PI/2),me(["#ffe3ec","#fff0d1","#e1d1ff"][u%3]),{pos:[Math.cos(d)*.075,0,Math.sin(d)*.075],scale:[1,.42,.65],rot:[.25,-d,.25]});l.add(f)}let h=pt("gold",.45,.16);return h.position.y=.12,l.add(h),r.add(l),r}function W_(){let i=new ce;i.name="flora",i.add(BT());let e=[[-6.8,4.4,.42,11],[7.5,-3.9,.36,12],[3.3,6.4,.32,13],[-3.7,6.6,.38,14],[5.2,-5.6,.3,15],[-7.55,.3,.3,16],[7.55,2.2,.26,17],[-5.2,-6.1,.28,18]];for(let[a,l,c,h]of e)i.add(OT(a,l,.365,c,h));let t=ft(147),n=me("#ffd6df",{side:De});for(let a=0;a<28;a++){let l=t()*xe,c=4.6+t()*3.1,h=Math.cos(l)*c,u=Math.sin(l)*c;if(Math.abs(h)<3.2&&Math.abs(u)<3)continue;let d=N(new oi(.05+t()*.06,7),n,{pos:[h,.365,u],rot:[-Math.PI/2,0,t()*xe],scale:[1.4,.4,1]});d.castShadow=!1,i.add(d)}let s=new ce;for(let a=0;a<8;a++){let l=t()*xe,c=9.8+t()*2.5,h=N(ze(.2+t()*.28,2),me(a%2?"#ffe1e2":"#fff4e9"),{pos:[Math.cos(l)*c,-.35+t()*4.4,Math.sin(l)*c],scale:[1.3,.5,1]});h.castShadow=!1,s.add(h)}i.add(s);let r=s.children.map(a=>a.position.clone());function o(a){s.children.forEach((l,c)=>{l.position.y=r[c].y+Math.sin(a*.16+c*1.8)*.15,l.position.x=r[c].x+Math.cos(a*.11+c)*.08})}return{group:i,update:o}}var q_=document.getElementById("stage"),ei=new Dc({canvas:q_,antialias:!0,alpha:!1,powerPreference:"high-performance"}),Z_=1.5;ei.setPixelRatio(Math.min(window.devicePixelRatio||1,Z_));ei.setSize(window.innerWidth,window.innerHeight);ei.outputColorSpace=Wt;ei.toneMapping=Js;ei.toneMappingExposure=.98;ei.shadowMap.enabled=!1;var Nn=new yr,ga=new on(35,window.innerWidth/window.innerHeight,.1,220),J_=new A(17.4,8.15,28.1),K_=new A(0,2.72,.12);ga.position.copy(J_);var gd=l_(Nn,ei),$_=new Rr("#ffeadb","#9b9ed0",.64);Nn.add($_);var qn=new Ms("#ffe0b7",1.5);qn.position.set(8.5,18.5,12);qn.target.position.set(0,2.5,0);qn.castShadow=!0;qn.shadow.mapSize.set(2048,2048);qn.shadow.camera.left=-14;qn.shadow.camera.right=14;qn.shadow.camera.top=14;qn.shadow.camera.bottom=-14;qn.shadow.camera.near=2;qn.shadow.camera.far=55;qn.shadow.bias=-4e-4;qn.shadow.normalBias=.035;qn.shadow.radius=4.5;Nn.add(qn,qn.target);var Gp=new Ms("#b9c9ff",.38);Gp.position.set(-12,7,10);Nn.add(Gp);var Vp=new Ms("#ffb98b",.46);Vp.position.set(-9,10,-14);Nn.add(Vp);var Wp=new Yt("#ffad91",3,13,2);Wp.position.set(-2.2,-1.65,-.6);Nn.add(Wp);var Xp=new Yt("#ffd0ac",2,12,2);Xp.position.set(5.2,-2.1,3.6);Nn.add(Xp);var Yp=new Yt("#ffc58d",3.1,5.5,2);Yp.position.set(-7.1,4,-3.6);Nn.add(Yp);var qp=p_();Nn.add(qp.group);var _a=y_();Nn.add(_a.group);var xa=P_();xa.group.position.set(-.05,Vr,.18);_a.group.add(xa.group);var j_=L_(xa.silkAnchors);xa.group.add(j_.group);var _d=V_();_a.group.add(_d.group);var Zp=z_();_a.group.add(Zp.group);var Jp=O_();Nn.add(Jp.group);var Kp=B_();Nn.add(Kp.group);var $p=W_();Nn.add($p.group);var jp=N_(_d.sources,112);Nn.add(jp.group);var Qp=new ce,HT=gd.dust.material.map,Hc=(()=>{let i=123456789;return()=>(i^=i<<13,i^=i>>>17,i^=i<<5,(i>>>0)/4294967296)})();for(let i=0;i<26;i++){let e=new ln({map:HT,color:i%2?"#ffe4b4":"#ffd2e0",transparent:!0,opacity:.22,depthWrite:!1,blending:wt,toneMapped:!1}),t=new Dn(e);t.position.set((Hc()-.5)*24,-1+Hc()*12,(Hc()-.5)*24),t.scale.setScalar(.15+Hc()*.25),t.userData={base:t.position.clone(),phase:Hc()*7},Qp.add(t)}Nn.add(Qp);Nn.add((()=>{let i=new Dn(new ln({map:gd.dust.material.map,color:"#ffd5b1",transparent:!0,opacity:.16,depthWrite:!1,blending:wt,toneMapped:!1}));return i.position.set(-1.5,Vr+.12,2.2),i.scale.set(6,2.3,1),i})());var hi=new sd(ga,ei.domElement);hi.target.copy(K_);hi.enableDamping=!0;hi.dampingFactor=.055;hi.enablePan=!1;hi.minDistance=13.5;hi.maxDistance=48;hi.minPolarAngle=.28;hi.maxPolarAngle=Math.PI*.488;hi.rotateSpeed=.62;hi.zoomSpeed=.7;hi.autoRotate=!1;hi.update();var ss,md;function zT(){let i=ei.getDrawingBufferSize(new J),e=new Qt(i.x,i.y,{type:yn,samples:2});ss=new ad(ei,e),ss.setPixelRatio(ei.getPixelRatio()),ss.setSize(window.innerWidth,window.innerHeight);let t=new ld(Nn,ga);ss.addPass(t),md=new da(new J(window.innerWidth,window.innerHeight),.14,.38,1.08),ss.addPass(md);let n=new cd;ss.addPass(n)}zT();window.__dream={THREE:Xn,scene:Nn,camera:ga,renderer:ei,controls:hi,composer:ss,bloomPass:md,sky:gd,base:qp,whale:_a,atelier:xa,jellies:Kp,wishingTree:Jp,dockAndBoat:Zp,vats:_d,flora:$p,bubbles:jp,lights:{hemi:$_,key:qn,fill:Gp,rim:Vp,underA:Wp,underB:Xp,treeLight:Yp},home:J_.clone(),look:K_.clone()};function kT(){let i=window.innerWidth,e=window.innerHeight;ga.aspect=i/e,ga.updateProjectionMatrix(),ei.setSize(i,e),ei.setPixelRatio(Math.min(window.devicePixelRatio||1,Z_)),ss.setPixelRatio(ei.getPixelRatio()),ss.setSize(i,e),md?.setSize(i,e)}window.addEventListener("resize",kT,{passive:!0});var X_=0,Y_=!0,kp=performance.now();function Q_(i=performance.now()){requestAnimationFrame(Q_);let e=Math.min((i-kp)/1e3,.05);kp=i,X_+=e;let t=X_;gd.update(t),qp.update(t),_a.update(t),xa.update(t),j_.update(t),_d.update(t),Zp.update(t),Jp.update(t),Kp.update(t),$p.update(t),jp.update(t),Qp.children.forEach((n,s)=>{n.position.y=n.userData.base.y+Math.sin(t*.18+n.userData.phase)*.45,n.position.x=n.userData.base.x+Math.cos(t*.12+n.userData.phase)*.25,n.material.opacity=.1+.13*(.5+.5*Math.sin(t*.5+s))}),hi.update(),ss.render(),Y_&&(Y_=!1,q_.classList.add("is-ready"),document.documentElement.classList.add("ready"))}requestAnimationFrame(Q_);document.addEventListener("visibilitychange",()=>{kp=performance.now()});})();
